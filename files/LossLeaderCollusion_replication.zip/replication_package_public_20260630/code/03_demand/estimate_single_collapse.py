#!/usr/bin/env python3
"""Estimate a SINGLE post-ban collapse from the demand, two forms (not an imposed multiply):
  PROPORTIONAL: alpha_post_j = kappa * alpha_pre_j     -> estimate kappa
  ADDITIVE:     alpha_post_j = alpha_pre_j - delta     -> estimate delta
Per-drug pre alpha_j (rival-IV) is the offset; the single collapse is estimated by cost-IV 2SLS on
cartel-excluded ads-banned weeks (the same valid window as Panel A). FirmDrug-demeaned."""
import os, sys, pickle
import numpy as np, pandas as pd
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import demand as D
from per_drug_post_costiv import SIG, N, CARTEL0, CARTEL1
cfg=D.CONFIG; df,meta=D.build_panel(cfg)
dobj=pickle.load(open(os.path.join(D.DATA,"data_objects.pkl"),"rb"))
dates=pd.to_datetime(pd.Series(meta["dates"]).values)
cost=dobj["cost_sb"].iloc[:,:N].copy()/1000.0; cost.index=pd.to_datetime(cost.index)
costmat=cost.reindex(dates).values
df=df[df.DrugID<N].copy(); df["cost"]=costmat[df.TimeID.values,df.DrugID.values]
df["Y_adj"]=df.Y-SIG*df.LogShareGroup
cartel=set(np.where((dates>=pd.Timestamp(CARTEL0))&(dates<=pd.Timestamp(CARTEL1)))[0])
post=df[(df.AdBan==1)&(~df.TimeID.isin(cartel))&df.cost.notna()].dropna(subset=["Y_adj","Price","cost","rival1","rival2"]).copy()
post["FirmDrug"]=post.Firm.astype(str)+"_"+post.DrugID.astype(str)
apre=pd.read_csv(os.path.join(D.OUT,"r2_demand_alpha_per_drug.csv")).set_index("DrugID").alpha
post["apre"]=post.DrugID.map(apre); post=post.dropna(subset=["apre"])
dd=D.within_demean(post,["Y_adj","Price","cost","rival1","rival2"],"FirmDrug")
Y=dd["Y_adj"].values.ravel(); P=dd["Price"].values.ravel(); a=post["apre"].values.ravel()
Zc=np.column_stack([dd["cost"].values.ravel(),dd["rival1"].values.ravel(),dd["rival2"].values.ravel()])
def tsls(Y,X,Z):
    ZtZi=np.linalg.inv(Z.T@Z); Xh=Z@(ZtZi@(Z.T@X)); b=float((Xh.T@Y)/(Xh.T@X))
    e=Y-X.ravel()*b; n=len(Y); xx=float(Xh.T@X); se=np.sqrt(float((e@e)/(n-1))/xx) if xx>0 else np.nan
    return b,se
# PROPORTIONAL: Y = -kappa*(apre*P); X=apre*P, IV=apre*Zc
Xk=(a*P).reshape(-1,1); Zk=a[:,None]*Zc
bk,sek=tsls(Y,Xk,Zk); kappa=-bk
# ADDITIVE: r = Y + apre*P = delta*P; regress r on P, IV=Zc
r=(Y+a*P)
bd,sed=tsls(r,P.reshape(-1,1),Zc); delta=bd
print(f"PROPORTIONAL  kappa_hat = {kappa:.4f}  (SE {sek:.4f})   [pooled ratio 0.286]")
print(f"   -> post = kappa*pre: median {kappa*float(np.median(apre)):.4f}")
print(f"ADDITIVE      delta_hat = {delta:.4f}  (SE {sed:.4f})   [pooled diff 0.074]")
print(f"   -> post = pre-delta: median {float(np.median(apre))-delta:.4f}  (Table 5 all-drug 0.029)")
import json; json.dump({"kappa":kappa,"kappa_se":sek,"delta":delta,"delta_se":sed,"pre_median":float(np.median(apre))},open(os.path.join(D.OUT,"single_collapse.json"),"w"),indent=2)
print("wrote output/single_collapse.json")
