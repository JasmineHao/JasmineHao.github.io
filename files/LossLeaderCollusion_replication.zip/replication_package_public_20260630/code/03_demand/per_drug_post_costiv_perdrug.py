#!/usr/bin/env python3
"""Per-drug post-ban alpha via cost-IV with POOLED fallback (Q1/Q2 fix, 2026-06-23).
Pre alpha_j (rival-IV) UNCHANGED; post re-identified per drug with the SB cost instrument on
cartel-excluded ads-banned weeks. Drugs with a weak/wrong-signed/thin cost IV fall back to the
pooled cost-IV post (~0.029). Writes a NEW csv for review (does not overwrite canonical)."""
import os, sys, pickle
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import demand as D
from per_drug_post_costiv import costiv, SIG, N, CARTEL0, CARTEL1
F_MIN, NMIN = 10.0, 30
cfg = D.CONFIG; df, meta = D.build_panel(cfg)
dobj = pickle.load(open(os.path.join(D.DATA, "data_objects.pkl"), "rb"))
dates = pd.to_datetime(pd.Series(meta["dates"]).values)
cost = dobj["cost_sb"].iloc[:, :N].copy() / 1000.0; cost.index = pd.to_datetime(cost.index)
costmat = cost.reindex(dates).values
df = df[df.DrugID < N].copy(); df["cost"] = costmat[df.TimeID.values, df.DrugID.values]
df["Y_adj"] = df.Y - SIG * df.LogShareGroup
cartel = set(np.where((dates >= pd.Timestamp(CARTEL0)) & (dates <= pd.Timestamp(CARTEL1)))[0])
post = df[(df.AdBan == 1) & (~df.TimeID.isin(cartel)) & df.cost.notna()]
post = post.dropna(subset=["Y_adj","Price","cost","rival1","rival2"]).copy()
post["FirmDrug"] = post.Firm.astype(str) + "_" + post.DrugID.astype(str)
a_pool, F_pool, n_pool = costiv(post)
print(f"pooled cost-IV post (fallback) = {a_pool:.4f}  (F={F_pool:.0f}, n={n_pool:,})")
canon = pd.read_csv(os.path.join(D.OUT, "r2_demand_alpha_per_drug.csv"))
pc, src = {}, {}
for j, sub in post.groupby("DrugID"):
    a, F, n = costiv(sub) if len(sub) >= NMIN else (np.nan, np.nan, len(sub))
    if np.isfinite(a) and a > 1e-3 and np.isfinite(F) and F >= F_MIN:
        pc[j], src[j] = a, "costiv"
    else:
        pc[j], src[j] = a_pool, "pooled"
canon["alpha_post"] = canon.DrugID.map(pc).fillna(a_pool)
canon["post_src"] = canon.DrugID.map(src).fillna("pooled")
canon["delta"] = canon.alpha_post - canon.alpha
pre, po = canon.alpha, canon.alpha_post
print(f"median pre {pre.median():.4f}  median post {po.median():.4f}   (Table 5: 0.130 / 0.029)")
print(f"mean   pre {pre.mean():.4f}  mean   post {po.mean():.4f}")
print(f"cost-IV identified: {(canon.post_src=='costiv').sum()}  | pooled fallback: {(canon.post_src=='pooled').sum()}")
canon.to_csv(os.path.join(D.OUT, "r2_demand_alpha_per_drug_costivpost.csv"), index=False)
print("wrote output/r2_demand_alpha_per_drug_costivpost.csv (review)")
