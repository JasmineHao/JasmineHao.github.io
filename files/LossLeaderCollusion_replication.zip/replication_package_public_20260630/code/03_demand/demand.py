"""demand.py -- Canonical nested-logit demand estimation.

This is the one demand script.  It estimates the nested-logit demand the structural
model (code/06_dynamic_final/full_structural_mpe.py) consumes, and emits every statistic,
diagnostic, goodness-of-fit measure, and per-drug elasticity in a single run.

To make a VARIATION (different sigma rule, IV set, sample window, panel frequency,
fallback policy, market-size calibration), edit the CONFIG block below and re-run --
all outputs regenerate consistently from this one file.  This is the prototype; the
previous per-task demand scripts (1_1 .. 1_13, per_product_alpha) are archived.

----------------------------------------------------------------------------------
Model.  Three chains i in {CV,FA,SB} sell drug j.  Berry (1994) inversion gives
    Y_ijt = log s_ijt - log s_0jt
          = -alpha * p_ijt + sigma * log s_{i|jt} + xi_ijt,
with within-group share s_{i|jt}.  Both p and log s_{i|j} are endogenous.

Estimation:
  Step 1 (headline): weekly IVGMM with a FirmxDrug within-transform identifies the
     pooled pre-ban (alpha0, sigma) using Salcobrand cost shifters and rival-chain
     prices.  Post-ban alpha is estimated on cartel-excluded ads-banned weeks with
     sigma fixed at the pre-ban value.
  Step 2 (per-drug): with sigma fixed, a per-drug 2SLS on the cartel-excluded daily
     panel recovers each pre-ban alpha_j using rival-price IVs.  The structural model
     consumes these pre-ban alpha_j and the pooled collapse alpha_post/alpha0.
  Post-ban per-drug checks: companion scripts recompute the post-ban table columns
     with Salcobrand cost IVs; these do not overwrite the structural input.
  Elasticities: pre-ban elasticities use each drug's alpha_j; post-ban elasticities
     use the collapsed sensitivity alpha_j * (alpha_post/alpha0), evaluated at
     post-ban prices and shares.

Outputs (the canonical set; structural model + paper read these):
  output/demand_params.json            headline (sigma,alpha0,alpha_post,OM,A_RATIO) +
                                        per-type params + all diagnostics + the CONFIG
  output/r2_demand_alpha_per_drug.csv   per-drug alpha_j, delta_j, t, elasticities  <-- STRUCTURAL INPUT
  output/r2_demand_type_params.csv      per-type sigma_g, alpha_g, F, J, admissible
  output/r2_demand_gof.csv              goodness-of-fit (headline fit + share fit by regime)
"""
from __future__ import annotations
import os, sys, json, pickle, warnings
import numpy as np
import pandas as pd
from linearmodels.iv import IVGMM

warnings.filterwarnings("ignore")

# ================================================================== #
# CONFIG -- the only thing you edit to make a variation               #
# ================================================================== #
CONFIG = dict(
    frequency        = "daily",        # "daily" | "weekly"  (daily -> stronger first stage)
    sigma_mode       = "pooled",       # "per_type" | "pooled" | "free"  (sigma_g source for Step 2)
                                       # pooled: the heterogeneous (per-drug) demand uses ONE sigma
                                       # (pre-ban Model B, 0.393) for every drug, not a per-type sigma_g
    sigma_pooled     = 0.393,          # pooled / fallback sigma (pre-ban Model B)
    headline_sigma_override = None,    # None -> use pooled estimate; set a float (e.g. 0.393)
                                       # to PIN the sigma the structural model reads (OM=1-sigma)
    instruments      = ["rival1", "rival2"],   # Hausman rival-chain prices
    sigma_window     = "preban",       # window identifying sigma in Step 1
    wrong_sign_fallback = True,        # alpha_j<=0 -> type alpha_g
    chain_mkt_share  = 0.92,           # rho: three-chain share of pharmacy sales (FNE 2008)
    market_size_mult = 7.0,            # peak-daily -> weekly-equivalent potential market
    adban_date       = "2007-09-04",   # CONAR 704/07
    abn_price_thresh = 3.0,
    abn_qty_window   = 7,
    min_obs_drug     = 30,
    min_obs_type     = 100,
)

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
DATA = os.path.join(ROOT, "data", "processed")
OUT  = os.path.join(ROOT, "output")
sys.path.insert(0, os.path.join(ROOT, "code", "shared"))
from EmpiricalDataHandling import correct_abnormal_prices, correct_abnormal_quantities


# ---------------------------------------------------------------- helpers
def within_demean(df, cols, grp):
    g = df.copy()
    gm = g.groupby(grp)[cols].transform("mean")
    g[cols] = g[cols].values - gm.values
    return g

def twoway_demean(df, cols):
    data = {c: df[c].values.copy().astype(float) for c in cols}
    firm, time = df["Firm"].values, df["TimeID"].values
    for _ in range(6):
        for f in np.unique(firm):
            m = firm == f
            for c in cols: data[c][m] -= np.nanmean(data[c][m])
        for t in np.unique(time):
            m = time == t
            for c in cols: data[c][m] -= np.nanmean(data[c][m])
    return data

def own_elas(a_signed, p, s, sg, rho):
    """Nested-logit own-price elasticity.  a_signed is the (negative) price coef."""
    if sg <= 0 or abs(1 - rho) < 1e-10: return np.nan
    return a_signed * p * (1 - s) / (1 - rho) + rho / (1 - rho) * (s / sg)

def cross_elas(a_signed, pk, sk, sg, rho):
    if sg <= 0 or abs(1 - rho) < 1e-10: return np.nan
    return -a_signed * pk * sk * (1 + rho / ((1 - rho) * sg))


# ---------------------------------------------------------------- panel
def build_panel(cfg):
    with open(os.path.join(DATA, "data_objects.pkl"), "rb") as f:
        dobj = pickle.load(f)
    attr  = dobj["attr"]; df_dt = dobj["date_df"].copy()
    p = {"CV": dobj["price_cv"].copy(), "FA": dobj["price_fa"].copy(), "SB": dobj["price_sb"].copy()}
    q = {"CV": dobj["quantity_cv"].copy(), "FA": dobj["quantity_fa"].copy(), "SB": dobj["quantity_sb"].copy()}
    pl = correct_abnormal_prices([p["CV"], p["FA"], p["SB"]], threshold=cfg["abn_price_thresh"])
    ql = correct_abnormal_quantities([q["CV"], q["FA"], q["SB"]], window=cfg["abn_qty_window"])
    p = dict(zip(["CV", "FA", "SB"], pl)); q = dict(zip(["CV", "FA", "SB"], ql))

    N = 222
    dates = pd.to_datetime(df_dt["Date"]).reset_index(drop=True)
    adban_day = int((dates >= pd.Timestamp(cfg["adban_date"])).idxmax())

    if cfg["frequency"] == "weekly":  # aggregate days -> ISO weeks (revenue-weighted price)
        wk = ((dates - dates.min()).dt.days // 7).astype(int).values
        def agg(arrP, arrQ):
            P, Q = arrP.values, arrQ.values; W = wk.max() + 1
            oP, oQ = np.full((W, N), np.nan), np.zeros((W, N))
            for w in range(W):
                m = wk == w
                if not m.any(): continue
                qq = np.nansum(Q[m], 0); rev = np.nansum(Q[m] * P[m], 0)
                oQ[w] = qq; oP[w] = np.where(qq > 0, rev / np.maximum(qq, 1e-9), np.nan)
            return pd.DataFrame(oP), pd.DataFrame(oQ)
        for c in ["CV", "FA", "SB"]: p[c], q[c] = agg(p[c], q[c])
        adban_day = int(adban_day // 7)
        dates = pd.Series([dates.min() + pd.Timedelta(weeks=w) for w in range(p["CV"].shape[0])])

    T = p["CV"].shape[0]
    QT = sum(q[c].values for c in ["CV", "FA", "SB"])          # (T,N)
    mkt = cfg["market_size_mult"] * QT.max(0) / cfg["chain_mkt_share"] + 1   # N_j

    amap = {k: dict(zip(range(N), attr[k].values))
            for k in ["ATCL4", "chronic", "Prescription", "ingredient"]}
    rows = []
    for d in range(N):
        ms = float(mkt[d])
        for t in range(T):
            qt = QT[t, d]
            if qt <= 0: continue
            s0 = 1 - qt / ms
            if not (0 < s0 < 1): continue
            for fid, c in enumerate(["CV", "FA", "SB"]):
                qq = q[c].values[t, d]; pp = p[c].values[t, d] / 1000
                if qq <= 0 or not np.isfinite(pp): continue
                sj = qq / ms; sjg = sj / (qt / ms)
                if not (0 < sjg < 1): continue
                Y, lsg = np.log(sj) - np.log(s0), np.log(sjg)
                if not (np.isfinite(Y) and np.isfinite(lsg)): continue
                rows.append((d, t, fid, c, int(t >= adban_day), Y, pp, lsg, sj, s0,
                             str(amap["ATCL4"][d]), int(amap["chronic"][d]),
                             int(amap["Prescription"][d]), str(amap["ingredient"][d])))
    df = pd.DataFrame(rows, columns=["DrugID", "TimeID", "FirmID", "Firm", "AdBan", "Y",
                                     "Price", "LogShareGroup", "share", "share_out",
                                     "ATCL4", "chronic", "Prescription", "Molecule"])
    df["ATC1"]  = df.ATCL4.str[0].str.upper()
    df["type4"] = (df.chronic.map({0: "Acute", 1: "Chronic"}) + "_" +
                   df.Prescription.map({0: "OTC", 1: "Rx"}))
    df["FirmDrug"] = df.Firm + "_" + df.DrugID.astype(str)
    # rival (Hausman) prices: the two rival chains' price for the same drug-period
    wide = df.groupby(["DrugID", "TimeID", "Firm"]).Price.first().unstack("Firm")
    df = df.merge(wide.rename(columns={"CV": "_CV", "FA": "_FA", "SB": "_SB"}),
                  on=["DrugID", "TimeID"], how="left")
    for fm, (a, b) in {"CV": ("_FA", "_SB"), "FA": ("_CV", "_SB"), "SB": ("_CV", "_FA")}.items():
        m = df.Firm == fm
        df.loc[m, "rival1"] = df.loc[m, a]; df.loc[m, "rival2"] = df.loc[m, b]
    df.drop(columns=["_CV", "_FA", "_SB"], inplace=True)
    meta = dict(N=N, T=T, adban=adban_day, mkt=mkt, p=p, q=q, dates=dates,
                attr=attr, QT=QT)
    return df, meta


# ---------------------------------------------------------------- IVGMM (pooled / per-group)
def ivgmm_fit(sub, cfg, label=""):
    cols = ["Y", "Price", "LogShareGroup"] + cfg["instruments"]
    sub = sub.dropna(subset=cols)
    sub = sub[np.isfinite(sub[cols].values).all(1)]
    if len(sub) < cfg["min_obs_type"]:
        return None
    ivs = sub[cfg["instruments"]].astype(float)
    ivs = ivs.loc[:, ivs.std() > 1e-10]
    if ivs.shape[1] == 0: return None
    try:
        r = IVGMM(sub.Y.astype(float), None,
                  sub[["Price", "LogShareGroup"]].astype(float), ivs,
                  weight_type="robust").fit(cov_type="robust", iter_limit=200)
        a, s = float(r.params["Price"]), float(r.params["LogShareGroup"])
        fsd = r.first_stage.diagnostics
        js  = r.j_stat
        yhat = sub.Y.values - r.resids.values
        ss_res = float(np.sum(r.resids.values ** 2))
        ss_tot = float(np.sum((sub.Y.values - sub.Y.values.mean()) ** 2))
        return dict(label=label, n=int(r.nobs), alpha=-a, alpha_coef=a, sigma=s,
                    se_alpha=float(r.std_errors["Price"]),
                    se_sigma=float(r.std_errors["LogShareGroup"]),
                    f_price=float(fsd.loc["Price", "f.stat"]),
                    f_logshare=float(fsd.loc["LogShareGroup", "f.stat"]),
                    j_stat=float(js.stat), j_pval=float(js.pval), j_df=int(js.df),
                    r2=1 - ss_res / max(ss_tot, 1e-12),
                    corr=float(np.corrcoef(sub.Y.values, yhat)[0, 1]),
                    rmse=float(np.sqrt(np.mean(r.resids.values ** 2))),
                    # exactly identified (2 Hausman IVs, 2 endog) -> no overid test;
                    # overid (J) only meaningful when j_df>0, in which case require p>0.05
                    admissible=(0 < s < 1) and (-a > 0) and (js.df == 0 or js.pval > 0.05))
    except Exception as e:
        print(f"    [ivgmm {label}] FAILED: {e}")
        return None

def first_stage_f(endog, exog, ivs):
    """Partial first-stage F for one endogenous regressor, conditional on exog.

    This avoids the expensive `linearmodels` diagnostics path for the sigma-fixed
    headline/post-ban checks, where price is the only endogenous variable.
    """
    y = np.asarray(endog, float).reshape(-1, 1)
    X0 = np.asarray(exog, float)
    Z = np.asarray(ivs, float)
    if X0.ndim == 1:
        X0 = X0.reshape(-1, 1)
    if Z.ndim == 1:
        Z = Z.reshape(-1, 1)
    X1 = np.column_stack([X0, Z])
    try:
        b0 = np.linalg.lstsq(X0, y, rcond=None)[0]
        b1 = np.linalg.lstsq(X1, y, rcond=None)[0]
    except np.linalg.LinAlgError:
        return np.nan
    e0 = y - X0 @ b0
    e1 = y - X1 @ b1
    ssr0 = float(e0.T @ e0)
    ssr1 = float(e1.T @ e1)
    q = Z.shape[1]
    df = max(len(y) - X1.shape[1], 1)
    if q <= 0 or ssr1 <= 0:
        return np.nan
    return ((ssr0 - ssr1) / q) / (ssr1 / df)


# ---------------------------------------------------------------- per-drug OLS (Step 2)
def per_drug_ols(sub, needed):
    sub = sub[np.isfinite(sub[needed].values).all(1)]
    n_post = int((sub.AdBan == 1).sum())
    if len(sub) < CONFIG["min_obs_drug"] or sub.Firm.nunique() < 2 or sub.TimeID.nunique() < 10:
        return None
    has_delta = n_post >= 30
    if has_delta:
        dm = twoway_demean(sub, needed); X = np.column_stack([dm["Price"], dm["Price_x_Ban"]]); k = 2
    else:
        pre = sub[sub.AdBan == 0]
        if len(pre) < 20: return None
        dm = twoway_demean(pre, ["Y_adj", "Price"]); X = dm["Price"].reshape(-1, 1); k = 1
    Y = dm["Y_adj"]
    if np.linalg.matrix_rank(X.T @ X) < k: return None
    try: XtXinv = np.linalg.inv(X.T @ X)
    except np.linalg.LinAlgError: return None
    coef = XtXinv @ (X.T @ Y); resid = Y - X @ coef
    V = XtXinv @ ((X * resid[:, None]).T @ (X * resid[:, None])) @ XtXinv
    se = np.sqrt(np.maximum(np.diag(V), 0))
    ss_res = float(resid @ resid); ss_tot = float((Y - Y.mean()) @ (Y - Y.mean()))
    return dict(alpha=-float(coef[0]), delta=(-float(coef[1]) if k == 2 else np.nan),
                se_alpha=float(se[0]), se_delta=(float(se[1]) if k == 2 else np.nan),
                t_alpha=(-float(coef[0]) / se[0] if se[0] > 1e-10 else np.nan),
                t_delta=(-float(coef[1]) / se[1] if (k == 2 and se[1] > 1e-10) else np.nan),
                r2_within=1 - ss_res / max(ss_tot, 1e-12),
                n=len(Y), n_post=n_post, has_delta=has_delta)


def per_drug_iv(sub, needed):
    """Per-drug 2SLS (replaces the OLS Panel B): instrument Price (and Price x Ban) with the two RIVAL
    chain prices (and rival x Ban) inside the Firm x Day within-transform.  Run on the cartel-EXCLUDED
    daily sample (see main) so the Hausman rivals are competitive -> valid instruments.  HC0 SEs."""
    chk = needed + ["rival1", "rival2"] + (["rival1_x_Ban", "rival2_x_Ban"] if "Price_x_Ban" in needed else [])
    sub = sub[np.isfinite(sub[chk].values).all(1)]
    n_post = int((sub.AdBan == 1).sum())
    if len(sub) < CONFIG["min_obs_drug"] or sub.Firm.nunique() < 2 or sub.TimeID.nunique() < 10:
        return None
    has_delta = n_post >= 30
    # Firm FE ONLY (within_demean by Firm), NOT Firm x Day: with 3 chains/drug-day, two-way demeaning forces
    # the three prices to sum to zero so own == -(rival1+rival2) MECHANICALLY -> the rival instrument is
    # degenerate (1st-stage R^2=1).  The headline avoids this the same way (Firm x Drug within-transform,
    # no day FE); the rivals then carry genuine cross-chain time variation.
    if has_delta:
        d = within_demean(sub, ["Y_adj", "Price", "Price_x_Ban", "rival1", "rival2", "rival1_x_Ban", "rival2_x_Ban"], "Firm")
        X = np.column_stack([d["Price"].values, d["Price_x_Ban"].values])
        Z = np.column_stack([d["rival1"].values, d["rival2"].values, d["rival1_x_Ban"].values, d["rival2_x_Ban"].values]); k = 2
    else:
        pre = sub[sub.AdBan == 0]
        if len(pre) < 20: return None
        d = within_demean(pre, ["Y_adj", "Price", "rival1", "rival2"], "Firm")
        X = d["Price"].values.reshape(-1, 1); Z = np.column_stack([d["rival1"].values, d["rival2"].values]); k = 1
    Y = d["Y_adj"].values
    if Z.shape[1] < k or np.linalg.matrix_rank(Z.T @ Z) < Z.shape[1]: return None
    try: ZtZinv = np.linalg.inv(Z.T @ Z)
    except np.linalg.LinAlgError: return None
    Xhat = Z @ (ZtZinv @ (Z.T @ X))                       # 2SLS first-stage projection
    XhX = Xhat.T @ X
    if np.linalg.matrix_rank(XhX) < k: return None
    try: XhXinv = np.linalg.inv(XhX)
    except np.linalg.LinAlgError: return None
    coef = XhXinv @ (Xhat.T @ Y); resid = Y - X @ coef
    meat = (Xhat * resid[:, None]).T @ (Xhat * resid[:, None])   # HC0 sandwich for 2SLS
    se = np.sqrt(np.maximum(np.diag(XhXinv @ meat @ XhXinv), 0))
    b1 = ZtZinv @ (Z.T @ X[:, 0]); e1 = X[:, 0] - Z @ b1         # first stage for Price (weak-IV F)
    ssr1 = float(e1 @ e1); sst1 = float((X[:, 0] - X[:, 0].mean()) @ (X[:, 0] - X[:, 0].mean()))
    f_first = ((sst1 - ssr1) / Z.shape[1]) / (ssr1 / max(len(Y) - Z.shape[1], 1)) if ssr1 > 0 else np.nan
    ss_res = float(resid @ resid); ss_tot = float((Y - Y.mean()) @ (Y - Y.mean()))
    return dict(alpha=-float(coef[0]), delta=(-float(coef[1]) if k == 2 else np.nan),
                se_alpha=float(se[0]), se_delta=(float(se[1]) if k == 2 else np.nan),
                t_alpha=(-float(coef[0]) / se[0] if se[0] > 1e-10 else np.nan),
                t_delta=(-float(coef[1]) / se[1] if (k == 2 and se[1] > 1e-10) else np.nan),
                r2_within=1 - ss_res / max(ss_tot, 1e-12), f_first=float(f_first),
                n=len(Y), n_post=n_post, has_delta=has_delta)


# ---------------------------------------------------------------- headline: over-identified Model B
def headline_modelB(cfg):
    """Paper's pooled Model B (Table headline row): WEEKLY panel, FirmDrug within-
    transform + ATCL4/Firm FE, IVGMM instrumented by Salcobrand wholesale cost
    (drug-level + weekly) AND rival-chain prices -> OVER-identified, so it reports a
    Hansen J.  Reproduces (alpha0, alpha_post, sigma)=(0.103, 0.029, 0.393), J=0.60(pre)
    /4.4(post, cartel-excluded).  The daily panel (build_panel) is used only for the per-type sigma_g and
    per-drug alpha_j; this weekly Model B is the headline the structural model reads."""
    with open(os.path.join(DATA, "data_objects.pkl"), "rb") as f:
        dobj = pickle.load(f)
    attr = dobj["attr"]; df_dt = dobj["date_df"].copy()
    dts = pd.to_datetime(df_dt["Date"])
    df_dt["YearWeek"] = (dts.dt.isocalendar().year.astype(str) + "-" +
                         dts.dt.isocalendar().week.astype(str).str.zfill(2))
    pl = correct_abnormal_prices([dobj["price_cv"].copy(), dobj["price_fa"].copy(),
                                  dobj["price_sb"].copy()], threshold=cfg["abn_price_thresh"])
    ql = correct_abnormal_quantities([dobj["quantity_cv"].copy(), dobj["quantity_fa"].copy(),
                                      dobj["quantity_sb"].copy()], window=cfg["abn_qty_window"])
    P = dict(zip(["CV", "FA", "SB"], pl)); Q = dict(zip(["CV", "FA", "SB"], ql))
    def aggwk(qty, price):
        rev = price * qty; q2 = qty.copy(); r2 = rev.copy()
        q2["YW"] = df_dt["YearWeek"].values; r2["YW"] = df_dt["YearWeek"].values
        wq = q2.groupby("YW").sum(numeric_only=True).reset_index(drop=True)
        return wq, (r2.groupby("YW").sum(numeric_only=True).reset_index(drop=True)) / wq
    for c in ["CV", "FA", "SB"]: Q[c], P[c] = aggwk(Q[c], P[c])
    wk = df_dt.groupby("YearWeek")["Date"].first().reset_index(); wk["TimeID"] = range(len(wk))
    T, N, ADBAN_T = len(wk), 222, 94
    ms_all = 7 * (Q["CV"] + Q["FA"] + Q["SB"]).max() + 1
    am = dict(zip(range(N), attr["ATCL4"].values))
    rows = []
    for d in range(N):
        ms = ms_all.iloc[d]
        for t in range(T):
            qt = Q["CV"].iloc[t, d] + Q["FA"].iloc[t, d] + Q["SB"].iloc[t, d]
            if qt <= 0: continue
            s0 = 1 - qt / ms
            if not (0 < s0 < 1): continue
            for fn in ["CV", "FA", "SB"]:
                qq = Q[fn].iloc[t, d]; pp = P[fn].iloc[t, d] / 1000
                if qq <= 0 or not np.isfinite(pp): continue
                sj = qq / ms; sjg = sj / (qt / ms)
                if not (0 < sjg < 1): continue
                Y = np.log(sj) - np.log(s0); lsg = np.log(sjg)
                if not (np.isfinite(Y) and np.isfinite(lsg)): continue
                rows.append((d, t, fn, int(t > ADBAN_T), Y, pp, lsg, str(am[d])))
    pn = pd.DataFrame(rows, columns=["DrugID", "TimeID", "Firm", "AdBan", "Y", "Price",
                                     "LogShareGroup", "ATCL4"])
    pn["FirmDrug"] = pn.Firm + "_" + pn.DrugID.astype(str)
    mkt = pn.groupby(["DrugID", "TimeID", "Firm"]).Price.first().unstack("Firm")
    def rp(row):
        rv = [f for f in ["CV", "FA", "SB"] if f != row.Firm]; idx = (row.DrugID, row.TimeID)
        try:
            return pd.Series({"rival1": mkt.loc[idx, rv[0]] if idx in mkt.index else np.nan,
                              "rival2": mkt.loc[idx, rv[1]] if idx in mkt.index else np.nan})
        except Exception:
            return pd.Series({"rival1": np.nan, "rival2": np.nan})
    pn = pd.concat([pn, pn[["DrugID", "TimeID", "Firm"]].apply(rp, axis=1)], axis=1)
    cost = dobj["cost_sb"].iloc[:, :N] / 1000; cavg = cost.mean(axis=0); cavg.index = range(N)
    d2yw = dict(zip(dts.dt.strftime("%Y-%m-%d"), df_dt["YearWeek"].values))
    yw2t = dict(zip(wk.YearWeek, wk.TimeID))
    cs = cost.copy(); cs.index = pd.to_datetime(cs.index)
    cs["YearWeek"] = cs.index.strftime("%Y-%m-%d").map(d2yw); cs["TimeID"] = cs["YearWeek"].map(yw2t)
    cs = cs.dropna(subset=["TimeID"]); cs["TimeID"] = cs["TimeID"].astype(int)
    wkc = cs.groupby("TimeID")[list(range(N))].mean()
    pn["cost_avg"] = pn.DrugID.map(cavg.to_dict())
    pn["cost_wk"] = pn.apply(lambda r: wkc.loc[r.TimeID, r.DrugID] if r.TimeID in wkc.index else np.nan, axis=1)
    pn["cost_wk"] = pn["cost_wk"].fillna(pn["cost_avg"])
    # ban-interacted price + cost instruments, for the full-sample (cartel-excluded) JOINT estimate of
    # (sigma, alpha0, alpha^post) -- so alpha may differ pre/post under ONE pooled sigma.
    pn["PriceBan"]    = pn.Price    * pn.AdBan
    pn["cost_avgBan"] = pn.cost_avg * pn.AdBan
    pn["cost_wkBan"]  = pn.cost_wk  * pn.AdBan
    pn["rival1Ban"]   = pn.rival1   * pn.AdBan
    pn["rival2Ban"]   = pn.rival2   * pn.AdBan
    wt = ["Y", "Price", "LogShareGroup", "cost_avg", "cost_wk", "rival1", "rival2",
          "PriceBan", "cost_avgBan", "cost_wkBan", "rival1Ban", "rival2Ban"]
    pc = pn.dropna(subset=wt + ["ATCL4"]); pc = pc[np.isfinite(pc[wt]).all(axis=1)].reset_index(drop=True)
    gm = pc.groupby("FirmDrug")[wt].transform("mean"); pcB = pc.copy(); pcB[wt] = pc[wt].values - gm.values
    def ivg(df, label, fix_sigma=None, iv_cols=("cost_avg", "cost_wk", "rival1", "rival2")):
        # fix_sigma not None -> sigma held at its pre-ban value (the nesting is a stable primitive;
        # only alpha changes at the ban), so LogShareGroup moves to the LHS and PRICE is the only
        # endogenous regressor -> cost instruments alone identify alpha, with NO reliance on the
        # post-ban rival prices (which coordination makes invalid -> the over-id rejection).
        ad = pd.get_dummies(df.ATCL4, prefix="a", drop_first=True).astype(float)
        fd = pd.get_dummies(df.Firm, prefix="f", drop_first=True).astype(float)
        ad = ad.loc[:, ad.var() > 1e-10]; fd = fd.loc[:, fd.var() > 1e-10]
        exog = pd.concat([ad.reset_index(drop=True), fd.reset_index(drop=True)], axis=1)
        ivs = df[list(iv_cols)].reset_index(drop=True).astype(float)
        ivs = ivs.loc[:, ivs.var() > 1e-10]
        cm = ivs.corr().abs(); up = cm.where(np.triu(np.ones(cm.shape), k=1).astype(bool))
        drp = [c for c in up.columns if any(up[c] > 0.9999)]
        if drp: ivs = ivs.drop(columns=drp)
        if ivs.shape[1] < (1 if fix_sigma is not None else 2):   # instruments collapsed (e.g. degenerate synthetic cost) -> graceful skip, don't crash
            return dict(label=label, n=0, alpha=float("nan"), sigma=(float(fix_sigma) if fix_sigma is not None else float("nan")),
                        se_alpha=float("nan"), se_sigma=float("nan"), j_stat=float("nan"), j_pval=float("nan"), j_df=0,
                        f_price=float("nan"), f_logshare=float("nan"), r2=float("nan"), corr=float("nan"),
                        rmse=float("nan"), admissible=False)
        if fix_sigma is not None:
            Y = (df.Y - fix_sigma * df.LogShareGroup).reset_index(drop=True).astype(float)
            endog = df[["Price"]].reset_index(drop=True).astype(float)
            r = IVGMM(Y, exog, endog,
                      ivs, weight_type="robust").fit(cov_type="robust")
            s, se_s, f_share = float(fix_sigma), float("nan"), float("nan")
        else:
            Y = df.Y.reset_index(drop=True).astype(float)
            endog = df[["Price", "LogShareGroup"]].reset_index(drop=True).astype(float)
            r = IVGMM(Y, exog, endog,
                      ivs, weight_type="robust").fit(cov_type="robust")
            s, se_s = float(r.params["LogShareGroup"]), float(r.std_errors["LogShareGroup"])
            fsd = r.first_stage.diagnostics
            f_share = float(fsd.loc["LogShareGroup", "f.stat"])
        js = r.j_stat; res = r.resids.values
        jdf = int(js.df)
        ss_res = float(np.sum(res ** 2)); ss_tot = float(np.sum((Y.values - Y.values.mean()) ** 2))
        a = float(r.params["Price"])
        f_price = (first_stage_f(endog["Price"].values, exog.values, ivs.values)
                   if fix_sigma is not None else float(fsd.loc["Price", "f.stat"]))
        return dict(label=label, n=int(r.nobs), alpha=-a, sigma=s,
                    se_alpha=float(r.std_errors["Price"]), se_sigma=se_s,
                    j_stat=(float(js.stat) if jdf > 0 else float("nan")),
                    j_pval=(float(js.pval) if jdf > 0 else float("nan")), j_df=jdf,
                    f_price=float(f_price), f_logshare=f_share,
                    r2=1 - ss_res / max(ss_tot, 1e-12),
                    corr=float(np.corrcoef(Y.values, Y.values - res)[0, 1]),
                    rmse=float(np.sqrt(np.mean(res ** 2))),
                    admissible=(0 < s < 1) and (-a > 0))
    pre = ivg(pcB[pcB.AdBan == 0], "Model B pre-ban")
    post_overid = ivg(pcB[pcB.AdBan == 1], "Model B post-ban (cost+rival, over-id)")
    post_costonly = ivg(pcB[pcB.AdBan == 1], "Model B post-ban (cost-only IV, sigma fixed)",
                        fix_sigma=pre["sigma"], iv_cols=("cost_avg", "cost_wk"))
    print(f"  [post-ban over-id ] alpha={post_overid['alpha']:.4f} (SE {post_overid['se_alpha']:.4f}) "
          f"J={post_overid['j_stat']:.2f} p={post_overid['j_pval']:.3f} Fprice={post_overid['f_price']:.0f}")
    print(f"  [post-ban COST-ONLY] alpha={post_costonly['alpha']:.4f} (SE {post_costonly['se_alpha']:.4f}) "
          f"sigma fixed={pre['sigma']:.3f}  Fprice={post_costonly['f_price']:.1f}  j_df={post_costonly['j_df']}  "
          f"<- preferred post-ban demand (Table tab:demand_hetero), no failing over-id J")
    # ---- ROBUSTNESS (2026-06-15): post-ban alpha EXCLUDING the cartel window ----------
    # The cartel (3 Dec 2007 - 11 Apr 2008) is collusive, not competitive, so its rival prices
    # are invalid instruments (coordinated prices co-move with the demand shock -> the over-id J
    # rejects).  Re-estimate the ad-ban alpha on the COMPETITIVE ads-banned weeks only.
    wkdt = pd.to_datetime(wk.Date)
    cartel_t = set(wk.TimeID[(wkdt >= "2007-12-03") & (wkdt <= "2008-04-11")])
    post = pcB[pcB.AdBan == 1]
    cutmax = max(cartel_t) if cartel_t else 0
    print("\n  ---- ROBUSTNESS: post-ban alpha, dropping the collusive cartel weeks ----")
    for nm, samp in [("post-ban ALL (incl cartel)", post),
                     ("post-ban EXCL cartel",       post[~post.TimeID.isin(cartel_t)]),
                     ("post-CARTEL only",            post[post.TimeID > cutmax])]:
        if len(samp) < 40:
            print(f"  [{nm:26s}] n={len(samp)} too few obs"); continue
        oid = ivg(samp, nm)
        fix4 = ivg(samp, nm, fix_sigma=pre["sigma"])   # sigma fixed at pre-ban + all 4 IVs -> admissible sigma + over-id J on price
        col = ivg(samp, nm, fix_sigma=pre["sigma"], iv_cols=("cost_avg", "cost_wk"))
        ar = fix4['alpha'] / pre['alpha'] if pre['alpha'] else float('nan')   # implied A_RATIO for the structural
        print(f"  [{nm:26s}] n={oid['n']:5d} | freeSig over-id a={oid['alpha']:.4f} sig={oid['sigma']:.3f} J p={oid['j_pval']:.3f}"
              f"  | SIGMA-FIXED(0.393) 4IV a={fix4['alpha']:.4f}({fix4['se_alpha']:.4f}) J={fix4['j_stat']:.2f} p={fix4['j_pval']:.3f} F={fix4['f_price']:.0f} A_RATIO={ar:.3f}"
              f"  | costonly a={col['alpha']:.4f}")

    # ---- HEADLINE post-ban demand = CARTEL-EXCLUDED, sigma pooled (2026-06-15) -----------
    # The post-ban price sensitivity is identified on the COMPETITIVE ads-banned weeks only:
    # the cartel weeks (3 Dec 2007 - 11 Apr 2008) are collusive, so their rival prices are
    # invalid Hausman instruments and the full-sample over-id J REJECTS (p=.001).  Dropping
    # them, the over-id J PASSES (p=.11) and gives alpha_post=0.029 (sigma pooled at the
    # pre-ban 0.393).  This is the demand the structural model consumes (A_RATIO=0.029/0.103
    # =0.286); the full-sample (cartel-inclusive) estimate is reported only to show WHY it is
    # dropped (the rejecting J).  See Table tab:demand_hetero.
    cartel_set = cartel_t                                  # defined above (collusive weeks)
    post_all = pcB[pcB.AdBan == 1]
    post_incl = ivg(post_all, "post-ban cartel-INCLUSIVE (cost+rival, sigma pooled)",
                    fix_sigma=pre["sigma"])                 # J rejects -> NOT USED
    post_excl = ivg(post_all[~post_all.TimeID.isin(cartel_set)],
                    "post-ban cartel-EXCLUDED (cost+rival, sigma pooled)",
                    fix_sigma=pre["sigma"])                 # J passes -> USED (headline)
    post_excl["alpha_incl"] = post_incl["alpha"]; post_excl["j_incl"] = post_incl["j_stat"]
    post_excl["jp_incl"] = post_incl["j_pval"]; post_excl["n_incl"] = post_incl["n"]
    print(f"  [HEADLINE post-ban] cartel-EXCL alpha={post_excl['alpha']:.4f} J={post_excl['j_stat']:.2f} "
          f"p={post_excl['j_pval']:.3f}  (cartel-INCL alpha={post_incl['alpha']:.4f} J={post_incl['j_stat']:.2f} "
          f"p={post_incl['j_pval']:.3f} -> dropped)   A_RATIO={post_excl['alpha']/pre['alpha']:.3f}")

    # ---- NEW HEADLINE (2026-06-16): JOINT (sigma, alpha0, alpha^post) on the FULL non-cartel sample -----
    # User request: estimate sigma on ALL competitive data (the pre-ban war + the post-ban weeks, EXCLUDING
    # the collusive cartel weeks 3 Dec 2007 -- 11 Apr 2008) JOINTLY with the pre- and post-ban price
    # coefficients, instead of identifying sigma on the pre-ban window alone and fixing it post-ban.  Price
    # is ban-interacted (PriceBan), so alpha differs pre/post under ONE pooled sigma; dropping the cartel
    # weeks restores the rival-price instruments (competitive -> valid), so the over-id J is informative.
    # This (sigma, alpha0, alpha^post) is the headline the structural model now consumes.
    def joint_ivg(df, label, interact=True, iv_cols=("cost_wk", "cost_wkBan", "rival1", "rival2")):
        # pcB is ALREADY FirmDrug-demeaned, so re-adding Firm/ATCL4 dummies is rank-deficient; a bare
        # intercept suffices.  interact=True -> ban-interacted price (alpha0 + alpha^post under one sigma);
        # interact=False -> a single pooled alpha.  sigma (LogShareGroup) is instrumented by the rivals.
        df = df.reset_index(drop=True)
        exog  = pd.DataFrame({"const": np.ones(len(df))})
        ecols = ["Price", "PriceBan", "LogShareGroup"] if interact else ["Price", "LogShareGroup"]
        endog = df[ecols].astype(float)
        ivs   = df[[c for c in iv_cols if c in df.columns]].astype(float)
        ivs   = ivs.loc[:, ivs.var() > 1e-10]
        cm = ivs.corr().abs(); up = cm.where(np.triu(np.ones(cm.shape), k=1).astype(bool))
        drp = [c for c in up.columns if any(up[c] > 0.9999)]
        if drp: ivs = ivs.drop(columns=drp)
        Y = df.Y.astype(float)
        r = IVGMM(Y, exog, endog, ivs, weight_type="robust").fit(cov_type="robust")
        a0 = float(r.params["Price"]); s = float(r.params["LogShareGroup"]); js = r.j_stat
        fs = r.first_stage.diagnostics
        d = dict(label=label, n=int(r.nobs), sigma=s, se_sigma=float(r.std_errors["LogShareGroup"]),
                 alpha0=-a0, se_alpha0=float(r.std_errors["Price"]),
                 j_stat=(float(js.stat) if int(js.df) > 0 else float("nan")),
                 j_pval=(float(js.pval) if int(js.df) > 0 else float("nan")), j_df=int(js.df),
                 f_price=float(fs.loc["Price", "f.stat"]),
                 f_priceban=(float(fs.loc["PriceBan", "f.stat"]) if interact else float("nan")))
        if interact:
            aban = float(r.params["PriceBan"]); cov = r.cov
            v0 = float(cov.loc["Price", "Price"]); vb = float(cov.loc["PriceBan", "PriceBan"]); cvb = float(cov.loc["Price", "PriceBan"])
            d["alpha_post"] = -(a0 + aban); d["se_alpha_post"] = float(np.sqrt(max(v0 + vb + 2 * cvb, 0.0)))
        else:
            d["alpha_post"] = -a0; d["se_alpha_post"] = float(r.std_errors["Price"])
        d["admissible"] = (0 < s < 1) and (-a0 > 0)
        return d
    nc = pcB[~pcB.TimeID.isin(cartel_set)]                    # full COMPETITIVE (non-cartel) sample
    joint = joint_ivg(nc, "JOINT full-excl-cartel (sigma, alpha0, alpha^post)")
    # ---- INVESTIGATE (2026-06-16): WHY is the full-sample joint sigma low (0.25) and the over-id J rejecting? --
    print("\n  ---- INVESTIGATE full-sample sigma: where do the 0.39->0.25 drop and the J rejection come from? ----")
    for nm, d in [
        ("pre-ban only, single-alpha",     joint_ivg(pcB[pcB.AdBan == 0], "pre", interact=False, iv_cols=("cost_wk", "rival1", "rival2"))),
        ("post-noncartel only, single-a",  joint_ivg(nc[nc.AdBan == 1],   "post", interact=False, iv_cols=("cost_wk", "rival1", "rival2"))),
        ("full-nc single-alpha (no ban)",  joint_ivg(nc, "full1a", interact=False, iv_cols=("cost_wk", "rival1", "rival2"))),
        ("full-nc ban-interacted (JOINT)", joint),
        ("full-nc ban-int, +rivalBan IVs", joint_ivg(nc, "full2a6iv", interact=True, iv_cols=("cost_wk", "cost_wkBan", "rival1", "rival2", "rival1Ban", "rival2Ban"))),
    ]:
        print(f"  [{nm:30s}] sigma={d['sigma']:+.3f}(se {d['se_sigma']:.3f}) a0={d['alpha0']:.4f} apost={d['alpha_post']:.4f} "
              f"J={d['j_stat']:.2f}(p={d['j_pval']:.3f},df={d['j_df']}) Fp={d['f_price']:.0f} Fpb={d['f_priceban']:.0f} N={d['n']}")
    return pre, post_excl, joint


# ================================================================== #
def main():
    cfg = CONFIG
    print("=" * 64); print("CANONICAL DEMAND ESTIMATION  (demand.py)")
    print("  config:", {k: cfg[k] for k in ["frequency", "sigma_mode", "instruments"]})
    print("=" * 64)
    df, meta = build_panel(cfg)
    N, T, adban = meta["N"], meta["T"], meta["adban"]
    print(f"panel: {len(df):,} rows | {df.DrugID.nunique()} drugs | "
          f"{cfg['frequency']} T={T} | ad-ban @ {adban} "
          f"(pre {(df.AdBan==0).sum():,} / post {(df.AdBan==1).sum():,})")

    # ---- Step 1a: HEADLINE = over-identified Model B (weekly, cost+rival IVs) -----
    # This is the headline the structural model reads (sigma, alpha0, A_RATIO).  It is
    # the over-identified spec (reports a Hansen J), reproducing the paper's Table row.
    print("\n[1a] HEADLINE: over-identified Model B (weekly panel, cost+rival IVs)")
    dmv = ["Y", "Price", "LogShareGroup"] + cfg["instruments"]   # daily IV set, used in Step 1b
    head_pre, head_post, head_joint = headline_modelB(cfg)
    for h in (head_pre, head_post):
        print(f"    {h['label']:18s}: alpha={h['alpha']:+.4f}(se {h['se_alpha']:.4f})  "
              f"sigma={h['sigma']:+.4f}(se {h['se_sigma']:.4f})  "
              f"J={h['j_stat']:.2f}(p={h['j_pval']:.3f})  "
              f"F_p={h['f_price']:.0f} F_s={h['f_logshare']:.0f}  N={h['n']}")
    # HEADLINE: sigma is identified on the PRE-BAN war (where it is credible, F huge) and held fixed; the
    # post-ban price sensitivity is the cartel-excluded alpha^post.  The full-sample JOINT estimate
    # (head_joint) is computed only as a ROBUSTNESS check -- the investigation shows the post-ban
    # competitive data carries no nesting signal (sigma~0, SE~0.3), so a pooled sigma is unidentified and
    # the over-id J rejects; hence sigma stays fixed at the pre-ban value.
    sigma_head = head_pre["sigma"]; alpha0 = head_pre["alpha"]
    if cfg["headline_sigma_override"] is not None:          # pin sigma (-> structural OM=1-sigma)
        sigma_head = float(cfg["headline_sigma_override"])
        print(f"    [sigma pinned to {sigma_head} via headline_sigma_override]")
    alpha_post = head_post["alpha"]

    # ---- Step 1b: per-type (sigma_g, alpha_g) -------------------------------
    print("\n[1b] PER-TYPE IVGMM (pre-ban; sigma_g for Step 2)")
    win = df[df.AdBan == 0] if cfg["sigma_window"] == "preban" else df
    type_rows = []
    for t4 in sorted(df.type4.dropna().unique()):
        r = ivgmm_fit(within_demean(win[win.type4 == t4], dmv, "FirmDrug"), cfg, t4)
        if r:
            r["type4"] = t4; type_rows.append(r); print(
            f"    {t4:13s}: alpha={r['alpha']:+.3f} sigma={r['sigma']:+.3f} "
            f"F_s={r['f_logshare']:.0f} J(p)={r['j_pval']:.3f}  "
            f"{'admissible' if r['admissible'] else 'INADMISSIBLE->pooled sigma'}")
    type_df = pd.DataFrame(type_rows)
    type_df["sigma_use"] = type_df.apply(
        lambda r: sigma_head if not r.admissible else r.sigma, axis=1)
    if cfg["sigma_mode"] == "pooled":
        type_df["sigma_use"] = sigma_head
    SIG_BY_TYPE = dict(zip(type_df.type4, type_df.sigma_use))

    # ---- Step 2: per-drug alpha_j (sigma_g fixed) ---------------------------
    print("\n[2] PER-DRUG 2SLS  (sigma_g fixed, Firm FE, rival-price IV, cartel weeks dropped)")
    df["sigma_g"] = df.type4.map(SIG_BY_TYPE).fillna(sigma_head)
    df["Y_adj"] = df.Y - df.sigma_g * df.LogShareGroup
    df["Price_x_Ban"]  = df.Price  * df.AdBan
    df["rival1_x_Ban"] = df.rival1 * df.AdBan
    df["rival2_x_Ban"] = df.rival2 * df.AdBan
    needed = ["Y_adj", "Price", "Price_x_Ban"]
    # the rival (Hausman) instruments are valid only on COMPETITIVE weeks; drop the collusive cartel days
    _dts = pd.to_datetime(meta["dates"]).reset_index(drop=True)
    cartel_days = set(np.where((_dts >= "2007-12-03") & (_dts <= "2008-04-11"))[0])
    full = df.dropna(subset=needed + ["rival1", "rival2"]); full = full[np.isfinite(full[needed].values).all(1)]
    full = full[~full.TimeID.isin(cartel_days)]
    res = []
    for did in sorted(full.DrugID.unique()):
        sub = full[full.DrugID == did]
        r = per_drug_iv(sub, needed)
        if r is None: continue
        r0 = sub.iloc[0]
        r.update(DrugID=int(did), type4=str(r0.type4), sigma_g=float(r0.sigma_g),
                 ATC1=str(r0.ATC1), Molecule=str(r0.Molecule),
                 chronic=int(r0.chronic), Prescription=int(r0.Prescription))
        res.append(r)
    A = pd.DataFrame(res)
    A["alpha_raw"] = A.alpha
    A["fallback"] = (A.alpha <= 0) & cfg["wrong_sign_fallback"]
    type_alpha = dict(zip(type_df.type4, type_df.alpha))   # type alpha_g (all positive)
    A.loc[A.fallback, "alpha"] = A.loc[A.fallback, "type4"].map(type_alpha)
    print(f"    estimated {len(A)} drugs | wrong-sign fallback: {int(A.fallback.sum())} "
          f"({A.fallback.mean():.0%}) | alpha_j median={A.alpha.median():.3f} "
          f"sig={(A.t_alpha.abs()>1.96).mean():.0%} | 1st-stage F median={A.f_first.median():.0f}")

    # ---- Het-OLS variant: per-drug OLS alpha (Firm x Day FE, no IV) for tab:spec_robustness Het-OLS column.
    #      Same sample/sigma/fallback as the canonical IV column; written to a SEPARATE csv (canonical untouched).
    res_ols = []
    for did in sorted(full.DrugID.unique()):
        sub = full[full.DrugID == did]
        r = per_drug_ols(sub, needed)
        if r is None: continue
        r0 = sub.iloc[0]; r.update(DrugID=int(did), type4=str(r0.type4), sigma_g=float(r0.sigma_g))
        res_ols.append(r)
    A_ols = pd.DataFrame(res_ols)
    A_ols["alpha_raw"] = A_ols.alpha
    A_ols["fallback"] = (A_ols.alpha <= 0) & cfg["wrong_sign_fallback"]
    A_ols.loc[A_ols.fallback, "alpha"] = A_ols.loc[A_ols.fallback, "type4"].map(type_alpha)
    A_ols[["DrugID", "type4", "sigma_g", "alpha", "alpha_raw", "fallback", "n", "n_post"]].to_csv(
        os.path.join(OUT, "r2_demand_alpha_per_drug_ols.csv"), index=False)
    print(f"    [Het-OLS variant] wrote r2_demand_alpha_per_drug_ols.csv  "
          f"(median alpha {A_ols.alpha.median():.3f}, fallback {int(A_ols.fallback.sum())})")

    # ---- per-drug elasticities (own/cross, pre & post) ----------------------
    print("\n[3] PER-DRUG ELASTICITIES (nested-logit, at each drug's alpha_j)")
    p, q, mkt = meta["p"], meta["q"], meta["mkt"]
    a_idx = adban
    a_ratio = alpha_post / alpha0 if alpha0 else np.nan
    def med_block(arr, d, lo, hi): return np.nanmedian(arr.values[lo:hi, d])
    el = {}
    for _, r in A.iterrows():
        d = int(r.DrugID); ms = mkt[d]; sg_par = r.sigma_g
        def blk(reg):
            lo, hi = (0, a_idx) if reg == "pre" else (a_idx, T)
            pr = {c: med_block(p[c], d, lo, hi) / 1000 for c in ["CV", "FA", "SB"]}
            sh = {c: med_block(q[c], d, lo, hi) / ms for c in ["CV", "FA", "SB"]}
            sg = sum(sh.values())
            a_signed = -r.alpha if reg == "pre" else -r.alpha * a_ratio
            oe = np.nanmean([own_elas(a_signed, pr[c], sh[c], sg, sg_par) for c in pr])
            ce = np.nanmean([cross_elas(a_signed, pr[c], sh[c], sg, sg_par) for c in pr])
            return oe, ce
        oe_pre, ce_pre = blk("pre"); oe_po, ce_po = blk("post")
        el[d] = (oe_pre, ce_pre, oe_po, ce_po)
    A["own_elas_pre"]  = A.DrugID.map(lambda d: el[d][0])
    A["cross_elas_pre"]= A.DrugID.map(lambda d: el[d][1])
    A["own_elas_post"] = A.DrugID.map(lambda d: el[d][2])
    A["cross_elas_post"]= A.DrugID.map(lambda d: el[d][3])
    print(f"    own-price elas (pre):  median={A.own_elas_pre.median():.2f}  "
          f"frac<0={(A.own_elas_pre<0).mean():.0%}")
    print(f"    own-price elas (post): median={A.own_elas_post.median():.2f}  "
          f"frac<0={(A.own_elas_post<0).mean():.0%}")

    # ---- goodness of fit ----------------------------------------------------
    print("\n[4] GOODNESS OF FIT")
    gof = []
    for h, reg in [(head_pre, "pre-ban"), (head_post, "post-ban")]:
        if h: gof.append(dict(diagnostic="headline IVGMM fit", regime=reg,
                              R2=h["r2"], Corr=h["corr"], RMSE=h["rmse"], N=h["n"],
                              J=h["j_stat"], J_p=h["j_pval"], F_price=h["f_price"],
                              F_logshare=h["f_logshare"]))
    # per-drug fit: within-R2 in the Firm x Day demeaned space Step 2 is estimated in
    # (raw-space R2 is not meaningful here because the FE absorb most variation)
    gof.append(dict(diagnostic="per-drug within-R2", regime="median",
                    R2=float(A.r2_within.median()), Corr=float(A.r2_within.mean()),
                    RMSE=np.nan, N=int(len(A))))
    gof_df = pd.DataFrame(gof)
    for _, g in gof_df.iterrows():
        print(f"    {g.diagnostic:22s} {g.regime:9s}: R2={g.R2:+.3f} Corr={g.Corr:+.3f} "
              f"RMSE={g.RMSE:.3f} N={int(g.N):,}")

    # ---- write canonical outputs -------------------------------------------
    A = A[["DrugID", "Molecule", "type4", "ATC1", "sigma_g",
           "alpha", "alpha_raw", "delta", "se_alpha", "se_delta", "t_alpha", "t_delta",
           "own_elas_pre", "cross_elas_pre", "own_elas_post", "cross_elas_post",
           "fallback", "n", "n_post", "has_delta"]]
    A.to_csv(os.path.join(OUT, "r2_demand_alpha_per_drug.csv"), index=False)
    type_df.to_csv(os.path.join(OUT, "r2_demand_type_params.csv"), index=False)
    gof_df.to_csv(os.path.join(OUT, "r2_demand_gof.csv"), index=False)

    params = dict(
        config=cfg,
        headline=dict(sigma=sigma_head, OM=1 - sigma_head, alpha0=alpha0,
                      alpha_post=alpha_post,
                      A_RATIO=(alpha_post / alpha0 if alpha0 else np.nan),
                      rho_mktshare=cfg["chain_mkt_share"]),
        diagnostics=dict(pre=head_pre, post=head_post, joint=head_joint),
        per_type={r.type4: dict(sigma=r.sigma, sigma_use=r.sigma_use, alpha=r.alpha,
                                f_logshare=r.f_logshare, j_pval=r.j_pval,
                                admissible=bool(r.admissible))
                  for _, r in type_df.iterrows()},
        per_drug=dict(n_drugs=int(len(A)), alpha_median=float(A.alpha.median()),
                      own_elas_pre_median=float(A.own_elas_pre.median()),
                      own_elas_post_median=float(A.own_elas_post.median()),
                      post_inelastic_frac=float((A.own_elas_post.abs() < 1).mean()),
                      n_fallback=int(A.fallback.sum())),
    )
    with open(os.path.join(OUT, "demand_params.json"), "w") as f:
        json.dump(params, f, indent=2, default=lambda o: None if (isinstance(o, float) and not np.isfinite(o)) else float(o))

    print("\n" + "=" * 64)
    print("HEADLINE (-> structural model constants)")
    print(f"  sigma = {sigma_head:.4f}   OM = 1-sigma = {1-sigma_head:.4f}")
    print(f"  alpha0 (pre-ban)  = {alpha0:.4f}")
    print(f"  alpha_post        = {alpha_post:.4f}    A_RATIO = {alpha_post/alpha0:.4f}")
    if head_post and head_post["j_pval"] < 0.05:
        print(f"  NOTE: post-ban overid J={head_post['j_stat']:.2f} (p={head_post['j_pval']:.3f}) "
              f"REJECTS -> post-ban IV not valid; sigma fixed from pre-ban (reported, not used as primary).")
    print("wrote: r2_demand_alpha_per_drug.csv, r2_demand_type_params.csv, "
          "r2_demand_gof.csv, demand_params.json")
    print("=" * 64)
    return A, params


if __name__ == "__main__":
    main()
