import os, sys, pickle, warnings, numpy as np, pandas as pd
warnings.filterwarnings("ignore")
ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
sys.path.insert(0, os.path.join(ROOT,"code","03_demand")); sys.path.insert(0, os.path.join(ROOT,"code","shared"))
import demand as D
from linearmodels.iv import IVGMM
import statsmodels.api as sm
cfg=D.CONFIG
# ---- replicate headline_modelB weekly panel ----
dobj=pickle.load(open(os.path.join(ROOT,"data","processed","data_objects.pkl"),"rb"))
attr=dobj["attr"]; df_dt=dobj["date_df"].copy(); dts=pd.to_datetime(df_dt["Date"])
df_dt["YearWeek"]=(dts.dt.isocalendar().year.astype(str)+"-"+dts.dt.isocalendar().week.astype(str).str.zfill(2))
pl=D.correct_abnormal_prices([dobj["price_cv"].copy(),dobj["price_fa"].copy(),dobj["price_sb"].copy()],threshold=cfg["abn_price_thresh"])
ql=D.correct_abnormal_quantities([dobj["quantity_cv"].copy(),dobj["quantity_fa"].copy(),dobj["quantity_sb"].copy()],window=cfg["abn_qty_window"])
P=dict(zip(["CV","FA","SB"],pl)); Q=dict(zip(["CV","FA","SB"],ql))
def aggwk(qty,price):
    rev=price*qty; q2=qty.copy(); r2=rev.copy(); q2["YW"]=df_dt["YearWeek"].values; r2["YW"]=df_dt["YearWeek"].values
    wq=q2.groupby("YW").sum(numeric_only=True).reset_index(drop=True); return wq,(r2.groupby("YW").sum(numeric_only=True).reset_index(drop=True))/wq
for c in ["CV","FA","SB"]: Q[c],P[c]=aggwk(Q[c],P[c])
wk=df_dt.groupby("YearWeek")["Date"].first().reset_index(); wk["TimeID"]=range(len(wk))
T,N,ADBAN_T=len(wk),222,94; ms_all=7*(Q["CV"]+Q["FA"]+Q["SB"]).max()+1; am=dict(zip(range(N),attr["ATCL4"].values))
rows=[]
for d in range(N):
    ms=ms_all.iloc[d]
    for t in range(T):
        qt=Q["CV"].iloc[t,d]+Q["FA"].iloc[t,d]+Q["SB"].iloc[t,d]
        if qt<=0: continue
        s0=1-qt/ms
        if not (0<s0<1): continue
        for fn in ["CV","FA","SB"]:
            qq=Q[fn].iloc[t,d]; pp=P[fn].iloc[t,d]/1000
            if qq<=0 or not np.isfinite(pp): continue
            sj=qq/ms; sjg=sj/(qt/ms)
            if not (0<sjg<1): continue
            Y=np.log(sj)-np.log(s0); lsg=np.log(sjg)
            if not(np.isfinite(Y) and np.isfinite(lsg)): continue
            rows.append((d,t,fn,int(t>ADBAN_T),Y,pp,lsg,str(am[d])))
pn=pd.DataFrame(rows,columns=["DrugID","TimeID","Firm","AdBan","Y","Price","LogShareGroup","ATCL4"])
pn["FirmDrug"]=pn.Firm+"_"+pn.DrugID.astype(str)
mkt=pn.groupby(["DrugID","TimeID","Firm"]).Price.first().unstack("Firm")
def rp(row):
    rv=[f for f in ["CV","FA","SB"] if f!=row.Firm]; idx=(row.DrugID,row.TimeID)
    try: return pd.Series({"rival1":mkt.loc[idx,rv[0]] if idx in mkt.index else np.nan,"rival2":mkt.loc[idx,rv[1]] if idx in mkt.index else np.nan})
    except Exception: return pd.Series({"rival1":np.nan,"rival2":np.nan})
pn=pd.concat([pn,pn[["DrugID","TimeID","Firm"]].apply(rp,axis=1)],axis=1)
cost=dobj["cost_sb"].iloc[:,:N]/1000; cavg=cost.mean(axis=0); cavg.index=range(N)
d2yw=dict(zip(dts.dt.strftime("%Y-%m-%d"),df_dt["YearWeek"].values)); yw2t=dict(zip(wk.YearWeek,wk.TimeID))
cs=cost.copy(); cs.index=pd.to_datetime(cs.index); cs["YearWeek"]=cs.index.strftime("%Y-%m-%d").map(d2yw); cs["TimeID"]=cs["YearWeek"].map(yw2t)
cs=cs.dropna(subset=["TimeID"]); cs["TimeID"]=cs["TimeID"].astype(int); wkc=cs.groupby("TimeID")[list(range(N))].mean()
pn["cost_avg"]=pn.DrugID.map(cavg.to_dict())
pn["cost_wk"]=pn.apply(lambda r: wkc.loc[r.TimeID,r.DrugID] if r.TimeID in wkc.index else np.nan,axis=1); pn["cost_wk"]=pn["cost_wk"].fillna(pn["cost_avg"])
wt=["Y","Price","LogShareGroup","cost_avg","cost_wk","rival1","rival2"]
pc=pn.dropna(subset=wt+["ATCL4"]); pc=pc[np.isfinite(pc[wt]).all(axis=1)].reset_index(drop=True)
gm=pc.groupby("FirmDrug")[wt].transform("mean"); pcB=pc.copy(); pcB[wt]=pc[wt].values-gm.values
# cartel weeks to drop post-ban
wkdt=pd.to_datetime(wk.Date); cartel_t=set(wk.TimeID[(wkdt>="2007-12-03")&(wkdt<="2008-04-11")])
def fe(df):
    ad=pd.get_dummies(df.ATCL4,prefix="a",drop_first=True).astype(float); fd=pd.get_dummies(df.Firm,prefix="f",drop_first=True).astype(float)
    ad=ad.loc[:,ad.var()>1e-10]; fd=fd.loc[:,fd.var()>1e-10]; return pd.concat([ad.reset_index(drop=True),fd.reset_index(drop=True)],axis=1)
def ols(df):
    X=pd.concat([df[["Price","LogShareGroup"]].reset_index(drop=True),fe(df)],axis=1).astype(float)
    r=sm.OLS(df.Y.reset_index(drop=True).astype(float),sm.add_constant(X)).fit(cov_type="HC1"); return -float(r.params["Price"]),float(r.params["LogShareGroup"])
def iv(df,iv_cols):
    exog=fe(df); ivs=df[list(iv_cols)].reset_index(drop=True).astype(float); ivs=ivs.loc[:,ivs.var()>1e-10]
    if ivs.shape[1]<2: return (np.nan,np.nan)
    r=IVGMM(df.Y.reset_index(drop=True).astype(float),exog,df[["Price","LogShareGroup"]].reset_index(drop=True).astype(float),ivs,weight_type="robust").fit(cov_type="robust")
    return -float(r.params["Price"]),float(r.params["LogShareGroup"])
pre=pcB[pcB.AdBan==0]; post=pcB[(pcB.AdBan==1)&(~pcB.TimeID.isin(cartel_t))]
print("n_pre=%d  n_post(excl cartel)=%d"%(len(pre),len(post)))
res={}
for nm,sub in [("PRE",pre),("POST",post)]:
    ao,so=ols(sub); ar,sr=iv(sub,("rival1","rival2")); ac,sc=iv(sub,("cost_avg","cost_wk"))
    res[nm]=dict(ols=ao,rival=ar,cost=ac)
    print(f"{nm}:  OLS a={ao:.4f}(sig {so:.3f})   rival-IV a={ar:.4f}(sig {sr:.3f})   cost-IV a={ac:.4f}(sig {sc:.3f})")
print("\nCOLLAPSE RATIO (post/pre):")
for k in ("ols","rival","cost"):
    rr=res["POST"][k]/res["PRE"][k] if res["PRE"][k] else float('nan')
    print(f"  {k:6s}: {res['PRE'][k]:.4f} -> {res['POST'][k]:.4f}   ratio={rr:.3f}")

print("\n================ SIGMA-FIXED at 0.393 (isolate the CONTESTED own-price endogeneity) ================")
SIG=0.393
def fe2(df):
    ad=pd.get_dummies(df.ATCL4,prefix="a",drop_first=True).astype(float); fd=pd.get_dummies(df.Firm,prefix="f",drop_first=True).astype(float)
    ad=ad.loc[:,ad.var()>1e-10]; fd=fd.loc[:,fd.var()>1e-10]; return pd.concat([ad.reset_index(drop=True),fd.reset_index(drop=True)],axis=1)
def lhs(df): return (df.Y - SIG*df.LogShareGroup).reset_index(drop=True).astype(float)
def ols_p(df):
    X=pd.concat([df[["Price"]].reset_index(drop=True),fe2(df)],axis=1).astype(float)
    r=sm.OLS(lhs(df),sm.add_constant(X)).fit(cov_type="HC1"); return -float(r.params["Price"])
def iv_p(df,iv_cols):
    ivs=df[list(iv_cols)].reset_index(drop=True).astype(float); ivs=ivs.loc[:,ivs.var()>1e-10]
    if ivs.shape[1]<1: return np.nan
    r=IVGMM(lhs(df),fe2(df),df[["Price"]].reset_index(drop=True).astype(float),ivs,weight_type="robust").fit(cov_type="robust")
    return -float(r.params["Price"])
r2={}
for nm,sub in [("PRE",pre),("POST",post)]:
    ao=ols_p(sub); ar=iv_p(sub,("rival1","rival2")); ac=iv_p(sub,("cost_wk",))
    r2[nm]=dict(ols=ao,rival=ar,cost=ac)
    print(f"{nm}:  OLS-price a={ao:.4f}   rival-IV a={ar:.4f}   cost-IV(cost_wk) a={ac:.4f}")
print("\nCOLLAPSE RATIO (post/pre), sigma fixed:")
for k in ("ols","rival","cost"):
    pr,po=r2["PRE"][k],r2["POST"][k]; print(f"  {k:6s}: {pr:.4f} -> {po:.4f}   ratio={(po/pr if pr else float('nan')):.3f}")
