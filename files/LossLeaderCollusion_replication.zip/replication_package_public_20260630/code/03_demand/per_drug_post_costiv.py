#!/usr/bin/env python3
"""Panel B post-ban alpha via the COST instrument (Table tab:demand_hetero).

Post-ban rival prices are coordination-contaminated, so the per-drug RIVAL-IV
post-ban alpha (the original Panel B 'post' column) is biased up toward the
pre-ban value.  Re-identify the post-ban price coefficient with the Salcobrand
wholesale-cost instrument -- the same instrument that anchors the pooled headline
(Panel A, alpha_post=0.029) -- on the COMPETITIVE ads-banned weeks (cartel weeks
3 Dec 2007 - 11 Apr 2008 dropped).  The cost series spans 2007-11-01+ (183 days),
so the post-ban coefficient is identified on the Nov-2007 + post-cartel
competitive window: the Chronic classes (195 drugs) identify cleanly and collapse
to ~0.02-0.06 (matching the pooled 0.029); the thin Acute classes (26 drugs,
~52 cost-covered days) are wrong-signed and NOT separately identified.

This recomputes ONLY the post-ban column for the table.  Pre-ban alpha_j (rival
IV, valid under competition) and sigma_g are UNCHANGED, and the structural model
keeps reading the canonical r2_demand_alpha_per_drug.csv -- nothing here feeds it.

Output: output/r2_demand_post_costiv.csv
"""
import os, sys, pickle
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import demand as D

SIG = 0.393; N = 222
CARTEL0, CARTEL1 = "2007-12-03", "2008-04-11"


def costiv(sub):
    """Over-identified 2SLS of Y_adj on Price, instruments = SB cost + the two rival prices (the FULL valid
    IV set on the cartel-excluded sample), FirmDrug-demeaned.  HC0-ish; returns (alpha, first-stage F, n)."""
    dd = D.within_demean(sub, ["Y_adj", "Price", "cost", "rival1", "rival2"], "FirmDrug")
    Y = dd["Y_adj"].values.ravel(); X = dd["Price"].values.reshape(-1, 1)
    Z = np.column_stack([dd["cost"].values.ravel(), dd["rival1"].values.ravel(), dd["rival2"].values.ravel()])
    if np.linalg.matrix_rank(Z.T @ Z) < Z.shape[1]:
        return np.nan, np.nan, len(sub)
    ZtZi = np.linalg.inv(Z.T @ Z); Xh = Z @ (ZtZi @ (Z.T @ X)); XhX = float(Xh.T @ X)
    if abs(XhX) < 1e-12:
        return np.nan, np.nan, len(sub)
    beta = float((Xh.T @ Y) / XhX)
    e1 = X[:, 0] - Z @ np.linalg.solve(Z.T @ Z, Z.T @ X[:, 0])                 # first stage: Price on IVs
    ssr = float(e1 @ e1); sst = float((X[:, 0] - X[:, 0].mean()) @ (X[:, 0] - X[:, 0].mean()))
    F = ((sst - ssr) / Z.shape[1]) / (ssr / max(len(Y) - Z.shape[1], 1)) if ssr > 0 else np.nan
    return -beta, float(F), len(sub)


def main():
    cfg = D.CONFIG
    df, meta = D.build_panel(cfg)
    dobj = pickle.load(open(os.path.join(D.DATA, "data_objects.pkl"), "rb"))
    dates = pd.to_datetime(pd.Series(meta["dates"]).values)
    cost = dobj["cost_sb"].iloc[:, :N].copy() / 1000.0
    cost.index = pd.to_datetime(cost.index)
    costmat = cost.reindex(dates).values                      # (T, N), NaN where no cost
    df = df[df.DrugID < N].copy()
    df["cost"] = costmat[df.TimeID.values, df.DrugID.values]
    df["Y_adj"] = df.Y - SIG * df.LogShareGroup
    cartel = set(np.where((dates >= pd.Timestamp(CARTEL0)) & (dates <= pd.Timestamp(CARTEL1)))[0])
    post = df[(df.AdBan == 1) & (~df.TimeID.isin(cartel)) & df.cost.notna()]
    post = post.dropna(subset=["Y_adj", "Price", "cost", "rival1", "rival2"]).copy()
    post["FirmDrug"] = post.Firm.astype(str) + "_" + post.DrugID.astype(str)

    canon = pd.read_csv(os.path.join(D.OUT, "r2_demand_alpha_per_drug.csv"))
    canon["post_rival"] = canon.alpha + canon.delta.fillna(0)
    pre_rival = canon.groupby("type4").alpha.median()
    post_rival = canon.groupby("type4").post_rival.median()
    n_drugs = canon.groupby("type4").size()

    rows = []
    for t4 in ["Chronic_Rx", "Chronic_OTC", "Acute_OTC", "Acute_Rx"]:
        sub = post[post.type4 == t4]
        a, F, n = costiv(sub) if sub.DrugID.nunique() >= 2 else (np.nan, np.nan, 0)
        identified = bool(np.isfinite(a) and a > 0)
        pr = float(pre_rival.get(t4, np.nan))
        rows.append(dict(type4=t4, n_drugs=int(n_drugs.get(t4, 0)),
                         pre_rival=round(pr, 3),
                         post_rival_old=round(float(post_rival.get(t4, np.nan)), 3),
                         post_costiv=(round(a, 3) if identified else np.nan),
                         ratio=(round(a / pr, 2) if identified else np.nan),
                         first_stage_F=(round(F, 0) if np.isfinite(F) else np.nan),
                         identified=identified))
    a_all, F_all, n_all = costiv(post)
    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(D.OUT, "r2_demand_post_costiv.csv"), index=False)
    print(out.to_string(index=False))
    print(f"\nALL-drug pooled cost-IV post-ban alpha = {a_all:.3f}  (F={F_all:.0f}, n={n_all:,})"
          f"   | pooled headline Panel A = 0.029")
    print("wrote output/r2_demand_post_costiv.csv")


if __name__ == "__main__":
    main()
