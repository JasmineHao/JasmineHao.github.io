"""figstyle.py
==============
Shared figure style for ALL paper figures (gathered under code/09_figures/).
Every figure script here calls fs.setup() and fs.save(), so the whole paper
shares one clean serif look, one palette, and one set of date-axis / regime-shade
helpers.  Output PDFs go to the manuscript directory (where \includegraphics
finds them); a PNG preview also goes to output/.

Palette / week-clock conventions match fig_price_path and fig_war_dynamics.
"""
import os
import datetime
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
FIGDIR = os.path.join(ROOT, "paper", "manuscript")
PNGDIR = os.path.join(ROOT, "output")

# ---- palette ----------------------------------------------------------------
INK   = "#404040"     # data / primary line
RED   = "#c0392b"     # model / emphasis
DRED  = "#9e2b1e"     # war, loss, below-cost
BLUE  = "#2166ac"     # coordination / secondary
TEAL  = "#1f5c8a"
GREY  = "#9aa0a6"     # data bars / muted
GOLD  = "#c8922b"
CHAIN = {"CV": "#4878a8", "FA": "#c8922b", "SB": "#9e2b1e"}   # consistent chain colours

# ---- key week-clock dates (weeks from 2006-01-01) ---------------------------
WK_DECLINE = 52       # Jan 2007  price decline begins (data)
WK_CV      = 82       # Aug 2007  Cruz Verde "Desafio" campaign (war intensifies)
WK_CONAR   = 87       # 7 Sep 2007 CONAR self-regulatory ruling (industry body)
WK_BAN     = 96       # 6 Nov 2007 binding Civil Court ad ban (medida precautoria)
WK_T0      = 100      # 3 Dec 2007 first three-chain coordination
WK_OFICIO  = 117      # 31 Mar 2008 FNE Oficio 419 (investigation)


def setup():
    plt.rcParams.update({
        "font.family": "serif", "font.serif": ["CMU Serif", "DejaVu Serif"],
        "mathtext.fontset": "cm", "axes.linewidth": 0.6, "font.size": 9,
        "axes.spines.top": False, "axes.spines.right": False, "axes.grid": False,
        "text.usetex": False, "axes.titlesize": 9, "axes.titlelocation": "left",
        "legend.frameon": False, "legend.fontsize": 8, "figure.dpi": 120,
    })


def wk_label(w):
    return (datetime.date(2006, 1, 1) + datetime.timedelta(weeks=int(w))).strftime("%b\n%Y")


def date_xaxis(ax, lo, hi, step=8, fontsize=6.6):
    # ticks anchored at MONTH STARTS (not every `step` weeks from `lo`), so each month label sits at the
    # first of that month instead of drifting to mid-month and making the axis read ~1 month early.
    # `step` (weeks between ticks) is converted to a whole-months interval.
    base = datetime.date(2006, 1, 1)
    lo_d = base + datetime.timedelta(weeks=int(lo))
    hi_d = base + datetime.timedelta(weeks=int(hi))
    every = max(1, int(round(step / 4.345)))            # weeks-between-ticks -> months-between-ticks
    y, m = lo_d.year, lo_d.month
    if lo_d.day > 1:                                     # first month-start on/after lo
        m += 1
        if m > 12:
            m, y = 1, y + 1
    ticks, labels, i = [], [], 0
    while datetime.date(y, m, 1) <= hi_d:
        if i % every == 0:
            d = datetime.date(y, m, 1)
            ticks.append((d - base).days / 7.0)
            labels.append(d.strftime("%b\n%Y"))
        i += 1
        m += 1
        if m > 12:
            m, y = 1, y + 1
    ax.set_xticks(ticks)
    ax.set_xticklabels(labels, fontsize=fontsize)
    ax.set_xlim(lo, hi)


def war_shade(ax, lo=WK_DECLINE, hi=WK_BAN):
    """light shade over the loss-leader war window."""
    ax.axvspan(lo, hi, color="#d6604d", alpha=0.06, lw=0)


def regime_marks(ax, decline=True, cv=True, ban=True, top=None):
    """vertical markers for the documented regime dates, labelled at the top."""
    yt = top if top is not None else ax.get_ylim()[1]
    if decline:
        ax.axvline(WK_DECLINE, color=DRED, ls="--", lw=0.8)
    if cv:
        ax.axvline(WK_CV, color=RED, ls=":", lw=0.7)
    if ban:
        ax.axvline(WK_BAN, color="0.45", ls="--", lw=0.8)


def save(fig, name):
    fig.tight_layout()
    fig.savefig(os.path.join(FIGDIR, name + ".pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(PNGDIR, name + ".png"), dpi=145, bbox_inches="tight")
    print("wrote", os.path.join(FIGDIR, name + ".pdf"))
