"""9_13_war_attempts.py -- Appendix: example WAR ATTEMPTS (failed coordination lifts).
Six pre-ban episodes where one chain raised price to coordinate, rivals undercut, and the
lift reverted within weeks -- the ledger's failed_attempt events the structural rate w_e
reproduces.  Each example is a clean central spike (rise & revert several std above the
drug's normal volatility).  Output -> paper/manuscript/fig_war_attempts.pdf"""
import os, sys, pickle
import pandas as pd, numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import matplotlib.dates as mdates
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),"..",".."))
sys.path.insert(0,os.path.join(ROOT,"code","shared"))
from EmpiricalDataHandling import correct_abnormal_prices
dobj=pickle.load(open(os.path.join(ROOT,"data","processed","data_objects.pkl"),"rb"))
pl=correct_abnormal_prices([dobj["price_cv"].copy(),dobj["price_fa"].copy(),dobj["price_sb"].copy()],threshold=3.0)
P={k:np.asarray(v) for k,v in zip(["CV","FA","SB"],pl)}
dates=pd.to_datetime(dobj["date_df"]["Date"]).reset_index(drop=True)
e=pd.read_csv(os.path.join(ROOT,"output","v16_events_unified.csv"),parse_dates=["date"])
e["wk"]=((e.date-pd.Timestamp("2006-01-01")).dt.days//7).astype(int)
fa=e[(e.kind=="failed_attempt")&(e.wk>=52)&(e.wk<96)].copy()
cost=e.assign(c=e.price/e.markup_c).groupby("DrugID").c.median()
COL={"CV":"#1b7837","FA":"#762a83","SB":"#d6604d"}; LAB={"CV":"Cruz Verde","FA":"FASA","SB":"Salcobrand"}
# (DrugID, lifting chain) -- chains chosen as the one whose price spikes (clean rise-then-revert)
picks=[(176,"CV"),(111,"SB"),(9,"SB"),(49,"CV"),(187,"SB"),(44,"SB")]; WIN=40
fig,ax=plt.subplots(2,3,figsize=(12.6,6.6))
for k,(d,lift) in enumerate(picks):
    a=ax[k//3,k%3]
    if fa[fa.DrugID==d].empty:                 # robust to ledger re-coding: skip a stale pick rather than crash
        a.axis("off"); continue
    nm=fa[fa.DrugID==d].drug.iloc[0]
    ev=fa[(fa.DrugID==d)&(fa.chain==lift)]; ev=ev.iloc[0] if len(ev) else fa[fa.DrugID==d].iloc[0]
    te=int(np.argmin(np.abs((dates-ev.date).dt.days)))
    sw=np.arange(max(0,te-18),min(len(dates),te+22))           # locate the spike peak near the event
    tp=sw[int(np.nanargmax(P[lift][sw,d]))]
    lo,hi=max(0,tp-WIN),min(len(dates),tp+WIN); ti=np.arange(lo,hi); cst=cost[d]/1000
    for c in ["CV","FA","SB"]:
        a.plot(dates[ti],P[c][ti,d]/1000,color=COL[c],lw=(2.4 if c==lift else 1.1),
               alpha=(1.0 if c==lift else 0.5),zorder=(3 if c==lift else 1),
               label=LAB[c]+(" (lifts)" if c==lift else ""))
    a.scatter([dates[tp]],[P[lift][tp,d]/1000],marker="*",s=110,color=COL[lift],edgecolor="k",lw=0.6,zorder=5)
    a.annotate("attempted lift",(dates[tp],P[lift][tp,d]/1000),textcoords="offset points",
               xytext=(0,6),ha="center",fontsize=7,color=COL[lift])
    a.axhline(cst,color="k",ls=":",lw=1.0); a.text(dates[lo],cst,"cost ",fontsize=6.5,va="bottom",ha="left",color="0.3")
    lows=[np.nanmin(P[c][ti,d])/1000 for c in COL]
    a.set_ylim(min(cst*0.85,min(lows)*0.95), max(P[lift][ti,d]/1000)*1.12)
    a.set_title(f"{nm} ({LAB[lift]})",fontsize=8.3)
    a.xaxis.set_major_formatter(mdates.DateFormatter("%d %b'%y")); a.tick_params(labelsize=6.3); a.margins(x=0.02)
    a.legend(fontsize=6.0,loc="lower right",framealpha=0.85)
fig.suptitle("Example war attempts",fontsize=10,y=1.005)
fig.supylabel("Transacted price (CLP '000)",fontsize=9); fig.tight_layout()
fig.savefig(os.path.join(ROOT,"paper","manuscript","fig_war_attempts.pdf"),bbox_inches="tight")
fig.savefig(os.path.join(ROOT,"output","fig_war_attempts.png"),dpi=150,bbox_inches="tight")
print("wrote; picks:",picks)
