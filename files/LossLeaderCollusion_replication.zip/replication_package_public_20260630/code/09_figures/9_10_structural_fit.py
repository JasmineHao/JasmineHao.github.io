"""9_10_structural_fit.py -- the two headline section-5 figures from the ESTIMATED v3 model.
  fig_full_structural.pdf : cumulative coordinations model vs data by lab-size tercile (the wave fit)
                            + lab coordination-week vs log lab size (the size sequence).
  fig_spillover_model.pdf : the one-shot undercut gain G(alpha) flipping sign at the ad ban.
Reads output/full_structural.json (estimated theta).  Output -> paper/manuscript/.
"""
import os, json, importlib.util
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
os.environ.setdefault("IJ", "1"); os.environ.setdefault("PERP_TERMINAL", "1")
spec = importlib.util.spec_from_file_location("fs", os.path.join(ROOT, "code", "06_dynamic_final", "full_structural_mpe.py"))
fs = importlib.util.module_from_spec(spec); spec.loader.exec_module(fs)
fs.PSI_LEAD = [0.60, 0.80, 0.00]; fs.CHAIN_SHARE = np.array([0.453, 0.309, 0.239])
fs.TAU_LEAD = 3.0; fs.TAU_RENT = 0.12; fs.SCRUT_LEARN = 1
D, WKS = fs.D, fs.WKS
H = json.load(open(os.path.join(ROOT, "output", "hetmu_mpe.json")))             # psi-leadership + learned-belief headline
fs.SCRUT_M = float(H["scrut_m"])
theta = [float(H["mu_bar"])] + [H["theta"][k] for k in ["lam", "tau_eng", "t0", "a0", "b0", "zeta", "chi", "rho", "g", "lam_cut"]]   # 11-vector (rho dummy, unused under SCRUT_LEARN)
WWIN = float(H["w_window"]); ONE = dict(onetime=True, w_window=WWIN, arrivals_throughout=True, kappa_chain=[float(H["mu_bar"])]*3)   # symmetric mu
A_POST = json.load(open(os.path.join(ROOT, "output", "demand_params.json")))["headline"]["alpha_post"]
COL = ["#1b7837", "#762a83", "#d6604d"]      # terciles small/mid/big
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})

# --- lab-size terciles (by lab revenue W) ---
DC = D.dropna(subset=["coord_wk"]).copy()
labW = DC.groupby("lab").W.first()
terc = {L: int(np.digitize(np.log(labW[L]), np.quantile(np.log(labW), [1/3, 2/3]))) for L in labW.index}
DC["terc"] = DC.lab.map(terc)


def cum_by_terc(cwk_drug_to_terc_week):
    """weeks x 3 cumulative-coordination matrix."""
    C = np.zeros((len(WKS), 3))
    for (te, wk) in cwk_drug_to_terc_week:
        wi = wk - WKS[0]
        if 0 <= wi < len(WKS):
            C[wi:, te] += 1
    return C


# data cumulative by tercile
data_pts = [(int(r.terc), int(r.coord_wk)) for r in DC.itertuples()]
Cdata = cum_by_terc(data_pts)
# model: average several representative paths
Cmod = np.zeros((len(WKS), 3))
NSIM = 40
for s in range(NSIM):
    cwk, _, _ = fs.one_path(theta, seed=100 + s, **ONE)
    pts = [(terc[D.loc[j, "lab"]], wk) for j, wk in cwk.items() if D.loc[j, "lab"] in terc]
    Cmod += cum_by_terc(pts)
Cmod /= NSIM
wk = np.array(WKS)

fig, ax = plt.subplots(1, 2, figsize=(9.2, 2.1))
labs3 = ["small labs", "mid labs", "big labs"]
for te in range(3):
    ax[0].plot(wk, Cdata[:, te], color=COL[te], lw=2.0, label=f"{labs3[te]} (data)")
    ax[0].plot(wk, Cmod[:, te], color=COL[te], lw=1.3, ls="--", alpha=0.9)
ax[0].axvline(96, color="0.5", ls=":", lw=1); ax[0].text(96.3, ax[0].get_ylim()[1]*0.05, "ban", fontsize=7, color="0.4")
ax[0].set_xlabel("week"); ax[0].set_ylabel("cumulative coordinations")
ax[0].set_title("A. The coordination wave", fontsize=8.5)
ax[0].legend(fontsize=6.5, loc="upper left")

# Panel B: lab coordination week vs log lab size (data + one model realization)
lab_med_data = DC.groupby("lab").coord_wk.median()
lw = np.log(labW.reindex(lab_med_data.index))
ax[1].scatter(lw, lab_med_data.values, s=18, color="#d6604d", label="data", zorder=3)
cwk, _, _ = fs.one_path(theta, seed=7, **ONE)
mod_lab = {}
for j, wkk in cwk.items():
    mod_lab.setdefault(D.loc[j, "lab"], []).append(wkk)
ml = {L: np.median(v) for L, v in mod_lab.items() if L in labW.index}
ax[1].scatter([np.log(labW[L]) for L in ml], list(ml.values()), s=14, facecolors="none",
              edgecolors="#1b7837", label="model", zorder=2)
b, a = np.polyfit(lw.values, lab_med_data.values, 1)
xs = np.array([lw.min(), lw.max()]); ax[1].plot(xs, a + b*xs, color="0.3", lw=1)
ax[1].set_xlabel("log lab revenue"); ax[1].set_ylabel("median coordination week")
ax[1].set_title("B. Timing vs. lab size", fontsize=8.5)
ax[1].legend(fontsize=7, loc="upper right")
fig.tight_layout()
dst = os.path.join(ROOT, "paper", "manuscript", "fig_full_structural.pdf")
fig.savefig(dst, bbox_inches="tight"); plt.close(fig)
print("wrote", dst)

# --- Figure 7 (REDESIGNED): future collusion profit vs. one-shot deviation gain, per drug, pre/post ban.
# What determines coordination is NEVER the alpha axis -- it is the ONE-SHOT deviation gain measured against
# ALL FUTURE payoff.  So we plot both quantities directly, for every drug, before and after the ban:
#   X = one-shot undercut gain  G01_j = kappa*ds01_j + mg01_j   (>0: undercutting pays = war;
#                                                                <0: holding the coordinated price is the
#                                                                static best response = coordination)
#   Y = future collusion profit = delta * escape value (V1_j - V0_ij, averaged over the three chains).
# The ban leaves the future payoff essentially UNCHANGED (and ~20x larger than the one-shot gain, so the
# repeated-game IC is always slack); what flips is the SIGN of the one-shot gain G01 -- the static-Nash margin.
kappa = float(np.mean(H["mu"]))                                  # mean store-traffic value (endolab)
G01 = {r: kappa * fs.DS[f"ds01_{r}"] + fs.DS[f"mg01_{r}"] for r in ("pre", "post")}
DV1ch = fs.value_funcs(kappa)
wi = {"pre":  max(i for i, t in enumerate(fs.WKS) if t <  fs.BAN),
      "post": min(i for i, t in enumerate(fs.WKS) if t >= fs.BAN)}
fut = {r: fs.DELTA * np.mean([DV1ch[i][wi[r]] for i in range(3)], axis=0) for r in ("pre", "post")}
XCLIP, YTOP = 3.0, 35.0
ratio = float(np.median(np.concatenate([fut["pre"], fut["post"]])) / np.median(np.abs(np.concatenate([G01["pre"], G01["post"]]))))
fig, ax = plt.subplots(figsize=(6.8, 2.6))
for r, col, lab in [("pre", "#c0392b", "ads on (pre-ban)"), ("post", "#1f6f3f", "ads banned (post-ban)")]:
    ax.scatter(np.clip(G01[r], -XCLIP, XCLIP), np.clip(fut[r], 0, YTOP), s=13, c=col, alpha=0.32, edgecolors="none", label=lab)
mp = (float(np.median(G01["pre"])),  float(np.median(fut["pre"])))            # the typical drug, ads on
mq = (float(np.median(G01["post"])), float(np.median(fut["post"])))           # ... and after the ban
ax.annotate("", xy=mq, xytext=mp, arrowprops=dict(arrowstyle="-|>", color="0.1", lw=2.2))   # slides left across 0, same height
ax.scatter(*mp, s=200, marker="D", c="#c0392b", edgecolors="white", lw=1.3, zorder=6)
ax.scatter(*mq, s=200, marker="D", c="#1f6f3f", edgecolors="white", lw=1.3, zorder=6)
ax.text(mp[0]+0.14, mp[1]-1.2, f"median, ads on\n$G_j={mp[0]:+.2f}$", fontsize=6.3, color="#7a160c", va="top")
ax.text(mq[0]-0.14, mq[1]+1.6, f"median, banned\n$G_j={mq[0]:+.2f}$", fontsize=6.3, color="#0a5020", ha="right", va="bottom")
ax.axvline(0, color="0.12", lw=1.5)                                           # the static-Nash flip
ax.set_xlim(-XCLIP, XCLIP); ax.set_ylim(0, YTOP)
ax.text(-2.92, YTOP*0.975, "$G_j<0\\Rightarrow$ COORDINATION", fontsize=6.6, color="#0a5020", va="top")
ax.text(0.16, YTOP*0.975, "$G_j>0\\Rightarrow$ WAR", fontsize=6.6, color="#a01010", va="top")
ax.text(1.18, YTOP*0.52, f"future payoff $\\approx\\!{ratio:.0f}\\times$ one-shot gain\n$\\Rightarrow$ IC slack; only $\\mathrm{{sign}}(G_j)$ flips",
        fontsize=6.4, color="0.2", va="center")
nout = int((fut["pre"] > YTOP).sum() + (fut["post"] > YTOP).sum())
ax.text(-2.92, 0.7, f"{nout} high-stake drugs $>{YTOP:.0f}$ clipped to top", fontsize=5.4, color="0.55", ha="left")
ax.set_xlabel("one-shot undercut gain $G_j$  (model profit units; clipped at $\\pm3$)")
ax.set_ylabel("future collusion profit $\\delta\\,\\Delta V^1_{j}$  (PV)")
ax.set_title("One-shot gain vs.\\ future payoff", fontsize=9.6)
ax.legend(fontsize=7.0, loc="lower right", framealpha=0.92)
fig.tight_layout()
dst2 = os.path.join(ROOT, "paper", "manuscript", "fig_spillover_model.pdf")
fig.savefig(dst2, bbox_inches="tight")
fig.savefig(os.path.join(ROOT, "output", "fig_spillover_model.png"), dpi=155, bbox_inches="tight")
plt.close(fig)
nflip = int(((G01["pre"] > 0) & (G01["post"] < 0)).sum())
print("wrote", dst2, f"| future ~const {np.median(fut['pre']):.1f}->{np.median(fut['post']):.1f}; "
      f"flips +->- for {nflip}/{fs.J}; future/one-shot ~ {ratio:.0f}x; {nout} clipped")
