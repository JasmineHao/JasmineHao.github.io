"""9_5_example_coord.py -- Figure 3: one drug's three-chain price path with its
FULL event sequence (Sildenafil, DrugID 80) -- war deviations, the two coordinated
tier steps, and the failed post-cartel push.  Restyle + enrichment of
fig_example_coord.pdf.  Output: fig_example_coord.pdf.
"""
import os, pickle
import numpy as np
import pandas as pd
import figstyle as fs
import matplotlib.pyplot as plt

DATA = os.path.join(fs.ROOT, "data", "processed")
d = pickle.load(open(os.path.join(DATA, "data_objects.pkl"), "rb"))
date = pd.to_datetime(pd.read_csv(os.path.join(DATA, "date.csv"))["Date"])
DRUG = 80
ing = d["attr"]["ingredient"].iloc[DRUG]

df = pd.DataFrame({"Date": date, "CV": d["price_cv"].values[:, DRUG],
                   "FA": d["price_fa"].values[:, DRUG], "SB": d["price_sb"].values[:, DRUG]}).set_index("Date").sort_index()
df = df.rolling(7, min_periods=3).mean() / 1000.0
df["wk"] = ((df.index - pd.Timestamp("2006-01-01")).days / 7.0)
df = df[(df.wk >= 60) & (df.wk <= 142)]               # Apr 2007 .. Sep 2008 (capture post-cartel)

ev = pd.read_csv(os.path.join(fs.ROOT, "output", "v16_events_unified.csv"), parse_dates=["date"])
ev["wk"] = ((ev.date - pd.Timestamp("2006-01-01")).dt.days // 7).astype(int)
evd = ev[ev.DrugID == DRUG].sort_values("wk")

fs.setup()
fig, ax = plt.subplots(figsize=(7.4, 2.5))
fs.war_shade(ax)
for ch in ["CV", "FA", "SB"]:
    ax.plot(df.wk, df[ch], color=fs.CHAIN[ch], lw=1.5,
            label={"CV": "Cruz Verde", "FA": "FASA", "SB": "Salcobrand"}[ch])
top = ax.get_ylim()[1]
pl = (df.CV + df.FA + df.SB) / 3.0
for _, r in evd.iterrows():
    w = r.wk
    if not (60 <= w <= 142):
        continue
    yv = float(pl.iloc[(df.wk - w).abs().argmin()])
    if r.kind == "coordination":
        ax.axvline(w, color=fs.BLUE, ls=":", lw=0.8)
        ax.annotate(f"$\\ell_{int(r.from_tier)}\\!\\to\\!\\ell_{int(r.to_tier)}$\n({r.chain})",
                    xy=(w, yv), xytext=(w - 1.5, yv + 2.4), fontsize=6.6, color=fs.BLUE, ha="center",
                    arrowprops=dict(arrowstyle="->", color=fs.BLUE, lw=0.7))
    elif r.kind == "failed_attempt":
        # the failed push is a brief Salcobrand price SPIKE that then reverts; the ledger week records
        # it once the price is back down, so snap the X to the local SB maximum (the spike peak itself).
        win = df[(df.wk >= w - 5) & (df.wk <= w + 1)]
        sp = win.SB.idxmax(); wx = float(win.wk[sp]); ysb = float(win.SB[sp])
        ax.scatter([wx], [ysb], marker="x", s=46, color=fs.DRED, lw=1.4, zorder=6)
        ax.annotate("failed push\n(post-cartel)", xy=(wx, ysb), xytext=(wx - 7.5, ysb - 1.6),
                    fontsize=6.6, color=fs.DRED, ha="center", arrowprops=dict(arrowstyle="->", color=fs.DRED, lw=0.7))
for x, lab, c in [(fs.WK_CONAR, "CONAR", fs.GOLD), (fs.WK_BAN, "Civil Court ban", "0.45")]:
    ax.axvline(x, color=c, ls="--", lw=0.8); ax.text(x + 0.5, ax.get_ylim()[0] + 0.2, lab, fontsize=6.2, color=c, rotation=90, va="bottom")
fs.date_xaxis(ax, 60, 142, step=8)
ax.set_ylabel("price (CLP'000s, 7-day avg.)")
ax.set_title(f"Full event sequence for one drug: {ing} (war $\\to$ cartel $\\to$ rent $\\to$ failed post-cartel push)", fontsize=8.4)
ax.legend(loc="upper left", ncol=3, fontsize=7.4)
fs.save(fig, "fig_example_coord")
print(f"drug {DRUG} {ing}; events: {evd.kind.value_counts().to_dict()}")
