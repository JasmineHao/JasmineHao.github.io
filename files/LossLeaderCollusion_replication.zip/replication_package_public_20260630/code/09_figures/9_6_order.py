"""9_6_order.py -- Figure 4: order of coordination across drugs (two panels).
Large-market and high-below-cost-loss drugs coordinate first, in BOTH the first
(0->1) and second (1->2) coordinated step.  Restyle of fig4_order_two_panels.pdf;
Output: fig4_order_two_panels.pdf.
"""
import os, pickle
import numpy as np
import pandas as pd
import figstyle as fs
import matplotlib.pyplot as plt

DATA = os.path.join(fs.ROOT, "data", "processed")


def _drug_coord_dates_by_tier():
    ep = pd.read_csv(os.path.join(DATA, "enriched_event_panel.csv"),
                     parse_dates=["event_date"])
    sw = ep[(ep["coord_success"] == 1) & (ep["in_window"] == True)]
    df01 = (sw[sw["from_tier"] == 0]
            .groupby("DrugID")["event_date"].min()
            .reset_index().rename(columns={"event_date": "first_evt_date"}))
    df12 = (sw[sw["from_tier"] == 1]
            .groupby("DrugID")["event_date"].min()
            .reset_index().rename(columns={"event_date": "first_evt_date"}))
    return df01, df12


def _drug_marketsize_preban():
    d = pickle.load(open(os.path.join(DATA, "data_objects.pkl"), "rb"))
    qcv, qfa, qsb = d["quantity_cv"].values, d["quantity_fa"].values, d["quantity_sb"].values
    pcv, pfa, psb = d["price_cv"].values, d["price_fa"].values, d["price_sb"].values
    n_drugs = qcv.shape[1]
    end = 84 * 7
    total_q = np.nansum(qcv[:end] + qfa[:end] + qsb[:end], axis=0)
    total_r = np.nansum(pcv[:end] * qcv[:end] + pfa[:end] * qfa[:end] + psb[:end] * qsb[:end], axis=0)
    weeks_pre = end / 7
    return pd.DataFrame({
        "DrugID": np.arange(n_drugs),
        "market_size_units": total_q / weeks_pre,
        "market_size_revenue_M": total_r / weeks_pre / 1e6,
    })

df01, df12 = _drug_coord_dates_by_tier()
ms = _drug_marketsize_preban()
mb = pd.read_csv(os.path.join(fs.ROOT, "output", "r2_mu_preban_by_firm.csv"))
mb["daily_loss"] = np.maximum(mb["c"] - mb["p"], 0.0) * mb["q"] * 1000 / 1e6
bs = (mb.groupby(["DrugID", "TimeID"])["daily_loss"].sum().reset_index()
        .groupby("DrugID")["daily_loss"].mean().rename("preban_daily_loss_clp").reset_index())
for df in (df01, df12):
    pass
df01 = df01.merge(ms, on="DrugID").merge(bs, on="DrugID", how="left").fillna({"preban_daily_loss_clp": 0.0})
df12 = df12.merge(ms, on="DrugID").merge(bs, on="DrugID", how="left").fillna({"preban_daily_loss_clp": 0.0})
for df in (df01, df12):
    df["wk"] = ((pd.to_datetime(df.first_evt_date) - pd.Timestamp("2006-01-01")).dt.days // 7)

C01, C12 = fs.TEAL, fs.DRED
fs.setup()
fig, (axA, axB) = plt.subplots(1, 2, figsize=(9.6, 4.0), gridspec_kw={"wspace": 0.26})
rng = np.random.default_rng(2026)
for ax, ycol, ylab, ttl in [(axA, "market_size_revenue_M", "pre-ban market size (CLP M/wk)", "(A) Large markets coordinate first"),
                            (axB, "preban_daily_loss_clp", "avg.\\ daily below-cost loss (CLP mn/day)", "(B) Highest-loss drugs coordinate first")]:
    for df, c, mk, lab in [(df01, C01, "s", f"Tier $0\\!\\to\\!1$ ($N={len(df01)}$)"),
                           (df12, C12, "^", f"Tier $1\\!\\to\\!2$ ($N={len(df12)}$)")]:
        jit = rng.uniform(-0.4, 0.4, size=len(df))
        ax.scatter(df.wk + jit, df[ycol], s=9, color=c, alpha=0.20, edgecolor="none", zorder=1)
        x, y = df.wk.values.astype(float), df[ycol].values.astype(float)
        v = np.isfinite(x) & np.isfinite(y)
        if v.sum() > 3:
            cc = np.polyfit(x[v], y[v], 2); xs = np.linspace(x[v].min(), x[v].max(), 80)
            ax.plot(xs, np.polyval(cc, xs), color=c, lw=1.6, ls=("-" if mk == "s" else "--"),
                    label=lab, zorder=3)
    ax.axvline(fs.WK_OFICIO, color=fs.GOLD, ls="--", lw=0.7)
    fs.date_xaxis(ax, 96, 122, step=4)
    ax.set_ylabel(ylab); ax.set_title(ttl, fontsize=8.8)
    if ax is axB:
        ax.set_ylim(bottom=0)
    ax.legend(loc="upper right", fontsize=7.6)
fs.save(fig, "fig4_order_two_panels")
print(f"df01 {len(df01)}, df12 {len(df12)}")
