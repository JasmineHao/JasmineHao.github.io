"""9_2_failed_attempts.py
=========================
Coordination events decomposed by tier transition and by initiating chain --- a
faithful restyle of the earlier two-panel events figure (no model-specific
language).
  Panel A: weekly events split four ways -- Success 0->1, Success 1->2 (blue
           shades) vs. Failed 0->1, Failed 1->2 (red shades).  The wave: failed
           0->1 attempts cluster pre-cartel, successful 0->1 dominate Dec-Jan,
           1->2 emerges Feb-Mar, failed 1->2 appears after the FNE Oficio.
  Panel B: the same events by initiating chain (success vs. failed) -- Salcobrand
           is the de facto leader.
Source data: enriched_event_panel.csv (carries from/to tier for FAILED attempts,
which v16 does not).  Output: fig_failed_attempts.pdf.
"""
import os
import numpy as np
import pandas as pd
import figstyle as fs
import matplotlib.pyplot as plt

ROOT = fs.ROOT
ep = pd.read_csv(os.path.join(ROOT, "data", "processed", "enriched_event_panel.csv"), parse_dates=["event_date"])
ep["wk"] = ((ep.event_date - pd.Timestamp("2006-01-01")).dt.days // 7).astype(int)
LO, HI = 52, 156                                   # Jan 2007 .. Dec 2008 (the full episode: war -> cartel -> aftermath)
w = ep[(ep.wk >= LO) & (ep.wk <= HI)].copy()

SB_SUCC = "#1f5c8a"; SB_SUCC2 = "#6aa0c8"          # success: dark / light blue
FAIL1 = "#9e2b1e"; FAIL2 = "#e0846a"               # failed: dark / light red
IDX = range(LO, HI + 1)
def wkcount(s):
    return s.groupby("wk").size().reindex(IDX, fill_value=0)
# SUCCESS (coordinations + rent) from v16 -- it carries the full rent series through Dec'08;
# the hand-coded enriched panel truncates the rent at the last hand-coded success (11 Apr).
e16 = pd.read_csv(os.path.join(ROOT, "output", "v16_events_unified.csv"), parse_dates=["date"])
e16["wk"] = ((e16.date - pd.Timestamp("2006-01-01")).dt.days // 7).astype(int)
co16 = e16[(e16.kind == "coordination") & (e16.wk >= LO) & (e16.wk <= HI)]
s01 = wkcount(co16[co16.to_tier == 1])     # 220 first coordinations (the Dec--Mar wave)
s12 = wkcount(co16[co16.to_tier == 2])     # 143 rent steps -- keep growing post-Oficio through Dec'08
# failed lifts stay from the clean hand-coded panel (v16 over-flags them); tier by coord state
cwk1 = e16[(e16.kind == "coordination") & (e16.to_tier == 1)].groupby("DrugID").wk.min()
fa = w[w.kind_clean == "failed_attempt"].copy()
fa["cwk1"] = fa.DrugID.map(cwk1)
fa["ftier2"] = fa.cwk1.notna() & (fa.wk >= fa.cwk1)
f01 = wkcount(fa[~fa.ftier2]); f12 = wkcount(fa[fa.ftier2])
wks = np.arange(LO, HI + 1)

fs.setup()
fig, (axA, axB) = plt.subplots(1, 2, figsize=(8.6, 3.2), gridspec_kw={"width_ratios": [2.7, 1]})

# ---- Panel A: by tier transition --------------------------------------------
bot = np.zeros(len(wks))
for ser, c, lab in [(s01, SB_SUCC, "success $0\\!\\to\\!1$"), (s12, SB_SUCC2, "success $1\\!\\to\\!2$"),
                    (f01, FAIL1, "failed $0\\!\\to\\!1$"), (f12, FAIL2, "failed $1\\!\\to\\!2$")]:
    axA.bar(wks, ser.values, bottom=bot, width=0.9, color=c, label=f"{lab} ($n={int(ser.sum())}$)")
    bot = bot + ser.values
# ---- cumulative success / fail on a TWIN axis (right) ----
axA2 = axA.twinx()
cum_s = np.cumsum((s01 + s12).values); cum_f = np.cumsum((f01 + f12).values)
axA2.plot(wks, cum_s, color="#0d3b5e", lw=1.9, label=f"cumulative success ($n={int(cum_s[-1])}$)", zorder=5)
axA2.plot(wks, cum_f, color="#7a160c", lw=1.9, ls="--", label=f"cumulative failed ($n={int(cum_f[-1])}$)", zorder=5)
axA2.set_ylim(0, max(cum_s[-1], cum_f[-1]) * 1.08)
axA2.set_ylabel("cumulative events", fontsize=8)
top = axA.get_ylim()[1]
for x, lab, c, fy in [(fs.WK_CV, "CV ad\ncampaign", "#9e2b1e", 0.96),
                      (fs.WK_CONAR, "CONAR\n7 Sep", "#7a4fb0", 0.78),
                      (fs.WK_BAN, "ad ban\n6 Nov", "0.4", 0.60),
                      (fs.WK_T0, "1st coord.\n3 Dec", "#1f5c8a", 0.96),
                      (fs.WK_OFICIO, "FNE Oficio\n31 Mar", fs.GOLD, 0.60)]:
    axA.axvline(x, color=c, ls="--", lw=0.8); axA.text(x + 0.4, top * fy, lab, fontsize=5.9, color=c, va="top")
fs.date_xaxis(axA, LO, HI, step=13)                # quarterly ticks over the 2-year span
axA.set_ylabel("events / week")
axA.set_title("(A) Events by tier transition", fontsize=8.8)
h1, l1 = axA.get_legend_handles_labels(); h2, l2 = axA2.get_legend_handles_labels()
axA.legend(h1 + h2, l1 + l2, loc="upper left", fontsize=6.2, ncol=1, framealpha=0.85)

# ---- Panel B: each chain split Cartel vs Post-cartel (the rent deepening) ----
chains = ["CV", "FA", "SB"]
CART0, CART1 = pd.Timestamp("2007-12-03"), pd.Timestamp("2008-03-31")
co16d = e16[e16.kind == "coordination"]              # coords + rents (with dates), v16
fad   = w[w.kind_clean == "failed_attempt"]          # failed lifts, hand-coded (clean)
def by_chain(df, dcol, ccol, post):
    d = df[df[dcol] > CART1] if post else df[(df[dcol] >= CART0) & (df[dcol] <= CART1)]
    vc = d[ccol].value_counts(); return np.array([vc.get(c, 0) for c in chains])
x = np.arange(3); ww = 0.38
for off, post, lbl, al in [(-ww / 2, False, "Cartel", 0.95), (ww / 2, True, "Post-cartel", 0.5)]:
    sv = by_chain(co16d, "date", "chain", post)
    fv = by_chain(fad, "event_date", "leader_firm", post)
    axB.bar(x + off, sv, ww, color=SB_SUCC, alpha=al, edgecolor="white", lw=0.4, label=f"success, {lbl}")
    axB.bar(x + off, fv, ww, bottom=sv, color=FAIL1, alpha=al, edgecolor="white", lw=0.4, label=f"failed, {lbl}")
    for xi in range(3):
        if sv[xi] + fv[xi] > 0:
            axB.text(x[xi] + off, sv[xi] + fv[xi] + 3, f"{int(sv[xi] + fv[xi])}", ha="center", fontsize=6.0, color=fs.INK)
axB.set_xticks(x); axB.set_xticklabels(["Cruz\nVerde", "FASA", "Salco-\nbrand"], fontsize=7.6)
axB.set_ylabel("initiations")
axB.set_title("(B) By initiator: cartel vs post-cartel", fontsize=8.8)
axB.legend(loc="upper left", fontsize=5.8, framealpha=0.9)
fs.save(fig, "fig_failed_attempts")
print(f"A: s01={int(s01.sum())} s12={int(s12.sum())} f01={int(f01.sum())} f12={int(f12.sum())}  | "
      f"B: CV {sv[0]}/{fv[0]} FA {sv[1]}/{fv[1]} SB {sv[2]}/{fv[2]}")
