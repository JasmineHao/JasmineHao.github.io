"""9_14_figure6_specs.py -- Figure 6: structural specifications versus the data (THREE panels).
For the one-time headline and five knockouts -- each RE-ESTIMATED under the identical SMM criterion
(output/knockouts_onetime.json) -- three panels over Jan-2007 -> Dec-2008, all drawn from the SAME
one_path() the estimator simulates so the figure and Table tab:spec_fit are one object:
  (a) regime PRICE LEVEL (model AND data quantity-weighted across drugs on the same fixed basket),
  (b) cumulative SUCCESSFUL coordinations (0->1 wave + 1->2 rent),
  (c) cumulative FAILED lifts.
The price panel alone cannot separate the estimate from "no belief" (both recover); the success and
failed panels do -- no belief FLOODS the war (coordinates ~220 before the ban vs the data's few),
learn-only (no focal jump) ignites far too slowly, belief-only / no-spillover mis-size the wave.
Output -> paper/manuscript/fig_belief_specs.pdf
"""
import os, json, pickle, importlib.util
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

# ===== the model's OWN dynamic-game war decision: the undercut gain G01 = kappa*ds01 + mg01 =====
# In full_structural.py (L564) each spec's firms undercut the coordinated price iff its aggregate
# pre-ban undercut gain G01_pre > 0 (WAR -> price dives to the war floor); if G01_pre <= 0 they
# HOLD (NO war -> the price stays put at the pre-coordination level).  We read ds01/mg01 from the
# estimated module (fs.DS) and form each spec's gain with the spec's OWN store-traffic value mu:
# the headline (mu~9.33) has G01_pre = +0.44 (war); the no-spillover spec (mu=0) has G01_pre = -1.18
# (the margin term alone -- undercutting loses money with no footfall) so it NEVER undercuts and the
# price stays FLAT at the common L_PREWAR start.  No Bertrand-with-footfall floor: the decision is
# binary (undercut or not), and "don't undercut" means "stay at the starting level," not 15.25.
os.environ.setdefault("IJ", "1"); os.environ.setdefault("PERP_TERMINAL", "1")
spec = importlib.util.spec_from_file_location("fs", os.path.join(ROOT, "code", "06_dynamic_final", "full_structural_mpe.py"))
fs = importlib.util.module_from_spec(spec); spec.loader.exec_module(fs)
fs.PSI_LEAD = [0.60, 0.80, 0.00]; fs.CHAIN_SHARE = np.array([0.453, 0.309, 0.239])
fs.TAU_LEAD = 3.0; fs.TAU_RENT = 0.12; fs.SCRUT_LEARN = 1
D, WKS, BAN, AUG, WK0, OFICIO = fs.D, fs.WKS, fs.BAN, fs.AUG, fs.WK0, fs.OFICIO
DS = fs.DS                                                # undercut primitives ds01/mg01 from the estimated module
def spec_has_war(spec_mu):
    """The model's decision for a spec with store-traffic value spec_mu: undercut the coordinated price
    (WAR -> dive) iff the aggregate pre-ban undercut gain G01_pre = (mu*ds01 + mg01).mean() > 0."""
    return float((spec_mu * DS["ds01_pre"] + DS["mg01_pre"]).mean()) > 0.0
K = ["kappa", "lam", "tau_eng", "t0", "a0", "b0", "zeta", "chi", "rho", "g", "lam_cut"]   # endolab 11-vector incl. lam_cut (symmetric up/down); w_window calibrated at 26. one_path uses theta[:10], so the time-paths shown are the up-only wave
HI = WKS[-1]
p0, p1, p2 = D.pw.to_numpy(), D.p1.to_numpy(), D.p2.to_numpy()
def wk2date(w): return pd.Timestamp("2006-01-02") + pd.Timedelta(weeks=int(w))
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})

# ===== the six specifications, each off the SAME estimated headline THETA (re-simulated knockouts) =====
H = json.load(open(os.path.join(ROOT, "output", "hetmu_mpe.json")))
fs.SCRUT_M = float(H["scrut_m"])
REST_K = ["lam", "tau_eng", "t0", "a0", "b0", "zeta", "chi", "rho", "g"]
THETA = [float(H["mu_bar"])] + [float(H["theta"][k]) for k in REST_K] + [float(H["theta"]["lam_cut"])]
MU = [float(H["mu_bar"])] * 3                                   # symmetric mu (count); leadership is psi (module global)
os.environ["HOMOG"] = "1"            # homogeneous (median-alpha) demand instance: the misspecified-demand spec
_sh = importlib.util.spec_from_file_location("fs_h", os.path.join(ROOT, "code", "06_dynamic_final", "full_structural_mpe.py"))
fs_h = importlib.util.module_from_spec(_sh); _sh.loader.exec_module(fs_h)
fs_h.PSI_LEAD = [0.60, 0.80, 0.00]; fs_h.CHAIN_SHARE = np.array([0.453, 0.309, 0.239])
fs_h.TAU_LEAD = 3.0; fs_h.TAU_RENT = 0.12; fs_h.SCRUT_LEARN = 1; fs_h.SCRUT_M = float(H["scrut_m"])
os.environ.pop("HOMOG", None)
homog_theta = list(THETA); MU_homog = MU                       # homog spec: re-simulate the headline under median-alpha demand
g = float(H["theta"]["g"])                                     # the realized Aug-campaign steepening (for the war-price ramp)
def _th(s):
    th = list(THETA)
    if s == "RC2": th[0] = 0.0                                  # no spillover: mu_bar=0
    return th, 26.0                                             # all specs off the same estimated headline THETA
# name, json-key, per-spec one_path kwargs (belief mode / alpha switch), colour, linestyle, marker
SPECS = [("Estimated",                            "full",       {},                            "#c0392b", "-",  "o"),
         (r"No belief ($b\!\equiv\!1$)",           "nobel",      dict(bmode="nobel"),           "#2166ac", "--", "s"),
         ("Jump, no learning",                    "jump_only",  dict(bmode="jump_only"),       "#d95f02", "-.", "D"),
         (r"Learning, no jump ($\zeta\!=\!0$)",    "learn_only", dict(bmode="learn_only"),      "#1b7837", ":",  "^"),
         ("No demand collapse",                   "C1",         dict(no_alpha_collapse=True),  "#666666", "--", "P"),
         (r"No spillover ($\mu\!=\!0$)",           "RC2",        {},                            "#6a51a3", "-.", "*")]

# 0->1 war-price ramp: falls from the tier-1 plateau toward the war floor, steeper after the Aug campaign.
# Renormalise so cum[0] = 0: every spec's price emanates from EXACTLY the common L_PREWAR start (the raw
# cumsum has cum[0] > 0, which would shift each line's first point part-way toward its own floor).
wts = np.array([(1 + g) if (WK0 + i) >= AUG else 1.0 for i in range(BAN - WK0)])
cum = np.cumsum(wts) / wts.sum()
cum = (cum - cum[0]) / (1.0 - cum[0])                # cum[0] -> 0 so the ramp begins at L_PREWAR for all specs
NSIM = 60
KREC = 12          # weeks for a coordinated drug's price to climb from the war floor to its tier level (tuned to the data recovery; structural counts unchanged)
def sim_paths(theta, w_window, kw, has_war, N=NSIM, fs_mod=fs, mu=MU):
    """Average per-week (price, cumulative successful coords incl. rent, cumulative failed lifts),
    all from one_path() under the one-time arrivals-throughout regime -- the exact path the estimator uses.
    fs_mod selects the demand instance (fs = headline hetIV; fs_h = homogeneous median-alpha demand).
    has_war is the spec's OWN dynamic-game decision (G01_pre > 0): if True the price dives from the common
    L_PREWAR start to the war trough (anchored to the data trough L_WAR_DATA) and recovers as drugs
    coordinate; if False (mu=0, G01_pre < 0) the firms never undercut, so the price stays FLAT at the
    common L_PREWAR start across the whole pre-coordination window -- the model says "hold, stay put."
    The coordinated-recovery baseline (the level a drug climbs FROM) is the war trough when there is a
    war, and L_PREWAR when there is not, so both regimes start every line at the same point."""
    wbase = L_WAR_DATA if has_war else L_PREWAR          # the war floor (war specs) / the held level (no-war specs)
    def wlev(t):                                         # war price at week(s) t: L_PREWAR at the start, descending
        t = np.asarray(t, float)                         #   to wbase along the ramp; flat at L_PREWAR if no war
        if not has_war:
            return np.full(t.shape, L_PREWAR)
        idx = np.clip(t - WK0, 0, len(cum) - 1).astype(int)
        ramp = L_PREWAR - (L_PREWAR - wbase) * cum[idx]
        return np.where(t < BAN, ramp, wbase)
    price = np.zeros(len(WKS)); succ = np.zeros(len(WKS)); fail = np.zeros(len(WKS))
    for s in range(N):
        cwk, cwk2, fwk = fs_mod.one_path(theta, seed=300 + s, onetime=True, w_window=w_window,
                                     arrivals_throughout=True, bmode=kw.get("bmode", "full"),
                                     no_alpha_collapse=kw.get("no_alpha_collapse", False), kappa_chain=mu)
        farr = np.array(fwk) if len(fwk) else np.empty(0)
        w1 = np.array(list(cwk.values())); w2 = np.array(list(cwk2.values()))
        cw1 = np.full(len(D), np.inf); cw2 = np.full(len(D), np.inf)   # per-drug 0->1 / 1->2 weeks (inf = never)
        for j, w in cwk.items():  cw1[j] = w
        for j, w in cwk2.items(): cw2[j] = w
        for wi, t in enumerate(WKS):
            succ[wi] += (int((w1 <= t).sum()) if len(w1) else 0) + (int((w2 <= t).sum()) if len(w2) else 0)
            fail[wi] += int((farr <= t).sum()) if len(farr) else 0
            # GRADUAL price recovery (not a snap): a coordinated drug's price climbs from the war level
            # PREVAILING AT ITS coordination week toward p1 over KREC weeks after its 0->1 week, then from
            # p1 toward p2 over KREC weeks after its 1->2 week -- in the data prices rise over ~a quarter,
            # not instantly.  Recovering from the per-drug coordination-week war level (wlev(cw1)) -- not a
            # fixed trough -- is what makes every line emanate from the COMMON L_PREWAR start: a drug that
            # coordinates at the window start leaves the war at L_PREWAR (cum[0]=0), so it begins recovery
            # at ~7, never snapping down to the trough first.  Un-coordinated drugs sit at the war price
            # wlev(t) (a ramp descending from L_PREWAR to the trough, then the trough).  The structural
            # coordination/rent COUNTS are unchanged.  A spec whose model decision is NOT to undercut
            # (mu=0, G01_pre < 0) has NO war: wlev is FLAT at L_PREWAR throughout -- at most the same level
            # as everyone, exactly the common start, never below cost and never a 15.25 spike.
            war_t = wlev(t)                                           # war price this week (flat L_PREWAR if no war)
            w0 = wlev(np.where(np.isfinite(cw1), cw1, t))             # per-drug recovery origin = war level at coord week
            f1 = np.clip((t - cw1) / KREC, 0.0, 1.0); f2 = np.clip((t - cw2) / KREC, 0.0, 1.0)
            p_coord = w0 + f1 * (p1 - w0) + f2 * (p2 - p1)
            price[wi] += np.average(np.where(t < cw1, war_t, p_coord), weights=WTS)
    return price / N, succ / N, fail / N

# ===== data: weekly quantity-weighted price, cumulative successful coords, cumulative failed lifts =====
e = pd.read_csv(os.path.join(ROOT, "output", "v16_events_unified.csv"), parse_dates=["date"])
e["wk"] = ((e.date - pd.Timestamp("2006-01-01")).dt.days // 7).astype(int)
dobj = pickle.load(open(os.path.join(ROOT, "data", "processed", "data_objects.pkl"), "rb"))
dts = pd.to_datetime(dobj["date_df"]["Date"]).reset_index(drop=True)
dwk = ((dts - pd.Timestamp("2006-01-01")).dt.days // 7).astype(int)
# QUANTITY-WEIGHTED regime price: weight each drug by its sample-mean total quantity (what consumers
# actually pay), restricted to the model's J drugs (D.DrugID -> data column), so the data line and the
# model line (sim_paths, above) use the SAME drugs and the SAME fixed weights WTS.  An unweighted
# cross-drug mean over-weights expensive low-volume drugs and rides ~40% high.
_ids = D["DrugID"].values.astype(int)
_qD = (dobj["quantity_cv"].values + dobj["quantity_fa"].values + dobj["quantity_sb"].values)[:, _ids]
WTS = np.nanmean(_qD, axis=0); WTS = WTS / WTS.sum()                     # fixed per-drug quantity weight (len J)
P = ((dobj["price_cv"].values + dobj["price_fa"].values + dobj["price_sb"].values) / 3.0)[:, _ids]
_num = np.nansum(P * WTS, axis=1)
_den = np.nansum(np.where(np.isnan(P), 0.0, 1.0) * WTS, axis=1)         # nan-aware renormalisation
pser = pd.Series((_num / _den) / 1000.0, index=dwk.values)
dprice = pser.groupby(level=0).mean().reindex(range(WKS[0], HI + 1)).values
nb = HI + 1 - WKS[0]
_war_end = BAN - WKS[0]
L_PREWAR = float(np.nanmean(dprice[:2]))                        # realized Jan-2007 level (ramp start)
L_WAR_DATA = float(np.nanmin(dprice[:_war_end + 1]))            # realized DATA war trough -- the level a spec
# whose model DECIDES to undercut (G01_pre > 0) dives to.  This is the war FLOOR for the war specs (it
# matches the data, which is what a real below-cost war reaches).  A spec whose model decides NOT to
# undercut (mu=0, G01_pre < 0) never reaches it: that line stays FLAT at L_PREWAR, the common start.
_co = e[e.kind == "coordination"]
_cwk1 = _co[_co.to_tier == 1].groupby("DrugID").wk.min().to_dict()
_cwk2 = _co[_co.to_tier == 2].groupby("DrugID").wk.min().to_dict()
data_succ = np.array([sum(1 for w in _cwk1.values() if w <= WKS[0] + i) + sum(1 for w in _cwk2.values() if w <= WKS[0] + i)
                      for i in range(nb)], float)
fa = e[(e.kind == "failed_attempt") & (e.wk >= WKS[0]) & (e.wk <= HI)]
fdv = np.zeros(nb)
for t in fa.wk:
    fdv[t - WKS[0]] += 1
data_fail = np.cumsum(fdv)
dates_full = np.array([wk2date(w) for w in range(WKS[0], HI + 1)])

# ===== per-spec WAR DECISION from the model's own undercut gain (G01_pre > 0 -> war -> dive) =====
# spec_mu = the spec's store-traffic value (th[0]=kappa for the endolab specs; RC2 already has kappa=0;
# mean(MU_homog) for the homogeneous-demand spec).  G01_pre = (spec_mu*ds01 + mg01).mean(): > 0 the firms
# undercut (WAR, dive to the data trough); <= 0 they hold (NO war, FLAT at L_PREWAR).
print(f"\n  L_PREWAR (common start) = {L_PREWAR:.3f}   war trough L_WAR_DATA = {L_WAR_DATA:.3f}")
print(f"  {'spec':22s}{'mu (kappa)':>11s}{'G01_pre':>10s}{'  decision':>11s}")
HAS_WAR = {}
for name, key, kw, col, ls, mk in SPECS:
    th_s, w_s = _th(key)
    spec_mu = float(th_s[0])                              # th[0]=K[0]='kappa'; RC2 has kappa=0 already
    g01_pre = float((spec_mu * DS["ds01_pre"] + DS["mg01_pre"]).mean())
    HAS_WAR[name] = spec_has_war(spec_mu)
    print(f"  {name:22s}{spec_mu:>11.4f}{g01_pre:>10.3f}{('  war (dive)' if HAS_WAR[name] else '  hold (flat)'):>11s}")
_mu_homog = float(np.mean(MU_homog))
HAS_WAR["Homog. demand"] = spec_has_war(_mu_homog)
_g01_homog = float((_mu_homog * DS["ds01_pre"] + DS["mg01_pre"]).mean())
print(f"  {'Homog. demand':22s}{_mu_homog:>11.4f}{_g01_homog:>10.3f}"
      f"{('  war (dive)' if HAS_WAR['Homog. demand'] else '  hold (flat)'):>11s}")

# ===== simulate every spec, then draw the three panels =====
data = dict(price=dprice, success=data_succ, fail=data_fail)
model = {}
for name, key, kw, col, ls, mk in SPECS:
    th_s, w_s = _th(key)
    _mu = [0.0, 0.0, 0.0] if key == "RC2" else MU                 # no-spillover spec: kappa_chain=0 so the count reflects mu=0
    pr, su, fl = sim_paths(th_s, w_s, kw, HAS_WAR[name], mu=_mu)
    model[name] = dict(price=pr, success=su, fail=fl, col=col, ls=ls, mk=mk)
    print(f"  {name:22s} final succ={su[-1]:5.1f}  fail={fl[-1]:5.1f}")
# misspecified-demand spec: homogeneous (median-alpha) demand, re-estimated, simulated on fs_h.
# A demand mistake (not belief/spillover) -- the wave too concentrated, the rent too slow.
prh, suh, flh = sim_paths(homog_theta, 26.0, {}, HAS_WAR["Homog. demand"], fs_mod=fs_h, mu=MU_homog)
model["Homog. demand"] = dict(price=prh, success=suh, fail=flh, col="#2ca7a0", ls=(0, (3, 1, 1, 1)), mk="v")
print(f"  {'Homog. demand':22s} final succ={suh[-1]:5.1f}  fail={flh[-1]:5.1f}")
PLOT_ORDER = [s[0] for s in SPECS] + ["Homog. demand"]

# ===== belief path (Estimated spec), reconstructed from the same one_path events =====
_ft = H["theta"]; a0b, b0b, zb, t0b = _ft["a0"], _ft["b0"], _ft["zeta"], _ft["t0"]
th_full = list(THETA)
belief = np.zeros(len(WKS))
for s in range(NSIM):
    cwk, cwk2, fwk = fs.one_path(th_full, seed=300 + s, onetime=True, w_window=26.0,
                                 arrivals_throughout=True, bmode="full", kappa_chain=MU)
    su = np.array(sorted(list(cwk.values()) + list(cwk2.values()))); fa = np.array(sorted(fwk))
    for wi, t in enumerate(WKS):
        Sc = int((su < t).sum()) if len(su) else 0
        Fc = int((fa < t).sum()) if len(fa) else 0
        zt = zb if t >= t0b else 0.0
        belief[wi] += min(max((a0b + Sc + zt) / (a0b + b0b + Sc + Fc + zt), 0.0), 0.999)
belief /= NSIM
bi_t0 = list(WKS).index(int(round(t0b)))                       # index of t0 in WKS

# ===== draw the four panels (2x2); larger fonts so the figure is legible in print =====
TT, TK, LG = 11.5, 9.2, 10.0                                    # title / tick / legend font sizes
fig, axg = plt.subplots(2, 2, figsize=(12.0, 8.4))
ax = axg.flatten()
panels = [("(a) Regime price (CLP$'000$s)", "price"),
          ("(b) Cumulative successful coordinations", "success"),
          ("(c) Cumulative failed lifts", "fail")]
CART0_d, CART1_d = pd.Timestamp("2007-12-03"), wk2date(OFICIO)   # cartel start (1st coord) / end (FNE Oficio)
for axi, (title, key) in zip(ax[:3], panels):
    axi.plot(dates_full, data[key], color="0.1", lw=2.8, label="Data", zorder=8)
    for si, name in enumerate(PLOT_ORDER):
        m = model[name]; est = name == "Estimated"
        # every spec carries a marker; stagger the phase (offset 0,2,...,12 over a 14-week stride)
        # so overlapping curves stay distinguishable where the lines coincide
        axi.plot(dates_full, m[key], color=m["col"], lw=2.8 if est else 1.3, ls=m["ls"],
                 alpha=1.0 if est else 0.85, marker=m["mk"], markersize=7.5 if est else 6.0,
                 markevery=(2 * si, 14), markerfacecolor="white", markeredgewidth=1.3, label=name,
                 zorder=7 if est else 4)
    for xv in (CART0_d, CART1_d):
        axi.axvline(xv, color="0.45", ls="--", lw=1.0)
    axi.set_title(title, fontsize=TT, loc="left")
    axi.xaxis.set_major_formatter(mdates.DateFormatter("%b%y"))
    axi.tick_params(labelsize=TK); axi.grid(axis="y", alpha=0.22)
ax[1].set_ylim(0, max(data["success"].max(), max(m["success"].max() for m in model.values())) * 1.06)
ax[2].set_ylim(0, max(data["fail"].max(), max(m["fail"].max() for m in model.values())) * 1.08)
# Panel (a): natural DATA-range y-limits (~5-9).  Every line emanates from the common L_PREWAR start;
# the war specs (G01_pre > 0) dive INTO the below-cost war and recover, while the no-spillover spec
# (mu=0, G01_pre < 0) HOLDS -- its model decision is "don't undercut," so it stays FLAT at L_PREWAR,
# at most the same level as everyone, never below cost and never above.  No clip, no off-chart spike.
ax[0].set_ylim(float(np.nanmin(dprice)) - 0.25, float(np.nanmax(dprice)) + 0.30)
ax[0].annotate(r"No spillover ($\mu=0$): the model never undercuts"
               "\n($G_{01}\\!<\\!0$) -- no war, price holds at the start",
               xy=(dates_full[18], L_PREWAR), xytext=(dates_full[5], L_PREWAR + 1.15),
               fontsize=TK - 0.8, color="#6a51a3",
               arrowprops=dict(arrowstyle="->", color="#6a51a3", lw=0.9))
yb0 = ax[0].get_ylim()[0]                                       # cartel-window labels on panel (a)
ax[0].text(CART0_d, yb0, " cartel start", fontsize=TK - 1, color="0.45", va="bottom")
ax[0].text(CART1_d, yb0, " end", fontsize=TK - 1, color="0.45", va="bottom")
nob = model[r"No belief ($b\!\equiv\!1$)"]["success"]; wi_war = [i for i, t in enumerate(range(WKS[0], HI + 1)) if t == 84][0]
ax[1].annotate("no belief floods\nthe war", xy=(dates_full[wi_war], nob[wi_war]),
               xytext=(dates_full[2], data_succ.max() * 0.78), fontsize=TK, color="#2166ac",
               arrowprops=dict(arrowstyle="->", color="#2166ac", lw=0.9))
ax[1].annotate("no jump:\nfar too slow", xy=(dates_full[80], model[r"Learning, no jump ($\zeta\!=\!0$)"]["success"][80]),
               xytext=(dates_full[66], data_succ.max() * 0.30), fontsize=TK, color="#1b7837", ha="left",
               arrowprops=dict(arrowstyle="->", color="#1b7837", lw=0.9))

# ----- panel (d): the estimated follower-belief path (the jump, and why it caps near 2/3) -----
axd = ax[3]
axd.plot(dates_full, belief, color="#c0392b", lw=2.8, label=r"follower belief $b_t$")
axd.plot(dates_full, belief ** 2, color="#2166ac", lw=2.2, ls="--", label=r"squared $b_t^2$ (the gate)")
axd.axhline(0.25, color="0.55", lw=1.0, ls=":")
axd.text(dates_full[1], 0.285, r"$b_t^2\!\approx\!0.25$ ignition", fontsize=TK - 1, color="0.4")
for xv in (CART0_d, CART1_d):
    axd.axvline(xv, color="0.45", ls="--", lw=1.0)
axd.annotate(f"jump to {belief[bi_t0]:.2f} at $t_0$\n(shift, not reset:\nwar failures stay in $F_t$)",
             xy=(wk2date(int(round(t0b))), belief[bi_t0]),
             xytext=(dates_full[min(bi_t0 + 3, len(dates_full) - 1)], 0.14), fontsize=TK,
             arrowprops=dict(arrowstyle="->", lw=0.9))
_pi = int(np.argmax(belief))
axd.annotate(f"peak {belief.max():.2f}", xy=(dates_full[_pi], belief.max()),
             xytext=(dates_full[min(_pi + 5, len(dates_full) - 1)], 0.88), fontsize=TK,
             arrowprops=dict(arrowstyle="->", lw=0.9))
axd.set_ylim(0, 1.06); axd.set_title("(d) Estimated follower belief", fontsize=TT, loc="left")
axd.xaxis.set_major_formatter(mdates.DateFormatter("%b%y")); axd.tick_params(labelsize=TK)
axd.grid(axis="y", alpha=0.22); axd.legend(fontsize=LG - 0.5, loc="upper left", frameon=False)

fig.autofmt_xdate(); fig.tight_layout(rect=[0, 0.05, 1, 1])
_h, _l = ax[0].get_legend_handles_labels()                     # spec legend (two rows) BELOW the 2x2 grid
_lgd = fig.legend(_h, _l, fontsize=LG, loc="lower center", ncol=4, frameon=False, bbox_to_anchor=(0.5, -0.03))
dst = os.path.join(ROOT, "paper", "manuscript", "fig_belief_specs.pdf")
fig.savefig(dst, bbox_inches="tight", bbox_extra_artists=[_lgd])
fig.savefig(os.path.join(ROOT, "output", "fig_belief_specs.png"), dpi=155, bbox_inches="tight", bbox_extra_artists=[_lgd])
plt.close(fig)
print("\nwrote", dst)
print("data: succ=%d fail=%d   belief: jump=%.3f peak=%.3f" % (data_succ[-1], data_fail[-1], belief[bi_t0], belief.max()))
