"""9_3_prices_and_loss.py -- three-panel descriptive exhibit (former Figures 1 + 2 merged).
Panel A: wholesale cost vs.\ retail price -- the transition is not a cost shock (ported from
         the standalone wholesale figure; own zoomed Aug-2007--May-2008 window).
Panel B: weekly quantity-weighted average price by chain.
Panel C: monthly below-cost revenue shortfall by chain.
The two advertising restrictions are marked separately: CONAR (7 Sep 2007) and the binding
Civil Court order (6 Nov 2007).  Output: fig1_prices_loss.pdf.
"""
import os, pickle
import numpy as np
import pandas as pd
import figstyle as fs
import matplotlib.pyplot as plt

DATA = os.path.join(fs.ROOT, "data", "processed")
# ---- Panel B data: per-chain weekly price ----
df = pd.read_csv(os.path.join(DATA, "demand_data_core.csv"))
df["rev"] = df.Price * df.Quantity
gp = df.groupby(["Firm", "TimeID"]).agg(rev=("rev", "sum"), q=("Quantity", "sum"))
gp["p"] = gp.rev / gp.q
# ---- Panel C data: monthly below-cost shortfall per chain ----
d = pickle.load(open(os.path.join(DATA, "data_objects.pkl"), "rb"))
date = pd.to_datetime(pd.read_csv(os.path.join(DATA, "date.csv"))["Date"])
cost = pd.read_csv(os.path.join(DATA, "CostoSB.csv"))
costcols = [c for c in cost.columns if c.startswith("cost")]
c_j = np.nanmean(cost[costcols].apply(pd.to_numeric, errors="coerce").values, axis=0)
def shortfall(P, Q):
    P = np.where(np.isnan(P), c_j[None, :], P); Q = np.where(np.isnan(Q), 0.0, Q)
    return (np.where(c_j[None, :] - P > 0, c_j[None, :] - P, 0.0) * Q).sum(axis=1)
loss = pd.DataFrame({"Date": date, "CV": shortfall(d["price_cv"], d["quantity_cv"]),
                     "FA": shortfall(d["price_fa"], d["quantity_fa"]),
                     "SB": shortfall(d["price_sb"], d["quantity_sb"])}).set_index("Date").sort_index()
lm = loss.resample("ME").sum() / 1e6
lm["wk"] = ((lm.index - pd.Timestamp("2006-01-01")).days // 7)

# ---- Panel A data: wholesale cost index vs.\ retail price index (Salcobrand WAC window) ----
cc = cost.drop(columns=[x for x in cost.columns if "Unnamed" in x]).copy()
cc["date"] = pd.to_datetime(cc["date"], format="%d.%m.%y", errors="coerce")
cc = cc.dropna(subset=["date"]).sort_values("date")
cc["wk"] = ((cc["date"] - pd.Timestamp("2006-01-01")).dt.days // 7).astype(int)
Mc = cc[costcols].apply(pd.to_numeric, errors="coerce")
cost_idx = Mc.mean(axis=1).values; cost_idx = cost_idx / cost_idx[0]
cost_wk = cc["wk"].values
cost_rise = 100 * (cost_idx[-1] - 1)
price_all = df.groupby("TimeID").agg(rev=("rev", "sum"), q=("Quantity", "sum"))
price_all = price_all.rev / price_all.q
wlo, whi = int(cost_wk.min()), int(cost_wk.max())
rlo = int(fs.WK_CV)                                          # retail extended back to the Aug-2007 campaign
base = float(price_all.loc[wlo]) if wlo in price_all.index else float(price_all[price_all.index >= wlo].iloc[0])
pw = price_all[(price_all.index >= rlo) & (price_all.index <= whi)]
price_idx = pw.values / base
price_rise = 100 * (price_idx[-1] - 1)
trough_wk = int(pw.index[int(np.argmin(price_idx))])

LO, HI = 0, 140
NAME = {"CV": "Cruz Verde", "FA": "FASA", "SB": "Salcobrand"}


def marks(ax, labels=False):
    fs.war_shade(ax)
    lo, hi = ax.get_ylim()
    spec = [(fs.WK_DECLINE, "decline", fs.DRED, "-"),
            (fs.WK_CV, "CV ad", fs.RED, ":"),
            (fs.WK_CONAR, "CONAR", fs.GOLD, (0, (2, 2))),
            (fs.WK_BAN, "Court ban", "0.45", "--"),
            (fs.WK_T0, "1st coord.", "#2e7d32", "-.")]
    for x, lab, c, ls in spec:
        ax.axvline(x, color=c, ls=ls, lw=0.85)
        if labels:                       # vertical labels along each line -> no horizontal overlap
            ax.text(x + 0.6, lo + 0.05 * (hi - lo), lab, fontsize=5.5, color=c,
                    rotation=90, va="bottom", ha="left")


fs.setup()
fig, (axA, axB, axC) = plt.subplots(3, 1, figsize=(6.6, 5.85),
                                    gridspec_kw={"height_ratios": [1, 1, 1]})

# Panel A: wholesale cost vs.\ retail price (own zoomed window)
axA.plot(pw.index, price_idx, color=fs.INK, lw=1.8, label="retail price (qty-weighted)")
axA.plot(cost_wk, cost_idx, color=fs.RED, lw=1.8, ls="--", label="wholesale cost (Salcobrand WAC)")
axA.axhline(1.0, color="0.7", lw=0.6, ls=(0, (1, 2)))
for _x, _lab, _c, _ls in [(fs.WK_CONAR, "CONAR", fs.GOLD, (0, (2, 2))),
                          (fs.WK_BAN, "Court ban", "0.45", "--"),
                          (fs.WK_T0, "1st coord.", "#2e7d32", "-.")]:
    axA.axvline(_x, color=_c, ls=_ls, lw=0.85)
    _loA, _hiA = axA.get_ylim()
    axA.text(_x + 0.4, _loA + 0.42 * (_hiA - _loA), _lab, fontsize=5.5, color=_c,
             rotation=90, va="center", ha="left")
axA.annotate(f"retail price {price_rise:+.0f}%", xy=(whi - 1, price_idx[-1]),
             fontsize=7.0, color=fs.INK, ha="right", va="bottom")
axA.annotate(f"wholesale cost flat ({cost_rise:+.1f}%)", xy=(cost_wk[-1], cost_idx[-1]),
             xytext=(whi - 14, 1.17), fontsize=7.0, color=fs.RED, ha="center",
             arrowprops=dict(arrowstyle="->", color=fs.RED, lw=0.7))
axA.annotate("war trough", xy=(trough_wk, price_idx.min()), xytext=(trough_wk + 7, 0.90),
             fontsize=6.6, color="0.35", ha="left", va="center",
             arrowprops=dict(arrowstyle="->", color="0.55", lw=0.6))
axA.set_ylabel("index")
axA.set_title("(A) Wholesale cost vs.\\ retail price", fontsize=8.0)
axA.legend(loc="upper left", fontsize=6.8)
fs.date_xaxis(axA, rlo, whi, step=4)

# Panel B: prices
for ch in ["CV", "FA", "SB"]:
    s = gp.loc[ch]; s = s[(s.index >= LO) & (s.index <= HI)]
    axB.plot(s.index, s.p, color=fs.CHAIN[ch], lw=1.4, label=NAME[ch])
marks(axB, labels=True)
axB.set_ylabel("CLP'000s")
axB.set_title("(B) Price by chain", fontsize=8.0)
axB.legend(loc="upper center", ncol=3, fontsize=7.4)
fs.date_xaxis(axB, LO, HI, step=13)
axB.set_xticklabels([])   # B and C share the time axis; date row only under C

# Panel C: below-cost loss intensity
for ch in ["CV", "FA", "SB"]:
    m = lm[(lm.wk >= LO) & (lm.wk <= HI)]
    axC.plot(m.wk, m[ch], color=fs.CHAIN[ch], lw=1.4, marker="o", ms=2.2, label=NAME[ch])
marks(axC, labels=True)
axC.set_ylabel("CLP mn/mo")
axC.set_title("(C) Below-cost loss by chain", fontsize=8.0)
fs.date_xaxis(axC, LO, HI, step=13)

fs.save(fig, "fig1_prices_loss")
print(f"done; Panel A cost {cost_rise:+.1f}% / retail {price_rise:+.0f}% (wk {rlo}-{whi})")
