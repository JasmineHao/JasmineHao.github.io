"""9_1_wholesale_cost.py
========================
Wholesale cost is NOT the driver of the price transition.  Salcobrand's wholesale
costs (the expert-evidence WAC series, Nov-2007 -- May-2008, the war-trough ->
cartel window) are essentially FLAT --- the aggregate cost index moves +2.2% over
six months (per-drug CV ~1%) --- while the retail price rises ~60% as coordination
takes hold.  A cost shock cannot explain a price path that moves the opposite way
and far more.  Output: fig_wholesale_cost.pdf.
"""
import os
import numpy as np
import pandas as pd
import figstyle as fs

ROOT = fs.ROOT
# ---- wholesale costs (CostoSB.csv: daily, 222 drug columns) ------------------
c = pd.read_csv(os.path.join(ROOT, "data", "processed", "CostoSB.csv"))
c = c.drop(columns=[x for x in c.columns if "Unnamed" in x])
costcols = [x for x in c.columns if x.startswith("cost")]
c["date"] = pd.to_datetime(c["date"], format="%d.%m.%y", errors="coerce")
c = c.dropna(subset=["date"]).sort_values("date")
c["wk"] = ((c["date"] - pd.Timestamp("2006-01-01")).dt.days // 7).astype(int)
M = c[costcols].apply(pd.to_numeric, errors="coerce")
cost_idx = M.mean(axis=1).values; cost_idx = cost_idx / cost_idx[0]      # aggregate cost index
cost_wk = c["wk"].values
cost_rise = 100 * (cost_idx[-1] - 1)
cv = float((M.std() / M.mean()).median())

# ---- retail price index over the same window --------------------------------
df = pd.read_csv(os.path.join(ROOT, "data", "processed", "demand_data_core.csv"))
df["rev"] = df.Price * df.Quantity
g = df.groupby("TimeID").agg(rev=("rev", "sum"), q=("Quantity", "sum"))
price = (g.rev / g.q)
lo, hi = int(cost_wk.min()), int(cost_wk.max())              # cost window (Nov 2007 -- May 2008)
rlo = int(fs.WK_CV)                                           # retail extended back to the Aug-2007 campaign
base = float(price.loc[lo]) if lo in price.index else float(price[price.index >= lo].iloc[0])
pw = price[(price.index >= rlo) & (price.index <= hi)]
price_idx = pw.values / base                                 # both series indexed to the cost-series start (=1)
price_rise = 100 * (price_idx[-1] - 1)
trough_wk = int(pw.index[int(np.argmin(price_idx))])         # war trough week (for the annotation)

# ---- figure -----------------------------------------------------------------
fs.setup()
import matplotlib.pyplot as plt
fig, ax = plt.subplots(figsize=(7.0, 3.9))
ax.plot(pw.index, price_idx, color=fs.INK, lw=2.0, label="retail price (qty-weighted)")
ax.plot(cost_wk, cost_idx, color=fs.RED, lw=2.0, ls="--", label="wholesale cost (Salcobrand WAC)")
ax.axhline(1.0, color="0.7", lw=0.6, ls=(0, (1, 2)))
ax.axvline(fs.WK_BAN, color="0.45", ls="--", lw=0.8); ax.text(fs.WK_BAN+0.4, ax.get_ylim()[1]*0.97, "ad ban", fontsize=7, va="top")
ax.annotate(f"wholesale cost flat: {cost_rise:+.1f}%\n(per-drug CV $\\approx${cv*100:.0f}%)",
            xy=(hi-3, cost_idx[-1]), xytext=(hi-16, 1.18), fontsize=7.4, color=fs.RED, ha="center",
            arrowprops=dict(arrowstyle="->", color=fs.RED, lw=0.7))
ax.annotate(f"retail price {price_rise:+.0f}%\n(coordination)", xy=(hi-2, price_idx[-1]),
            fontsize=7.6, color=fs.INK, ha="center", va="bottom")
ax.annotate("war trough ($2$ Dec)", xy=(trough_wk, price_idx.min()), xytext=(trough_wk + 9, 0.90),
            fontsize=6.8, color="0.35", ha="left", va="center",
            arrowprops=dict(arrowstyle="->", color="0.55", lw=0.6))
fs.date_xaxis(ax, rlo, hi, step=4)
ax.set_ylabel("index (start of cost series $=1$)")
ax.set_title("Wholesale cost vs.\\ retail price", fontsize=9)
ax.legend(loc="upper left")
fs.save(fig, "fig_wholesale_cost")
print(f"cost index {cost_idx[0]:.3f} -> {cost_idx[-1]:.3f} ({cost_rise:+.1f}%); price {price_rise:+.0f}%; window wk{lo}-{hi}")
