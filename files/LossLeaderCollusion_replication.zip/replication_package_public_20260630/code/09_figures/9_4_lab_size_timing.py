"""9_4_lab_size_timing.py -- lab-level coordination timing vs.\\ lab size.
Each laboratory coordinates its whole portfolio in one batch call, so timing is set at the
lab level: larger labs (more pre-ban revenue) cross the reach-out threshold and coordinate
first.  This panel plots, per lab, the lab's median first-coordination week against its size.
Lab Size := the laboratory's total pre-ban revenue, summed across its drugs (the W_L stake
the structural model uses; the same measure as the corr(log lab size, week) moment).
Output: fig_lab_size_timing.pdf.
"""
import os
import numpy as np
import pandas as pd
import figstyle as fs
import matplotlib.pyplot as plt

DATA = os.path.join(fs.ROOT, "data", "processed")
OUT = os.path.join(fs.ROOT, "output")

# ---- per-drug revenue + lab (Lab Size = total pre-ban revenue per lab) ----
df = pd.read_csv(os.path.join(DATA, "demand_data_core.csv"))
df["rev"] = df.Price * df.Quantity
lab_of = df.groupby("DrugID")["Lab"].agg(lambda x: x.value_counts().index[0])
lab_rev = df.groupby("Lab")["rev"].sum()

# ---- first three-chain coordination week per drug (Tier 0->1, in window) ----
e = pd.read_csv(os.path.join(OUT, "v16_events_unified.csv"), parse_dates=["date"])
e["wk"] = ((e.date - pd.Timestamp("2006-01-01")).dt.days // 7).astype(int)
co = e[e.kind == "coordination"]
cwk = co[(co.in_window) & (co.to_tier == 1)].groupby("DrugID").wk.min()

# ---- per-drug table: lab, lab revenue W, coordination week ----
D = pd.DataFrame({"DrugID": sorted(set(cwk.index))})
D["lab"] = D.DrugID.map(lab_of)
D["coord_wk"] = D.DrugID.map(cwk)
_rec = pd.read_csv(os.path.join(OUT, "recovered_drugs.csv"))   # 4 hand-coded coords v16 lacks a clean triple for
_rec = _rec[~_rec.DrugID.isin(D.DrugID)][["DrugID", "lab", "coord_wk"]]
D = pd.concat([D, _rec], ignore_index=True).dropna(subset=["coord_wk", "lab"])
D["W"] = D.lab.map(lab_rev)
D = D.dropna(subset=["W"])

# ---- lab-level aggregate ----
lab = D.groupby("lab").agg(W=("W", "first"), wk=("coord_wk", "median"),
                           n=("DrugID", "size")).reset_index()
lab["logW"] = np.log(lab.W)
xw = lab.logW.to_numpy(float)
yw = lab.wk.to_numpy(float)
corr = float(np.corrcoef(xw, yw)[0, 1])
sl, ic = np.polyfit(xw, yw, 1)

# ---- plot ----
fs.setup()
fig, ax = plt.subplots(figsize=(6.6, 3.6))
ax.scatter(lab.logW, lab.wk, s=10 + 6 * lab.n, color=fs.CHAIN["CV"], alpha=0.55,
           edgecolor="white", linewidth=0.6, zorder=3, label="laboratory (size $\\propto$ number of drugs)")
xs = np.linspace(lab.logW.min(), lab.logW.max(), 50)
ax.plot(xs, sl * xs + ic, color=fs.DRED, lw=1.7, zorder=4,
        label=f"linear fit (corr $= {corr:.2f}$)")
ax.axhline(fs.WK_BAN, color="0.6", ls="--", lw=0.7)
ax.text(lab.logW.max(), fs.WK_BAN - 0.5, "Court ban (6 Nov 2007)",
        fontsize=6.0, color="0.45", va="top", ha="right")
ax.axhline(fs.WK_T0, color="#2e7d32", ls="-.", lw=0.7)
ax.text(lab.logW.max(), fs.WK_T0 + 0.5, "first coordination (3 Dec)",
        fontsize=6.0, color="#2e7d32", va="bottom", ha="right")
ax.set_xlabel("Lab size: log total pre-ban revenue (CLP)")
ax.set_ylabel("Median first-coordination week")
ax.legend(loc="lower left", fontsize=7.0)
fs.save(fig, "fig_lab_size_timing")
print(f"done; {len(lab)} labs, {len(D)} drugs, corr(logW, median wk) = {corr:.3f}, "
      f"slope = {sl:.2f} wk per log-CLP")
