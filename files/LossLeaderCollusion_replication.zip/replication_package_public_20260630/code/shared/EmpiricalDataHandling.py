# %%
from asyncio import FIRST_COMPLETED
from typing import List, Dict, Tuple
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
import os
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf
import ruptures as rpt

def detect_change_points(data, model="rbf", pen=10):
    """使用ruptures库检测时间序列中的变更点"""
    algo = rpt.Pelt(model=model).fit(data)
    return algo.predict(pen=pen)

def detect_combined_change_points(series1, series2, series3, model="rbf", pen=10):
    """检测三个时间序列组合后的变更点"""
    combined_series = np.vstack((series1.values, series2.values, series3.values)).T
    algo = rpt.Pelt(model=model).fit(combined_series)
    return algo.predict(pen=pen)


def correct_abnormal_prices(price_dfs, threshold=2.5):
    """
    Detect and correct abnormal price jumps in price DataFrames.
    If a day's price is more than `threshold` times the previous day's price (or vice versa),
    it is considered abnormal and replaced with the median of its neighbors.

    Args:
        price_dfs: List of price DataFrames (one per company).
        threshold: Multiplier threshold for detecting abnormal jumps.

    Returns:
        List of corrected price DataFrames.
    """
    corrected_dfs = []
    for price_df in price_dfs:
        df = price_df.copy()
        for col in df.columns:
            prices = df[col]
            # Compute price ratios (current / previous)
            ratios = prices / prices.shift(1)
            # Find abnormal indices (either direction)
            abnormal_idx = ratios[(ratios > threshold) | (ratios < 1/threshold)].index
            for idx in abnormal_idx:
                # Replace with median of previous and next valid prices
                prev_idx = prices.index.get_loc(idx) - 1
                next_idx = prices.index.get_loc(idx) + 1
                vals = []
                if prev_idx >= 0:
                    vals.append(prices.iloc[prev_idx])
                if next_idx < len(prices):
                    vals.append(prices.iloc[next_idx])
                if vals:
                    df.at[idx, col] = np.median(vals)
        df = df.replace(0, np.nan)
        df = df.ffill()
        df = df.bfill()
        corrected_dfs.append(df)

    return corrected_dfs

def correct_abnormal_quantities(quantity_dfs, window=3):
    """
    Detect and correct abnormal quantity jumps in quantity DataFrames.
    If a day's quantity is more than `threshold` times the previous day's quantity (or vice versa),
    it is considered abnormal and replaced with the median of its neighbors.

    Args:
        quantity_dfs: List of quantity DataFrames (one per company).
        threshold: Multiplier threshold for detecting abnormal jumps.

    Returns:
        List of corrected quantity DataFrames.
    """
    corrected_dfs = []
    for quantity_df in quantity_dfs:
        df = quantity_df.copy()
        df = df.fillna(0)
        # Apply moving average smoothing to each column (company)
        window = 3  # You can adjust the window size as needed
        for col in df.columns:
            df[col] = df[col].rolling(window=window, min_periods=1, center=True).mean()
        # Replace all 0's with 1e-3
        df = df.replace(0, 1e-3)
        corrected_dfs.append(df)
        
    return corrected_dfs

def predict_levels_with_unrealized_events(
    prices: pd.DataFrame,
    events: pd.DataFrame,
    company_names: List[str],
    date_df: pd.DataFrame,
    phases: List[str]
) -> Tuple[pd.DataFrame, Dict[str, Dict[int, float]]]:
    """
    Predict price levels accounting for unrealized leadership events.
    
    Determines price levels (0=low, 1=medium, 2=high) based on:
    - Historical price patterns
    - Price leadership events
    - Phase-specific price characteristics
    
    Args:
        prices: DataFrame of prices with company columns and date index
        events: Filtered events DataFrame for the specific drug
        company_names: List of company names to analyze
        date_df: DataFrame containing phase date ranges
        phases: List of phase names
        
    Returns:
        Tuple containing:
        - DataFrame of price levels (same shape as input prices)
        - Dictionary of benchmark prices for each level by company
    """
    # Extract phase price characteristics
    phase_data = {
        'phase1': prices.loc[date_df[phases[0]].index],
        'phase2': prices.loc[date_df[phases[1]].index],
        'phase3': prices.loc[date_df[phases[2]].index]
    }
    
    # Determine which scenario to apply based on event types
    num_leadership = events[events['event_pct_change']>10]['is_price_leadership'].sum()
    num_partial = events[events['event_pct_change']>10]['is_partial_followed'].sum()
    
    # Scenario 1: At least 2 leadership events
    if num_leadership >= 2:
        print("Scenario 1: At least 2 leadership events")
        price_levels, level_prices = _handle_multiple_leadership_events(
            phase_data['phase3'], events, company_names
        )
    
    # Scenario 2: 1 leadership + partial follows
    elif num_leadership == 1 and (num_leadership + num_partial) >= 2:
        print("Scenario 2: 1 leadership + partial follows")
        price_levels, level_prices = _handle_mixed_events(
            phase_data['phase3'], events, company_names
        )
    
    # Scenario 3: Only partial follows
    elif num_leadership == 0 and num_partial >= 1:
        print("Scenario 3: Only partial follows")
        price_levels, level_prices = _handle_partial_follows(
            phase_data['phase3'], events, company_names
        )
    
    # Scenario 4: Single leadership event
    elif num_leadership == 1:
        print("Scenario 4: Single leadership event")
        price_levels, level_prices = _handle_single_leadership(
            phase_data, events, company_names
        )
    
    # # Default scenario: Cluster analysis
    else:
        print("Default scenario: Cluster analysis")
        price_levels, level_prices = _handle_no_events(
            prices, company_names, phase_data['phase3']
        )
    
    # Post-processing and validation
    level_prices = _validate_levels(level_prices, company_names, phase_data['phase3'])
    
    # Reassign levels based on validated benchmarks
    price_levels = _assign_levels(prices, level_prices, company_names)
    
    # Apply smoothing and jump detection
    price_levels, events = _smooth_levels(prices, events, price_levels, level_prices, company_names)
    
    return price_levels, level_prices, events


from typing import List, Dict, Tuple, Optional
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans

def predict_all_price_levels(
    price_dfs,
    company_names,
    event_df,
    date_df,
    phases
):
    """
    Predict complete price levels (including unrealized levels) for all companies and drugs.
    
    This function analyzes price patterns and leadership events to determine price levels (low, medium, high)
    for each company and drug combination. It handles various scenarios based on available event data.
    
    Args:
        price_dfs: List of price DataFrames (one per drug) with dates as index
        company_names: List of company names to analyze
        event_df: DataFrame containing price leadership events with columns:
                 - drug_id: Identifier for each drug
                 - event_date: Date of the event
                 - is_price_leadership: Boolean indicating leadership events
                 - is_partial_followed: Boolean indicating partial follow events
                 - event_pct_change: Percentage price change of the event
        date_df: DataFrame containing phase date ranges with columns matching phases
        phases: List of phase names (e.g., ['phase1', 'phase2', 'phase3'])
    
    Returns:
        Tuple containing:
        - List of DataFrames (one per company) with price levels for all drugs
        - Dictionary of benchmark prices for each level, company and drug
          Format: {company: {drug_id: {0: low_price, 1: medium_price, 2: high_price}}}
    """
    # Convert dates to datetime format consistently
    date_df['Date'] = pd.to_datetime(date_df['Date'], format='%Y-%m-%d')
    
    # Initialize results storage
    level_benchmarks = {company: {} for company in company_names}
    price_level_dfs = [pd.DataFrame(index=price_dfs[0].index, 
                                  columns=price_dfs[0].columns) 
                      for _ in company_names]
    
    event_df_new = pd.DataFrame()
    # Process each drug
    for drug_id in price_dfs[0].columns:
        # Extract prices for this drug across all companies
        prices = pd.concat([df[drug_id] for df in price_dfs], axis=1)
        prices.columns = company_names
        
        # Get relevant events for this drug (with significant changes)
        events = event_df[
            (event_df['drug_id'] == drug_id)
        ].copy()
        
        print(f"Processing drug {drug_id} with {len(events)} events")
        # Predict price levels based on events and phases
        price_levels, level_prices, updated_events = predict_levels_with_unrealized_events(
            prices, events, company_names, date_df, phases
        )
        
        # Store results
        for i, company in enumerate(company_names):
            price_level_dfs[i][drug_id] = price_levels[company]
            level_benchmarks[company][drug_id] = level_prices[company]
        updated_events['drug_id'] = drug_id
        # Update event_df: drop old rows for this drug, append updated_events
        event_df_new = pd.concat([event_df_new, updated_events], ignore_index=True)
    # Fill NaN values in 'date' column with 'event_date'
    event_df_new['date'] = event_df_new['date'].fillna(event_df_new['event_date'])
    return price_level_dfs, level_benchmarks, event_df_new
    

# %%
# Helper Functions

def _handle_multiple_leadership_events(
    phase3_prices: pd.DataFrame,
    events: pd.DataFrame,
    company_names: List[str]
) -> Tuple[pd.DataFrame, Dict[str, Dict[int, float]]]:
    """
    Handle scenario with 2+ price leadership events.
    
    Uses the two most significant events as breakpoints for level determination.
    """
    top_events = events[events['is_price_leadership']]\
        .sort_values('event_pct_change', ascending=False)\
        .head(2)\
        .sort_values('event_date')
    
    level_prices = {}
    for company in company_names:
        level_prices[company] = {
            0: phase3_prices.loc[top_events.event_date.iloc[0]-8:top_events.event_date.iloc[0], company].quantile(0.1),
            1: phase3_prices.loc[top_events.event_date.iloc[0]:top_events.event_date.iloc[1], company].median(),
            2: phase3_prices.loc[top_events.event_date.iloc[1]:top_events.event_date.iloc[1]+8, company].quantile(0.9)
        }
    
    price_levels = _assign_levels(phase3_prices, level_prices, company_names)
    return price_levels, level_prices

def _handle_mixed_events(
    phase3_prices: pd.DataFrame,
    events: pd.DataFrame,
    company_names: List[str],
    threshold: float = 0.1
) -> Tuple[pd.DataFrame, Dict[str, Dict[int, float]]]:
    """
    Handle scenario with 1 leadership + partial follow events.
    """
    lead_event = events[events['is_price_leadership']].iloc[0]
    partial_event = events[events['is_partial_followed']]\
        .sort_values('event_pct_change', ascending=False)\
        .iloc[0]
    
    # Calculate raw level prices
    level_prices_raw = {}
    for company in company_names:
        level_prices_raw[company] = {
            0: phase3_prices.loc[lead_event.event_date-8:lead_event.event_date, company].quantile(0.1),
            1: phase3_prices.loc[lead_event.event_date:lead_event.event_date+8, company].quantile(0.9),
            2: phase3_prices.loc[partial_event.event_date-8:partial_event.event_date, company].quantile(0.1),
            3: phase3_prices.loc[partial_event.event_date:partial_event.event_date+8, company].quantile(0.9)
        }
    
    # Adjust for outliers
    level_prices_raw = _adjust_level_outliers(level_prices_raw, company_names, threshold)
    
    # Create final 3 levels
    level_prices = {}
    for company in company_names:
        levels = sorted(level_prices_raw[company].values())
        level_prices[company] = {
            0: levels[0],
            1: np.mean(levels[1:3]),
            2: levels[3]
        }
    
    price_levels = _assign_levels(phase3_prices, level_prices, company_names)
    return price_levels, level_prices

def _handle_partial_follows(
    phase3_prices: pd.DataFrame,
    events: pd.DataFrame,
    company_names: List[str]
) -> Tuple[pd.DataFrame, Dict[str, Dict[int, float]]]:
    """
    Handle scenario with only partial follow events.
    """
    top_events = events[events['is_partial_followed']].sort_values(['event_pct_change'], ascending=False).head(2).sort_values('event_date',ascending=True)
    
    level_prices = {}
    if len(top_events) == 2:
        for company in company_names:
            level_prices[company] = {
                0: phase3_prices.loc[:top_events.event_date.iloc[0], company].quantile(0.1),
                1: phase3_prices.loc[top_events.event_date.iloc[0]:top_events.event_date.iloc[1], company].median(),
                2: phase3_prices.loc[top_events.event_date.iloc[1]:, company].quantile(0.9)
            }
    else:
        event = top_events.iloc[0]
        for company in company_names:
            level_prices[company] = {
                0: phase3_prices.loc[:event.event_date, company].quantile(0.1),
                1: phase3_prices.loc[event.event_date:, company].median(),
                2: phase3_prices[company].quantile(0.9)
            }
    
    price_levels = _assign_levels(phase3_prices, level_prices, company_names)
    return price_levels, level_prices

def _handle_single_leadership(
    phase_data: Dict[str, pd.DataFrame],
    events: pd.DataFrame,
    company_names: List[str]
) -> Tuple[pd.DataFrame, Dict[str, Dict[int, float]]]:
    """
    Handle scenario with single leadership event.
    """
    event = events[events['is_price_leadership']].iloc[0]
    level_prices = {}
    
    pre_price = phase_data['phase3'].loc[event.event_date-8:event.event_date].median()
    post_price = phase_data['phase3'].loc[event.event_date:event.event_date+8].median()
    
    phase1_high = phase_data['phase1'].quantile(0.99)
    phase2_low = phase_data['phase2'].quantile(0.01)
    phase1_median = phase_data['phase1'].median()
    phase3_high = phase_data['phase3'].quantile(0.99).max()
    
    for company in company_names:
        level_prices[company] = {}
        
        # Determine level 0
        if abs(pre_price[company] - phase2_low[company]) < 0.05 * phase2_low[company]:
            level_prices[company][0] = min(pre_price[company], phase2_low[company])
        else:
            level_prices[company][0] = phase2_low[company]
        
        # Determine levels 1 and 2
        if (post_price[company] - phase1_median[company]) < 0.05 * phase1_median[company]:
            level_prices[company][1] = post_price[company]
            level_prices[company][2] = phase3_high if phase3_high > post_price[company] else phase1_high.mean()
        else:
            level_prices[company][1] = phase1_median.mean()
            level_prices[company][2] = phase3_high if phase3_high > post_price[company] else post_price[company]
    
    price_levels = _assign_levels(phase_data['phase3'], level_prices, company_names)
    return price_levels, level_prices

def _handle_no_events(
    prices: pd.DataFrame,
    company_names: List[str],
    phase3_prices: pd.DataFrame
) -> Tuple[pd.DataFrame, Dict[str, Dict[int, float]]]:
    """
    Handle scenario with no significant events using clustering.
    """
    pooled_prices = pd.concat([prices[company].dropna() for company in company_names]).values.reshape(-1, 1)

    # Try 4 clusters first
    kmeans = KMeans(n_clusters=4, random_state=0).fit(pooled_prices)
    centers = sorted(kmeans.cluster_centers_.flatten())

    # If any two centers are too close, fall back to 3 clusters
    too_close = any(abs(centers[i+1] - centers[i]) < 0.02 * np.median(pooled_prices) for i in range(3))
    if too_close:
        kmeans = KMeans(n_clusters=3, random_state=0).fit(pooled_prices)
        centers = sorted(kmeans.cluster_centers_.flatten())
        # Use the 3 centers as levels 0, 1, 2
    else:
        # Use the lowest, two middle averaged, and highest as 3 levels
        centers = [centers[0], np.mean(centers[1:3]), centers[3]]

    level_prices = {company: {i: centers[i] for i in range(3)} for company in company_names}
    price_levels = _assign_levels(prices, level_prices, company_names)

    # Update with company-specific medians
    for company in company_names:
        company_prices = prices[company].dropna()
        for level in range(3):
            level_prices_i = company_prices[price_levels[company] == level].median()
            if not pd.isna(level_prices_i):
                level_prices[company][level] = level_prices_i
    
    return price_levels, level_prices

# Utility Functions

def _assign_levels(
    prices: pd.DataFrame,
    level_prices: Dict[str, Dict[int, float]],
    company_names: List[str]
) -> pd.DataFrame:
    """
    Assign each price to the closest level benchmark.
    """
    price_levels = pd.DataFrame(index=prices.index, columns=company_names, dtype=int)
    for company in company_names:
        for idx, price in prices[company].items():
            closest_level = min(
                level_prices[company].items(),
                key=lambda x: abs(price - x[1])
            )[0]
            price_levels.loc[idx, company] = closest_level
    return price_levels

def _adjust_level_outliers(
    level_prices: Dict[str, Dict[int, float]],
    company_names: List[str],
    threshold: float = 0.1
) -> Dict[str, Dict[int, float]]:
    """
    Adjust level prices where one company deviates significantly from others.
    """
    for level in next(iter(level_prices.values())).keys():
        for i, company in enumerate(company_names):
            others = [level_prices[c][level] for j, c in enumerate(company_names) if j != i]
            others_mean = np.mean(others)
            if abs(level_prices[company][level] - others_mean) > threshold * others_mean:
                level_prices[company][level] = others_mean
    return level_prices

def _validate_levels(
    level_prices: Dict[str, Dict[int, float]],
    company_names: List[str],
    phase3_prices: pd.DataFrame
) -> Dict[str, Dict[int, float]]:
    """
    Ensure level prices are properly ordered and adjusted.
    """
    # Ensure 2 > 1 > 0 for each company
    for company in company_names:
        if (level_prices[company][2] <= level_prices[company][1] or 
            level_prices[company][1] <= level_prices[company][0]):
            sorted_levels = sorted(level_prices[company].items(), key=lambda x: x[1])
            level_prices[company] = {i: price for i, (level, price) in enumerate(sorted_levels)}
    
    # Adjust outliers between companies
    level_prices = _adjust_level_outliers(level_prices, company_names)
    
    # Final check on level 2 prices
    if (min(level_prices[company][2] for company in company_names) <= 
        max(level_prices[company][1] for company in company_names)):
        for company in company_names:
            company_prices = phase3_prices[company].dropna()
            if not company_prices.empty:
                level_prices[company][2] = company_prices.quantile(0.95)
    
    return level_prices

def _smooth_levels(
    prices,
    events,
    price_levels,
    level_prices,
    company_names,
    min_jump_ratio=0.1,
    window_size=5,
    max_allowed_changes=150
):
    """
    Smooth price levels by restricting level changes to significant price movements.
    
    Only allows level changes:
    1. Near the largest price jumps (within window_size days)
    2. When the price change exceeds min_jump_ratio
    
    Args:
        prices: Raw price data
        price_levels: Current level assignments
        level_prices: Benchmark prices for each level
        company_names: List of companies to process
        min_jump_ratio: Minimum relative change to consider significant
        window_size: Days around jumps to allow level changes
        n_largest_jumps: Number of largest jumps to consider
        
    Returns:
        Smoothed price levels DataFrame
    """
    smoothed_levels = price_levels.copy()
    idx_list = list(price_levels.index)[668:]

    # Track new events for coordinated jumps and price decreases
    new_events = []
    
    for company in company_names:
        price_series = prices.loc[idx_list,company]
        # Find all change points (both + and -) in price_levels for this company
        price_level_changes = smoothed_levels.loc[idx_list,company].diff().fillna(0)
        price_level_changes_points = price_level_changes[price_level_changes != 0].index.tolist()

        # You can use change_points for further analysis or debugging if needed
        # Compute absolute price changes for the selected index list
        abs_changes = price_series.diff().abs().fillna(0)

        # --- Smooth sharp one-day price decreases that revert the next day ---
        for i in range(1, len(idx_list) - 1):
            prev_price = price_series.loc[idx_list[i - 1]]
            curr_price = price_series.loc[idx_list[i]]
            next_price = price_series.loc[idx_list[i + 1]]
            # If sharp drop and then revert back (within a small tolerance)
            if (
            (curr_price < prev_price * (1 - min_jump_ratio)) and
            (abs(next_price - prev_price) < min_jump_ratio * prev_price)
            ):
                # Smooth: set current price to previous price
                price_series.loc[idx_list[i]] = prev_price
                # Also update abs_changes for consistency
                abs_changes[idx_list[i]] = 0
                abs_changes[idx_list[i + 1]] = abs(next_price - prev_price)
        

        # Only apply smoothing if there are too many level changes (e.g., more than 10)
        level_changes = smoothed_levels[company].diff().abs().fillna(0)
        num_changes = (level_changes > 0).sum()

        # Count the number of level changes (jumps)
        jump_indices = smoothed_levels.loc[idx_list, :][company].diff().abs().fillna(0) > 0
        jump_indices = jump_indices[jump_indices].index 
        num_jumps = len(jump_indices)

        # Find all jump points and their magnitudes
        
        jump_mags = abs_changes.loc[jump_indices].values
        # Sort jump_points by magnitude (descending)
        # Find jump points with largest magnitude
        sorted_jump_points = [jp for _, jp in sorted(zip(jump_mags, jump_indices), reverse=True)]
        # For each top jump, find the nearest price_level_changes_points (within window_size)
        keep_jumps = set()
        for jp in sorted_jump_points[:max_allowed_changes]:
            # Find all price_level_changes_points within window_size days of jp
            nearby = [pt for pt in price_level_changes_points if abs((pt - jp).days if hasattr(pt, 'days') else (pt - jp)) <= window_size]
            # Determine the sign of the price jump at jp
            jump_sign = np.sign(price_series.loc[jp] - price_series.loc[jp - 1]) if price_series.index.get_loc(jp) > 0 else 0
            # Find the nearest point with the same sign as the jump
            closest = None
            min_dist = None
            dist = window_size + 1  # Initialize with a value larger than window_size
            for pt in nearby:
                idx_pt = smoothed_levels.index.get_loc(pt)
            if idx_pt > 0:
                level_change_sign = np.sign(smoothed_levels.loc[pt, company] - smoothed_levels.loc[smoothed_levels.index[idx_pt - 1], company])
                if level_change_sign == jump_sign and jump_sign != 0:
                    dist = abs((pt - jp)) 
                if min_dist is None or dist < min_dist:
                    closest = pt
                    min_dist = dist
            if closest is not None:
                keep_jumps.add(closest)
            else:
                keep_jumps.add(jp)

        
        # Collect all event points (event_date for leader, response_date for follower)
        event_points = set()
        for _, event in events.iterrows():
            if event.get('leader_firm_id', None) == company and pd.notnull(event.get('event_date', None)):
                event_points.add(event['event_date'])
            else:
                follower_info = event['followers'].get(company, None)
                if follower_info and pd.notnull(follower_info.get('response_date', None)):
                    event_points.add(follower_info['response_date'])
        # Keep only the first max_allowed_changes jumps, revert others

        prev_level = smoothed_levels[company].iloc[0]

        for i, idx in enumerate(idx_list):
            if idx in event_points:
                date = idx
                # Determine if this company is a leader or a follower for event matching
                def is_follower_event(ev):
                    if isinstance(ev.get('followers', None), dict):
                        follower_info = ev['followers'].get(company, None)
                        response_date = follower_info.get('response_date', None) if follower_info else None
                        if response_date is not None and date is not None:
                            # Compare absolute difference in days
                            if hasattr(response_date, 'to_pydatetime'):
                                response_date = response_date.to_pydatetime()
                            if hasattr(date, 'to_pydatetime'):
                                date_cmp = date.to_pydatetime()
                            else:
                                date_cmp = date
                            diff_days = abs((response_date - date_cmp))
                            return diff_days < 2
                        return False
                    return False

                event_match = events[
                    (
                        ((events['leader_firm_id'] == company) & (events['event_date'] == date))
                        |
                        (events.apply(is_follower_event, axis=1))
                    )
                ]
                # Only keep the first matching event if multiple found
                if not event_match.empty:
                    event_match = event_match.iloc[[0]]
                    if (event_match['is_price_leadership'] | event_match['is_partial_followed']).any(): 
                        
                        if event_match['leader_firm_id'].iloc[0] == company:
                        # Record this as a coordinated jump event                        
                            new_events.append({
                                'event_type': 'coordinated_lead',
                                'leader_firm_id': event_match['leader_firm_id'].iloc[0],
                                'firm_id': company,
                                'event_date': event_match['event_date'].iloc[0],
                                'date': date,
                                'from_level': prev_level,
                                'to_level': smoothed_levels.loc[idx, company],
                                'event_idx': event_match.index[0]  # Unique identifier for merging
                            })
                        else: 
                            # Record this as a coordinated jump event                        
                            new_events.append({
                                'event_type': 'coordinated_follow',
                                'leader_firm_id': event_match['leader_firm_id'].iloc[0],
                                'firm_id': company,
                                'event_date': event_match['event_date'].iloc[0],
                                'date': date,
                                'from_level': prev_level,
                                'to_level': smoothed_levels.loc[idx, company],
                                'event_idx': event_match.index[0]  # Unique identifier for merging
                            })
                        # If event_pct_change > 10, force a price level change
                        if event_match['event_pct_change'].iloc[0] > 10:
                            # Force the jump: if the level is the same, increment by 1 (cap at 2)
                            if smoothed_levels.loc[idx, company] == prev_level:
                                smoothed_levels.loc[idx, company] = min(prev_level + 1, 2)
                            prev_level = smoothed_levels.loc[idx, company]
                        
                    elif prev_level != smoothed_levels.loc[idx, company]:
                        # If this is a follower event, record it
                        new_events.append({
                            'event_type': 'price_increase',
                            'leader_firm_id': event_match['leader_firm_id'].iloc[0],
                            'event_date': date,
                            'firm_id': company,
                            'date':date,
                            'from_level': prev_level,
                            'to_level': smoothed_levels.loc[idx, company]
                        })
                    # if the event exists, allow the jump
                    prev_level = smoothed_levels.loc[idx, company]

                else:
                    # Revert this jump if not in events
                    smoothed_levels.loc[idx, company] = prev_level
                
            else:
                # If this is a jump and not reverted, check for price decrease
                if idx in keep_jumps:
                    prev_val = smoothed_levels.loc[idx_list[i-1], company] if i > 0 else smoothed_levels.loc[idx, company]
                    curr_val = smoothed_levels.loc[idx, company]
                    if curr_val < prev_val:
                        # Price decrease detected
                        new_events.append({
                            'event_type': 'price_decrease',
                            'leader_firm_id': company,
                            'firm_id': company,
                            'event_date': idx,
                            'from_level': prev_val,
                            'to_level': curr_val
                        })
                    if curr_val > prev_val:
                        new_events.append({
                            'event_type': 'price_increase',
                            'leader_firm_id': company,
                            'firm_id': company,
                            'event_date': idx,
                            'from_level': prev_val,
                            'to_level': curr_val
                        })
                else: 
                    # If not a jump, keep the previous level
                    smoothed_levels.loc[idx, company] = prev_level

    
    # Add new_events to events DataFrame if needed
    
    new_events_df = pd.DataFrame(new_events)
    
    return smoothed_levels, new_events_df
    # return smoothed_levels
   


# %%
def classify_event_price_level_shifts(event_df, price_dfs, company_names, level_dfs):
    """
    根据price_levels判断每次提价事件属于0-1, 1-2, 0-2哪种类型，并标记fully followed, partial followed, not followed

    返回:
    - event_df: 新增 'level_shift_type' 和 'follow_status' 列
    """
    # 新增列
    event_df = event_df.copy()
    event_df['level_shift_type'] = None
    event_df['follow_status'] = None

    # 构建公司到price_df和level_df的映射
    price_df_map = dict(zip(company_names, price_dfs))
    level_df_map = dict(zip(company_names, level_dfs))

    for idx, row in event_df.iterrows():
        drug_id = row['drug_id']
        leader = row['leader_firm_id']
        event_date = row['event_date']
        followers = row['followers']
        # 获取事件发生前后的日期索引
        price_df = price_df_map[leader]
        level_df = level_df_map[leader]
        
        
        # 找到事件日期在index中的位置
        date_idx = event_date
        

        # 取事件前后各10天的level，选取majority
        window = 10
        # 找到事件日期在index中的位置
        
        date_pos = price_df.index.get_loc(event_date)
        prev_start = max(date_pos - window, 0)
        prev_end = date_pos  # 不包含event_date
        next_start = date_pos + 1
        next_end = min(date_pos + 1 + window, len(price_df.index))

        prev_dates = price_df.index[prev_start:prev_end]
        next_dates = price_df.index[next_start:next_end]

        prev_levels = level_df[drug_id].loc[prev_dates]
        next_levels = level_df[drug_id].loc[next_dates]

        if not prev_levels.empty:
            prev_level = prev_levels.mode().iloc[0]
        else:
            prev_level = None
        if not next_levels.empty:
            next_level = next_levels.mode().iloc[0]
        else:
            next_level = None

        # 判断level shift类型
        if prev_level == 0 and next_level == 1:
            shift_type = '0-1'
        elif prev_level == 1 and next_level == 2:
            shift_type = '1-2'
        elif prev_level == 0 and next_level == 2:
            shift_type = '0-2'
        else:
            shift_type = 'other'

        event_df.at[idx, 'level_shift_type'] = shift_type

        # 判断跟随情况
        follow_status = 'not followed'
        if followers:
            responded = []
            
            for follower in followers:
                responded.append(followers[follower]['responded'])
                
                # follower_level_df = level_df_map[follower][drug_id]
                # follower_prev_level = follower_level_df.loc[prev_dates[-1]] if len(prev_dates) > 0 else None
                # follower_next_level = follower_level_df.loc[next_dates[0]] if len(next_dates) > 0 else None
                # Responded if level increased
                # responded.append(follower_next_level > follower_prev_level if follower_prev_level is not None and follower_next_level is not None else False)
            
            if responded and all(responded):
                follow_status = 'fully followed'
            elif responded and any(responded):
                follow_status = 'partial followed'
            else:
                follow_status = 'not followed'
        event_df.at[idx, 'follow_status'] = follow_status

    return event_df

# %%
def visualize_all_price_levels(price_dfs, level_dfs, level_benchmarks, company_names, drug_ids, output_dir='price_level_visualization'):
    """
    可视化所有价格等级，包括预测的未实现等级
    """
    # 创建输出目录
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # 为每个药品生成可视化
    for drug_id in drug_ids:
        plt.figure(figsize=(14, 8))
        
        for i, (price_df, level_df, company_name) in enumerate(zip(price_dfs, level_dfs, company_names)):
            # 提取药品价格和等级
            prices = price_df[drug_id]
            levels = level_df[drug_id]
            
            # 绘制价格曲线
            plt.plot(prices.index, prices, label=f'{company_name} - Price', color=f'C{i}', alpha=0.7)
            
            # 绘制等级区域
            for level in range(3):
                mask = levels == level
                plt.fill_between(prices.index, prices, where=mask, 
                                color=['blue', 'green', 'red'][level], alpha=0.1, 
                                label=f'{company_name} - Level {level}' if level == 0 and i == 0 else "")
            
            # 标记价格等级基准值
            if drug_id in level_benchmarks[company_name]:
                drug_benchmarks = level_benchmarks[company_name][drug_id]
                for level, price in drug_benchmarks.items():
                    plt.axhline(y=price, color=['blue', 'green', 'red'][level], linestyle='--', alpha=0.5,
                               label=f'{company_name} - Level {level} Benchmark' if level == 0 and i == 0 else "")
        
        plt.title(f'Drug {drug_id} - All Price Levels')
        plt.xlabel('Date')
        plt.ylabel('Price')
        plt.legend(loc='upper left', bbox_to_anchor=(1.05, 1))
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(f"{output_dir}/drug_{drug_id}_all_price_levels.png", dpi=300, bbox_inches='tight')
        plt.close()

# %%
# %% 
# =========================
# Section: Game Estimation
# =========================
# This section is reserved for functions and logic related to game-theoretic estimation
# (e.g., Nash equilibrium estimation, payoff matrix construction, etc.)


# %%
# =========================
# Section: Predict 1st Stage Primitives of Dynamic Structural Model
# =========================

from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
import pandas as pd

def estimate_targeting_and_success_prob(event_df_with_levels, market_chars, price_dfs, price_jump_profit_predictions):
    # %%
    event_df_with_levels['same_level'] = event_df_with_levels['from_level'] == event_df_with_levels['to_level']

    # Drop events where from_level == to_level and event_type is 'price_increase'
    drop_index = event_df_with_levels[
        (event_df_with_levels['same_level']) 
    ].index
    # event_df_with_levels = event_df_with_levels.drop(drop_index)

    # Drop events where from_level == 2 and event_type is 'coordinated_lead' or 'price_increase'
    drop_index = drop_index.union(
        event_df_with_levels[
            (event_df_with_levels['from_level'] == 2) & (event_df_with_levels['event_type'] == 'coordinated_lead')
        ].index
    )
    # event_df_with_levels = event_df_with_levels.drop(drop_index)
    
    drop_index = drop_index.union(
        event_df_with_levels[
            (event_df_with_levels['from_level'] == 2) & (event_df_with_levels['event_type'] == 'price_increase')
        ].index
    )
    event_df_with_levels = event_df_with_levels.drop(drop_index)
    
    event_counts = (
        event_df_with_levels
        .groupby(['event_date', 'event_type'])
        .size()
        .unstack(fill_value=0)
        .sort_index()
    ).cumsum().shift(1).fillna(0)

    all_events = event_df_with_levels.copy()
    
    # --- Create complete panel ---
    # Get all possible (drug, period) combinations
    all_periods = pd.DataFrame({
        'date': np.arange(
            669, 1096)})
    all_drugs = pd.DataFrame({'drug_id': all_events['drug_id'].unique()})
    # all_firms = pd.DataFrame({'firm_id': ['CV','FA','SB']})
    panel = all_periods.merge(all_drugs, how='cross')
    # Mark periods with leadership attempts
    panel = panel.merge(
        all_events[all_events.event_type.isin(['coordinated_lead', 'price_increase'])],
        on=['drug_id', 'date'],
        how='left'
    )

    panel = panel.merge(
        event_counts.reset_index(),
        left_on='date',
        right_on='event_date',
        how='left',
        suffixes=('', '_cum')
    )
    # Merge targeted_events with market_chars on drug_id
    panel = panel.merge(
        market_chars,
        on='drug_id',
        how='left',
        suffixes=('', '_market')
    )

    panel['targeted'] = ((panel.event_type == 'price_increase' ) | (panel.event_type == 'coordinated_lead') )
    panel['success'] = (panel.event_type == 'coordinated_lead')
    
    # --- Calculate features ---
    # Sort by drug and period
    panel = panel.sort_values(['drug_id', 'event_date'])
    # Generate lagged targeted variable
    panel['lag_targeted'] = panel.groupby('drug_id')['targeted'].shift(1).fillna(0).astype(int)
    # %%
    # 1. Time since last targeting (hazard model style)
    # Compute time since last targeting event for each drug_id
    def time_since_last_targeted(subdf):
        last_event = None
        times = []
        for idx, row in subdf.iterrows():
            if row['targeted'] != 0:
                if last_event is None:
                    times.append(np.nan)
                else:
                    times.append(row['event_date'] - last_event)
                last_event = row['event_date']
            else:
                if last_event is None:
                    times.append(np.nan)
                else:
                    times.append(row['event_date'] - last_event)
        return pd.Series(times, index=subdf.index)

    panel['time_since_last'] = panel.groupby('drug_id', group_keys=False).apply(time_since_last_targeted)
    


    # 2. Past success rate (rolling window)
    # Drug_id-specific cumulative sum of past successes (up to previous period)
    panel['past_success_indicator'] = panel.groupby('drug_id')['success'].transform(
        lambda x: x.shift(1).cumsum().fillna(0)
    ) > 0
    
    # 3. Recent targeting frequency
    panel['targeting_freq'] = panel.groupby('drug_id')['targeted'].transform(
        lambda x: x.shift(1).rolling(7, min_periods=1).mean().ffill().bfill()
    )
    
    # panel['past_success'] = panel['past_success'].fillna(0)
    panel['time_since_last'] = panel['time_since_last'].fillna(1000)
    
    panel['from_level'] = panel.groupby(['drug_id'])['from_level'].ffill().bfill()
    panel['to_level'] = panel.groupby(['drug_id'])['to_level'].ffill().bfill()
    panel[['coordinated_lead', 'price_increase', 'price_decrease']] = panel[['coordinated_lead', 'price_increase', 'price_decrease']].ffill().bfill()

    # Fill missing event_date with date
    panel['event_date'] = panel['event_date'].fillna(panel['date'])
    panel[['event_date','date']] = panel[['event_date','date']].astype(int)
    # 4. Market concentration (example - modify as needed)
    
    # Fill missing market_size, price, price_coef using drug_id mapping
    for col in ['market_size', 'price', 'price_coef','Lab']:
        panel[col] = panel.groupby('drug_id')[col].transform('first' )
    
    # Fill missing from_level using drug_id and date mapping from level_dfs

    data_ccp_estimate = panel.dropna(subset=['time_since_last', 'price_coef'])
    
    # price_jump_profit_predictions.keys()
    # dict_keys(['profit_results', 'quantity_results', 'leadership_profit', 'leadership_quantity', 'deviation_profit', 'deviation_quantity'])
    # Check for NaNs in columns used in the formula
    # columns_used = [
    #     'targeted', 'past_success', 'from_level', 'to_level', 'coordinated_lead',
    #     'price_increase', 'price_decrease', 'market_size', 'price', 'price_coef', 'firm_id'
    # ]

    data_ccp_estimate = data_ccp_estimate[data_ccp_estimate['from_level'] < 2]
    data_ccp_estimate.loc[data_ccp_estimate.event_type.isna(), 'to_level'] = data_ccp_estimate.loc[data_ccp_estimate.event_type.isna(), 'from_level'] + 1
    
    
    # %%
    for idx in data_ccp_estimate.index:
        each_row = data_ccp_estimate.loc[idx]
        for firm_id in ['CV','FA','SB']:
            data_ccp_estimate.loc[idx,f'profit_difference_{firm_id}'] = (
                price_jump_profit_predictions['profit_results'][each_row.drug_id][each_row.to_level][firm_id]
            - price_jump_profit_predictions['profit_results'][each_row.drug_id][each_row.from_level][firm_id]
            ) / 1000 
    
    data_ccp_estimate['targeted'] = data_ccp_estimate['targeted'].astype(int)
    model_target = smf.logit(
        formula='targeted ~  price_increase + C(from_level) + (market_size + price_coef) * np.log(coordinated_lead + 1)', 
        data=data_ccp_estimate
    ).fit(maxiter=500)
    print(model_target.summary())
    # In-sample prediction
    data_ccp_estimate['psi'] = model_target.predict(data_ccp_estimate)
    
    targeted_events = data_ccp_estimate.loc[data_ccp_estimate.targeted>0,:]
    # Ensure 'success' is numeric (0/1) for statsmodels
    targeted_events['success'] = targeted_events['success'].astype(int)
    model_success = smf.logit(
        formula='success ~  price_increase + C(firm_id) + C(from_level) + ( market_size + price_coef) * np.log(coordinated_lead + 1)',
        data=targeted_events
    ).fit(maxiter=500)
    print(model_success.summary())
    # Predict in-sample targeted event success rate
    targeted_events['success_pred'] = model_success.predict(targeted_events)
    
    # Ensure firm_id is categorical for multinomial logit
    targeted_events['firm_id'] = pd.Categorical(targeted_events['firm_id'], categories=['CV', 'FA', 'SB'])
    targeted_events['firm_id_code'] = targeted_events['firm_id'].cat.codes

    model_leader = smf.mnlogit(
        formula='firm_id_code ~  price_increase + C(from_level) + ( market_size + price_coef) * np.log(coordinated_lead + 1)',
        data=targeted_events
    ).fit(maxiter=500)
    print(model_leader.summary())
    # %%
    # Return both the model and the dataframe with predictions
    return model_target, model_leader, model_success, data_ccp_estimate


def get_initial_values(model_target, model_leader, model_success, grids, data_ccp_estimate):
    S_grids, l_grids = grids
    firm_list = ['CV', 'FA', 'SB']
    n_drug = 222
    n_firm = 3
    phi_0 = np.zeros((n_drug, n_firm, len(l_grids)-1, len(S_grids)))
    psi_0 = np.zeros((n_drug, len(l_grids)-1, len(S_grids)))
    rho_0 = np.zeros((n_drug, n_firm, len(l_grids)-1, len(S_grids)))
    
    # For each drug_id, create a DataFrame with all combinations of from_level (0,1) and price_increase (S_grids)
    drug_ids = data_ccp_estimate['drug_id'].unique()
    data_rows = []
    for drug_id in drug_ids:
        # Use the first row for this drug_id as a template for other columns
        base_row = data_ccp_estimate[data_ccp_estimate['drug_id'] == drug_id].iloc[0].to_dict()
        for from_level in [0, 1]:
            for S in S_grids:
                row = base_row.copy()
                row['from_level'] = from_level
                row['coordinated_lead'] = S
                    
                data_rows.append(row)
    data_by_drug = pd.DataFrame(data_rows)
    data_by_drug.reset_index(drop=True, inplace=True)

    data_by_drug['psi'] = model_target.predict(data_by_drug)
    data_by_drug[['rho_cv','rho_fa','rho_sb']] = model_leader.predict(data_by_drug)
    
    for drug_id in drug_ids:
        for from_level in [0, 1]:
            for S_idx, S in enumerate(S_grids):
                # Filter data_by_drug for this drug_id and from_level
                sub_data = data_by_drug[
                    (data_by_drug['drug_id'] == drug_id) & 
                    (data_by_drug['from_level'] == from_level) & 
                    (data_by_drug['coordinated_lead'] == S)
                ]
                if not sub_data.empty:
                    # Get the first row's psi and rho values
                    rho_0[drug_id, :, from_level, S_idx] = sub_data[['rho_cv', 'rho_fa', 'rho_sb']].values[0]
                    psi_0[drug_id, from_level, S_idx] = sub_data['psi'].values[0]

    # Expand data_by_drug for each firm_id ('CV', 'FA', 'SB')
    expanded_rows = []
    for _, row in data_by_drug.iterrows():
        for firm_id in ['CV', 'FA', 'SB']:
            new_row = row.copy()
            new_row['firm_id'] = firm_id
            expanded_rows.append(new_row)
    data_by_drug = pd.DataFrame(expanded_rows)
    data_by_drug['success'] = model_success.predict(data_by_drug)

    for drug_id in drug_ids:
        for from_level in [0, 1]:
            for S_idx, S in enumerate(S_grids):
                # Filter data_by_drug for this drug_id and from_level
                sub_data = data_by_drug[
                    (data_by_drug['drug_id'] == drug_id) & 
                    (data_by_drug['from_level'] == from_level) & 
                    (data_by_drug['coordinated_lead'] == S)
                ]
                if not sub_data.empty:
                    # Get the first row's psi and rho values
                    phi_0[drug_id, :, from_level, S_idx] = sub_data['success'].values
    return phi_0, psi_0, rho_0

# %%
def estimate_psi_transition_by_drug(data_ccp_estimate, n_bins=2):
    """
    Estimate psi transition matrices for each drug_id and each time_since_event value,
    using quantile-based bins and computing bin means per drug_id.
    Returns:
        - transition_matrices: dict of dicts: {drug_id: {time_since_event: transition_matrix}}
        - bin_means: dict of arrays: {drug_id: bin_means}
        - bin_edges: dict of arrays: {drug_id: bin_edges}
    """
    psi_col='psi'
    psi_next_col='psi_next'
    drug_col='drug_id'
    # time_col = 'past_success_indicator'
    # data_ccp_estimate[time_col] = (data_ccp_estimate['past_success'] > 0).astype(int)  # Ensure time_col is integer type
    # Shift targeting probability by -1 within each drug_id to get the future targeting prob
    # Ensure data is sorted by drug_id and date before shifting
    data_ccp_estimate = data_ccp_estimate.sort_values([drug_col, 'date'])
    data_ccp_estimate['psi_lag'] = data_ccp_estimate.groupby(drug_col)[psi_col].shift(1)

    data_ccp_estimate['spillovers'] = data_ccp_estimate.groupby('date')['targeted'].transform('sum') - data_ccp_estimate['targeted']  # Sum targeting in other markets

    # Drop NA (first period per drug)
    df_ar = data_ccp_estimate.dropna(subset=['psi_lag', 'spillovers'])

    # OLS for AR(1) parameters
    X_ar = df_ar[['psi_lag', 'spillovers']]
    X_ar = sm.add_constant(X_ar)  # Add intercept
    y_ar = df_ar['psi']

    model_ar = sm.OLS(y_ar, X_ar).fit()
    rho, gamma = model_ar.params['psi_lag'], model_ar.params['spillovers']
    sigma_epsilon = np.std(model_ar.resid)

    print(f"AR(1) coefficient (ρ): {rho:.3f}")
    print(f"Spillover coefficient (γ): {gamma:.3f}")
    print(f"Innovation SD (σ_ε): {sigma_epsilon:.3f}")

    return None
    # transition_matrices = {}
    # bin_means = {}
    # bin_edges = {}
    # for drug_id, group in data_ccp_estimate.groupby(drug_col):
    #     # Compute quantile-based bin edges for this drug_id
    #     quantiles = np.linspace(0, 1, n_bins + 1)
    #     edges = group[psi_col].quantile(quantiles).values
    #     edges[-1] = np.inf
    #     edges[0] = -np.inf  # Ensure the first edge is negative infinity
    #     # If all edges are equal, make lower bound slightly lower to avoid empty bins
    #     if np.allclose(edges, edges[0]):
    #         edges[0] = edges[0] - 1e-6
    #     # If any consecutive edges are equal, make lower bound slightly lower
    #     for i in range(1, len(edges)):
    #         if np.isclose(edges[i], edges[i-1]):
    #             edges[i-1] = edges[i-1] - 1e-6
    #     # edges = np.unique(edges)
        
    #     bin_edges[drug_id] = edges
    #     digitized = np.digitize(group[psi_col], edges, right=True) - 1
    #     means = []
    #     for i in range(len(edges) - 1):
    #         bin_vals = group[psi_col][digitized == i]
    #         # If bin is empty, use the overall mean of the group as fallback
    #         means.append(bin_vals.mean() if not bin_vals.empty else (edges[i + 1] + edges[i]) / 2)
    #     bin_means[drug_id] = np.array(means)

    #     # Estimate transition matrices for each time_since_event
    #     transition_matrices[drug_id] = {}
    #     for t, sub in group.groupby(time_col):
    #         current_bin = np.digitize(sub[psi_col], edges, right=False) - 1
    #         next_bin = np.digitize(sub[psi_next_col], edges, right=False) - 1
    #         mat = np.zeros((n_bins, n_bins))
    #         for i, j in zip(current_bin, next_bin):
    #             if 0 <= i < n_bins and 0 <= j < n_bins:
    #                 mat[i, j] += 1
    #         mat = (mat + 0.01) / (mat.sum(axis=1, keepdims=True) + 0.01 * n_bins)
    #         transition_matrices[drug_id][t] = mat
    # return transition_matrices, bin_means, bin_edges
# %%

# 定义提价事件
def identify_price_events(price_arrays, penalty=10.0, num_series=222, col_start=668, col_end=1096, model="rbf"):
    """
    识别提价事件
    df: 预处理后的数据
    threshold: 提价百分比阈值，默认5%
    """
    event_data = []
    for i in range(num_series):
        price_cv_series = price_arrays[0].loc[col_start:col_end, i]
        price_fa_series = price_arrays[1].loc[col_start:col_end, i]
        price_sb_series = price_arrays[2].loc[col_start:col_end, i]

        # 检测各企业的变更点
        change_points_cv = detect_change_points(price_cv_series.values, model=model, pen=penalty)
        change_points_fa = detect_change_points(price_fa_series.values, model=model, pen=penalty)
        change_points_sb = detect_change_points(price_sb_series.values, model=model, pen=penalty)

        # 记录CV的变更点为事件
        for cp in change_points_cv[:-1]:  # 最后一个点是序列结尾
            pct_changes = price_cv_series.pct_change()
            window_start = max(cp-2, 0)
            window_end = min(cp+2, len(pct_changes))
            window = pct_changes.iloc[window_start:window_end]
            if not window.empty and not window.isna().all():
                idx = window.idxmax()
            if not pd.isna(idx):
                event_data.append({
                'drug_id': i,
                'leader_firm_id': 'CV',
                'event_date': idx,
                'event_pct_change': pct_changes[idx] * 100
                })
        # 记录FA的变更点为事件
        for cp in change_points_fa[:-1]:
            pct_changes = price_fa_series.pct_change()
            window_start = max(cp-2, 0)
            window_end = min(cp+2, len(pct_changes))
            window = pct_changes.iloc[window_start:window_end]
            if not window.empty and not window.isna().all():
                idx = window.idxmax()
            if not pd.isna(idx):
                event_data.append({
                'drug_id': i,
                'leader_firm_id': 'FA',
                'event_date': idx,
                'event_pct_change': pct_changes[idx] * 100
                })
        # 记录SB的变更点为事件
        for cp in change_points_sb[:-1]:
            pct_changes = price_sb_series.pct_change()
            window_start = max(cp-2, 0)
            window_end = min(cp+2, len(pct_changes))
            window = pct_changes.iloc[window_start:window_end]
            if not window.empty and not window.isna().all():
                idx = window.idxmax()
            if not pd.isna(idx):
                event_data.append({
                'drug_id': i,
                'leader_firm_id': 'SB',
                'event_date': idx,
                'event_pct_change': pct_changes[idx] * 100
                })
    event_df = pd.DataFrame(event_data)
    return event_df


# %%

def check_follower_response(event_df, price_df, window_days=8, follower_threshold=3.0, price_approx_threshold=0.1):
    
    results = []
    firms = ['CV', 'FA', 'SB']  # 固定企业列表
    
    # 为每个事件添加提价前的价格信息
    event_df_with_price = pd.merge(
        event_df,
        price_df[['drug_id', 'firm_id', 'date', 'price', 'pct_change']],
        left_on=['drug_id', 'leader_firm_id', 'event_date'],
        right_on=['drug_id', 'firm_id', 'date'],
        how='left'
    ).rename(columns={'price': 'pre_event_price'})
    
    # 对每个药品的事件按日期排序
    for drug_id, drug_events in event_df_with_price.groupby('drug_id'):
        # drug_id = 0
        drug_events = event_df_with_price[event_df_with_price['drug_id'] == drug_id]
    
        sorted_events = drug_events.sort_values('event_date')
        sorted_events['already_counted'] = False  # 添加响应标志列
        # 处理每个提价事件
        for i in range(len(sorted_events)):
            event = sorted_events.iloc[i]
            if event['already_counted']:
                continue

            leader_firm = event['leader_firm_id']
            event_date = event['event_date']
            event_pct = event['event_pct_change']
            pre_event_price = event['pre_event_price']

            follower_firms = [f for f in firms if f != leader_firm]

            # 定义窗口期
            window_end = event_date + window_days

            # 计算leader绝对价格变动
            leader_data = price_df[
                (price_df['drug_id'] == drug_id) &
                (price_df['firm_id'] == leader_firm) &
                (price_df['date'] >= event_date) &
                (price_df['date'] <= window_end)
            ]
            leader_abs_change = None
            leader_post_event_price = None
            if not leader_data.empty and not pd.isna(pre_event_price):
                # 取事件日后的第一个价格
                leader_post_event_price = leader_data.iloc[0]['price']
                leader_abs_change = leader_post_event_price - pre_event_price

            # 检查每个跟随者的响应
            follower_responses = {}
            for follower in follower_firms:
                # 获取跟随者在窗口期内的数据
                follower_data = price_df[
                    (price_df['drug_id'] == drug_id) &
                    (price_df['firm_id'] == follower) &
                    (price_df['date'] >= event_date) &
                    (price_df['date'] <= window_end)
                ]

                # 获取跟随者提价前的价格
                pre_follower_data = price_df[
                    (price_df['drug_id'] == drug_id) &
                    (price_df['firm_id'] == follower) &
                    (price_df['date'] < event_date) & 
                    (price_df['date'] >= event_date - 3)
                ].sort_values('date', ascending=False)

                pre_leader_data = price_df[
                    (price_df['drug_id'] == drug_id) &
                    (price_df['firm_id'] == leader_firm) &
                    (price_df['date'] < event_date) & 
                    (price_df['date'] >= event_date - 3)
                ].sort_values('date', ascending=False)

                # 检查提价前价格是否充分近似
                price_approx = False
                # 取最近一天的价格
                if not pre_follower_data.empty and not pre_leader_data.empty:
                    pre_follower_price = pre_follower_data.iloc[0]['price']
                    pre_leader_price = pre_leader_data.iloc[0]['price']
                    price_diff_ratio = abs(pre_follower_price - pre_leader_price) / pre_leader_price
                    # 检查最近3天内价格变动是否都很小
                    follower_stable = (pre_follower_data['pct_change'].abs() < price_approx_threshold * 100).all()
                    leader_stable = (pre_leader_data['pct_change'].abs() < price_approx_threshold * 100).all()
                    price_approx = follower_stable and leader_stable
                else:
                    price_approx = False

                if len(follower_data) == 0 or not price_approx:
                    follower_responses[follower] = {
                        'responded': False,
                        'pct_change': 0,
                        'response_date': None,
                        'lag_days': None,
                        'price_approx': price_approx,
                        'pre_event_price': pre_follower_data.iloc[0]['price'] if not pre_follower_data.empty else None,
                        'pre_event_price_diff_ratio': None,
                        'abs_change': None,
                        'post_event_price': None
                    }
                    continue

                # 检查是否有提价≥3%
                has_responded = any(follower_data['pct_change'] >= follower_threshold)
                if has_responded:
                    # 获取首次提价的日期和幅度
                    first_respond = follower_data[follower_data['pct_change'] >= follower_threshold].iloc[0]
                    abs_change = first_respond['price'] - pre_follower_price
                    follower_responses[follower] = {
                        'responded': True,
                        'pct_change': first_respond['pct_change'],
                        'response_date': first_respond['date'],
                        'lag_days': (first_respond['date'] - event_date),
                        'price_approx': price_approx,
                        'pre_event_price': pre_follower_price,
                        'pre_event_price_diff_ratio': (price_diff_ratio <= price_approx_threshold),
                        'abs_change': abs_change,
                        'post_event_price': first_respond['price']
                    }
                else:
                    follower_responses[follower] = {
                        'responded': False,
                        'pct_change': 0,
                        'response_date': None,
                        'lag_days': None,
                        'price_approx': price_approx,
                        'pre_event_price': pre_follower_price,
                        'pre_event_price_diff_ratio': (price_diff_ratio <= price_approx_threshold) if 'price_diff_ratio' in locals() else None,
                        'abs_change': None,
                        'post_event_price': None
                    }

            # 判断是否为成功的价格领导行为
            all_followed = all(resp['responded'] for resp in follower_responses.values())
            partial_followed = any(resp['responded'] for resp in follower_responses.values()) and not all_followed

            # 检查leader后续是否降价
            leader_future_data = price_df[
                (price_df['drug_id'] == drug_id) &
                (price_df['firm_id'] == leader_firm) &
                (price_df['date'] > event_date)
            ].sort_values('date')
            leader_price_reduced = False
            leader_reduce_date = None
            leader_reduce_pct = None
            if not leader_future_data.empty:
                # 找到首次降价的日期和幅度
                price_changes = leader_future_data['pct_change']
                reduce_idx = price_changes[price_changes < -0.5*event_pct].index
                if len(reduce_idx) > 0:
                    first_reduce = leader_future_data.loc[reduce_idx[0]]
                    if (first_reduce['date'] - event_date) < 40:  # 降价必须在4o天内
                        leader_price_reduced = True
                        leader_reduce_date = first_reduce['date']
                        leader_reduce_pct = first_reduce['pct_change']

            # 构建所有follower信息
            follower_info = {}
            for follower in follower_firms:
                resp = follower_responses.get(follower, {})
                follower_info[follower] = {
                    'responded': resp.get('responded'),
                    'pct_change': resp.get('pct_change'),
                    'response_date': resp.get('response_date'),
                    'lag_days': resp.get('lag_days'),
                    'price_approx': resp.get('price_approx'),
                    'pre_event_price': resp.get('pre_event_price'),
                    'pre_event_price_diff_ratio': resp.get('pre_event_price_diff_ratio'),
                    'abs_change': resp.get('abs_change'),
                    'post_event_price': resp.get('post_event_price')
                }

            # 如果所有跟随者都响应，标记为已处理
            if all_followed:
                print(f"Drug {drug_id}, Leader {leader_firm}, Event Date {event_date} - All followers responded.")
            results.append({
                'drug_id': drug_id,
                'leader_firm_id': leader_firm,
                'event_date': event_date,
                'event_pct_change': event_pct,
                'pre_event_price': pre_event_price,
                'leader_abs_change': leader_abs_change,
                'leader_post_event_price': leader_post_event_price,
                'already_counted': event['already_counted'],
                'followers': follower_info,
                'is_price_leadership': all_followed,
                'is_partial_followed': partial_followed,
                'leader_price_reduced': leader_price_reduced,
                'leader_reduce_date': leader_reduce_date,
                'leader_reduce_pct': leader_reduce_pct
            })
            # 标记已处理
            if all_followed:
                sorted_events.loc[(sorted_events.date >= event_date) & (sorted_events.date <= window_end), 'already_counted'] = True

            elif partial_followed:
                # 标记部分跟随的窗口也为已处理
                sorted_events.loc[(sorted_events.date >= event_date) & (sorted_events.date <= window_end), 'already_counted'] = True

    leadership_df = pd.DataFrame(results)
    return leadership_df



# %%
# =========================
# Section: Price Leadership Analysis Utilities
# =========================
# ------------------------------------------------------------

def calculate_differences(combined_series, change_points):
    """计算变更点前后的差异和百分比变化"""
    differences = []
    percentage_changes = []
    prev_cp = 0
    prev_prev_cp = 0
    
    for cp in change_points:
        if prev_cp != 0:
            segment = combined_series[prev_cp:cp]
            prev_segment = combined_series[prev_prev_cp:prev_cp]
        else:
            segment = combined_series[prev_cp:cp]
            prev_segment = combined_series[:cp]
            
        mean_before = np.mean(prev_segment, axis=0)
        mean_after = np.mean(segment, axis=0)
        
        diff = mean_after - mean_before
        pct_change = ((mean_after - mean_before) / mean_before) * 100
        
        differences.append(diff)
        percentage_changes.append(pct_change)
        
        prev_prev_cp = prev_cp
        prev_cp = cp
        
    return differences, percentage_changes


def analyze_price_series(price_cv, price_fa, price_sb, col_start, col_end, num_series=222, 
                            model="rbf", penalty=10):
    """
    分析多个价格序列中的变更点和价格变动
    
    参数:
    - price_cv, price_fa, price_sb: DataFrame，包含不同类型的价格数据
    - col_start, col_end: 分析的列范围
    - num_series: 要分析的序列数量
    - model: 变更点检测模型
    - penalty: 变更点检测的惩罚参数
    
    返回:
    - summary_data: 包含每个序列的变更点数量和差异的列表
    - price_jump_magnitudes: 包含每个序列正向价格变动幅度的列表
    - change_point_details: 包含每个序列详细变更点信息的字典列表
    """
    summary_data = []
    price_jump_magnitudes = []
    change_point_details = []

    for i in range(num_series):
        # 获取三个价格序列
        price_cv_series = price_cv.loc[col_start:col_end, i]
        price_fa_series = price_fa.loc[col_start:col_end, i]
        price_sb_series = price_sb.loc[col_start:col_end, i]

        # 检测变更点
        change_points_combined = detect_combined_change_points(price_cv_series, price_fa_series, price_sb_series,      model=model, pen=penalty)
        change_points_cv = detect_change_points(price_cv_series.values, model=model, pen=penalty)
        change_points_fa = detect_change_points(price_fa_series.values, model=model, pen=penalty)
        change_points_sb = detect_change_points(price_sb_series.values, model=model, pen=penalty)

        # 偏移变更点索引
        change_points_combined_offset = [each + col_start for each in change_points_combined]
        change_points_cv_offset = [each + col_start for each in change_points_cv]
        change_points_fa_offset = [each + col_start for each in change_points_fa]
        change_points_sb_offset = [each + col_start for each in change_points_sb]

        change_point_details.append({
            'i': i, 
            'change_points_combined': change_points_combined_offset, 
            'change_points_cv': change_points_cv_offset,
            'change_points_fa': change_points_fa_offset,
            'change_points_sb': change_points_sb_offset
        })

        # 计算变更点前后的差异
        combined_series = np.vstack((price_cv_series.values, price_fa_series.values, price_sb_series.values)).T
        differences, percentage_changes = calculate_differences(combined_series, change_points_combined)

        # 存储摘要信息
        num_jumps = len(change_points_combined) - 1  # 最后一个变更点是序列的结束
        summary_data.append([i, num_jumps, differences])

        # 存储正向百分比变化用于分析
        price_jump_magnitudes.append([pct for pct in percentage_changes if np.all(pct > 0)])
    
    return summary_data, price_jump_magnitudes, change_point_details

# %%

