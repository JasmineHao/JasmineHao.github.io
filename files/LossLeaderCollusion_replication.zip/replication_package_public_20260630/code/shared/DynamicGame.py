# %%
import array
import os
import sys
import time

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from scipy.optimize import minimize
from scipy.linalg import block_diag
from scipy.stats import norm

from statsmodels.api import OLS, add_constant
from numdifftools import Hessian

from sklearn.cluster import KMeans


np.set_printoptions(precision=4)



def indfind(state_m1, states):
    for j in range(len(states)):
        identifier = states[j] == state_m1
        try:
            identifier = all(identifier)
        except:
            pass
        if identifier:
            return (j)


def my_meshgrid(list_of_vec):
    """meshgrid"""
    tmp = np.meshgrid(*list_of_vec, sparse=False)
    num_vec = len(list_of_vec)
    num_d0 = len(list_of_vec[0])
    mehsgrid_matrix = np.zeros([len(tmp[0].flatten()), 0])
    for d_i in range(num_vec):
        meshgrid_vec = np.zeros(0)
        for n_i in range(num_d0):
            meshgrid_vec = np.append(meshgrid_vec, tmp[d_i][:, n_i].flatten())
        mehsgrid_matrix = np.column_stack([mehsgrid_matrix, meshgrid_vec])
    return (mehsgrid_matrix)


def clogit_scipy(ydum, x, restx, namesb, print_output, use_bounds=False):
    time_start = time.time()

    nobs = int(ydum.shape[0])
    nalt = int(max(ydum) + 1)
    npar = int(x.shape[1]/nalt)
    myzero = 1e-16

    xysum = 0
    y = np.zeros((nobs, nalt))
    for j in range(nalt):
        y[:, j] = ydum == j
    llike = 0
    b0 = np.zeros(npar)
    
    
    def obj_fun(b):

        phat = np.dot(x, block_diag(*[b]*nalt).T) + restx

        phat = (phat.T - phat.max(1)).T
        phat = np.exp(phat)
        phat[phat < myzero] = myzero

        phat = (phat.T / phat.sum(1)).T
        # phat[phat < myzero] = myzero
        # phat[phat > 1- myzero] = 1 - myzero
        # np.sum(y * np.log(phat))
        return (-np.sum(y * np.log(phat)))

    start_time = time.time()
    if use_bounds:
        bounds = [(-np.inf, 0)] * npar
    else:
        bounds = []

    results = minimize(obj_fun, b0, method='BFGS', options={
                       'maxiter': 1000, 'disp': False, 'gtol': 1e-2})
    
    Avarb = results.hess_inv
    
    sdb = np.sqrt(np.diag(Avarb))
    b0 = results.x
    tstat = b0/sdb

    if print_output:
        print("="*70)
        print(f"{'Conditional Logit Estimation Results':^70}")
        print("="*70)
        print(f"{'Number of Iterations':<30}: {results.nit}")
        print(f"{'Number of Observations':<30}: {nobs}")
        print(f"{'Log-Likelihood':<30}: {-results.fun:.4f}")
        print(f"{'Elapsed Time (s)':<30}: {time.time() - time_start:.2f}")
        print("-"*70)
        print(f"{'Parameter':<20}{'Estimate':>12}{'Std. Error':>15}{'t-Statistic':>15}")
        print("-"*70)
        for j in range(npar):
            print(f"{namesb[j]:<20}{b0[j]:>12.4f}{sdb[j]:>15.4f}{tstat[j]:>15.2f}")
        print("-"*70)
    print(f'Estimation completed in {time.time() - start_time:.2f} seconds.')
    return ([b0, Avarb, results.success])


# def tauchen_arbitrary_bounds(mu, rho, sigma, S_grid):
#     """
#     Discretize AR(1): x' = mu + rho x + eps, eps ~ N(0, sigma^2)
#     Only fill upper triangular part of transition matrix.

#     Args:
#         mu (float): Mean/intercept
#         rho (float): AR(1) coefficient
#         sigma (float): Std dev of shocks
#         S_grid (np.array): Grid points

#     Returns:
#         Pi (np.array): Transition probability matrix (upper triangular only)
#     """
#     z_min = min(S_grid)
#     z_max = max(S_grid)
#     n = len(S_grid)
#     z = np.linspace(z_min, z_max, n)
#     step = (z_max - z_min) / (n - 1)
#     Pi = np.zeros((n, n))
#     for i in range(n):
#         for j in range(i, n):  # Only upper triangular part
#             mid = mu + rho * z[i]
#             if j == 0:
#                 Pi[i, j] = norm.cdf((z[0] - mid + step / 2) / sigma)
#             elif j == n - 1:
#                 Pi[i, j] = 1 - norm.cdf((z[-1] - mid - step / 2) / sigma)
#             else:
#                 z_lower = (z[j] - mid - step / 2) / sigma
#                 z_upper = (z[j] - mid + step / 2) / sigma
#                 Pi[i, j] = norm.cdf(z_upper) - norm.cdf(z_lower)
#         # Ensure row sums to 1 by adding remainder to diagonal
#         remainder = 1.0 - Pi[i].sum()
#         Pi[i, i] += remainder
#     return Pi


# def estimate_ar1_and_discretize(S_series, S_grid):
#     X = S_series[:-1]
#     y = S_series[1:]
#     X_ols = add_constant(X)
#     ar1_model = OLS(y, X_ols).fit()
#     mu = ar1_model.params[0]
#     rho = ar1_model.params[1]
#     sigma = np.sqrt(ar1_model.mse_resid)
#     transition_matrix = tauchen_arbitrary_bounds(mu, rho, sigma, S_grid)
#     return transition_matrix



# %%
# =========================
# Section: Value Iteration for Dynamic Game
# =========================
#

def stable_sigmoid(x):
    mask = x >= 0
    positive = 1 / (1 + np.exp(-x[mask]))
    negative = np.exp(x[~mask]) / (1 + np.exp(x[~mask]))
    out = np.empty_like(x)
    out[mask] = positive
    out[~mask] = negative
    return out

def bellman_operator(V, transition_matrix, params, grids, price_jump_profits,
            price_jump_quantities,
            leader_profits,
            leader_quantities,
            deviator_profits,
            deviator_quantities, attr_regression, scale="uniform", delta=0.99,psi_bar=1.0, learning='probability'):
    # Unpack state grids
    S_grid, l_grid = grids

    # Initialize new value function array
    V_new = np.zeros_like(V)

    # Extract parameters with numerical safety
    menu_cost = np.asanyarray(params['menu_cost'])
    demand_spillover_ = np.asarray(params['demand_spillover'])[None,:] + attr_regression['ln_market_size'].values[:,None] * np.asarray(params['demand_spillover_market_size'])[None,:] + attr_regression['chronic'].values[:,None] * np.asarray(params['demand_spillover_chronic'])[None,:]
    
    
    # demand_spillover = params['demand_spillover']
    beta = params.get('beta')
    gamma = params.get('gamma')
    zeta = params.get('zeta')
    lambda_ = np.asarray(params['lambda']) 

    pi_level = price_jump_profits[:,:,:,None] 
    pi_leader = leader_profits[:,:,:,None] 
    pi_deviation = deviator_profits[:,:,:,None] 
    
    
    # Numerical stabilization
    tau_grid = 1 / (1 + np.exp(- np.clip(lambda_[0] + lambda_[1] * S_grid, -100, 100)))
    
    if learning == 'conduct':
        # Expand last dimension of pi_level to have length equal to len(tau_grid)
        pi_level_new = np.repeat(pi_level, len(tau_grid), axis=-1).copy()
        pi_leader_new = np.repeat(pi_leader, len(tau_grid), axis=-1).copy()
        pi_deviation_new = np.repeat(pi_deviation, len(tau_grid), axis=-1).copy()
        for _i in range(pi_level.shape[1]):
            other_idx = [_j for _j in range(pi_level.shape[1]) if _j != _i]
            
            # Get indices of the other two columns
            pi_level_new[:, _i, :, :] = pi_level[:, _i, :, :] + tau_grid[None, None, None, :] * (pi_level[:, other_idx[0], :, :] + pi_level[:, other_idx[1], :, :])

            pi_leader_new[:, _i, :, :] = pi_leader[:, _i, :, :] + tau_grid[None, None, None, :] * (pi_leader[:, other_idx[0], :, :] + pi_leader[:, other_idx[1], :, :])

            pi_deviation_new[:, _i, :, :] = pi_deviation[:, _i, :, :] + tau_grid[None, None, None, :] * (pi_deviation[:, other_idx[0], :, :] + pi_deviation[:, other_idx[1], :, :])
        pi_level = pi_level_new.copy()
        pi_leader = pi_leader_new.copy()
        pi_deviation = pi_deviation_new.copy()

    # if scale == "uniform":
    #     scale_array = 0.5 * (pi_level.max(keepdims=True) - pi_level.min(keepdims=True))
    # else:
    #     scale_array = 0.2 * pi_level.mean(axis=2, keepdims=True)- pi_level.min(axis=2, keepdims=True)
    
    pi_level = pi_level + price_jump_quantities[:,:,:,None] * demand_spillover_[:,:,None, None] 
    pi_leader = pi_leader + leader_quantities[:,:,:,None] * demand_spillover_[:,:,None, None]
    pi_deviation = pi_deviation + deviator_quantities[:,:,:,None] * demand_spillover_[:,:,None, None]

    if scale == "uniform":
        scale_array = 0.1 * pi_level.max(keepdims=True)
    else:
        scale_array = 0.1 * pi_level.mean(axis=2, keepdims=True)- pi_level.min(axis=2, keepdims=True)
    
    pi_level = pi_level / scale_array
    pi_leader = pi_leader / scale_array
    pi_deviation = pi_deviation / scale_array
    menu_cost = menu_cost[None,:,None,None] / scale_array

    # tau_grid = np.exp(0.01 * (lambda_[0] + lambda_[1] * S_grid))
    # tau_grid = np.clip(tau_grid, 1e-6, 1-1e-6)  # Prevent 0/1

    # Compute value functions with numerical safety
    V_F_d = pi_deviation[:,:,:-1,:]  + delta * np.einsum('ijkl,ml->ijkm', V[:,:,:-1], transition_matrix)
    V_F_f_success = (pi_level[:,:,1:,:]  - menu_cost) + delta * np.einsum('ijkl,ml->ijkm', V[:,:,1:], transition_matrix) 
    V_F_f_fail = (pi_level[:,:,:-1,:] - menu_cost) - delta * menu_cost + delta * np.einsum('ijkl,ml->ijkm', V[:,:,:-1], transition_matrix) 

    # V_F_f_success = (pi_level[:,:,1:,None] ) + delta * np.einsum('ijkl,ml->ijkm', V[:,:,:-1], transition_matrix) 
    # V_F_f_fail = (pi_level[:,:,:-1,None]  ) + delta * np.einsum('ijkl,ml->ijkm', V[:,:,:-1], transition_matrix) 

    # Stabilized tau_crit calculation
    # logit_arg =  (tau_grid[None,None,None,:] * (V_F_f_success - V_F_f_fail) + V_F_f_fail -  V_F_d ) / beta

    logit_arg =  ((V_F_f_success - V_F_f_fail) + V_F_f_fail -  V_F_d ) / beta
    # logit_arg =  (V_F_f_success -  V_F_d ) / beta
    logit_arg = np.clip(logit_arg, -100, 100)  # Prevent overflow
    
    # Compute phi such that for the i-th column, multiply the other 2 columns' values
    phi = np.ones_like(logit_arg)
    for _i in range(logit_arg.shape[1]):
        # Get indices of the other two columns
        other_idx = [_j for _j in range(logit_arg.shape[1]) if _j != _i]
        # Multiply the other two columns
        phi[:,_i] = stable_sigmoid(logit_arg[:, other_idx[0]]) * stable_sigmoid(logit_arg[:, other_idx[1]])

        # phi[:,_i] = (1 / (1 + np.exp(-logit_arg[:, other_idx[0]]))) * (1 / (1 + np.exp(-logit_arg[:, other_idx[1]])))

    if learning=='probability':
        # Value calculations with stabilization
        # V_F = phi * (tau_grid[None,None,None,:] * V_F_f_success + 
                    # (1 - tau_grid[None,None,None,:]) * V_F_f_fail) + (1 - phi) * V_F_d
        # V_F = phi * (V_F_f_success) + (1 - phi) * V_F_d
        V_F = V_F_f_success
        V_F = np.nan_to_num(V_F, nan=0.0)


        V_L = (pi_leader[:,:,:-1,:] - menu_cost) + \
            delta * (phi * tau_grid[None,None,None,:] * tau_grid[None,None,None,:] * np.einsum('ijkl,ml->ijkm', V[:,:,1:], transition_matrix)  + (1 -  phi * tau_grid[None,None,None,:] * tau_grid[None,None,None,:] ) * ( np.einsum('ijkl,ml->ijkm', V[:,:,:-1], transition_matrix) - menu_cost ) )
        V_L = np.nan_to_num(V_L, nan=0.0)
    else:
        V_F = V_F_f_success
        V_F = np.nan_to_num(V_F, nan=0.0)


        V_L = (pi_leader[:,:,:-1,:] - menu_cost) + \
            delta * (phi  * np.einsum('ijkl,ml->ijkm', V[:,:,1:], transition_matrix)  + (1 -  phi  ) * ( np.einsum('ijkl,ml->ijkm', V[:,:,:-1], transition_matrix) - menu_cost ) )
        V_L = np.nan_to_num(V_L, nan=0.0)

    V_no_coord = pi_level[:, :, :-1, :]  + delta * np.einsum('ijkl,ml->ijkm', V[:,:,:-1], transition_matrix) 

    # Stabilized leadership probability (rho)
    utility_diff = (V_L - V_F) / gamma
    
    max_utility = np.nanmax(utility_diff, axis=1)
    exp_utility = np.exp(utility_diff - max_utility[:,None,:,:])
    # Add 4th dimension (length of S_grid) to rho
    S_grid_len = S_grid.shape[0] if hasattr(S_grid, 'shape') else len(S_grid)

    rho = exp_utility / np.nansum(exp_utility, axis=1, keepdims=True)
    # Expand rho to shape (..., S_grid_len)
    
    # rho = np.repeat(rho[..., np.newaxis], S_grid_len, axis=-1)

    # Stabilized targeting probability (psi)
    V_coord_m = np.sum(V_L * rho + V_F * (1 - rho), axis=1)
    V_no_coord_m = np.sum(V_no_coord * rho, axis=1)
    
    # Log-sum-exp trick for psi
    term1 = (V_no_coord_m - V_coord_m) / zeta

    # psi should have shape (n_drug, n_level, len(S_grid))
    # term1 shape: (n_drug, n_level, n_S)
    term1 = np.clip(term1, -100, 100)  # Prevent overflow
    psi = (psi_bar) / (1 + np.exp(term1))
    psi = np.clip(psi, 1e-10, 1-1e-10)
    # Set psi(j, l) = 0 if l > l_grid[j] for each drug j
    for j in range(psi.shape[0]):
        for l in range(psi.shape[1]):
            if l > l_grid[j]-2:
                psi[j, l, :] = 0
    # Broadcast psi to have S_grid as the last dimension if needed

    # Final value update
    V_new[:,:,:-1] = psi[:,None,:] * (rho * V_L + (1 - rho) * V_F) + (1 - psi[:,None,:]) * V_no_coord
    # V_new[:,:,1:] = pi_level[:,:,1:,None] + delta * ( tau_grid[None,None,None,:] * (V_new[:,:,1:] - menu_cost - V[:,:,:-1]) +  V[:,:,:-1])
    V_new[:,:,-1] = pi_level[:,:,-1] + delta * np.einsum('ijl,ml->ijm', V[:,:,-1], transition_matrix) 

    # Find indices where tau_grid > 1 - 1e-3
    high_tau_idx = np.where(tau_grid > 1 - 1e-3)[0]
    if len(high_tau_idx) > 0:
        # For each index, replace V_new[:,:,:,idx] with its mean over the last dimension
        mean_vals = np.mean(V_new[:,:,:,high_tau_idx], axis=-1, keepdims=True)
        for i, idx in enumerate(high_tau_idx):
            V_new[:,:,:,idx] = mean_vals[:,:,:,0]
    
    return V_new, psi, phi, rho
   


# =========================
# Section: Solve for Value Function (Value Iteration)
# =========================

def solve_value_function(
            params, grids, transition_matrix, price_jump_profits,
            price_jump_quantities,
            leader_profits,
            leader_quantities,
            deviator_profits,
            deviator_quantities, attr_regression, scale='uniform', delta=0.99, max_iter=1000, tol=1e-6, verbose=False,psi_bar=0.01, learning='probability'):
    """
    Solves for the value function using value iteration.

    Parameters
    ----------
    params : dict
        Model parameters.
    grids : tuple of np.ndarray
        State grids (S_grid, l_grid, psi_grid).
    price_jump_profit_matrix, price_jump_quantity_matrix, leader_profit_matrix, leader_quantity_matrix,
    deviator_profit_matrix, deviator_quantity_matrix : np.ndarray
        Arrays for profits and quantities.
    delta : float
        Discount factor.
    max_iter : int
        Maximum number of iterations.
    tol : float
        Convergence tolerance.
    verbose : bool
        If True, print progress.

    Returns
    -------
    V : np.ndarray
        Converged value function.
    n_iter : int
        Number of iterations performed.
    """
    # Initialize value function to zeros
    # S_grid, l_grid, psi_grid = grids
    S_grid, l_grid = grids
    n_drug, n_firm = 222, 3
    n_l = np.max(l_grid)
    V = np.zeros((n_drug, n_firm, n_l, len(S_grid)))

    for n_iter in range(1, max_iter + 1):
        V_new, psi, phi, rho = bellman_operator(
            V, transition_matrix, params, grids, price_jump_profits,
            price_jump_quantities,
            leader_profits,
            leader_quantities,
            deviator_profits,
            deviator_quantities, attr_regression, scale=scale, delta=delta,psi_bar=psi_bar, learning=learning
        )
        diff = np.max(np.abs(V_new - V))
        if verbose and n_iter % 10 == 0:
            print(f"Iteration {n_iter}: max diff = {diff:.6e}")
        if diff < tol:
            if verbose:
                print(f"Value function converged after {n_iter} iterations (tol={tol})")
            break
        V = V_new
    else:
        if verbose:
            print(f"Value function did not fully converge after {max_iter} iterations (final diff={diff:.6e})")
    return  V, psi, phi, rho


def array_to_params(param_array):
    # Assumes order: [beta, gamma, lambda, zeta, menu_cost (n_firms), demand_spillover (n_firms)]
    beta = param_array[0]
    gamma = param_array[1]
    zeta = param_array[2]
    lambda_ = param_array[3:5]
    menu_cost = param_array[5:8]
    demand_spillover = param_array[8:11]
    demand_spillover_market_size = param_array[11:14]
    demand_spillover_chronic = param_array[14:17]
    return {
        'beta': beta,
        'gamma': gamma,
        'zeta': zeta,
        'lambda': np.array(lambda_),
        'menu_cost': np.array(menu_cost),
        'demand_spillover': np.array(demand_spillover),
        'demand_spillover_market_size': np.array(demand_spillover_market_size), 
        'demand_spillover_chronic': np.array(demand_spillover_chronic)
    }

def param_to_array(params):
    """
    Converts a parameter dictionary to a flat numpy array.
    Assumes keys: beta, gamma, zeta, lambda, menu_cost, demand_spillover.
    """
    beta = np.atleast_1d(params['beta'])
    gamma = np.atleast_1d(params['gamma'])
    zeta = np.atleast_1d(params['zeta'])
    lambda_ = np.asarray(params['lambda']).flatten()
    menu_cost = np.asarray(params['menu_cost']).flatten()
    demand_spillover = np.asarray(params['demand_spillover']).flatten()
    demand_spillover_market_size = np.asarray(params['demand_spillover_market_size']).flatten()
    demand_spillover_chronic = np.asarray(params['demand_spillover_chronic']).flatten()
    return np.concatenate([beta, gamma, zeta, lambda_, menu_cost, demand_spillover, demand_spillover_market_size, demand_spillover_chronic])


def neg_log_likelihood(param_array, V, transition_matrix, grids, price_jump_profits,
            price_jump_quantities,
            leader_profits,
            leader_quantities,
            deviator_profits,
            deviator_quantities,
            data, attr_regression, scale=np.ones(222), delta=0.99,
            penalty_weight=0.1, tau_0=0.01, tau_1=0.95, S_target=250, targeting_weight=1.0,psi_bar=0.01, learning='probability'):
    params = array_to_params(param_array)
    
    total_log_lik = 0.0
    
    V_new, psi, phi, rho = bellman_operator(
            V, transition_matrix, params, grids, price_jump_profits,
            price_jump_quantities,
            leader_profits,
            leader_quantities,
            deviator_profits,
            deviator_quantities, attr_regression, scale=scale, delta=delta,psi_bar=psi_bar, learning=learning
        )
    
    # Extract tau (tau_grid) from bellman operator
    # You might want to modify bellman_operator to return tau_grid explicitly,
    # or recompute tau_grid here from params and grids:
    S_grid, _ = grids
    lambda_ = np.asarray(params['lambda'])
    tau_grid = 1 / (1 + np.exp(- np.clip(lambda_[0] + lambda_[1] * S_grid, -100, 100)))
    # Find indices closest to 0 and S_target
    idx_0 = np.argmin(np.abs(S_grid - 0))
    idx_target = np.argmin(np.abs(S_grid - S_target))
    
    # Calculate penalty
    penalty = penalty_weight * len(data) * (
        (tau_grid[idx_0] - tau_0)**2 + (tau_grid[idx_target] - tau_1)**2
    )
    
    # Existing likelihood calculation
    psi_data = psi[data[:,0], data[:,2], data[:,3]] 
    rho_data = rho[data[:,0], data[:,1], data[:,2], data[:,3]]
    phi_data = phi[data[:,0], data[:,1], data[:,2], data[:,3]]

    psi_data = np.clip(psi_data, 1e-3, 1 - 1e-3)
    rho_data = np.clip(rho_data, 1e-3, 1 - 1e-3)
    phi_data = np.clip(phi_data, 1e-3, 1 - 1e-3)

    success_data = data[:,4]
    targeted_data = data[:,5]

    log_lik = (
        targeting_weight * np.log(1 - psi_data) * (1 - targeted_data)  # Untargeted markets
        + targeted_data * (
            targeting_weight * np.log(psi_data)                        # Targeting probability
            + np.log(rho_data)                      # Leadership probability
            + success_data * np.log(phi_data)       # Success term
            + (1 - success_data) * np.log(1 - phi_data)  # Failure term
        )
    )
    log_lik = np.nan_to_num(log_lik, nan=0.0)
    
    # Return negative log-likelihood plus penalty
    return - np.sum(log_lik) + penalty


# %%
def dict_to_array(nested_dict, firm_list, l_grid):
        n_drug = len(nested_dict)
        n_firm = len(firm_list)
        n_l = np.max(l_grid)
        arr = np.zeros((n_drug, n_firm, n_l))
        for i in range(n_drug):
            for l in nested_dict[i].keys():
                for j, firm in enumerate(firm_list):
                    arr[i, j, l] = nested_dict[i][l][firm]
        return arr


# %%
# Transition of psi and S
# compute the success probability of each drug based on the current state and value


# %%
# =========================
# Section: Simulate Dynamic Game
# =========================

def simulate_dynamic_game(
    psi, phi, rho, grids, 
    n_days=466, start_day=630, max_targets=30, lockout_day=0, verbose=False
):
    """
    Simulate the dynamic game over a specified number of days.

    Args:
        model_target: Fitted model to predict targeting probabilities.
        model_leader: Fitted model to predict leader probabilities.
        model_success: Fitted model to predict success probabilities.
        market_chars: DataFrame with market characteristics.
        simulation_columns: List of columns to use in simulation.
        n_days: Number of days to simulate (default 427). 
        start_day: Starting day index (default 669).
        max_targets: Maximum number of markets to target per day (default 5).

    Returns:
        simulated_data_df: DataFrame with simulation snapshots for each period.
    """
    (S_grid, l_grid) = grids
    # # Initialize current_state: DataFrame with drug_id, 
    current_state = pd.DataFrame({
        'DrugID': np.arange(222),
        'current_level': 0,  # Initial level
        'from_level': 0,  # Initial from_level
        'to_level': 0,  # Initial to_level
        'coordinated_lead': 0,
        'price_increase': 0,
        'price_decrease': 0,
    })
    
    current_state.set_index('DrugID', inplace=True)
    # Track drugs that are "locked out" for 8 days after being targeted
    index_date = np.arange(start_day, start_day + n_days)

    lockout_days = pd.Series(0, index=range(222))  # 0 means available
    simulation_snapshots = []
    coordinated_snapshots = []
    # Initialize cumulative counters
    coordinated_lead = pd.DataFrame(0, columns=range(222), index=range(n_days))
    price_increase = pd.DataFrame(0, columns=range(222), index=range(n_days))
    price_decrease = pd.DataFrame(0, columns=range(222), index=range(n_days))

    
    price_cv = pd.DataFrame(0, columns=range(222), index=range(n_days))
    price_fa = pd.DataFrame(0, columns=range(222), index=range(n_days))
    price_sb = pd.DataFrame(0, columns=range(222), index=range(n_days))
    
    price_level_dfs = {'CV': price_cv, 'FA': price_fa, 'SB': price_sb}
    # Discretize the coordinated_lead value of the first available drug according to S_grid
    
    for t_idx, t in enumerate(np.arange(start_day, start_day + n_days)):
        # Mark drugs unavailable if in lockout
        current_state['from_level'] = current_state['current_level']
        available_mask = (lockout_days <= 0) & (current_state['current_level'] < psi.shape[1])
        
        current_state['to_level'] = current_state['from_level']
        current_state['firm_id'] = -1
        current_state.loc[available_mask, 'to_level'] = current_state.loc[available_mask, 'from_level'] + 1

        coordinated_lead_val = current_state.coordinated_lead.iloc[0]
        S_idx = np.argmin(np.abs(S_grid - coordinated_lead_val))
    
        # Step 1: Predict targeting probabilities for available drugs
        available_state = current_state[available_mask].copy()
        targeting_probs = psi[available_state.index, available_state.current_level, S_idx] 
        
        # Replace NaNs with a small probability to avoid errors
        targeting_probs = np.nan_to_num(targeting_probs, nan=1e-6)
        # Draw 0 or 1 for each probability (Bernoulli trial)
        targeted_binaries = pd.Series(
            np.random.binomial(1, targeting_probs),
            index=available_state.index
        )

        targeting_probs = pd.Series(targeting_probs, index=available_state.index)
        targeted_markets = targeted_binaries[targeted_binaries > 0].index
        if len(targeted_markets) > max_targets:
            targeted_markets = targeting_probs[targeted_markets].nlargest(max_targets).index
        if verbose & len(targeted_markets) > 0:
            print(f"Targeted markets at time {t}: {targeted_markets.tolist()}")

        # Step 2: For each targeted market, predict leader and success
        targeted_state = available_state.loc[targeted_markets].copy()

        if not targeted_state.empty:
            leader_probs = rho[targeted_markets,:,targeted_state.from_level.values ,S_idx]
            # Draw leader randomly for each row according to leader_probs
            leader_idx = [np.random.choice(leader_probs.shape[1], p=leader_probs[i]/leader_probs[i].sum()) for i in range(leader_probs.shape[0])]
            leader_map = {0: 'CV', 1: 'FA', 2: 'SB'}
            leader = pd.Series(leader_idx, index=targeted_state.index).map(leader_map)
            
            targeted_state['firm_id'] = leader
            
            success_prob = phi[targeted_markets, leader_idx, targeted_state.from_level.values, S_idx]
            
            success = pd.Series(
                [np.random.binomial(1, phi_i) for phi_i in success_prob],
                index=targeted_markets
            )
            targeted_state['success'] = success
            targeted_state['event_time'] = t
            # Update state for targeted drugs
            for m in targeted_state.index:
                lockout_days[m] = lockout_day
                # Map 'CV' to 0, 'FA' to 1, 'SB' to 2 for firm_id
                firm_map = {'CV': 0, 'FA': 1, 'SB': 2}
                current_state.loc[m, 'firm_id'] = firm_map.get(targeted_state.loc[m, 'firm_id'], -1)
                if success[m] > 0:
                    current_state.loc[m, 'current_level'] = current_state.loc[m, 'to_level']
                    coordinated_lead.loc[t_idx, m] = 1
                    price_level_dfs[leader[m]].loc[t_idx:, m] = current_state.loc[m, 'to_level']   # Set price based on level
                    # Assign other 2 firms to the to_level as well
                    for other_firm in ['CV', 'FA', 'SB']:
                        if other_firm != leader[m]:
                            price_level_dfs[other_firm].loc[ (t_idx+5):,m] = current_state.loc[m, 'to_level']
                else:
                    price_level_dfs[leader[m]].loc[t_idx:(t_idx+14),m] = current_state.loc[m, 'to_level']   # Set price 
                    price_increase.loc[t_idx, m] = 1
                    if t_idx + 14 < n_days:
                        price_decrease.loc[t_idx + 14, m] = 1
            coordinated_snapshots.append(targeted_state.reset_index())
        # Add cumulative columns to current_state for snapshot
        current_state['coordinated_lead'] = coordinated_lead.loc[:t_idx, :].sum().sum()
        current_state['price_increase'] = price_increase.loc[:t_idx, :].sum().sum()
        current_state['price_decrease'] = price_decrease.loc[:t_idx, :].sum().sum()

        # Store snapshot for this period
        snapshot = current_state.copy()
        snapshot['event_time'] = t
        simulation_snapshots.append(snapshot.reset_index())

        # Decrement lockout counters
        lockout_days = lockout_days - 1
        lockout_days[lockout_days < 0] = 0

        # Mark locked-out drugs with special state (e.g., set a flag)
        current_state['locked_out'] = lockout_days > 0

    # Combine all snapshots into a single DataFrame
    simulated_data_df = pd.concat(simulation_snapshots, ignore_index=True)
    simulated_event_df = pd.concat(coordinated_snapshots, ignore_index=True)

    # Flatten coordinated_lead and price_increase into long format and merge into simulated_data_df
    coordinated_lead_long = coordinated_lead.stack().reset_index()
    coordinated_lead_long.columns = ['event_time', 'DrugID', 'success']
    coordinated_lead_long['event_time'] = coordinated_lead_long['event_time'] + start_day  # Adjust date to match simulation

    price_increase_long = (price_increase + coordinated_lead).stack().reset_index()
    price_increase_long.columns = ['event_time', 'DrugID', 'targeted']
    price_increase_long['event_time'] = price_increase_long['event_time'] + start_day  # Adjust date to match simulation
    # Merge into simulated_data_df on date and drug_id


    # Drop 'success' and 'targeted' columns if they exist
    simulated_data_df = simulated_data_df.drop(columns=[col for col in ['success', 'targeted'] if col in simulated_data_df.columns])

    simulated_data_df = simulated_data_df.merge(
        coordinated_lead_long,
        left_on=['DrugID', 'event_time'],
        right_on=['DrugID', 'event_time'],
        how='left'
    )
    
    simulated_data_df = simulated_data_df.merge(
        price_increase_long,
        left_on=['DrugID', 'event_time'],
        right_on=['DrugID', 'event_time'],
        how='left'
    )

    simulated_data_df['coordinated_lead'] = simulated_data_df['coordinated_lead'].fillna(0).astype(int)
    simulated_data_df['price_increase'] = simulated_data_df['price_increase'].fillna(0).astype(int)

    # Transpose all price_level_dfs and return as a list
    price_level_dfs = [df.set_index(np.arange(start_day,start_day+n_days)) for df in price_level_dfs.values()]
    return simulated_data_df, simulated_event_df, price_level_dfs




# %%
def plot_smoothed_weighted_avg_prices(weighted_avg_prices, date_df, firm_list, window=3, start_day=669):
    """
    Plot smoothed weighted average prices (divided by 1000) over time for each firm.

    Args:
        weighted_avg_prices (dict): Dict of {firm: {date: avg_price}}.
        date_df (pd.DataFrame): DataFrame with date information and index as date indices.
        firm_list (list): List of firm/channel names.
        window (int): Rolling window size for smoothing.
    """
    fig, ax = plt.subplots(figsize=(12, 6))
    markers = {'CV': 'o', 'FA': 's', 'SB': 'D'}

    for firm in firm_list:
        dates = [date for date in date_df.index if date in weighted_avg_prices[firm]]
        avg_prices = [weighted_avg_prices[firm][date] / 1000 for date in dates]
        # Smooth the price series using rolling average
        if len(avg_prices) >= window:
            smoothed_prices = pd.Series(avg_prices).rolling(window=window, center=True, min_periods=1).mean()
        else:
            smoothed_prices = avg_prices
        ax.plot(dates, smoothed_prices, label=firm, marker=markers.get(firm, 'o'), markevery=10, linewidth=2)

    ax.set_xlabel('Date')
    ax.set_ylabel('Weighted Avg Price (thousands)')
    ax.set_title('Smoothed Weighted Average Prices by Firm Over Time (Rolling Average)')
    ax.legend()
    ax.xaxis.set_major_locator(plt.MaxNLocator(10))
    xtick_dates = np.linspace(669, len(date_df) - 1, 6, dtype=int)
    xtick_dates[-1] = len(date_df) - 1
    ax.set_xticks(xtick_dates)
    ax.set_xticklabels(
        [pd.to_datetime(date_df.Date[i]).strftime('%Y-%m-%d') for i in xtick_dates],
        rotation=45
    )
    ax.set_xlim([start_day, date_df.index.max()])
    plt.tight_layout()
    plt.show()


# %%
def compute_weighted_avg_price(price_df, market_size):
    """
    Compute weighted average price for each date, weighted by market size.

    Args:
        price_df (pd.DataFrame): DataFrame of prices, index=date, columns=drug_id.
        market_size (pd.DataFrame): DataFrame of market sizes, index=date, columns=drug_id.

    Returns:
        pd.Series: Weighted average price per date.
    """
    # Align indices and columns
    ms = market_size.loc[price_df.columns]
    weighted_sum = (price_df * ms).sum(axis=1)
    total_weight = ms.sum()
    avg_price_series = weighted_sum / total_weight
    return avg_price_series


def get_discretized_prices(price_level_dfs, price_levels_by_firm_by_drug, firm_list):
    """Map price levels to actual price values for each firm and drug."""
    discretized_prices = []
    for firm_id, level_df in zip(range(len(firm_list)), price_level_dfs):
        price_df = level_df.copy()
        for drug_id in level_df.columns:
            price_map = {l: price_levels_by_firm_by_drug[drug_id][firm_id, l] for l in range(price_levels_by_firm_by_drug[drug_id].shape[1])}
            price_df[drug_id] = level_df[drug_id].map(price_map)
        discretized_prices.append(price_df)
    return discretized_prices


def get_weighted_avg_prices(price_dfs, market_size, firm_list):
    """Compute weighted average prices for each firm."""
    weighted_avg_prices = {}
    for idx, firm in enumerate(firm_list):
        weighted_avg_prices[firm] = compute_weighted_avg_price(price_dfs[idx], market_size)
    return weighted_avg_prices

# def simulate_and_plot(psi, phi, rho, grids, price_levels_by_firm_by_drug, firm_list, market_size, date_df, data_df):
#     psi = np.nan_to_num(psi, nan=0.0)
#     phi = np.nan_to_num(phi, nan=0.0)
#     rho = np.nan_to_num(rho, nan=0.0)

#     simulated_data_df, simulated_event_df, price_level_dfs = simulate_dynamic_game(psi, phi, rho, grids)

    
    
#     discretized_prices_sim = get_discretized_prices(pivot_from_level_by_event_time(simulated_data_df), price_levels_by_firm_by_drug, firm_list)
#     weighted_avg_prices_sim = get_weighted_avg_prices(discretized_prices_sim, market_size, firm_list)
#     plot_smoothed_weighted_avg_prices(weighted_avg_prices_sim, date_df, firm_list, window=3)


#     # Count the number of price increase events led by each firm using 'leader_firm_id'
#     price_increase_counts = data_df['firm_id'].value_counts().sort_index()
#     print("Frequency of price increase events led by each firm (by firm_id):")
#     print(price_increase_counts)
#     print(simulated_data_df['firm_id'].value_counts().sort_index())

#     return simulated_data_df, simulated_event_df, price_level_dfs

# %%

def pivot_from_level_by_event_time(data_df):
    data_df = data_df.drop_duplicates(subset=['DrugID', 'event_time'], keep='first')
    success_data = data_df.loc[data_df.success>0]
    pivot_df = success_data.pivot(index='event_time', columns='DrugID', values='from_level')
    # Ensure columns are from 0 to 221 (222 columns)
    pivot_df = pivot_df.reindex(columns=range(222))
    pivot_df = pivot_df.reindex(range(data_df.event_time.min(), data_df.event_time.max())).reset_index()
    # Forward fill with last value + 1
    pivot_df.bfill()
    for drug_id in range(222):
        pivot_df[drug_id] = pivot_df[drug_id].ffill().apply(lambda x: x + 1 if pd.notnull(x) else x)
    pivot_df = pivot_df.fillna(0)
    pivot_df = pivot_df.astype(int).set_index('event_time')
    return [pivot_df] * 3

# %%
# Drop duplicate (DrugID, event_time) pairs in data_df, keeping the first occurrence

# %%
def DynamicGameEstimation(
    param_array=None,
    bounds=None,
    grids=None,
    price_jump_analysis=None,
    scale=None,
    data=None,
    transition_matrix=None,
    delta=0.99,
    max_outer_iter=50,
    tol_outer=1e-4,
    normalize=False,
    same_normalize=False,
    menu_cost=True,
    demand_spillover=True,
    demand_spillover_type='constant', # ['constant', 'log']
    belief=True,
    belief_update=True,
    same_spillover=False,
    same_menu=False,
    payoff_parameter=True,
    penalty_weight=1.,
    tau_0=0.01,
    tau_1=0.99,
    S_target=250,
    market_size=None,
    firm_list=None,
    date_df=None,
    psi_bar=0.01,
    col_start=101,
    col_end=120,
    price_levels_by_firm_by_drug=None,
    attr_regression=None,
    sim_data = True,
    targeting_weight=1.,
    learning='probability' # ['probability', 'conduct', 'spillover']
):
    # Default bounds and param_array if not provided
    if bounds is None:
        bounds = [
            (1e-3, None),  # beta > 0
            (1e-3, None),  # gamma > 0
            (1e-3, 200),  # zeta > 0
            (-20, 20),
            (0, 10),  # lambda_1 > 0
            (0, None),       # menu_cost > 0
            (0, None),       # menu_cost > 0
            (0, None),       # menu_cost > 0
            (0, None), # demand_spillover > 0
            (0, None), # demand_spillover > 0
            (0, None), # demand_spillover > 0
            (0, None), # demand_spillover_market_size[0] > 0
            (0, None), # demand_spillover_market_size[1] > 0
            (0, None), # demand_spillover_market_size[2] > 0
            (0, None), # demand_spillover_chronic[0] > 0
            (0, None), # demand_spillover_chronic[1] > 0
            (0, None) # demand_spillover_chronic[2] > 0
        ]
    if param_array is None:
        param_array = np.array([
            1.,      # beta
            1.,      # gamma
            1.,      # zeta
            0.0,     # lambda_0
            0.1,     # lambda_1
            0.0,     # menu_cost[0]
            0.0,     # menu_cost[1]
            0.0,     # menu_cost[2]
            0.5,     # demand_spillover[0]
            0.5,     # demand_spillover[1]
            0.5,      # demand_spillover[2]
            0.0,     # demand_spillover_market_size[0]
            0.0,     # demand_spillover_market_size[1]
            0.0,      # demand_spillover_market_size[2]
            0.0,     # demand_spillover_chronic[0]
            0.0,     # demand_spillover_chronic[1]
            0.0,      # demand_spillover_chronic[2]
        ])
    param_se_array = np.zeros_like(param_array)
    n_l = max(grids[1])
    n_firms = 3 if firm_list is None else len(firm_list)
    drug_ids = np.arange(len(scale)) if scale is not None else np.arange(222)
    V = np.zeros((len(drug_ids), n_firms, n_l, len(grids[0])))

    params = array_to_params(param_array)
    firm_list = ['CV','FA','SB']
    
    price_jump_profits = dict_to_array(price_jump_analysis['profit_results'], firm_list, grids[1])
    price_jump_quantities = dict_to_array(price_jump_analysis['quantity_results'], firm_list, grids[1])
    leader_profits = dict_to_array(price_jump_analysis['leadership_profit'], firm_list, grids[1])
    leader_quantities = dict_to_array(price_jump_analysis['leadership_quantity'], firm_list, grids[1])
    deviator_profits = dict_to_array(price_jump_analysis['deviation_profit'], firm_list, grids[1])
    deviator_quantities = dict_to_array(price_jump_analysis['deviation_quantity'], firm_list, grids[1])

    # Define objective function for MLE with fixed V_old
        # Determine which parameters to optimize (mask out fixed ones)
    mask = np.ones_like(param_array, dtype=bool)
    # mask[2] = False # Must set zeta to 1, otherwise unidentified
    mask[:2] = False
    
    if (not normalize): 
        # Mask out indices 0:3 (e.g., beta, gamma, zeta)
        mask[:3] = False
    if not belief:
        # Mask out indices 3:5 (e.g., lambda)
        mask[3:5] = False
    if not menu_cost:
        mask[5:8] = False
    if not demand_spillover:
        mask[8:] = False
    if belief and not belief_update:
        mask[4] = False
        param_array[4] = 0.
    if demand_spillover_type == 'constant':
        # covariates for demand_spillover 11:17
        mask[11:17] = False
        param_array[11:17] = 0
    
    converged = False

    for outer_iter in range(max_outer_iter):
        # print(f"Outer iteration {outer_iter+1}")

        # Step 1: Solve value function given current parameters
        V_old, psi, phi, rho = solve_value_function(
            array_to_params(param_array), grids, transition_matrix, price_jump_profits,
            price_jump_quantities,
            leader_profits,
            leader_quantities,
            deviator_profits,
            deviator_quantities, 
            attr_regression, scale=scale, 
            delta=delta, max_iter=10, tol=1e-6, verbose=False,psi_bar=psi_bar, learning=learning
        )

        
        # Only optimize over unmasked parameters
        param_init = param_array[mask]
        bounds_opt = [b for b, m in zip(bounds, mask) if m]
        
        def obj(param_init):
            # Reconstruct full parameter vector from optimized and fixed values
            param_full = param_array.copy()
            param_full[mask] = param_init

            # If same_menu is True, set menu_cost (5:8) to the same value
            if same_normalize:
                param_full[:3] = param_full[0]
            if same_menu:
                param_full[5:8] = param_full[5]
            if same_spillover:
                param_full[8:11] = param_full[8]
                param_full[11:14] = param_full[11]
                param_full[14:17] = param_full[14]
            return neg_log_likelihood(
                param_full, V_old, transition_matrix,
                grids,  price_jump_profits,
                price_jump_quantities,
                leader_profits,
                leader_quantities,
                deviator_profits,
                deviator_quantities, data, attr_regression, scale=scale,
                delta=delta, penalty_weight=penalty_weight, tau_0=tau_0, tau_1=tau_1, S_target=S_target,psi_bar=psi_bar,targeting_weight=targeting_weight, learning=learning
                )
        
        

        # Step 3: Optimize parameters given V_old
        res = minimize(
            fun=obj,
            x0=param_init,
            method='L-BFGS-B',
            bounds=bounds_opt,
            options={'disp': False, 'maxiter': 100}
        )

        param_new = param_array.copy()
        param_new[mask] = res.x

        
        # If same_menu is True, set menu_cost (5:8) to the same value
        if payoff_parameter & same_menu:
            param_new[5:8] = param_new[5]
            
        # If same_spillover is True, set demand_spillover (8:11) to the same value
        if payoff_parameter & demand_spillover & same_spillover:
            param_new[8:11] = param_new[8]
            param_new[11:14] = param_new[11]
            param_new[14:17] = param_new[14]
        # Check convergence of parameters
        param_diff = np.linalg.norm(param_new - param_array)
        # print(f"Parameter change norm: {param_diff}")

        param_array = param_new

        if (param_diff < tol_outer):
            print("Converged!")
            converged=True
            break
    _success = res.success
    _message = res.message
    params = array_to_params(param_array)
    params_se = array_to_params(param_se_array)
    # print("Optimal parameters:")
    # for key, value in params.items():
    #     print(f"{key}: {value}")
    print("Optimization success:", _success)
    print("Message:", _message)
    
    # Compute Hessian
    hessian_estimator = Hessian(obj)
    hessian_matrix = hessian_estimator(res.x)  # optimal_params: estimated parameters
    param_se_array[mask] = np.sqrt(np.diag(np.linalg.pinv(hessian_matrix)))

    if payoff_parameter & same_menu:
        param_se_array[5:8] = param_se_array[5]
    if payoff_parameter & same_spillover:
        param_se_array[8:11] = param_se_array[8]

    # After convergence, solve value function one last time with optimal params
    V, psi, phi, rho = solve_value_function(
            array_to_params(param_array), grids, transition_matrix, price_jump_profits,
            price_jump_quantities,
            leader_profits,
            leader_quantities,
            deviator_profits,
            deviator_quantities, attr_regression, scale=scale, 
            delta=delta, max_iter=100, tol=1e-6, verbose=False,psi_bar=psi_bar, learning=learning
        )

    # print("Estimated Parameters:")
    # for k, v in params.items():
    #     print(f"{k}: {v}")

    if sim_data:
        simulated_data_df, simulated_event_df, price_level_dfs = simulate_dynamic_game(psi, phi, rho, grids, n_days=col_end-col_start+1, start_day=col_start, max_targets=50, lockout_day=0)

        discretized_prices_sim = get_discretized_prices(
            pivot_from_level_by_event_time(simulated_data_df),
            price_levels_by_firm_by_drug,
            firm_list
        )
        weighted_avg_prices_sim = get_weighted_avg_prices(discretized_prices_sim, market_size, firm_list)
    else:
        simulated_data_df = None
        simulated_event_df = None
        price_level_dfs = None
        weighted_avg_prices_sim = None
    # plot_smoothed_weighted_avg_prices(weighted_avg_prices_sim, date_df, firm_list, window=1)

    return {
        "params": params,
        "param_se": params_se,
        "converged": converged,
        "optimization_success": _success,
        "V": V,
        "psi": psi,
        "phi": phi,
        "rho": rho,
        "result": res,
        "simulated_data_df": simulated_data_df,
        "simulated_event_df": simulated_event_df,
        "price_level_dfs": price_level_dfs,
        "weighted_avg_prices_sim": weighted_avg_prices_sim
    }

# %%
# Functions for goodness of fit

def get_event_rank_df(data_df, simulated_df):
    # Extract actual successful events and assign ranks
    event_actual = (
        data_df[data_df.success > 0]
        .sort_values('event_time')
        .groupby(['DrugID', 'from_level'])
        .first()
        .reset_index()[['DrugID', 'event_time', 'from_level']]
        .sort_values(['event_time'])
    )
    event_actual['event_rank'] = np.arange(1, len(event_actual) + 1)

    # Extract simulated successful events and assign ranks
    event_sim = (
        simulated_df[simulated_df.success > 0]
        .sort_values('event_time')
        .groupby(['DrugID', 'from_level'])
        .first()
        .reset_index()[['DrugID', 'event_time', 'from_level']]
        .sort_values(['event_time'])
    )
    event_sim['event_rank'] = np.arange(1, len(event_sim) + 1)

    # Merge actual and simulated events on DrugID and from_level
    df_merged = pd.merge(
        event_actual, event_sim, on=['DrugID', 'from_level'],
        suffixes=('_actual', '_sim'),
        how='outer'  # Take the intersection (joint) of the two DataFrames
    )
    return df_merged

# %%
def plot_event_rank_comparison(df_list, model_names, figsize=(8, 5)):
    """
    Plots actual vs simulated event ranks for multiple models and returns the figure.

    Args:
        df_list (list of pd.DataFrame): Each DataFrame must have 'event_rank_actual' and 'event_rank_sim' columns.
        model_names (list of str): Names for each model, used in the legend.
        figsize (tuple): Figure size.
    Returns:
        matplotlib.figure.Figure: The created figure.
    """
    import matplotlib.pyplot as plt
    fig = plt.figure(figsize=figsize)
    min_rank = min(df['event_rank_actual'].min() for df in df_list)
    max_rank = max(df['event_rank_actual'].max() for df in df_list)
    for df, name in zip(df_list, model_names):
        plt.scatter(df['event_rank_actual'], df['event_rank_sim'], alpha=0.5, label=name)
    plt.plot([min_rank, max_rank], [min_rank, max_rank], 'r--', label='Perfect Rank')
    plt.xlim(min_rank, max_rank)
    plt.xlabel('Actual Rank')
    plt.ylabel('Simulated Rank')
    plt.legend()
    plt.tight_layout()
    plt.show()
    return fig
# %%

def get_simulated_weighted_avg_prices(model_result, price_levels_by_firm_by_drug, market_size, firm_list):
    discretized_prices = get_discretized_prices(model_result['price_level_dfs'], price_levels_by_firm_by_drug, firm_list)
    return get_weighted_avg_prices(discretized_prices, market_size, firm_list)

# Helper functions
def correlation_with_time_weights(series1, series2):
    """
    Calculates time-weighted (sqrt(time)) correlation between two series.
    """
    series1 = np.asarray(series1)
    series2 = np.asarray(series2)
    times = np.arange(1, len(series1)+1)
    weights = np.sqrt(times)
    mean1 = np.average(series1, weights=weights)
    mean2 = np.average(series2, weights=weights)
    cov = np.average((series1 - mean1) * (series2 - mean2), weights=weights)
    std1 = np.sqrt(np.average((series1 - mean1)**2, weights=weights))
    std2 = np.sqrt(np.average((series2 - mean2)**2, weights=weights))
    return cov / (std1 * std2) if std1 > 0 and std2 > 0 else 0

# %%
# Section: Demand Prediction
# ------------------------
def nested_demand(p, alpha, rho, beta, delta0, log_price=True): 
    # Cap rho between 0.01 and 0.99 for numerical stability
    rho = np.clip(rho, 0.01, 0.99)

    if log_price:
        u_store = beta + alpha * np.log(p)
    else:
        u_store = beta + alpha * p
    # to prevent overflow in exp
    dz = u_store / (1 - rho)
    a = np.max(dz)
    iv_store = (1 - rho) * (a + np.log(np.sum(np.exp(dz - a))))

    # Nest utilities
    u_nest = np.array([
        iv_store,  # Store nest
        delta0          # Outside good
    ])
    # Nest probabilities
    exp_nest = np.exp(u_nest)
    nest_shares = exp_nest / np.sum(exp_nest)
    
    # Within-nest shares
    exp_store = np.exp(dz - a)
    store_shares = exp_store / np.sum(exp_store)

    # Final shares
    return (store_shares * nest_shares[0]).tolist() + [nest_shares[1]]


def profit_firm(p, c, alpha, rho, beta, delta0=0, demand_spillover=0, log_price=True):
    """Profit for a firm given price p, cost c, alpha, rho, beta, and demand spillover"""
    # Calculate market shares
    s1, s2, s3, s_out = nested_demand(p, alpha, rho, beta, delta0, log_price=log_price)

    # Calculate profits
    profit = (p - c) * np.array([s1, s2, s3]) + demand_spillover * np.array([s1, s2, s3])
    
    return profit

def nash_equilibrium(c, alpha, rho, beta, delta0, demand_spillover, tol=1e-4, max_iter=50, log_price=True):
    """Nash equilibrium with nested logit
    c: marginal cost 
    """

    p =  c * 1.2 # Start with 50% markup
    
    for _ in range(max_iter):
        old_p = p.copy()
        
        # Sequential best response
        for i in range(3):
            res = minimize(
                lambda x: -profit_firm(
                    np.array([x[0] if j == i else p[j] for j in range(3)]), 
                    c, alpha, rho, beta, delta0, demand_spillover, log_price=log_price
                )[i],
                x0=np.array([p[i]]),
                bounds=[(c[i], c[i]*3)]  # Constrain to 3x cost max for each firm
            )
            p[i] = res.x[0]
        if np.max(np.abs(p - old_p)) < tol:
            break
    s1, s2, s3, s_out = nested_demand(p, alpha, rho, beta, delta0, log_price=log_price)            
    return p, np.array([s1, s2, s3])



# %%
# Game Estimation
# --------------------
def compute_profit_given_price(p,c,ms,alpha,beta,rho,log_price):
    s = nested_demand(p, alpha, rho, beta, 0, log_price=log_price)[:3]
    quantity = ms * np.array(s)
    profit = (p - c) * quantity
    return profit, quantity, s

def estimate_price_jump_profits(price_levels_by_firm_by_drug, demand_result, marginal_cost, market_size, market_size_within_nest, adjust=False, log_price=True, adban=True):
    """
    Estimate profits and quantities for different price jump scenarios.

    Args:
        level_benchmarks (dict): Nested dict with price benchmarks for each firm and drug.
        demand_result (dict): Output from demand estimation containing 'alphas', 'betas', 'rhos'.
        marginal_cost (pd.Series or np.ndarray): Marginal cost for each drug.
        market_size (pd.Series or np.ndarray): Market size for each drug.

    Returns:
        dict: Contains nested dicts and matrices for profits and quantities under various scenarios.
    """
    profit_results = {}
    quantity_results = {}
    leadership_profit = {}
    leadership_quantity = {}
    deviation_profit = {}
    deviation_quantity = {}

    alphas = demand_result['alphas']
    betas = demand_result['betas']
    rhos = demand_result['rhos']
    
    # for drug_id in rhos.index:
    for drug_id in range(222):
        profit_results[drug_id] = {}
        quantity_results[drug_id] = {}
        leadership_profit[drug_id] = {}
        leadership_quantity[drug_id] = {}
        deviation_profit[drug_id] = {}
        deviation_quantity[drug_id] = {}
        
        beta = betas[drug_id].values 
        if adban:
            alpha = alphas[drug_id][1]
        else:
            alpha = alphas[drug_id][0]
        rho = rhos[drug_id]
        
        c = marginal_cost[drug_id]
        ms = market_size[drug_id] 

            
        level_prices_by_firm = price_levels_by_firm_by_drug[drug_id]
        for l in range(level_prices_by_firm.shape[1]):
            p = level_prices_by_firm[:,l] / 1000
            profit, quantity, _ = compute_profit_given_price(p, c, ms, alpha, beta, rho, log_price=log_price)
            if adjust:
                sum_quantity_i = np.sum(quantity)
                quantity = quantity * market_size_within_nest[drug_id] / sum_quantity_i
                profit = profit * market_size_within_nest[drug_id] / sum_quantity_i

            profit_results[drug_id][l] = dict(zip(['CV', 'FA', 'SB'], profit))
            quantity_results[drug_id][l] = dict(zip(['CV', 'FA', 'SB'], quantity))

        # transitions = []
        # # Leadership transitions: from lower to higher levels
        # for from_idx in range(max_level):
        #     to_idx = from_idx + 1
        #     transitions.append((f'{from_idx}to{to_idx}', from_idx, to_idx))
        # # Deviation transitions: from higher to lower levels
        # for from_idx in range(1, max_level + 1):
        #     to_idx = from_idx - 1
        #     transitions.append((f'{from_idx}to{to_idx}', from_idx, to_idx))

        max_level = level_prices_by_firm.shape[1] - 1
        

        for from_idx in range(max_level):
            leadership_profit[drug_id][from_idx] = {}
            leadership_quantity[drug_id][from_idx] = {}
            deviation_profit[drug_id][from_idx] = {}
            deviation_quantity[drug_id][from_idx] = {}

            for f, f_id in zip(['CV', 'FA', 'SB'], [0, 1, 2]):
                to_idx = from_idx + 1
                p = np.array(level_prices_by_firm[:,from_idx]) / 1000
                p[f_id] = level_prices_by_firm[f_id, to_idx] / 1000
                profit, quantity, _ = compute_profit_given_price(p, c, ms, alpha, beta, rho, log_price=log_price)
                if adjust:
                    sum_quantity_i = np.sum(quantity)
                    quantity = quantity * market_size_within_nest[drug_id] / sum_quantity_i
                    profit = profit * market_size_within_nest[drug_id] / sum_quantity_i
                
                leadership_profit[drug_id][from_idx][f] = profit[f_id]
                leadership_quantity[drug_id][from_idx][f] = quantity[f_id]

                
                p = np.array(level_prices_by_firm[:,to_idx]) / 1000
                p[f_id] = level_prices_by_firm[f_id, from_idx] / 1000
                profit, quantity, _ = compute_profit_given_price(p, c, ms, alpha, beta, rho, log_price=log_price)
                if adjust:
                    sum_quantity_i = np.sum(quantity)
                    quantity = quantity * market_size_within_nest[drug_id] / sum_quantity_i
                    profit = profit * market_size_within_nest[drug_id] / sum_quantity_i
                
                deviation_profit[drug_id][from_idx][f] = profit[f_id]
                deviation_quantity[drug_id][from_idx][f] = quantity[f_id]

    # drug_ids = range(222)
    # firms = ['CV', 'FA', 'SB']

    # def nested_dict_to_array(nested_dict):
    #     # nested_dict[drug_id][level][firm]
    #     return np.array([
    #         [
    #             [nested_dict[drug_id][level][firm] for level in range(3)]
    #             for firm in firms
    #         ]
    #         for drug_id in drug_ids
    #     ])

    # profit_matrix = nested_dict_to_array(profit_results)
    # quantity_matrix = nested_dict_to_array(quantity_results)

    # def shift_dict_to_array(shift_dict, shift_labels):
    #     # shift_dict[drug_id][firm][shift][firm]
    #     return np.array([
    #         [
    #             [shift_dict[drug_id][firm][shift][firm_id] for shift in shift_labels]
    #             for firm, firm_id in zip(firms, range(3))
    #         ]
    #         for drug_id in drug_ids
    #     ])

    # leadership_shifts = ['0to1', '1to2', '0to2']
    # deviation_shifts = ['1to0', '2to1', '2to0']

    # leadership_profit_matrix = shift_dict_to_array(leadership_profit, leadership_shifts)
    # leadership_quantity_matrix = shift_dict_to_array(leadership_quantity, leadership_shifts)
    # deviation_profit_matrix = shift_dict_to_array(deviation_profit, deviation_shifts)
    # deviation_quantity_matrix = shift_dict_to_array(deviation_quantity, deviation_shifts)

    return {
        'profit_results': profit_results,
        'quantity_results': quantity_results,
        'leadership_profit': leadership_profit,
        'leadership_quantity': leadership_quantity,
        'deviation_profit': deviation_profit,
        'deviation_quantity': deviation_quantity,
        # 'profit_matrix': profit_matrix,
        # 'quantity_matrix': quantity_matrix,
        # 'leadership_profit_matrix': leadership_profit_matrix,
        # 'leadership_quantity_matrix': leadership_quantity_matrix,
        # 'deviation_profit_matrix': deviation_profit_matrix,
        # 'deviation_quantity_matrix': deviation_quantity_matrix
    }


# %%

def plot_V_difference(estimation_results, S_grid, s_grid_by_date, date_df_year_week, plot_indices):
    """
    Plot the mean and quantiles of V[:,:,1] - V[:,:,0] for each firm.
    """
    xtick_dates = date_df_year_week.reset_index().set_index('YearWeekInd').loc[plot_indices, 'Date']

    num_ticks = 6
    if len(xtick_dates) > num_ticks:
        tick_positions = np.linspace(0, len(xtick_dates) - 1, num_ticks, dtype=int)
        xtick_dates = xtick_dates.iloc[tick_positions]

    tau_grid = 1 / (1 + np.exp(- (estimation_results['params']['lambda'][0] + estimation_results['params']['lambda'][1] * S_grid)))

    # Prepare V differences
    V_diff_1_0 = tau_grid[None,None,:] * estimation_results['phi'][:,:, 0] * (estimation_results['V'][:, :, 1] - estimation_results['V'][:, :, 0]) 
    V_diff_2_1 =  tau_grid[None,None,:] * estimation_results['phi'][:,:, 1] * (estimation_results['V'][:, :, 2] - estimation_results['V'][:, :, 1])
    colors = {'CV': 'blue', 'FA': 'green', 'SB': 'orange'}
    markers = {'CV': 'o', 'FA': 's', 'SB': 'D'}
    firm_names = ['CV', 'FA', 'SB']

    mean_diff_1_0 = np.mean(V_diff_1_0, axis=0)
    q5_diff_1_0 = np.quantile(V_diff_1_0, 0.05, axis=0)
    q95_diff_1_0 = np.quantile(V_diff_1_0, 0.95, axis=0)

    mean_diff_2_1 = np.mean(V_diff_2_1, axis=0)
    q5_diff_2_1 = np.quantile(V_diff_2_1, 0.05, axis=0)
    q95_diff_2_1 = np.quantile(V_diff_2_1, 0.95, axis=0)

    fig, axs = plt.subplots(3, 1, figsize=(8, 8), sharex=True, gridspec_kw={'height_ratios': [1, 1, 1]}, sharey='row')

    # Subplot 1: V[:,:,1] - V[:,:,0]
    for i, firm in enumerate(firm_names):
        # Smooth the mean_diff_1_0[i] using a rolling window
        smoothed = pd.Series(mean_diff_1_0[i][s_grid_by_date[plot_indices].values]).rolling(window=5, center=True, min_periods=1).mean()
        axs[0].plot(plot_indices, smoothed, label=firm, color=colors[firm])
        
    axs[0].set_ylabel('V1 - V0')
    axs[0].set_title('Mean of V Difference by Firm (1-0)')
    axs[0].legend()
    axs[0].grid(True)

    # Subplot 2: V[:,:,2] - V[:,:,1]
    for i, firm in enumerate(firm_names):
        smoothed = pd.Series(mean_diff_2_1[i][s_grid_by_date[plot_indices].values]).rolling(window=5, center=True, min_periods=1).mean()
        axs[1].plot(plot_indices, smoothed, label=firm, color=colors[firm])

    axs[1].set_xlabel('Index')
    axs[1].set_ylabel('V2 - V1')
    axs[1].set_title('Mean of V Difference by Firm (2-1)')
    axs[1].legend()
    axs[1].grid(True)

    # Set xlim for both subplots
    xlim = (plot_indices.min(), plot_indices.max())
    axs[0].set_xlim(xlim)
    axs[1].set_xlim(xlim)
    
    axs[2].plot(plot_indices, tau_grid.flatten()[s_grid_by_date[plot_indices].values])
    axs[2].set_xlabel('week')
    axs[2].set_ylabel(r'$\tau$')
    axs[2].set_ylim(0.2,1.2)
    axs[2].set_title('Tau Grid vs S Grid')
    axs[2].grid(True)

    # Set xticks to xtick_dates
    axs[2].set_xticks(xtick_dates.index)
    axs[2].set_xticklabels([pd.to_datetime(d).strftime('%Y-%m-%d') for d in xtick_dates.values], rotation=0)

    plt.tight_layout()
    plt.show()
    return fig

# %%

def SimulateCounterfactual(params, grids, transition_matrix, price_jump_analysis, price_levels_by_firm_by_drug, market_size, delta, scale, psi_bar, attr_regression, col_start=101, col_end=120, learning='probability'):
    firm_list = ['CV','FA','SB']
    price_jump_profits = dict_to_array(price_jump_analysis['profit_results'], firm_list, grids[1])
    price_jump_quantities = dict_to_array(price_jump_analysis['quantity_results'], firm_list, grids[1])
    leader_profits = dict_to_array(price_jump_analysis['leadership_profit'], firm_list, grids[1])
    leader_quantities = dict_to_array(price_jump_analysis['leadership_quantity'], firm_list, grids[1])
    deviator_profits = dict_to_array(price_jump_analysis['deviation_profit'], firm_list, grids[1])
    deviator_quantities = dict_to_array(price_jump_analysis['deviation_quantity'], firm_list, grids[1])
    # After convergence, solve value function one last time with optimal params
    V, psi, phi, rho = solve_value_function(
            params, grids, transition_matrix, price_jump_profits,
            price_jump_quantities,
            leader_profits,
            leader_quantities,
            deviator_profits,
            deviator_quantities, attr_regression, scale=scale, 
            delta=delta, max_iter=100, tol=1e-6, verbose=False,psi_bar=psi_bar, learning=learning
        )

    simulated_data_df, simulated_event_df, price_level_dfs = simulate_dynamic_game(psi, phi, rho, grids, n_days=col_end-col_start+1, start_day=col_start, max_targets=50, lockout_day=0)

    discretized_prices_sim = get_discretized_prices(
        pivot_from_level_by_event_time(simulated_data_df),
        price_levels_by_firm_by_drug,
        firm_list
    )
    weighted_avg_prices_sim = get_weighted_avg_prices(discretized_prices_sim, market_size, firm_list)

    return {
        "params": params,
        "V": V,
        "psi": psi,
        "phi": phi,
        "rho": rho,
        "simulated_data_df": simulated_data_df,
        "simulated_event_df": simulated_event_df,
        "price_level_dfs": price_level_dfs,
        "weighted_avg_prices_sim": weighted_avg_prices_sim
    }

# %%
