# %%
import os
import time

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import ruptures as rpt
from linearmodels.iv import IV2SLS
from statsmodels.sandbox.regression.gmm import GMM

from linearmodels.panel.model import PanelFormulaParser
from numpy.linalg import matrix_rank
from numpy.linalg import inv
from patsy import dmatrix
from scipy.optimize import minimize
from sklearn.linear_model import LinearRegression
import re
import sys

import stata_setup
stata_setup.config('/Applications/Stata', 'mp')

# stata_setup.config(r'D:\Program Files\Stata17', 'mp')

from pystata import stata
import pystata


def load_all_data(data_path):
    # --- Section 1: Load attribute and date data ---
    attr = pd.read_csv(os.path.join(data_path, 'attr.csv'))
    date_df = pd.read_csv(os.path.join(data_path, "date.csv"))
    date_df['Date'] = pd.to_datetime(date_df['Date'], format='%Y-%m-%d')
    
    firm_list = ['CV', 'FA', 'SB']
    firm_dict = {'CV': 'Cruz Verde', 'SB': 'Salcobrand', 'FA': 'FASA'}

    # --- Section 2: Load price, quantity, and col data ---
    def load_data(file_name, fill_method=None):
        file_path = os.path.join(data_path, file_name)
        df = pd.read_csv(file_path, names=range(222))
        if fill_method:
            df.fillna(method=fill_method, inplace=True)
        return df

    price_cv = load_data('price_cv.csv', fill_method='ffill')
    quantity_cv = load_data('quantity_cv.csv')
    col_cv = load_data('col_cv.csv')
    price_sb = load_data('price_sb.csv', fill_method='ffill')
    quantity_sb = load_data('quantity_sb.csv')
    col_sb = load_data('col_sb.csv')
    price_fa = load_data('price_fa.csv', fill_method='ffill')
    quantity_fa = load_data('quantity_fa.csv')
    col_fa = load_data('col_fa.csv')
    

    # --- Section 3: Calculate shares and total quantities ---
    total_quantity = quantity_cv + quantity_fa + quantity_sb
    shares_cv = quantity_cv / total_quantity
    shares_fa = quantity_fa / total_quantity
    shares_sb = quantity_sb / total_quantity
    

    # --- Section 4: Load and process cost data ---
    cost_sb = pd.read_csv(os.path.join(data_path, 'CostoSB.csv'))
    cost_sb['date'] = pd.to_datetime(cost_sb['date'], format='%d.%m.%y')
    cost_sb.columns = ['date'] + list(range(cost_sb.shape[1] - 1))
    cost_sb.set_index('date', inplace=True)
    cost_sb = cost_sb.apply(pd.to_numeric, errors='coerce')

    marginal_cost = cost_sb.mean() / 1000
    marginal_cost.iloc[-1] = marginal_cost.iloc[-2]
    

    # --- Section 5: Calculate market size and other variables ---
    col_ind = col_cv + col_fa + col_sb
    market_size = total_quantity / 0.9
    

    return {
        'attr': attr,
        'date_df': date_df,
        'firm_list': firm_list,
        'firm_dict': firm_dict,
        'price_cv': price_cv,
        'quantity_cv': quantity_cv,
        'col_cv': col_cv,
        'price_sb': price_sb,
        'quantity_sb': quantity_sb,
        'col_sb': col_sb,
        'price_fa': price_fa,
        'quantity_fa': quantity_fa,
        'col_fa': col_fa,
        'total_quantity': total_quantity,
        'shares_cv': shares_cv,
        'shares_fa': shares_fa,
        'shares_sb': shares_sb,
        'cost_sb': cost_sb,
        'marginal_cost': marginal_cost,
        'col_ind': col_ind,
        'market_size': market_size
    }

# %%

def remove_collinear(X, colnames):
    X = np.asarray(X)
    keep = []
    cols = []
    for i in range(X.shape[1]):
        if len(keep) == 0:
            keep.append(i)
            cols.append(colnames[i])
        else:
            test = np.column_stack([X[:, k] for k in keep] + [X[:, i]])
            if matrix_rank(test) > matrix_rank(np.column_stack([X[:, k] for k in keep])):
                keep.append(i)
                cols.append(colnames[i])
    return X[:, keep], cols, keep

# %%


# %%
DELTA_LOWER_BOUND = -10.0  # Adjust as needed

def demand_moment(params, dependent, exog, instruments):
    return instruments * (dependent - exog @ params)[:, None]  # Residuals


def delta_lower_bound(coef, exog, delta_lower):
    return exog @ coef - delta_lower
    
def delta_upper_bound(coef, exog, delta_upper):
    return delta_upper - exog @ coef



def demand_objective_function(coef, dependent, exog, instruments,  W=None):
    _moment = demand_moment(coef, dependent, exog, instruments)
    if W is None:
        W = np.eye(_moment.shape[1])

    avg_moment = np.mean(_moment, axis=0)  # Average over observations
    return avg_moment @ W @ avg_moment  # GMM objective: avg_moment' 


def clean_series(s):
        """Replace inf/-inf with NaN, then drop"""
        s = s.replace([np.inf, -np.inf], np.nan)
        return s

# Remove collinear columns
def remove_collinear_cols(X):
    cols = X.columns.tolist()
    mat = X.values
    keep = []
    for i, col in enumerate(cols):
        temp = mat[:, keep + [i]]
        if np.linalg.matrix_rank(temp) > len(keep):
            keep.append(i)
    return X.iloc[:, keep]


def jacobian_matrix(params, demand_moment, dependent, exog, instruments, epsilon=1e-6):
    
    n_params = len(params)
    jac = []
    for i in range(n_params):
        params_plus = params.copy()
        params_plus[i] += epsilon
        moments_plus = demand_moment(params_plus,dependent,exog,instruments).mean(0)
        
        params_minus = params.copy()
        params_minus[i] -= epsilon
        moments_minus = demand_moment(params_minus,dependent,exog,instruments).mean(0)
        
        # 中心差分近似导数
        jac_i = (moments_plus - moments_minus) / (2 * epsilon)
        jac.append(jac_i)
    return np.array(jac).T  # 形状为 (矩条件数, 参数数)

def calculate_standard_errors(params, demand_moment, dependent, exog, instruments):
    n = exog.shape[0]
    moments = demand_moment(params,dependent,exog,instruments)
    S = np.cov(moments, rowvar=False)  
    
    G = jacobian_matrix(params, demand_moment, dependent, exog, instruments)

    # Add regularization to avoid singular matrix inversion
    reg = 1e-8
    W = np.linalg.inv(S + reg * np.eye(S.shape[0]))

    G_W = G.T @ W
    G_W_G = G_W @ G
    inv_G_W_G = np.linalg.inv(G_W_G + reg * np.eye(G_W_G.shape[0]))

    cov_matrix = inv_G_W_G @ G_W @ S @ G_W.T @ inv_G_W_G / n
    # Replace negative or NaN diagonal values with zero before sqrt
    diag_cov = np.diag(cov_matrix)
    diag_cov = np.where(np.isnan(diag_cov) | (diag_cov < 0), 0, diag_cov)
    standard_errors = np.sqrt(diag_cov)
    return standard_errors, cov_matrix

# %%
def within_transform_variables(regression_df, vars_to_transform, group_vars=['Firm', 'DrugID']):
    """
    Apply within transformation to remove fixed effects
    """
    transformed_data = regression_df.copy()
    
    
    for var in vars_to_transform:
        # Compute group means
        group_means = regression_df.groupby(group_vars)[var].transform('mean')
        # Subtract group means (within transformation)
        transformed_data[f'{var}_demean'] = regression_df[var] - group_means
    
    return transformed_data

def rename_price_cols(price_cols):
    """
    Automatically rename price column names to be Stata-compatible.
    Replaces characters that are not allowed (e.g., brackets, parentheses, '/') with underscores.
    
    Parameters:
        price_cols (list of str): List of price column names.
    
    Returns:
        list of str: List of renamed price column names.
    """
    renamed = []
    for col in price_cols:
        # Replace problematic characters with an underscore
        col_new = re.sub(r'[\[\]\(\)/]', '_', col)
        # Replace any sequence of underscores with a single underscore
        col_new = re.sub(r'_+', '_', col_new)
        # Remove any leading or trailing underscores
        col_new = col_new.strip('_')
        renamed.append(col_new)
    return renamed

# %%   
# Section: Demand GMM
# -------------------------------
def DemandGMM(
    demand_data_core,
    instruments=None,
    dependent_variable='Y',
    price_coef_colnames='Price',
    # char_formula='0 + C(Firm) + RefillFrequency + Chronic + Lab',
    char_formula='0+C(Firm)*C(DrugID)',
    price_interaction_formula= '0+C(Molecule)',
    ad_ban = True, 
    nest = True, 
    demean = True,
    method = 'OLS',
    rho_bound = 0.9,
    ):

    # %%
    # 1. Deep copy and initial cleaning
    regression_df = demand_data_core.copy()

    # 2. Handle infinite and missing values
    # Clean all numeric columns
    numeric_cols = regression_df.select_dtypes(include=[np.number]).columns
    regression_df[numeric_cols] = regression_df[numeric_cols].apply(clean_series)

    # 3. Generate fixed effect dummies
    char_matrix = dmatrix(char_formula, regression_df, return_type='dataframe')
    char_colnames = list(char_matrix.columns)  # Record the fixed effect column names
    
    # Avoid duplicate columns when concatenating char_dummy_matrix
    char_matrix = char_matrix.loc[:, ~char_matrix.columns.isin(regression_df.columns)]
    regression_df = pd.concat([regression_df.reset_index(drop=True), char_matrix.reset_index(drop=True)], axis=1)
    
    # 4. Generate price interaction dummies
    price_interaction_dummy_matrix = dmatrix(price_interaction_formula, regression_df, return_type='dataframe')
    price_interaction_cols = []
    price_ad_ban_interaction_cols = []

    
    # Ensure AdBan is numeric (0/1)
    if 'AdBan' in regression_df.columns:
        regression_df['AdBan'] = regression_df['AdBan'].astype(int)

    if ad_ban:
        for col in price_interaction_dummy_matrix.columns:
            # Interaction for pre-ban (AdBan == 0)
            interaction_preban_col = f"{price_coef_colnames}_x_{col}_preban"
            regression_df[interaction_preban_col] = (
                regression_df[price_coef_colnames].to_numpy() *
                price_interaction_dummy_matrix[col].to_numpy() *
                (1 - regression_df['AdBan'].to_numpy())
            )
            price_interaction_cols.append(interaction_preban_col)

            # Interaction for post-ban (AdBan == 1)
            interaction_postban_col = f"{price_coef_colnames}_x_{col}_postban"
            regression_df[interaction_postban_col] = (
                regression_df[price_coef_colnames].to_numpy() *
                price_interaction_dummy_matrix[col].to_numpy() *
                regression_df['AdBan'].to_numpy()
            )
            price_ad_ban_interaction_cols.append(interaction_postban_col)


    else:
        for col in price_interaction_dummy_matrix.columns:
            interaction_col = f"{price_coef_colnames}_x_{col}"
            regression_df[interaction_col] = (
                regression_df[price_coef_colnames].to_numpy() *
                price_interaction_dummy_matrix[col].to_numpy()
            )
            price_interaction_cols.append(interaction_col)

    # 5. Add nested logit terms if needed
    if nest:
        share_within_group_interaction_cols = ['LogShareGroup']
    else:
        share_within_group_interaction_cols = []

    # 6. Build exogenous variable matrix
    endog_cols = (
        price_interaction_cols +
        price_ad_ban_interaction_cols +
        share_within_group_interaction_cols +
        char_colnames
    )
    # Remove duplicate column names
    endog_cols_unique = list(dict.fromkeys(endog_cols))
    endog = regression_df[endog_cols_unique].values

    # 7. Build dependentenous variable vector
    dependent = regression_df[dependent_variable].values

    # 8 Interact instruments with price_interaction_dummy_matrix
    if (instruments is None) and method == 'GMM':
        instruments_array = endog
    elif instruments is None and method == 'OLS':
        instruments_array = np.array([])
    else: 
        instruments_df = pd.DataFrame()
        # instruments is a numpy array, so loop over its columns
        for instr_idx in range(instruments.shape[1]):
            instr_col = f"IV_{instr_idx+1}"
            for col in price_ad_ban_interaction_cols:
                interaction_col = f"{instr_col}_x_{col}"
                instruments_df[interaction_col] = (
                    instruments[:, instr_idx] *
                    regression_df[col].to_numpy()
                )
        instruments_array = instruments_df.values

    # Set bounds: price_interaction_cols must be negative, rest unbounded
    n_price = len(price_interaction_cols)
    n_adban = len(price_ad_ban_interaction_cols)
    n_share = len(share_within_group_interaction_cols)
    n_fe = len(char_colnames)
    
    
    market_size_df = regression_df['MarketSize'] 
    delta_lower = regression_df['DrugID'].map(regression_df.groupby('DrugID')['Y'].quantile(0.1)).values
    # Compute the max Y for each DrugID and assign back to each row
    delta_upper = regression_df['DrugID'].map(regression_df.groupby('DrugID')['Y'].quantile(0.9)).values

    # # Compute and print the column rank of the instruments matrix
    # instruments_rank = np.linalg.matrix_rank(instruments)
    # print(f"Column rank of instruments: {instruments_rank}")

    # %%    
    # Extract the relevant columns for each group
    price_interaction_df = regression_df.groupby(['DrugID', 'AdBan']).first()[price_interaction_cols + price_ad_ban_interaction_cols + [price_coef_colnames]]

    price_interaction_df = price_interaction_df.div(price_interaction_df[price_coef_colnames], axis=0)
    price_interaction_df = price_interaction_df[price_interaction_cols + price_ad_ban_interaction_cols]

    if len(share_within_group_interaction_cols) > 1:
        share_within_group_df = regression_df.groupby(['DrugID']).first()[share_within_group_interaction_cols + ['LogShareGroup'] ]
        share_within_group_df = share_within_group_df.div(share_within_group_df['LogShareGroup'], axis=0)
        share_within_group_df = share_within_group_df[share_within_group_interaction_cols]
    else:
        share_within_group_df = pd.DataFrame(1, index = range(222), columns=['ind'])


    fe_df = regression_df.groupby(['DrugID', 'Firm']).first()[char_colnames]

    
    # Use OLS as a warm start for the minimization
    # This provides a good initial guess for the optimizer
    # OLS warm start (ignoring bounds and moments)
    ols = LinearRegression(fit_intercept=False)
    ols.fit(endog, dependent)
    x0_ols = ols.coef_

    # %%
    # ols_se now contains the standard errors for each OLS coefficient

    # if method == 'GMM':
    if demean or method=='OLS':
        # Demean dependent, exog, and instruments by group (fixed effects)
        group_keys = char_matrix.apply(tuple, axis=1)
        dependent_demeaned = dependent - pd.Series(dependent).groupby(group_keys).transform('mean').values
        endog_demeaned = endog[:, :n_price+n_adban+n_share] - pd.DataFrame(endog[:, :n_price+n_adban+n_share]).groupby(group_keys).transform('mean').values
        if instruments_array.size == 0:
            instruments_demeaned = instruments_array
        else:
            instruments_demeaned = instruments_array - pd.DataFrame(instruments_array).groupby(group_keys).transform('mean').values

        # instruments_demeaned = instruments 

    if method == 'GMM' and demean:
        # Adjust bounds and constraints for demeaned variables
        bounds = [(-np.inf, -0.01)] * (n_price + n_adban) + [(0, rho_bound)] * n_share
        # bounds = [(-np.inf, np.inf)] * (n_price + n_adban) + [(0, 0.9)] * n_share
        constraints = [
            {'type': 'ineq', 'fun': delta_lower_bound, 'args': (endog_demeaned, delta_lower)},
            {'type': 'ineq', 'fun': delta_upper_bound, 'args': (endog_demeaned, delta_upper)}
        ]

        # First-stage GMM
        res1 = minimize(
            demand_objective_function,
            x0_ols[:n_price+n_adban+n_share],
            args=(dependent_demeaned, endog_demeaned, instruments_demeaned, None),
            method='L-BFGS-B',
            bounds=bounds,
            constraints=constraints,
            options={'disp': True, 'maxiter': 1000, 'ftol': 1e-5, 'gtol': 1e-4}
        )

        # Optimal weighting matrix
        moments = demand_moment(res1.x, dependent_demeaned, endog_demeaned, instruments_demeaned)
        W_optimal = inv(np.cov(moments, rowvar=False) + 1e-10 * np.eye(moments.shape[1]))

        # Second-stage GMM
        res2 = minimize(
            demand_objective_function,
            res1.x,
            args=(dependent_demeaned, endog_demeaned, instruments_demeaned, W_optimal),
            method='L-BFGS-B',
            bounds=bounds,
            constraints=constraints,
            options={'disp': True, 'maxiter': 1000, 'ftol': 1e-5, 'gtol': 1e-4}
        )

        standard_errors, cov_matrix = calculate_standard_errors(res2.x, demand_moment, dependent_demeaned, endog_demeaned, instruments_demeaned)
        alphas = price_interaction_df @ res2.x[:n_price+n_adban]
        rhos = share_within_group_df @ res2.x[n_price+n_adban:n_price+n_adban+n_share]
        alphas_se = price_interaction_df @ standard_errors[:n_price+n_adban]
        rhos_se = share_within_group_df @ standard_errors[n_price+n_adban:n_price+n_adban+n_share]

        residuals = dependent - endog[:, :n_price+n_adban+n_share] @ res2.x[:n_price+n_adban+n_share]

    if method == 'OLS':  
        # res = IV2SLS(
        #         dependent=dependent_demeaned,
        #         endog=endog_demeaned,
        #         exog=None,
        #         instruments=instruments_demeaned)
        # results = res.fit(cov_type='robust')
        if instruments_array.size == 0:
            stata_regression_df = pd.DataFrame({
                    'Y': dependent_demeaned,
                    **{
                        f'X{i+1}': endog_demeaned[:, i]
                        for i in range(endog_demeaned.shape[1])
                    }
                })
        else:
            stata_regression_df = pd.DataFrame({
                    'Y': dependent_demeaned,
                    **{
                        f'X{i+1}': endog_demeaned[:, i]
                        for i in range(endog_demeaned.shape[1])
                    },
                    **{
                        f'Z{i+1}': instruments_demeaned[:, i]
                        for i in range(instruments_demeaned.shape[1])
                    } 
                })
        stata.run('display "Hello from Stata!"') 
        stata.run('clear')
        stata.pdataframe_to_data(stata_regression_df)  # Sends 

        # stata.run('describe')
        if instruments_array.size == 0:
            stata.run('regress Y X*, vce(robust)')
        else:
            stata.run('ivregress 2sls Y (X* = Z*), vce(robust)')

        coef_df = stata.get_ereturn()
        coefs = coef_df['e(b)'].flatten()
        coefs_std = np.sqrt(np.diag(coef_df['e(V)']))
        cov_matrix = coef_df['e(V)']
        standard_errors = np.sqrt(np.diag(cov_matrix))
        alphas = price_interaction_df @ coefs[:n_price+n_adban]
        alphas_se = price_interaction_df @ coefs_std[:n_price+n_adban]

        rhos = share_within_group_df @ coefs[n_price+n_adban:n_price+n_adban+n_share]
        rhos_se = share_within_group_df @ coefs_std[n_price+n_adban:n_price+n_adban+n_share]
        residuals = dependent - endog[:, :n_price+n_adban+n_share] @ coefs[:n_price+n_adban+n_share]

        # Estimate betas (fixed effects) by regressing residuals on char_matrix
        ols_fe = LinearRegression(fit_intercept=False).fit(char_matrix.values, residuals)
        betas = fe_df @ ols_fe.coef_
        sigma2_fe = np.sum((residuals - char_matrix.values @ ols_fe.coef_) ** 2) / (char_matrix.shape[0] - char_matrix.shape[1])
        cov_matrix_fe = sigma2_fe * np.linalg.inv(char_matrix.values.T @ char_matrix.values)
        betas_se = fe_df @ np.sqrt(np.diag(cov_matrix_fe))

        # stata.run('estat endogenous')
        # stata.run('estat overid')

    if not demean and method == 'GMM':
    
        bounds = [(-np.inf, 0)] * (n_price + n_adban) + [(0, rho_bound)] * n_share + [(-np.inf, np.inf)] * n_fe
        constraints = [
            {'type': 'ineq', 'fun': delta_lower_bound, 'args': (endog, delta_lower)},
            {'type': 'ineq', 'fun': delta_upper_bound, 'args': (endog, delta_upper)}
        ]
        res1 = minimize(
            demand_objective_function,
            x0_ols,
            args=(dependent, endog, instruments_array, None),
            method='L-BFGS-B',
            bounds=bounds,
            constraints=constraints,
            options={'disp': True, 'maxiter': 10, 'ftol': 1e-5, 'gtol': 1e-4}
        )

        moments = demand_moment(res1.x, dependent, endog, instruments_array)
        W_optimal = inv(np.cov(moments, rowvar=False) + 1e-10 * np.eye(moments.shape[1]))

        res2 = minimize(
            demand_objective_function,
            res1.x,
            args=(dependent, endog, instruments_array, W_optimal),
            method='L-BFGS-B',
            bounds=bounds,
            constraints=constraints,
            options={'disp': True, 'maxiter': 10, 'ftol': 1e-5, 'gtol': 1e-4}
        )

        standard_errors, cov_matrix = calculate_standard_errors(res2.x, demand_moment, dependent, endog, instruments_array)
        alphas = price_interaction_df @ res2.x[:n_price+n_adban]
        rhos = share_within_group_df @ res2.x[n_price+n_adban:n_price+n_adban+n_share]
        betas = fe_df @ res2.x[n_price+n_adban+n_share:]
        alphas_se = price_interaction_df @ standard_errors[:n_price+n_adban]
        rhos_se = share_within_group_df @ standard_errors[n_price+n_adban:n_price+n_adban+n_share]
        betas_se = fe_df @ standard_errors[n_price+n_adban+n_share:]
        
    
    delta_mean = demand_data_core.groupby(['DrugID','AdBan', 'Firm'])[['Y','LogPrice','LogShareGroup']].mean()


    # Prepare index for lookup
    idx = delta_mean.index
    drugids = idx.get_level_values('DrugID')
    adban = idx.get_level_values('AdBan')

    
    # Get alpha for each (DrugID, AdBan)
    alpha_vals = [
        alphas.loc[(drugid, int(adban_val))]
        for drugid, adban_val in zip(drugids, adban)
    ]
    rho_vals = [rhos.loc[drugid] if drugid in rhos.index else np.nan for drugid in drugids]
    # Subtract LogPrice * alpha + LogShareGroup * rho from Y
    # Compute beta_2step: delta as Y minus fitted price and share terms
    betas_2step = (
        delta_mean['Y']
        - delta_mean['LogPrice'].to_numpy() * np.array(alpha_vals)
        - delta_mean['LogShareGroup'].to_numpy() * np.array(rho_vals)
    )
    # Include delta_mean in the returned dictionary

    return {
        'standard_errors':standard_errors,
        'cov_matrix': cov_matrix,
        'alphas': alphas,
        'rhos': rhos,
        'betas': betas,
        'betas_2step': betas_2step,
        'alphas_se': alphas_se,
        'rhos_se': rhos_se,
        'betas_se': betas_se
    }
    # return demand_coefficient_summary, drug_price_coef_by_drugid, iv_results, dependent_j, endog_j





def get_drug_price_coefficients(model_output, ad_ban=False):
    results = model_output['results']
    df = model_output['model_data']
    price_var = model_output['price_var']
    formula = model_output['formula']
    
    # Get model's design matrix processor
    model = results.model
    endog_cols = model.exog.dataframe.columns
    
    # Get one row per DrugID
    drug_samples = df.groupby('DrugID').first().reset_index()
    if ad_ban:
        drug_samples_pre_ban = drug_samples.copy()
        drug_samples_pre_ban['AdBan'] = False
        drug_samples_post_ban = drug_samples.copy()
        drug_samples_post_ban['AdBan'] = True
        drug_samples = pd.concat([drug_samples_pre_ban, drug_samples_post_ban])
    
    # Create base and perturbed scenarios
    base = drug_samples.copy().set_index(['DrugID',np.arange(len(drug_samples))])
    perturbed = drug_samples.copy().set_index(['DrugID',np.arange(len(drug_samples))])
    perturbed[price_var] += 1
    
    
    if ad_ban:
        def to_panel(data):
            parser = PanelFormulaParser(formula, data=data)
            design_matrices = parser.exog  # This is a dict with keys: 'dependent', 'endog', 'effects', etc.
            design_matrices_pre_ban = design_matrices.loc[~data.AdBan,endog_cols]
            design_matrices_post_ban = design_matrices.loc[data.AdBan,endog_cols]
            return design_matrices_pre_ban, design_matrices_post_ban
        
        # Create a post-ban scenario
        base_pre_ban, base_post_ban = to_panel(base)
        perturbed_pre_ban, perturbed_post_ban = to_panel(perturbed)
        pred_base_pre_ban = results.params[endog_cols] @ base_pre_ban.T
        pred_base_post_ban = results.params[endog_cols] @ base_post_ban.T
        pred_perturbed_pre_ban = results.params[endog_cols] @ perturbed_pre_ban.T
        pred_perturbed_post_ban = results.params[endog_cols] @ perturbed_post_ban.T

        

        # Calculate coefficients for post-ban scenario
        coefficients_pre_ban = (pred_perturbed_pre_ban - pred_base_pre_ban).rename('price_coefficient_post_ban')
        coefficients_pre_ban = coefficients_pre_ban.reset_index(level=1, drop=True)
        coefficients_pre_ban.index.name = 'DrugID'

        # Calculate coefficients for post-ban scenario
        coefficients_post_ban = (pred_perturbed_post_ban - pred_base_post_ban).rename('price_coefficient_post_ban')
        coefficients_post_ban = coefficients_post_ban.reset_index(level=1, drop=True)
        coefficients_post_ban.index.name = 'DrugID'
    else:
        # Convert to panel structure
        def to_panel(data):
            parser = PanelFormulaParser(formula, data=data)
            design_matrices = parser.exog  # This is a dict with keys: 'dependent', 'exog', 'effects', etc.
            design_matrices = design_matrices[endog_cols]
            
            return design_matrices
        
        # Get predictions
        pred_base = results.params[endog_cols] @ to_panel(base).T
        pred_perturbed = results.params[endog_cols] @ to_panel(perturbed).T

        # Calculate coefficients
        coefficients_pre_ban = (pred_perturbed - pred_base).rename('price_coefficient')
        coefficients_pre_ban = coefficients_pre_ban.reset_index(level=1, drop=True)
        coefficients_pre_ban.index.name = 'DrugID'
        
        coefficients_post_ban = coefficients_pre_ban.copy()
    return coefficients_pre_ban, coefficients_post_ban


# %%


# %%
# Section: Prepare Data
# -------------------------------
def prepare_demand_data(
    price_cv, price_fa, price_sb,
    quantity_cv, quantity_fa, quantity_sb,
    market_size, col_ind, attr, date_df, data_path
):
    demand_data = []
    shares_records = []
    all_price_jumps_by_pen = {2:[], 5:[], 10: [], 20: [], 50: []}  # Store jumps for each pen value


    for i in range(222):
        # Normalize prices and calculate shares
        price_cv_i = price_cv[i] / 1000
        price_fa_i = price_fa[i] / 1000
        price_sb_i = price_sb[i] / 1000
        share_cv_i = quantity_cv[i] / market_size[i]
        share_fa_i = quantity_fa[i] / market_size[i]
        share_sb_i = quantity_sb[i] / market_size[i]
        share_0_i = 1 - share_cv_i - share_fa_i - share_sb_i

        # Detect abnormal price jumps using ruptures for multiple pen values
        for pen in [2, 5, 10, 20, 50]:
            price_jump_records = []
            for firm_name, price_series in zip(
                ['cv', 'fa', 'sb'],
                [price_cv_i, price_fa_i, price_sb_i]
            ):
                price_series_clean = price_series.dropna().reset_index(drop=True)
                if len(price_series_clean) > 10:
                    algo = rpt.Pelt(model="rbf").fit(price_series_clean.values)
                    change_points = algo.predict(pen=pen)
                    for cp in change_points[:-1]:
                        price_jump_records.append({
                            'DrugID': i,
                            'Firm': firm_name,
                            'JumpIndex': cp
                        })
            all_price_jumps_by_pen[pen].extend(price_jump_records)

        # Record shares for this drug
        shares_records.append({
            'DrugID': i,
            'share_cv': share_cv_i,
            'share_fa': share_fa_i,
            'share_sb': share_sb_i
        })
        total_share = share_cv_i + share_fa_i + share_sb_i
        # Calculate log-differences for shares
        y_cv_i = np.log(share_cv_i) - np.log(share_0_i)
        y_fa_i = np.log(share_fa_i) - np.log(share_0_i)
        y_sb_i = np.log(share_sb_i) - np.log(share_0_i)

        # Compile data for each firm (skip lagged prices)
        for firm, y, price, quantity,share in zip(
            ['CV', 'FA', 'SB'],
            [y_cv_i, y_fa_i, y_sb_i],
            [price_cv_i, price_fa_i, price_sb_i],
            [quantity_cv[i], quantity_fa[i], quantity_sb[i]], 
            [share_cv_i, share_fa_i, share_sb_i]
        ):
            firm_data = pd.DataFrame({
                'Y': y,
                'TimeID': date_df['Date'].index,
                'Firm': firm,
                'Price': price,
                'Quantity': quantity,
                'ShareWithinGroup': share/total_share,
                'DrugID': i,
                'DateID': range(len(price)),
                'NumCol': (col_ind>2).sum(axis=1),
                'Chronic': attr.loc[i, 'chronic'],
                'Treat': attr.loc[i, 'Treat'],
                'Number Dosage': attr.loc[i, 'num_dose'],
                'Lab': attr.loc[i, 'lab'],
                'Molecule': attr.loc[i, 'ingredient'],
                'RefillFrequency': attr.loc[i, 'refill_frequency'],
                'Prescription': attr.loc[i, 'Prescription'],
                'ATCL4': attr.loc[i, 'ATCL4'],
            })
            demand_data.append(firm_data)

    # Combine all firm data and clean up
    demand_data_core = pd.concat(demand_data, ignore_index=True)
    shares_df = pd.DataFrame(shares_records)

    # demand_data_core = demand_data_core[demand_data_core['Y'] != -np.inf]
    demand_data_core['AdBan'] = demand_data_core['TimeID'] > 660
    # NOTE (revision2 dedup): demand_data_df.csv was byte-identical to demand_data_core.csv
    # and never read by the active pipeline. Redundant write disabled; file moved to data/_archive/.
    # demand_data_core.to_csv(os.path.join(data_path, "demand_data_df.csv"), index=False)

    # Save all price jumps for each pen value to separate CSVs and DataFrames
    price_jump_matrices = {}
    for pen in [2, 5, 10, 20, 50]:
        all_price_jumps = all_price_jumps_by_pen[pen]
        # Create a DataFrame with shape (len(date_df), 222*3), columns as (DrugID, Firm)
        price_jump_matrix = pd.DataFrame(
            0, index=date_df['Date'].index,
            columns=pd.MultiIndex.from_product([range(222), ['cv', 'fa', 'sb']], names=['DrugID', 'Firm'])
        )
        for jump in all_price_jumps:
            idx = jump['JumpIndex']
            drug = jump['DrugID']
            firm = jump['Firm']
            if idx in price_jump_matrix.index:
                price_jump_matrix.loc[idx, (drug, firm)] = 1
        # Optionally, flatten columns for easier CSV writing
        price_jump_matrix.columns = [f"Drug{drug}_{firm}" for drug, firm in price_jump_matrix.columns]
        matrix_csv_path = os.path.join(data_path, f"price_jump_matrix_pen{pen}.csv")
        price_jump_matrix.to_csv(matrix_csv_path)
        price_jump_matrices[pen] = price_jump_matrix

        # Save all price jumps to a CSV for later analysis (long format)
        all_price_jumps_df = pd.DataFrame(all_price_jumps)
        jumps_csv_path = os.path.join(data_path, f"price_jumps_pen{pen}.csv")
        all_price_jumps_df.to_csv(jumps_csv_path, index=False)

    return demand_data_core, shares_df, price_jump_matrices



# %%
def generate_price_jump_ivs(demand_data_core, attr, price_jump_matrices, window_days=[7,30], firm_col='Firm', drugid_col='DrugID', manufacturer_col='lab'):
    
    """
    For each row in demand_data_df, generate an IV equal to the sum of price jumps (in price_jump_matrix)
    for products with the same manufacturer (excluding the focal product), for the same firm, in the last window_days.
    Also generates lagged prices (up to 7 days) for self and rivals 1 and 2.
    """
    # %%
    # Map DrugID to manufacturer
    drugid_to_manufacturer = attr.set_index('no')[manufacturer_col].to_dict()
    # Prepare a lookup for each DrugID: which other DrugIDs share the same manufacturer
    manufacturer_to_drugids = attr.groupby(manufacturer_col)['no'].apply(list).to_dict()
    # Prepare a lookup for each DrugID: which DrugIDs share the same manufacturer (excluding self)
    drugid_to_related_drugids = {
        drugid: [d for d in manufacturer_to_drugids[drugid_to_manufacturer[drugid+1]] if d != drugid+1]
        for drugid in range(222)
    }
    # Prepare a lookup for each firm: column name in price_jump_matrix
    firm_map = {'CV': 'cv', 'FA': 'fa', 'SB': 'sb'}
    rival_map = {
            'CV': ['FA', 'SB'],
            'FA': ['CV', 'SB'],
            'SB': ['CV', 'FA']
        }

    # Build a multi-indexed DataFrame for price lookup
    price_lookup = demand_data_core.set_index(['DrugID', 'Firm']).sort_values('TimeID', ascending=True)[['Price','TimeID']]
    
    # Precompute: for each DrugID, get related DrugIDs (other drugs with same manufacturer, excluding self)
    
    # For efficiency, precompute rolling sums for each (DrugID, Firm) in price_jump_matrix
    rolling_sums = {}
    

    for pen, price_jump_matrix in price_jump_matrices.items():
        for window in window_days:
            for drugid in range(222):
                for firm in ['cv', 'fa', 'sb']:
                    col = f'Drug{drugid}_{firm}'
                    # Rolling sum over window (assume daily data, so window rows)
                    rolling = price_jump_matrix[col].rolling(window=window, min_periods=1).sum()
                    # Store with pen and window as part of the key
                    rolling_sums[(drugid, firm, pen, window)] = rolling
    
    # Compute the IV for   each (DrugID, TimeID, Firm) for time windows of 7 and 30 days
    # For each drugid and firm, precompute related drugids (excluding self)

    demand_data_df_list = []
    for drugid in range(222):
        t0 = time.time()
        for firm_short in ['cv', 'fa', 'sb']:
            # Get all other DrugIDs with the same manufacturer (excluding self)
            related_drugids = [
            d-1 for d in drugid_to_related_drugids.get(drugid, [])
            if (d-1) != drugid
            ]
            mask = (demand_data_core[drugid_col] == drugid) & (demand_data_core[firm_col].str.lower() == firm_short)
            demand_data_df_ij = demand_data_core.loc[mask,:].reset_index(drop=True)
            # For each pen and window, compute IVs as sum of rolling_sums for related products
            for pen in [2, 5, 10, 20, 50]:
                for window in window_days:
                    iv_other_firms_col = f'IV_price_jumps_otherfirms_pen{pen}_{window}d'
                    iv_own_firm_col = f'IV_price_jumps_ownfirm_pen{pen}_{window}d'
                    # Only create the columns if not already present
                    
                    
                    iv_other_firms = np.zeros(len(demand_data_df_ij))
                    iv_own_firm = np.zeros(len(demand_data_df_ij))
                    
                    for other_drugid in related_drugids:
                        for firm2 in ['cv', 'fa', 'sb']:
                            key = (other_drugid, firm2, pen, window)
                            rolling_series = rolling_sums[key]
                            if firm2 == firm_short:
                                iv_own_firm += rolling_series
                            else:
                                iv_other_firms += rolling_series

                    demand_data_df_ij[iv_other_firms_col] = iv_other_firms
                    demand_data_df_ij[iv_own_firm_col] = iv_own_firm

            rivals = rival_map[firm_short.upper()]
            for lag in range(1, 8):
                # --- Price IVs (existing) ---
                own_lag_col = f'IV_price_lag{lag}_self'
                own_avg_lag_col = f'IV_price_lag{lag}_self_avg_related'
                own_avg_lag_pctchg_col = f'IV_price_lag{lag}_self_avg_related_pctchg'
                rival1_lag_col = f'IV_price_lag{lag}_rival1'
                rival2_lag_col = f'IV_price_lag{lag}_rival2'
                rival1_avg_lag_col = f'IV_price_lag{lag}_rival1_avg_related'
                rival2_avg_lag_col = f'IV_price_lag{lag}_rival2_avg_related'
                rival1_avg_lag_pctchg_col = f'IV_price_lag{lag}_rival1_avg_related_pctchg'
                rival2_avg_lag_col_pctchg = f'IV_price_lag{lag}_rival2_avg_related_pctchg'

                # --- Quantity IVs ---
                own_qty_lag_col = f'IV_quantity_lag{lag}_self'
                own_qty_avg_lag_col = f'IV_quantity_lag{lag}_self_avg_related'
                own_qty_avg_lag_pctchg_col = f'IV_quantity_lag{lag}_self_avg_related_pctchg'
                rival1_qty_lag_col = f'IV_quantity_lag{lag}_rival1'
                rival2_qty_lag_col = f'IV_quantity_lag{lag}_rival2'
                rival1_qty_avg_lag_col = f'IV_quantity_lag{lag}_rival1_avg_related'
                rival2_qty_avg_lag_col = f'IV_quantity_lag{lag}_rival2_avg_related'
                rival1_qty_avg_lag_pctchg_col = f'IV_quantity_lag{lag}_rival1_avg_related_pctchg'
                rival2_qty_avg_lag_pctchg_col = f'IV_quantity_lag{lag}_rival2_avg_related_pctchg'

                # --- ShareWithinGroup IVs ---
                own_share_lag_col = f'IV_share_lag{lag}_self'
                own_share_avg_lag_col = f'IV_share_lag{lag}_self_avg_related'
                own_share_avg_lag_pctchg_col = f'IV_share_lag{lag}_self_avg_related_pctchg'
                rival1_share_lag_col = f'IV_share_lag{lag}_rival1'
                rival2_share_lag_col = f'IV_share_lag{lag}_rival2'
                rival1_share_avg_lag_col = f'IV_share_lag{lag}_rival1_avg_related'
                rival2_share_avg_lag_col = f'IV_share_lag{lag}_rival2_avg_related'
                rival1_share_avg_lag_pctchg_col = f'IV_share_lag{lag}_rival1_avg_related_pctchg'
                rival2_share_avg_lag_pctchg_col = f'IV_share_lag{lag}_rival2_avg_related_pctchg'

                # --- Price IVs ---
                price_self = price_lookup.loc[(drugid, firm.upper())].set_index('TimeID').sort_index()
                demand_data_df_ij[own_lag_col] = price_self.shift(lag).values

                related_prices_prev = []
                related_prices_prev_pctchg = []
                for other_drugid in related_drugids + [drugid]:
                    price_related = price_lookup.loc[(other_drugid, firm.upper())].set_index('TimeID').sort_index()
                    price_prev = price_related.shift(lag)
                    price_prev_pctchg = (price_prev - price_prev.shift(1)) / price_prev.shift(1)
                    related_prices_prev.append(price_prev)
                    related_prices_prev_pctchg.append(price_prev_pctchg)
                demand_data_df_ij[own_avg_lag_col] = pd.concat(related_prices_prev, axis=1).mean(axis=1).values
                demand_data_df_ij[own_avg_lag_pctchg_col] = pd.concat(related_prices_prev_pctchg, axis=1).mean(axis=1).values

                demand_data_df_ij[rival1_lag_col] = price_lookup.loc[(drugid, rivals[0].upper())].set_index('TimeID').sort_index().shift(lag).values
                demand_data_df_ij[rival2_lag_col] = price_lookup.loc[(drugid, rivals[1].upper())].set_index('TimeID').sort_index().shift(lag).values

                related_prices_prev = []
                related_prices_prev_pctchg = []
                for other_drugid in related_drugids + [drugid]:
                    price_related = price_lookup.loc[(other_drugid, rivals[0].upper())].set_index('TimeID').sort_index()
                    price_prev = price_related.shift(lag)
                    price_prev_pctchg = (price_prev - price_prev.shift(1)) / price_prev.shift(1)
                    related_prices_prev.append(price_prev)
                    related_prices_prev_pctchg.append(price_prev_pctchg)
                demand_data_df_ij[rival1_avg_lag_col] = pd.concat(related_prices_prev, axis=1).mean(axis=1).values
                demand_data_df_ij[rival1_avg_lag_pctchg_col] = pd.concat(related_prices_prev_pctchg, axis=1).mean(axis=1).values

                related_prices_prev = []
                related_prices_prev_pctchg = []
                for other_drugid in related_drugids + [drugid]:
                    price_related = price_lookup.loc[(other_drugid, rivals[1].upper())].set_index('TimeID').sort_index()
                    price_prev = price_related.shift(lag)
                    price_prev_pctchg = (price_prev - price_prev.shift(1)) / price_prev.shift(1)
                    related_prices_prev.append(price_prev)
                    related_prices_prev_pctchg.append(price_prev_pctchg)
                demand_data_df_ij[rival2_avg_lag_col] = pd.concat(related_prices_prev, axis=1).mean(axis=1).values
                demand_data_df_ij[rival2_avg_lag_col_pctchg] = pd.concat(related_prices_prev_pctchg, axis=1).mean(axis=1).values

                # --- Quantity IVs ---
                quantity_self = price_lookup.loc[(drugid, firm.upper())].set_index('TimeID').sort_index()
                if 'Quantity' in demand_data_df_ij.columns:
                    quantity_self = demand_data_df_ij['Quantity']
                demand_data_df_ij[own_qty_lag_col] = quantity_self.shift(lag).values

                related_qty_prev = []
                related_qty_prev_pctchg = []
                for other_drugid in related_drugids + [drugid]:
                    mask_related = (demand_data_core['DrugID'] == other_drugid) & (demand_data_core['Firm'].str.upper() == firm.upper())
                    qty_related = demand_data_core.loc[mask_related, 'Quantity'].reset_index(drop=True)
                    qty_prev = qty_related.shift(lag)
                    qty_prev_pctchg = (qty_prev - qty_prev.shift(1)) / qty_prev.shift(1)
                    related_qty_prev.append(qty_prev)
                    related_qty_prev_pctchg.append(qty_prev_pctchg)
                demand_data_df_ij[own_qty_avg_lag_col] = pd.concat(related_qty_prev, axis=1).mean(axis=1).values
                demand_data_df_ij[own_qty_avg_lag_pctchg_col] = pd.concat(related_qty_prev_pctchg, axis=1).mean(axis=1).values

                for idx, rival in enumerate(rivals):
                    mask_rival = (demand_data_core['DrugID'] == drugid) & (demand_data_core['Firm'].str.upper() == rival.upper())
                    qty_rival = demand_data_core.loc[mask_rival, 'Quantity'].reset_index(drop=True)
                    demand_data_df_ij[[rival1_qty_lag_col, rival2_qty_lag_col][idx]] = qty_rival.shift(lag).values

                    related_qty_prev = []
                    related_qty_prev_pctchg = []
                    for other_drugid in related_drugids + [drugid]:
                        mask_related = (demand_data_core['DrugID'] == other_drugid) & (demand_data_core['Firm'].str.upper() == rival.upper())
                        qty_related = demand_data_core.loc[mask_related, 'Quantity'].reset_index(drop=True)
                        qty_prev = qty_related.shift(lag)
                        qty_prev_pctchg = (qty_prev - qty_prev.shift(1)) / qty_prev.shift(1)
                        related_qty_prev.append(qty_prev)
                        related_qty_prev_pctchg.append(qty_prev_pctchg)
                    demand_data_df_ij[[rival1_qty_avg_lag_col, rival2_qty_avg_lag_col][idx]] = pd.concat(related_qty_prev, axis=1).mean(axis=1).values
                    demand_data_df_ij[[rival1_qty_avg_lag_pctchg_col, rival2_qty_avg_lag_pctchg_col][idx]] = pd.concat(related_qty_prev_pctchg, axis=1).mean(axis=1).values

                # --- ShareWithinGroup IVs ---
                share_self = demand_data_df_ij['ShareWithinGroup']
                demand_data_df_ij[own_share_lag_col] = share_self.shift(lag).values

                related_share_prev = []
                related_share_prev_pctchg = []
                for other_drugid in related_drugids + [drugid]:
                    mask_related = (demand_data_core['DrugID'] == other_drugid) & (demand_data_core['Firm'].str.upper() == firm.upper())
                    share_related = demand_data_core.loc[mask_related, 'ShareWithinGroup'].reset_index(drop=True)
                    share_prev = share_related.shift(lag)
                    share_prev_pctchg = (share_prev - share_prev.shift(1)) / share_prev.shift(1)
                    related_share_prev.append(share_prev)
                    related_share_prev_pctchg.append(share_prev_pctchg)
                demand_data_df_ij[own_share_avg_lag_col] = pd.concat(related_share_prev, axis=1).mean(axis=1).values
                demand_data_df_ij[own_share_avg_lag_pctchg_col] = pd.concat(related_share_prev_pctchg, axis=1).mean(axis=1).values

                for idx, rival in enumerate(rivals):
                    mask_rival = (demand_data_core['DrugID'] == drugid) & (demand_data_core['Firm'].str.upper() == rival.upper())
                    share_rival = demand_data_core.loc[mask_rival, 'ShareWithinGroup'].reset_index(drop=True)
                    demand_data_df_ij[[rival1_share_lag_col, rival2_share_lag_col][idx]] = share_rival.shift(lag).values

                    related_share_prev = []
                    related_share_prev_pctchg = []
                    for other_drugid in related_drugids + [drugid]:
                        mask_related = (demand_data_core['DrugID'] == other_drugid) & (demand_data_core['Firm'].str.upper() == rival.upper())
                        share_related = demand_data_core.loc[mask_related, 'ShareWithinGroup'].reset_index(drop=True)
                        share_prev = share_related.shift(lag)
                        share_prev_pctchg = (share_prev - share_prev.shift(1)) / share_prev.shift(1)
                        related_share_prev.append(share_prev)
                        related_share_prev_pctchg.append(share_prev_pctchg)
                    demand_data_df_ij[[rival1_share_avg_lag_col, rival2_share_avg_lag_col][idx]] = pd.concat(related_share_prev, axis=1).mean(axis=1).values
                    demand_data_df_ij[[rival1_share_avg_lag_pctchg_col, rival2_share_avg_lag_pctchg_col][idx]] = pd.concat(related_share_prev_pctchg, axis=1).mean(axis=1).values

            demand_data_df_list.append(demand_data_df_ij)
        t1 = time.time()
        print(f"IV and lagged price generation for DrugID {drugid} took {t1-t0:.2f} seconds")    
        # %%
        demand_data_df = pd.concat(demand_data_df_list, ignore_index=True)
    return demand_data_df

# %%


# %%
