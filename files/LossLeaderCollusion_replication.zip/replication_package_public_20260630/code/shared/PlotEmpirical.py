# %%
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
from scipy import stats
import seaborn as sns


def process_multi_company_price_data(price_dfs, company_names, date_df, phases):
    """
    处理多公司多药品的价格数据，进行平滑、分位数计算和等级划分
    
    参数:
    - price_dfs: 价格DataFrame列表，每个DataFrame的index是日期索引，columns是药品ID
    - company_names: 公司名称列表
    - date_df: 包含日期列的DataFrame
    - phases: 包含三个阶段的日期范围列表
    
    返回:
    - 处理后的DataFrame列表，包含平滑价格、分位数和价格等级
    """
    # 确保日期格式一致
    date_df['Date'] = pd.to_datetime(date_df['Date'], format='%Y-%m-%d')
    
    # 存储处理后的结果
    processed_dfs = []
    
    # 对每个公司的数据进行处理
    for i, (price_df, company_name) in enumerate(zip(price_dfs, company_names)):
        print(f"处理公司 {company_name} 的数据...")
        
        # 1. 价格平滑处理
        price_smoothed = price_df.rolling(window=3, center=True).mean()
        # 填充边界NaN值
        price_smoothed = price_smoothed.fillna(price_df)
        
        # 2. 分阶段分位数计算
        # 创建存储分位数的DataFrame
        q10 = pd.DataFrame(index=price_df.index, columns=price_df.columns)
        q50 = pd.DataFrame(index=price_df.index, columns=price_df.columns)
        q90 = pd.DataFrame(index=price_df.index, columns=price_df.columns)
        
        # 为每个药品计算滑动窗口分位数
        for drug_id in price_df.columns:
            # 对每个阶段分别计算分位数
            for phase in phases:
                phase_indices = date_df[phase].index
                if len(phase_indices) > 0:
                    # 提取当前阶段的数据
                    phase_data = price_smoothed.loc[phase_indices, drug_id]
                    
                    # 计算该阶段的分位数
                    phase_q10 = phase_data.quantile(0.1)
                    phase_q50 = phase_data.quantile(0.5)
                    phase_q90 = phase_data.quantile(0.9)
                    
                    # 填充到对应阶段的索引位置
                    q10.loc[phase_indices, drug_id] = phase_q10
                    q50.loc[phase_indices, drug_id] = phase_q50
                    q90.loc[phase_indices, drug_id] = phase_q90
        
        # 3. 价格等级划分
        price_level = pd.DataFrame(index=price_df.index, columns=price_df.columns)
        
        # 等级0: price <= q10
        # 等级1: q10 < price <= q90
        # 等级2: price > q90
        price_level = np.where(
            price_smoothed <= q10, 0,
            np.where(price_smoothed <= q90, 1, 2)
        )
        
        # 转换为DataFrame
        price_level = pd.DataFrame(price_level, index=price_df.index, columns=price_df.columns)
        
        # 4. 识别提价类型
        # 创建前一期的价格等级
        prev_level = price_level.shift(1)
        
        # 计算价格变化
        level_change = price_level - prev_level
        
        # 定义提价类型
        price_hike_type = pd.DataFrame(index=price_df.index, columns=price_df.columns)
        price_hike_type = np.where(
            level_change == 1, '0→1',
            np.where(level_change == 2, '0→2', 'None')
        )
        
        # 转换为DataFrame
        price_hike_type = pd.DataFrame(price_hike_type, index=price_df.index, columns=price_df.columns)
        
        # 5. 合并结果
        result_df = pd.DataFrame(index=price_df.index)
        result_df['date'] = date_df['Date']
        
        # 为每个药品添加处理结果
        for drug_id in price_df.columns:
            result_df[f'drug_{drug_id}_price'] = price_df[drug_id]
            result_df[f'drug_{drug_id}_smoothed'] = price_smoothed[drug_id]
            result_df[f'drug_{drug_id}_level'] = price_level[drug_id]
            result_df[f'drug_{drug_id}_hike_type'] = price_hike_type[drug_id]
        
        processed_dfs.append(result_df)
    
    return processed_dfs



def validate_price_levels(processed_dfs, company_names, drug_ids, output_dir='price_level_validation'):
    """
    Validate price level segmentation for each drug and generate visual reports
    
    Parameters:
    - processed_dfs: List of processed DataFrames containing price level information
    - company_names: List of company names
    - drug_ids: List of drug IDs to validate
    - output_dir: Directory to save the output charts
    """
    # Create output directory
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # Generate validation report for each drug
    for drug_id in drug_ids:
        print(f"Validating price level segmentation for Drug {drug_id}...")
        
        # Create subplots
        fig = plt.figure(figsize=(16, 12))
        
        # 1. Price timeline with level segmentation
        ax1 = plt.subplot2grid((3, 2), (0, 0), colspan=2)
        plot_price_levels_over_time(ax1, processed_dfs, company_names, drug_id)
        
        # 2. Boxplot of price distribution by level
        ax2 = plt.subplot2grid((3, 2), (1, 0))
        plot_price_distribution_by_level(ax2, processed_dfs, company_names, drug_id)
        
        # 3. Transition matrix heatmap
        ax3 = plt.subplot2grid((3, 2), (1, 1))
        plot_transition_matrix(ax3, processed_dfs, company_names, drug_id)
        
        # 4. Price hike type statistics
        ax4 = plt.subplot2grid((3, 2), (2, 0))
        plot_hike_type_statistics(ax4, processed_dfs, company_names, drug_id)
        
        # 5. Level validation statistics
        ax5 = plt.subplot2grid((3, 2), (2, 1))
        plot_level_validation_stats(ax5, processed_dfs, company_names, drug_id)
        
        # Adjust layout and save
        plt.tight_layout()
        plt.savefig(f"{output_dir}/drug_{drug_id}_price_level_validation.png", dpi=300, bbox_inches='tight')
        plt.close()

def plot_price_levels_over_time(ax, processed_dfs, company_names, drug_id):
    """Plot price timeline with level segmentation"""
    colors = ['blue', 'green', 'red']
    level_labels = ['Level 0 (Low)', 'Level 1 (Medium)', 'Level 2 (High)']
    
    for i, (df, company_name) in enumerate(zip(processed_dfs, company_names)):
        # Extract drug-specific columns
        price_col = f'drug_{drug_id}_price'
        smoothed_col = f'drug_{drug_id}_smoothed'
        level_col = f'drug_{drug_id}_level'
        
        # Plot smoothed price
        ax.plot(df['date'], df[smoothed_col], label=f'{company_name} - Smoothed Price', 
                color=f'C{i}', alpha=0.7, linewidth=1.5)
        
        # Fill color by price level
        for level in range(3):
            mask = df[level_col] == level
            ax.fill_between(df['date'], df[smoothed_col], where=mask, 
                           color=colors[level], alpha=0.2, label=f'{company_name} - {level_labels[level]}' if level == 0 and i == 0 else "")
    
    ax.set_title(f'Drug {drug_id} - Price Level Timeline')
    ax.set_ylabel('Price')
    ax.legend(loc='upper left', bbox_to_anchor=(1.05, 1))
    ax.grid(True, linestyle='--', alpha=0.3, axis='both')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

def plot_price_distribution_by_level(ax, processed_dfs, company_names, drug_id):
    """Plot boxplot of price distribution by level"""
    data = []
    labels = []
    
    for i, (df, company_name) in enumerate(zip(processed_dfs, company_names)):
        # Extract drug-specific columns
        price_col = f'drug_{drug_id}_price'
        level_col = f'drug_{drug_id}_level'
        
        # Group by price level
        for level in range(3):
            level_data = df[df[level_col] == level][price_col]
            if len(level_data) > 0:
                data.append(level_data)
                labels.append(f'{company_name} - Level {level}')
    
    # Plot boxplot
    if data:
        boxplot = ax.boxplot(data, labels=labels, vert=False, patch_artist=True)
        
        # Set box colors
        colors = ['lightblue', 'lightgreen', 'lightcoral']
        for patch, color in zip(boxplot['boxes'], colors * len(company_names)):
            patch.set_facecolor(color)
    
    ax.set_title(f'Drug {drug_id} - Price Distribution by Level')
    ax.set_xlabel('Price')
    ax.grid(True, linestyle='--', alpha=0.3, axis='both')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

def plot_transition_matrix(ax, processed_dfs, company_names, drug_id):
    """Plot transition matrix heatmap"""
    for i, (df, company_name) in enumerate(zip(processed_dfs, company_names)):
        # Extract drug-specific column
        level_col = f'drug_{drug_id}_level'
        
        # Calculate transition matrix
        transitions = pd.crosstab(
            df[level_col].shift(1),
            df[level_col],
            rownames=['From'],
            colnames=['To'],
            normalize='index'
        )
        
        # Ensure all states exist
        for level in range(3):
            if level not in transitions.index:
                transitions.loc[level] = [0, 0, 0]
            if level not in transitions.columns:
                transitions[level] = 0
        
        # Sort index and columns
        transitions = transitions.sort_index().sort_index(axis=1)
        
        # Plot heatmap
        sns.heatmap(transitions, annot=True, fmt='.2f', cmap='YlGnBu', 
                    ax=ax if i == 0 else None, cbar=i == 0)
        
        if i == 0:
            ax.set_title(f'Drug {drug_id} - Price Level Transition Probability')
            ax.set_xlabel('To Level')
            ax.set_ylabel('From Level')

def plot_hike_type_statistics(ax, processed_dfs, company_names, drug_id):
    """Plot price hike type statistics"""
    hike_types = ['0→1', '0→2', 'None']
    data = []
    labels = []
    
    for i, (df, company_name) in enumerate(zip(processed_dfs, company_names)):
        # Extract drug-specific column
        hike_type_col = f'drug_{drug_id}_hike_type'
        
        # Count hike types
        type_counts = df[hike_type_col].value_counts().reindex(hike_types, fill_value=0)
        data.append(type_counts.values)
        labels.append(company_name)
    
    # Plot bar chart
    x = np.arange(len(hike_types))
    width = 0.8 / len(company_names)
    
    for i, counts in enumerate(data):
        ax.bar(x + i*width - 0.4 + width/2, counts, width, label=labels[i])
    
    ax.set_title(f'Drug {drug_id} - Price Hike Type Statistics')
    ax.set_xlabel('Hike Type')
    ax.set_ylabel('Frequency')
    ax.set_xticks(x)
    ax.set_xticklabels(hike_types)
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.3, axis='both')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

def plot_level_validation_stats(ax, processed_dfs, company_names, drug_id):
    """Plot level validation statistics"""
    for i, (df, company_name) in enumerate(zip(processed_dfs, company_names)):
        # Extract drug-specific columns
        price_col = f'drug_{drug_id}_price'
        level_col = f'drug_{drug_id}_level'
        
        # Calculate statistics by level
        level_stats = df.groupby(level_col)[price_col].agg(['mean', 'std', 'count'])
        
        # Plot mean and standard deviation
        ax.errorbar(level_stats.index, level_stats['mean'], yerr=level_stats['std'], 
                   fmt='o', label=f'{company_name} - Mean±Std', capsize=5)
        
        # Add count labels
        for level, row in level_stats.iterrows():
            ax.text(level, row['mean'] + row['std'] + 0.1, 
                   f"N={int(row['count'])}", ha='center')
    
    ax.set_title(f'Drug {drug_id} - Price Level Statistical Characteristics')
    ax.set_xlabel('Price Level')
    ax.set_ylabel('Price Mean ± Std Dev')
    ax.set_xticks([0, 1, 2])
    ax.set_xticklabels(['Level 0', 'Level 1', 'Level 2'])
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.3, axis='both')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

# Usage example
# validate_price_levels(
#     processed_dfs=processed_dfs,  # Previously processed DataFrame list
#     company_names=['CV', 'FA', 'SB'],
#     drug_ids=[0, 1, 2],  # Select drug IDs to validate
#     output_dir='price_level_validation'
# )
# %%