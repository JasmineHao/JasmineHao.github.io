"""sequence_predictors.py
=======================
Reduced-form analysis of the coordination sequence:
  which drug-level characteristics predict the timing of the first
  coordinated price increase?

The manuscript's response to the generated-regressor concern uses the OLS
lab-fixed-effects rows: drug characteristics alone explain little timing
variation, while laboratory membership explains the ordering.  The Cox blocks
below are retained as legacy diagnostics in the output table, not as the
manuscript's identifying timing specification.

OUTPUTS
-------
output/r2_sequence_ols_cox.csv     regression coefficients (OLS rows used in the manuscript; Cox diagnostics retained)
output/fig_sequence_binscatter.pdf 2-panel binscatter (alpha_j, log_rev)

MODELS
------
OLS-1  first_coord_day ~ alpha_j + log_rev          (baseline, no FE)
OLS-2  ... + below_gap + type_FE                    (add loss-leader depth)
OLS-3  ... + lab_FE                                 (add manufacturer FE)
OLS-4  ... + alpha_j^2 + alpha_j*log_rev            (non-monotonicity test)
Cox-1  same covariates as OLS-3 (no quadratic)
Cox-2  same covariates as OLS-4 (with quadratic + interaction)

Note: OLS outcome = first_coord_day (days since Jan 1 2006).
      Larger value = coordinated *later*.  Negative coefficient on
      log_rev / below_gap means larger / more-loss-leader drugs
      were coordinated *earlier*.
      Cox: higher hazard ratio (HR > 1) = coordinated *earlier*.

ADDRESSES
---------
Referee R3.1: "justify which markets were targeted sooner"
Referee AI-32: sign of the elasticity predictor
Referee AI-O4: use pre-ban (predetermined) characteristics
"""
from __future__ import annotations
import os, sys, pickle, warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats
warnings.filterwarnings("ignore")

# ------------------------------------------------------------------ #
def _root():
    pl = os.getcwd().replace("\\", "/").split("/")
    for i, p in enumerate(pl):
        if p == "DrugStoreCollusion-RAND":
            return "/".join(pl[:i+1])
    return os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))

ROOT = _root()
DATA = os.path.join(ROOT, "data", "processed")
OUT  = os.path.join(ROOT, "output")
sys.path.insert(0, os.path.join(ROOT, "code", "shared"))

plt.rcParams.update({
    "text.usetex": True,
    "text.latex.preamble": r"\usepackage{amsmath}",
    "font.family": "serif", "font.serif": ["Computer Modern Roman"],
    "axes.labelsize": 11, "axes.titlesize": 11,
    "xtick.labelsize": 9.5, "ytick.labelsize": 9.5,
    "legend.fontsize": 9, "axes.spines.top": False,
    "axes.spines.right": False, "axes.linewidth": 0.8,
    "axes.grid": True, "grid.color": "#bfbfbf",
    "grid.linestyle": ":", "grid.linewidth": 0.45,
    "figure.dpi": 140, "pdf.fonttype": 42,
})

# ================================================================== #
# 0.  Build analysis dataset                                         #
# ================================================================== #
print("=" * 60)
print("STEP 0: Build analysis dataset")
print("=" * 60)

# --- per-drug demand params (pre-ban alpha_j, delta_j) ----------- #
alpha_df = pd.read_csv(os.path.join(OUT, "r2_demand_alpha_per_drug.csv"))
_attr_needed = ["ATCL4", "chronic", "Prescription"]
_attr_missing = [c for c in _attr_needed if c not in alpha_df.columns]
if _attr_missing:
    _d0 = pickle.load(open(os.path.join(DATA, "data_objects.pkl"), "rb"))
    _attr0 = _d0["attr"].reset_index(drop=True).copy()
    _attr0["DrugID"] = np.arange(len(_attr0))
    alpha_df = alpha_df.merge(_attr0[["DrugID"] + _attr_missing], on="DrugID", how="left")
alpha_df = alpha_df[["DrugID", "alpha", "delta", "se_alpha", "se_delta",
                     "type4", "sigma_g", "fallback", "ATCL4",
                     "chronic", "Prescription"]].copy()

# --- first coordination timing ----------------------------------- #
ep = pd.read_csv(os.path.join(DATA, "enriched_event_panel.csv"),
                 parse_dates=["event_date"])
sw = ep[(ep["coord_success"] == 1) & (ep["in_window"] == True)]
t01 = (sw[sw["from_tier"] == 0]
       .groupby("DrugID")["event_day"].min()
       .reset_index()
       .rename(columns={"event_day": "first_coord_day"}))
t01_date = (sw[sw["from_tier"] == 0]
            .groupby("DrugID")["event_date"].min()
            .reset_index().rename(columns={"event_date": "first_coord_date"}))
t01 = t01.merge(t01_date, on="DrugID")

# --- reconcile the coordinated set to the structural sample (J=220) -------- #
#  The panel's from-tier-0 set (219) includes the defector (#202, excluded
#  structurally) and misses #129/#186 (validated coordinations with no recorded
#  from-tier-0 panel event).  Align to the structural DC: drop #202, add the two,
#  their day mapped from the structural coordination week (linear over the overlap).
import importlib.util as _il
_sp = _il.spec_from_file_location("fs", os.path.join(ROOT, "code", "06_dynamic_final", "full_structural.py"))
_fs = _il.module_from_spec(_sp); _sp.loader.exec_module(_fs)
_DC = _fs.DC[["DrugID", "coord_wk"]].copy()
_ov = _DC.merge(t01[["DrugID", "first_coord_day"]], on="DrugID")
_sl, _ic = np.polyfit(_ov.coord_wk.values, _ov.first_coord_day.values.astype(float), 1)
_miss = _DC[~_DC.DrugID.isin(t01.DrugID)].copy()
_miss["first_coord_day"] = (_miss.coord_wk * _sl + _ic).round().astype(int)
_miss["first_coord_date"] = pd.NaT
t01 = pd.concat([t01[t01.DrugID.isin(set(_DC.DrugID))],
                 _miss[["DrugID", "first_coord_day", "first_coord_date"]]], ignore_index=True)
print(f"  reconciled coordinated set to structural J={len(t01)} (dropped defector #202, added #129/#186)")

# --- pre-ban market characteristics ------------------------------ #
mu = pd.read_csv(os.path.join(OUT, "r2_mu_preban_by_firm.csv"))
ADBAN_DAY = 659
mu_pre = mu[mu["TimeID"] < ADBAN_DAY].copy()
mu_pre["gap_clp"] = np.maximum(mu_pre["c"] - mu_pre["p"], 0.0)
mu_pre["rev"] = mu_pre["p"] * mu_pre["q"]
# Drug-level aggregates (across all firms and pre-ban days)
by_drug = mu_pre.groupby("DrugID").agg(
    rev_mean=("rev", "mean"),      # mean daily chain-drug revenue (CLP)
    below_gap=("gap_clp", "mean"), # mean below-cost gap (0 if always above cost)
    below_share=("gap_clp",        # fraction of obs below cost
                 lambda x: (x > 0).mean()),
).reset_index()
by_drug["log_rev"] = np.log1p(by_drug["rev_mean"])

# --- lab (manufacturer) ------------------------------------------ #
d    = pickle.load(open(os.path.join(DATA, "data_objects.pkl"), "rb"))
attr = d["attr"]
lab_ser = attr["lab"].reset_index(drop=True)
lab_ser.index.name = "DrugID"
lab_df = lab_ser.reset_index().rename(columns={"lab": "lab"})

# --- merge ------------------------------------------------------- #
df = (alpha_df
      .merge(t01, on="DrugID", how="left")
      .merge(by_drug, on="DrugID", how="left")
      .merge(lab_df, on="DrugID", how="left"))

# Census window last day: 831 (7 Apr 2008)
CENSUS_DAY = 831
df["coordinated"] = df["first_coord_day"].notna().astype(int)
df["surv_day"] = df["first_coord_day"].fillna(CENSUS_DAY)
# Days since first event (day 679)
FIRST_DAY = int(t01["first_coord_day"].min())
df["t_since_first"] = df["surv_day"] - FIRST_DAY

print(f"  N total: {len(df)}  |  coordinated: {df['coordinated'].sum()}")
print(f"  first_coord_day range: {df[df['coordinated']==1]['first_coord_day'].min():.0f}"
      f" -- {df[df['coordinated']==1]['first_coord_day'].max():.0f}")
print(f"  alpha_j range: {df['alpha'].min():.4f} -- {df['alpha'].max():.4f}"
      f"  (median {df['alpha'].median():.4f})")
print(f"  log_rev range: {df['log_rev'].min():.2f} -- {df['log_rev'].max():.2f}")
print(f"  n_labs: {df['lab'].nunique()}")

# Restrict OLS sample to coordinated drugs (same as Fig 4)
ols_df = df[df["coordinated"] == 1].copy().reset_index(drop=True)
# Drop drugs missing pre-ban revenue or below-gap data
_n_before = len(ols_df)
ols_df = ols_df.dropna(subset=["alpha", "log_rev", "below_gap"]).reset_index(drop=True)
if len(ols_df) < _n_before:
    print(f"  Dropped {_n_before - len(ols_df)} drug(s) with missing covariates")
print(f"  OLS sample (coordinated only): {len(ols_df)}")

# Standardize continuous variables for coefficient comparability
for col in ["alpha", "log_rev", "below_gap"]:
    m, s = ols_df[col].mean(), ols_df[col].std()
    ols_df[f"{col}_z"] = (ols_df[col] - m) / s
ols_df["alpha_sq_z"]     = ols_df["alpha_z"] ** 2
ols_df["alpha_logrev_z"] = ols_df["alpha_z"] * ols_df["log_rev_z"]

# ================================================================== #
# 1.  OLS models                                                     #
# ================================================================== #
print("\n" + "=" * 60)
print("STEP 1: OLS — outcome = first_coord_day")
print("=" * 60)

def ols_cluster(y, X, cluster, add_const=True):
    """OLS with cluster-robust SEs (HC1 within-cluster).
    Returns: coef, se, tstat, n, r2, r2_adj
    """
    y = np.asarray(y, dtype=float).reshape(-1)
    X = np.asarray(X, dtype=float)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    cluster = np.asarray(cluster).reshape(-1)
    if add_const:
        X = np.column_stack([np.ones(len(y)), X])
    N, K = X.shape
    XtX_inv = np.linalg.pinv(X.T @ X)
    beta = XtX_inv @ X.T @ y
    resid = y - X @ beta
    # Cluster-robust sandwich
    clusters = np.unique(cluster)
    bread = XtX_inv
    meat  = np.zeros((K, K))
    for c in clusters:
        m = cluster == c
        Xc = X[m]; ec = np.asarray(resid[m]).reshape(-1)
        meat += Xc.T @ np.outer(ec, ec) @ Xc
    G = len(clusters)
    # HC1-style cluster correction
    meat *= (G / (G - 1)) * (N / (N - K))
    vcov = bread @ meat @ bread
    se   = np.sqrt(np.diag(vcov))
    tstat = beta / se
    ss_tot = np.sum((y - y.mean())**2)
    ss_res = resid @ resid
    r2     = 1 - ss_res / ss_tot
    r2_adj = 1 - (ss_res / (N - K)) / (ss_tot / (N - 1))
    return beta, se, tstat, N, r2, r2_adj

def make_dummies(series, drop_first=True):
    cats = sorted(series.unique())
    if drop_first:
        cats = cats[1:]
    D = np.zeros((len(series), len(cats)))
    for i, c in enumerate(cats):
        D[:, i] = (series == c).astype(float)
    return D, cats

y  = ols_df["first_coord_day"].values.astype(float)
cl = ols_df["lab"].values   # cluster at lab level

# Type FE dummies (drop Acute_OTC as base)
D_type, type_cats = make_dummies(ols_df["type4"], drop_first=True)
# Lab FE dummies
D_lab, lab_cats = make_dummies(ols_df["lab"], drop_first=True)

CORE_Z = ["alpha_z", "log_rev_z"]
CORE_BELOW = CORE_Z + ["below_gap_z"]

def run_ols(xvars, add_type_fe=False, add_lab_fe=False, label=""):
    Xlist = [ols_df[v].values.astype(float) for v in xvars]
    if add_type_fe: Xlist.append(D_type)
    if add_lab_fe:  Xlist.append(D_lab)
    X = np.column_stack(Xlist) if len(Xlist) > 1 else Xlist[0][:, None]
    b, se, t, n, r2, r2a = ols_cluster(y, X, cl)
    n_params = len(xvars) + (D_type.shape[1] if add_type_fe else 0) \
               + (D_lab.shape[1] if add_lab_fe else 0) + 1  # +1 intercept
    print(f"\n  {label}  (N={n}, R²={r2:.3f}, R²_adj={r2a:.3f})")
    for i, v in enumerate(xvars):
        print(f"    {v:25s}  β={b[i+1]:8.3f}  se={se[i+1]:7.3f}  t={t[i+1]:7.2f}"
              f"  {'***' if abs(t[i+1])>3.3 else '**' if abs(t[i+1])>2.6 else '*' if abs(t[i+1])>1.96 else ''}")
    return {"label": label, "n": n, "r2": r2, "r2_adj": r2a,
            "vars": xvars, "b": b[1:len(xvars)+1],
            "se": se[1:len(xvars)+1], "t": t[1:len(xvars)+1],
            "type_fe": add_type_fe, "lab_fe": add_lab_fe}

res1 = run_ols(CORE_Z,                                               label="OLS-1 (baseline)")
res2 = run_ols(CORE_BELOW, add_type_fe=True,                         label="OLS-2 (+below_gap+type_FE)")
res3 = run_ols(CORE_BELOW, add_type_fe=True, add_lab_fe=True,        label="OLS-3 (+lab_FE)")
res4 = run_ols(CORE_BELOW + ["alpha_sq_z", "alpha_logrev_z"],
               add_type_fe=True, add_lab_fe=True,                    label="OLS-4 (non-monotonic)")

# ================================================================== #
# 2.  Cox PH models                                                  #
# ================================================================== #
print("\n" + "=" * 60)
print("STEP 2: Cox PH — outcome = t_since_first (right-censored at 152 d)")
print("=" * 60)

from lifelines import CoxPHFitter

def run_cox(xvars, add_type_fe=False, strata=False, label=""):
    sub = ols_df[["t_since_first", "coordinated"] + xvars].copy()
    if add_type_fe:
        for cat in type_cats:
            sub[f"type_{cat}"] = (ols_df["type4"] == cat).astype(float)
    if strata:                                   # lab fixed effects via stratified baseline hazard
        sub["lab"] = ols_df["lab"].values
    sub = sub.dropna()
    cph = CoxPHFitter()
    cph.fit(sub, duration_col="t_since_first", event_col="coordinated",
            strata=(["lab"] if strata else None), robust=True)
    s = cph.summary
    # R^2-like goodness of fit for the Cox model: Harrell's concordance (C-index) and McFadden's
    # pseudo-R^2 = 1 - LL_full/LL_null (LL_null backed out of the partial-likelihood-ratio test).
    cph.concordance = float(cph.concordance_index_)
    try:
        lr = float(cph.log_likelihood_ratio_test().test_statistic)
        ll0 = cph.log_likelihood_ - lr / 2.0
        cph.mcfadden_r2 = float(1.0 - cph.log_likelihood_ / ll0) if ll0 != 0 else float("nan")
    except Exception:
        cph.mcfadden_r2 = float("nan")
    print(f"\n  {label}  (N={len(sub)}, log-lik={cph.log_likelihood_:.1f}, "
          f"C={cph.concordance:.3f}, pseudo-R²={cph.mcfadden_r2:.3f})")
    for v in xvars:
        row = s.loc[v] if v in s.index else None
        if row is not None:
            hr  = np.exp(row["coef"])
            z   = row["z"]
            p   = row["p"]
            sig = "***" if p < 0.01 else "**" if p < 0.05 else "*" if p < 0.1 else ""
            print(f"    {v:25s}  HR={hr:7.3f}  z={z:7.2f}  p={p:.3f} {sig}")
    return cph, s

cph1, s1 = run_cox(CORE_BELOW, add_type_fe=True, label="Cox-1")
cph2, s2 = run_cox(CORE_BELOW + ["alpha_sq_z", "alpha_logrev_z"],
                    add_type_fe=True, label="Cox-2 (non-monotonic)")
cph3, s3 = run_cox(CORE_BELOW, strata=True, label="Cox-3 (+lab strata)")

# ================================================================== #
# 3.  Monotonicity binscatter                                        #
# ================================================================== #
print("\n" + "=" * 60)
print("STEP 3: Monotonicity binscatter")
print("=" * 60)

def binscatter(ax, x, y, n_bins=10, color="#1f3b73", label_x="", label_y="",
               title="", fit_deg=2):
    """Binscatter: sort x into quantile bins, plot mean x vs mean y per bin.
    Overlay raw scatter (faint) + linear + quadratic fits.
    """
    valid = np.isfinite(x) & np.isfinite(y)
    xv, yv = x[valid], y[valid]
    # Raw scatter
    ax.scatter(xv, yv, s=6, alpha=0.18, color=color, edgecolor="none", zorder=1)
    # Binned means
    qtiles = pd.qcut(xv, n_bins, labels=False, duplicates="drop")
    bx = [xv[qtiles == k].mean() for k in sorted(set(qtiles))]
    by = [yv[qtiles == k].mean() for k in sorted(set(qtiles))]
    ax.scatter(bx, by, s=55, color=color, edgecolor="white",
               linewidth=0.9, zorder=4, label=f"binned mean ({n_bins} bins)")
    # Linear fit
    xs = np.linspace(xv.min(), xv.max(), 80)
    cf1 = np.polyfit(xv, yv, 1)
    ax.plot(xs, np.polyval(cf1, xs), "-", color=color, lw=1.4,
            alpha=0.7, label=f"linear fit (slope={cf1[0]:.1f})", zorder=3)
    # Quadratic fit
    cf2 = np.polyfit(xv, yv, 2)
    ax.plot(xs, np.polyval(cf2, xs), "--", color="#a8203a", lw=1.3,
            alpha=0.85, label=f"quadratic fit", zorder=3)
    ax.set_xlabel(label_x); ax.set_ylabel(label_y); ax.set_title(title)
    ax.legend(frameon=False, fontsize=8.5)
    # Report quadratic coef and significance
    # F-test for quadratic term: compare residuals
    n = len(xv)
    pred1 = np.polyval(cf1, xv)
    pred2 = np.polyval(cf2, xv)
    rss1  = np.sum((yv - pred1)**2)
    rss2  = np.sum((yv - pred2)**2)
    F     = ((rss1 - rss2) / 1) / (rss2 / (n - 3))
    p     = 1 - stats.f.cdf(F, 1, n - 3)
    print(f"  {title}: quad coef = {cf2[0]:.3f}, "
          f"F(1,{n-3}) = {F:.2f}, p = {p:.3f}")
    return cf2

fig, axes = plt.subplots(1, 2, figsize=(11.0, 4.2))

# Panel A: alpha_j vs first_coord_day
xA = ols_df["alpha"].values
yA = ols_df["first_coord_day"].values
cfA = binscatter(axes[0], xA, yA,
    label_x=r"Pre-ban price sensitivity $\hat\alpha_j$",
    label_y=r"First coordinated raise (day no.)",
    title=r"\textbf{(A)} Elasticity and coordination order",
    color="#1f3b73")

# Panel B: log_rev vs first_coord_day
xB = ols_df["log_rev"].values
yB = ols_df["first_coord_day"].values
cfB = binscatter(axes[1], xB, yB,
    label_x=r"Pre-ban log revenue (CLP)",
    label_y=r"First coordinated raise (day no.)",
    title=r"\textbf{(B)} Market size and coordination order",
    color="#3f7c5c")

fig.subplots_adjust(left=0.08, right=0.98, bottom=0.14, top=0.88, wspace=0.30)
fig_path = os.path.join(OUT, "fig_sequence_binscatter.pdf")
fig.savefig(fig_path, bbox_inches="tight")
print(f"\n  Binscatter saved: {fig_path}")
plt.close()

# ================================================================== #
# 4.  Regression summary table                                       #
# ================================================================== #
print("\n" + "=" * 60)
print("STEP 4: Regression table")
print("=" * 60)

key_vars = ["alpha_z", "log_rev_z", "below_gap_z", "alpha_sq_z", "alpha_logrev_z"]
var_names = {
    "alpha_z":        r"alpha_j (std.)",
    "log_rev_z":      r"log_rev (std.)",
    "below_gap_z":    r"below_gap (std.)",
    "alpha_sq_z":     r"alpha_j^2 (std.)",
    "alpha_logrev_z": r"alpha_j x log_rev (std.)",
}

rows = []
for v in key_vars:
    row = {"variable": var_names[v]}
    for res in [res1, res2, res3, res4]:
        if v in res["vars"]:
            idx = res["vars"].index(v)
            b  = res["b"][idx]
            se = res["se"][idx]
            t  = res["t"][idx]
            sig = "***" if abs(t) > 3.3 else "**" if abs(t) > 2.6 else "*" if abs(t) > 1.96 else ""
            row[res["label"]] = f"{b:.2f} ({se:.2f}){sig}"
        else:
            row[res["label"]] = "—"
    # Cox models
    for cph, sl, clabel in [(cph1, s1, "Cox-1"), (cph2, s2, "Cox-2"), (cph3, s3, "Cox-3")]:
        cox_v = v  # same var name in Cox
        if cox_v in sl.index:
            hr = np.exp(sl.loc[cox_v, "coef"])
            z  = sl.loc[cox_v, "z"]
            p  = sl.loc[cox_v, "p"]
            sig = "***" if p < 0.01 else "**" if p < 0.05 else "*" if p < 0.1 else ""
            row[clabel] = f"HR {hr:.3f} ({z:.2f}){sig}"
        else:
            row[clabel] = "—"
    rows.append(row)

# Footer rows  (R2 = OLS R^2; Concordance + Pseudo-R2 = the Cox goodness-of-fit analogues)
cox_cph = {"Cox-1": cph1, "Cox-2": cph2, "Cox-3": cph3}
for lbl, res in [("N", None), ("R2", None), ("Concordance", None), ("Pseudo-R2", None),
                 ("Type FE", None), ("Lab FE", None)]:
    row = {"variable": lbl}
    for res_ in [res1, res2, res3, res4]:
        if lbl == "N":     row[res_["label"]] = str(res_["n"])
        elif lbl == "R2":  row[res_["label"]] = f"{res_['r2']:.3f}"
        elif lbl == "Type FE": row[res_["label"]] = "Yes" if res_["type_fe"] else "No"
        elif lbl == "Lab FE":  row[res_["label"]] = "Yes" if res_["lab_fe"] else "No"
        else:              row[res_["label"]] = "—"
    for ccol, has_lab in [("Cox-1", False), ("Cox-2", False), ("Cox-3", True)]:
        cph = cox_cph[ccol]
        if lbl == "N":             row[ccol] = str(len(ols_df))
        elif lbl == "Concordance": row[ccol] = f"{cph.concordance:.3f}"
        elif lbl == "Pseudo-R2":   row[ccol] = f"{cph.mcfadden_r2:.3f}"
        elif lbl == "Type FE":     row[ccol] = "No" if ccol == "Cox-3" else "Yes"
        elif lbl == "Lab FE":      row[ccol] = "Yes" if has_lab else "No"
        else:                      row[ccol] = "—"
    rows.append(row)

tab = pd.DataFrame(rows)
print(tab.to_string(index=False))
tab.to_csv(os.path.join(OUT, "r2_sequence_ols_cox.csv"), index=False)
print(f"\n  Table saved: output/r2_sequence_ols_cox.csv")
print(f"  Figure saved: {fig_path}")

# ================================================================== #
# 5.  Variable importance summary                                    #
# ================================================================== #
print("\n" + "=" * 60)
print("STEP 5: Which variables are most predictive?")
print("=" * 60)

print("\n  OLS-3 (lab+type FE) standardised coefficients (|t|-ranked):")
order = np.argsort(-np.abs(res3["t"]))
for i in order:
    v = res3["vars"][i]
    print(f"    {v:25s}  β={res3['b'][i]:8.3f}  |t|={abs(res3['t'][i]):6.2f}")

print(f"\n  R² progression:")
for res_ in [res1, res2, res3, res4]:
    print(f"    {res_['label']:40s}  R²={res_['r2']:.3f}")

print("\n  Cox-1 HR (ranked by |z|):")
for v in CORE_BELOW:
    if v in s1.index:
        z = s1.loc[v, "z"]
        hr = np.exp(s1.loc[v, "coef"])
        p  = s1.loc[v, "p"]
        print(f"    {v:25s}  HR={hr:.3f}  |z|={abs(z):.2f}  p={p:.3f}")

print("\n  Non-monotonicity (OLS-4):")
for v in ["alpha_sq_z", "alpha_logrev_z"]:
    if v in res4["vars"]:
        idx = res4["vars"].index(v)
        print(f"    {v:30s}  β={res4['b'][idx]:.3f}  t={res4['t'][idx]:.2f}")

# ================================================================== #
# 6.  Between- vs within-lab decomposition of the size gradient      #
# ================================================================== #
# The coordination wave is a LABORATORY phenomenon (batch calls): a lab
# coordinates its whole portfolio together.  So the market-size ordering should run
# BETWEEN labs (big labs called first), and be WEAK WITHIN a lab (which of a lab's
# own drugs goes first is barely predicted by that drug's size).  We decompose the
# standardised log-revenue gradient into a between-lab piece (lab means) and a
# within-lab piece (deviations from the lab mean), both scaled by the POOLED SD so
# "per SD" is comparable, and report the share of the timing variance the lab
# identity alone explains (the intraclass correlation, ICC).
print("\n" + "=" * 60)
print("STEP 6: Between- vs within-lab size gradient (batch-call test)")
print("=" * 60)
gb           = ols_df.groupby("lab")
lab_mean_lr  = gb["log_rev"].transform("mean")
pooled_sd    = ols_df["log_rev"].std()
betw_z       = ((lab_mean_lr - lab_mean_lr.mean()) / pooled_sd).values        # between component
with_z       = ((ols_df["log_rev"] - lab_mean_lr) / pooled_sd).values          # within component
# ICC + drug-char vs lab-FE R^2 ladder (lab FE ALONE, no drug characteristics)
_, _, _, _, r2_labfe, _ = ols_cluster(y, D_lab, cl)                            # ICC of coord timing
_, _, _, _, r2_drug,  _ = ols_cluster(y, ols_df[CORE_Z].values, cl)            # drug chars only (alpha,log_rev)
X_drug_lab = np.column_stack([ols_df[CORE_Z].values, D_lab])
_, _, _, _, r2_drug_lab, _ = ols_cluster(y, X_drug_lab, cl)                    # drug chars + lab FE
# (a) WITHIN-lab gradient: y ~ within_z + lab FE  (lab-clustered SE)
bw, sew, tw, _, r2_w, _ = ols_cluster(y, np.column_stack([with_z, D_lab]), cl)
# (b) BETWEEN-lab gradient: collapse to lab level, mean timing on mean size
lab_tab = ols_df.groupby("lab").agg(cday=("first_coord_day", "mean"),
                                    lr=("log_rev", "mean")).reset_index()
bz = ((lab_tab["lr"] - lab_tab["lr"].mean()) / pooled_sd).values
bb, seb, tb, _, _, _ = ols_cluster(lab_tab["cday"].values, bz[:, None], lab_tab["lab"].values)
print(f"  ICC (lab FE alone explains)          R^2 = {r2_labfe:.3f}")
print(f"  drug chars alone                     R^2 = {r2_drug:.3f}")
print(f"  drug chars + lab FE                  R^2 = {r2_drug_lab:.3f}")
print(f"  BETWEEN-lab: larger lab coordinates  beta = {bb[1]:+.2f} days/SD   t = {tb[1]:+.2f}  (n_labs={len(lab_tab)})")
print(f"  WITHIN-lab : own size vs lab-mates   beta = {bw[1]:+.2f} days/SD   t = {tw[1]:+.2f}")
print(f"  within adds to R^2 over lab FE alone: {r2_w - r2_labfe:+.3f}")
