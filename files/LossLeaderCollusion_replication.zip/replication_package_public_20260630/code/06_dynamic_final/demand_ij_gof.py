"""demand_ij_gof.py -- Goodness-of-fit of the (i,j) product-firm demand mapping.

Two checks the structural game inherits from demand, BOTH out-of-sample:
  (1) MARKET SHARE  -- the per-chain within-nest shares s_{i|j}.  The intercepts phi_ij are
      recovered from the COORDINATED-window within-shares; we then predict the WAR and RENT
      within-shares (different price regimes) and compare to observed.
  (2) QUANTITY       -- the per-chain quantity N_j * s_ij.  Market size N_j is anchored on a
      NORMAL-period median; we compare implied vs observed three-chain quantity at war / coord / rent.

Writes output/demand_ij_gof.json + paper/manuscript/fig_demand_ij_gof.pdf and prints the appendix numbers.
"""
import os, json
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
FIRMS = ["CV", "FA", "SB"]

# ---- demand primitives (must match full_structural_ij.py) -------------------
dem = json.load(open(os.path.join(ROOT, "output", "demand_params.json")))
SIG = float(dem["headline"]["sigma"]);  OM = 1.0 - SIG
RHO = float(dem["headline"].get("rho_mktshare", 0.92))
A_RATIO = float(dem["headline"]["A_RATIO"])
_TGT_DG = (RHO / (1.0 - RHO)) ** (1.0 / OM)

def shares(p, phi, a, om=OM):
    """Nested-logit shares of the 3 chains (out of the whole market) at prices p, qualities phi."""
    p = np.asarray(p, float); d = np.exp((phi - a * p) / om)
    Dg = d.sum(); inn = d / Dg                       # within-nest shares
    Sg = Dg ** om / (1.0 + Dg ** om)                 # nest (inside) share
    return inn * Sg

def within(p, phi, a, om=OM):
    p = np.asarray(p, float); d = np.exp((phi - a * p) / om); return d / d.sum()

def phi_ij(sw, p1, a, om=OM):
    """Per-chain quality from observed within-shares sw at the common coord price p1 (matches full_structural_ij)."""
    sw = np.clip(np.asarray(sw, float), 1e-4, None); sw = sw / sw.sum()
    phi = om * np.log(sw); phi -= phi.mean()
    return phi + om * np.log(_TGT_DG / np.exp((phi - a * p1) / om).sum())

# ---- data -------------------------------------------------------------------
df = pd.read_csv(os.path.join(ROOT, "data", "processed", "demand_data_core.csv"))
alpha = pd.read_csv(os.path.join(ROOT, "output", "r2_demand_alpha_per_drug.csv")).set_index("DrugID").alpha
amed = float(alpha.median())
e = pd.read_csv(os.path.join(ROOT, "output", "v16_events_unified.csv"), parse_dates=["date"])
e["wk"] = ((e.date - pd.Timestamp("2006-01-01")).dt.days // 7).astype(int)
e["c_imp"] = e.price / e.markup_c
co = e[e.kind == "coordination"]
war_p = e[e.kind == "deviation_war"].groupby("DrugID").price.median()
t1 = co[co.to_tier == 1].groupby("DrugID").price.median()
t2 = co[co.to_tier == 2].groupby("DrugID").price.median()
cost = e.groupby("DrugID").c_imp.median()

# observed windows: WAR (active, pre-ban), COORD (phi recovered here), RENT (post-coordination)
WIN = {"war": (78, 96), "coord": (105, 118), "rent": (118, 140), "normal": (52, 78)}
def _wm(col, lo, hi):
    s = df[(df.TimeID >= lo) & (df.TimeID < hi)]
    return s.groupby(["DrugID", "Firm"])[col].median()
def _wq(lo, hi):
    s = df[(df.TimeID >= lo) & (df.TimeID < hi)]
    return s.groupby(["DrugID", "TimeID"]).Quantity.sum().groupby(level=0).median()

sw_obs = {w: _wm("ShareWithinGroup", *WIN[w]) for w in WIN}
q_obs  = {w: _wq(*WIN[w]) for w in WIN}

# ---- per-drug prediction ----------------------------------------------------
rows = []
for j in sorted(set(e.DrugID) & set(alpha.index)):
    pw, pc1, pc2, c = war_p.get(j, np.nan), t1.get(j, np.nan), t2.get(j, np.nan), cost.get(j, np.nan)
    if not (np.isfinite(pw) and np.isfinite(pc1) and np.isfinite(c)):
        continue
    pc2 = pc2 if np.isfinite(pc2) else pc1 * 1.12
    a = float(alpha.get(j, amed)); a = a if a > 1e-3 else amed
    swc = np.array([sw_obs["coord"].get((j, f), np.nan) for f in FIRMS])     # COORD within-shares -> recover phi
    if not np.all(np.isfinite(swc)) or swc.sum() <= 0:
        continue
    swc = swc / swc.sum()
    phi = phi_ij(swc, pc1 / 1000.0, a)                                       # prices in '000s (match panel)
    Nj = (q_obs["normal"].get(j, np.nan))
    Nj = Nj / RHO if np.isfinite(Nj) else np.nan
    for w, pr in [("war", pw), ("coord", pc1), ("rent", pc2)]:
        p3 = np.full(3, pr / 1000.0)
        wn_pred = within(p3, phi, a)                                         # predicted within-nest shares (= softmax(phi/om))
        s_pred = shares(p3, phi, a)                                          # predicted market shares
        swo = np.array([sw_obs[w].get((j, f), np.nan) for f in FIRMS])
        if swo.sum() > 0: swo = swo / swo.sum()
        q_pred3 = float(Nj * s_pred.sum()) if np.isfinite(Nj) else np.nan    # implied three-chain quantity
        q_o = q_obs[w].get(j, np.nan)
        rows.append(dict(DrugID=j, win=w,
                         wn_pred=wn_pred, wn_obs=swo,
                         qpred=q_pred3, qobs=float(q_o) if np.isfinite(q_o) else np.nan))
R = pd.DataFrame(rows)
print(f"drugs with full (war,coord,rent) data: {R.DrugID.nunique()}")

# ---- (1) MARKET SHARE goodness of fit (within-nest, per chain, out-of-sample) ----
def share_err(win):
    sub = R[R.win == win].dropna(subset=["wn_obs"])
    sub = sub[sub.wn_obs.apply(lambda v: np.all(np.isfinite(v)))]
    err = np.array([np.abs(p - o) for p, o in zip(sub.wn_pred, sub.wn_obs)]).reshape(-1)  # |pred-obs| pp, all chains
    return err
share_gof = {}
for w in ["war", "coord", "rent"]:
    err = share_err(w)
    share_gof[w] = dict(median_pp=float(np.median(err) * 100), mean_pp=float(np.mean(err) * 100),
                        p90_pp=float(np.percentile(err, 90) * 100), n=int(len(err)))
    print(f"  MARKET SHARE [{w:5s}] median |pred-obs| = {share_gof[w]['median_pp']:.2f}pp  "
          f"mean {share_gof[w]['mean_pp']:.2f}pp  p90 {share_gof[w]['p90_pp']:.2f}pp  (N={share_gof[w]['n']})")

# ---- (2) QUANTITY goodness of fit (three-chain, per tier) ----
qty_gof = {}
for w in ["war", "coord", "rent"]:
    sub = R[R.win == w].dropna(subset=["qpred", "qobs"])
    sub = sub[(sub.qobs > 0) & (sub.qpred > 0)]
    ratio = (sub.qpred / sub.qobs).to_numpy()
    qty_gof[w] = dict(median_ratio=float(np.median(ratio)), iqr=[float(np.percentile(ratio, 25)), float(np.percentile(ratio, 75))],
                      corr=float(np.corrcoef(np.log(sub.qpred.to_numpy(float)),
                                             np.log(sub.qobs.to_numpy(float)))[0, 1]), n=int(len(sub)))
    print(f"  QUANTITY     [{w:5s}] median pred/obs = {qty_gof[w]['median_ratio']:.3f}  "
          f"IQR [{qty_gof[w]['iqr'][0]:.2f},{qty_gof[w]['iqr'][1]:.2f}]  corr(log) {qty_gof[w]['corr']:.3f}  (N={qty_gof[w]['n']})")

# ---- figure: (a) predicted vs observed within-share (war, out-of-sample); (b) quantity ----
fig, ax = plt.subplots(1, 2, figsize=(11, 4.6))
col = {"CV": "#1f77b4", "FA": "#ff7f0e", "SB": "#2ca02c"}
sub = R[R.win == "war"].dropna(subset=["wn_obs"]); sub = sub[sub.wn_obs.apply(lambda v: np.all(np.isfinite(v)))]
for fi, f in enumerate(FIRMS):
    xo = np.array([o[fi] for o in sub.wn_obs]); xp = np.array([p[fi] for p in sub.wn_pred])
    ax[0].scatter(xo, xp, s=14, alpha=0.5, color=col[f], label=f)
ax[0].plot([0, 1], [0, 1], "k--", lw=1)
ax[0].set_xlabel("observed within-nest share (war)"); ax[0].set_ylabel("predicted (from coord $\\phi_{ij}$)")
ax[0].set_title(f"(a) Market share, out-of-sample  (median {share_gof['war']['median_pp']:.1f}pp)")
ax[0].legend(frameon=False, fontsize=9); ax[0].set_xlim(0, 1); ax[0].set_ylim(0, 1)
for w, mk in [("war", "o"), ("coord", "s"), ("rent", "^")]:
    sub = R[R.win == w].dropna(subset=["qpred", "qobs"]); sub = sub[(sub.qobs > 0) & (sub.qpred > 0)]
    ax[1].scatter(sub.qobs, sub.qpred, s=12, alpha=0.45, marker=mk, label=f"{w} (×{qty_gof[w]['median_ratio']:.2f})")
lim = [max(1, R.qobs.min()), R.qobs.max() * 1.1]
ax[1].plot(lim, lim, "k--", lw=1); ax[1].set_xscale("log"); ax[1].set_yscale("log")
ax[1].set_xlabel("observed three-chain quantity"); ax[1].set_ylabel("predicted $N_j\\,\\sum_i s_{ij}$")
ax[1].set_title("(b) Quantity, by tier"); ax[1].legend(frameon=False, fontsize=9)
plt.tight_layout()
figp = os.path.join(ROOT, "paper", "manuscript", "fig_demand_ij_gof.pdf")
plt.savefig(figp, bbox_inches="tight"); plt.savefig(os.path.join(ROOT, "output", "fig_demand_ij_gof.png"), dpi=130, bbox_inches="tight")
print(f"wrote {figp}")

json.dump(dict(share=share_gof, quantity=qty_gof, n_drugs=int(R.DrugID.nunique()),
               sigma=SIG, OM=OM, RHO=RHO),
          open(os.path.join(ROOT, "output", "demand_ij_gof.json"), "w"), indent=2)
print("wrote output/demand_ij_gof.json")
