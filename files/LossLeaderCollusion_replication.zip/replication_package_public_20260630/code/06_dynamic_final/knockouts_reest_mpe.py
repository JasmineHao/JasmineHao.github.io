"""knockouts_reest_mpe.py -- RE-ESTIMATE each belief/payoff knockout under the psi-leadership + learned-belief
HEADLINE (so Table tab:spec_fit is a fair horse race: every restricted spec gets its own best-fit params,
not the headline's).  Mirrors estimate_hetmu_mpe.py: fixed psi/share/TAU/SCRUT_LEARN; estimate the 11 params
mu_bar + 8 belief/timing + lam_cut + m, with one ingredient switched off in every objective evaluation.

Specs (Table 8 columns):
  nobel   -- no belief (b==1)                      jump    -- ad-ban jump but NO event-update
  learn   -- event-update but NO focal jump (z=0)  belonly -- ban shifts beliefs, no alpha collapse
  mu0     -- no store traffic (mu_bar fixed at 0)
The value-function checks (myopic/foresight/absorbing) are NOT re-estimated -- they test the solution
concept and are re-simulated at the estimate (see scenarios_mpe.py).

Run: IJ=1 PERP_TERMINAL=1 python3 knockouts_reest_mpe.py  ->  output/knockouts_reest_mpe.json
"""
import os, json, time, importlib.util
import numpy as np
from scipy.optimize import minimize
os.environ.setdefault("IJ", "1"); os.environ.setdefault("PERP_TERMINAL", "1")
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
spec = importlib.util.spec_from_file_location("fs", os.path.join(ROOT, "code", "06_dynamic_final", "full_structural_mpe.py"))
fs = importlib.util.module_from_spec(spec); spec.loader.exec_module(fs)
fs.PSI_LEAD = [0.60, 0.80, 0.00]; fs.CHAIN_SHARE = np.array([0.453, 0.309, 0.239])
fs.TAU_LEAD = 3.0; fs.TAU_RENT = 0.12; fs.SCRUT_LEARN = 1
RHO_FIX = 2.0
BND = dict(mu_bar=(6.0, 14.0), lam=(0.05, 0.95), tau_eng=(30.0, 400.0), t0=(98, 106), a0=(0.3, 8.0),
           b0=(5.0, 150.0), zeta=(40.0, 3000.0), chi=(1.0, 4.0), g=(0.0, 1.5), lam_cut=(0.0, 0.30), scrut_m=(5.0, 60.0))
K = list(BND); bounds = [BND[k] for k in K]
REST = ["lam", "tau_eng", "t0", "a0", "b0", "zeta", "chi", "g"]
d = json.load(open(os.path.join(ROOT, "output", "hetmu_mpe.json")))
WARM = [float(d["mu_bar"])] + [float(d["theta"][k]) for k in REST] + [float(d["theta"]["lam_cut"]), float(d["scrut_m"])]

# spec -> (simulate kw, fix-dict {param:value}, force mu_bar)
SPECS = {
    "nobel":   (dict(bmode="nobel"), {}, None),
    "jump":    (dict(bmode="jump_only"), {}, None),
    "learn":   (dict(bmode="learn_only"), {}, None),   # learn_only zeros zeta internally (the focal jump off)
    "belonly": (dict(no_alpha_collapse=True), {}, None),
    "mu0":     (dict(), {}, 0.0),                       # mu_bar fixed at 0
}
MOMK = ["tot01", "tot12", "peak", "sd", "succ_war", "succ_cart", "fail_war", "dev_war", "corr_sz", "lead_sb_cart"]

def clip(x): return [min(max(float(x[i]), bounds[i][0]), bounds[i][1]) for i in range(len(K))]

def run(name):
    kw, fix, mb = SPECS[name]
    _DV = {"v": None}
    def unpack(x):
        xc = clip(x)
        for p, v in fix.items(): xc[K.index(p)] = v
        if mb is not None: xc[0] = mb
        mu_bar = xc[0]
        # K order: mu_bar,lam,tau_eng,t0,a0,b0,zeta,chi,g,lam_cut,scrut_m -> theta11: ...,chi,rho(dummy),g,lam_cut
        theta = [mu_bar, xc[1], xc[2], xc[3], xc[4], xc[5], xc[6], xc[7], RHO_FIX, xc[8], xc[9]]
        return theta, np.array([mu_bar] * 3), xc[10], xc
    def obj(x, B=16, n_outer=3, warm=False):
        theta, mu, sm, _ = unpack(x); fs.SCRUT_M = sm
        o, dv = fs.simulate_mpe(theta, mu, B=B, n_outer=n_outer, final_sim=False, psi=[0.0, 0.0, 0.0],
                                onetime=True, w_window=26.0, arrivals_throughout=True,
                                dv_init=(_DV["v"] if warm else None), return_dv=True, **kw)
        if warm: _DV["v"] = dv
        return fs.loss(o)
    # knockouts are perturbations of the headline -> warm-start a single Powell from WARM (no random scan)
    best = (obj(WARM, B=16, n_outer=3), clip(WARM))
    _DV["v"] = None
    res = minimize(lambda x: obj(x, B=16, n_outer=3, warm=True), np.array(WARM, float), method="Powell",
                   bounds=bounds, options=dict(maxiter=45, xtol=4e-3, ftol=4e-3))
    f = obj(res.x, B=20, n_outer=4)
    if f < best[0]: best = (f, clip(res.x))
    theta, mu, sm, xc = unpack(best[1]); fs.SCRUT_M = sm
    M = fs.simulate_mpe(theta, mu, B=240, n_outer=6, psi=[0.0, 0.0, 0.0], onetime=True, w_window=26.0, arrivals_throughout=True, **kw)
    L = float(fs.loss(M))
    return dict(name=name, loss=L, params=dict(zip(K, xc)), moments={k: float(M[k]) for k in MOMK})

if __name__ == "__main__":
    t0 = time.time(); out = {}
    for nm in ["nobel", "jump", "learn", "belonly", "mu0"]:
        r = run(nm); out[nm] = r
        print(f"[{time.time()-t0:.0f}s] {nm:8s} loss {r['loss']:8.1f}  tot01 {r['moments']['tot01']:.0f}  "
              f"tot12 {r['moments']['tot12']:.0f}  SBcart {r['moments']['lead_sb_cart']:.2f}  dev_war {r['moments']['dev_war']:.0f}", flush=True)
    json.dump(out, open(os.path.join(ROOT, "output", "knockouts_reest_mpe.json"), "w"), indent=2)
    print(f"[{time.time()-t0:.0f}s] wrote output/knockouts_reest_mpe.json")
