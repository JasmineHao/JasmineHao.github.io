"""appendix_full_path.py  --  the full 2006->2008 price-war path from the belief dynamics.

Rolls the belief + lift dynamics from January 2006 (week 0), not just the Jan-2007 onset, to show
the model GENERATES the war endogenously: starting from the prior belief, firms test coordinated
lifts; pre-ban the undercut gain G01>0 so every lift is undercut and reverts, the belief stays low
(self-fulfilling), and the war entrenches; the Aug-2007 campaign intensifies it; the Nov-2007 ban
delivers the focal jump and flips G01<0, and the cartel forms.  Validates the simulated failure path
against the record (2006: 87 reverted lifts; 2007 war: 123) and reports the war-state belief entering
the post-ban window -- the input to the experimentation-horizon counterfactual.

Run: python3 appendix_full_path.py   ->  prints validation + writes fig_full_path.pdf
"""
import os, json, importlib.util
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
os.environ.setdefault("IJ", "1"); os.environ.setdefault("PERP_TERMINAL", "1")
spec = importlib.util.spec_from_file_location("fs", os.path.join(ROOT, "code", "06_dynamic_final", "full_structural_mpe.py"))
fs = importlib.util.module_from_spec(spec); spec.loader.exec_module(fs)
fs.PSI_LEAD = [0.60, 0.80, 0.00]; fs.CHAIN_SHARE = np.array([0.453, 0.309, 0.239])
fs.TAU_LEAD = 3.0; fs.TAU_RENT = 0.12; fs.SCRUT_LEARN = 1; fs.SCRUT_M = 14.8

# Headline psi-leadership MPE theta (output/hetmu_mpe.json)
KAPPA, A0, B0, ZETA, G = 9.261, 1.803, 128.845, 306.9, 0.573
TAU, DELTA, J = fs.TAU, fs.DELTA, fs.J
BAN, AUG, OFICIO = fs.BAN, fs.AUG, fs.OFICIO          # 96, 84, 117 (week index; week 0 = Jan 2006)
G01 = {"pre": KAPPA * fs.DS["ds01_pre"] + fs.DS["mg01_pre"],
       "post": KAPPA * fs.DS["ds01_post"] + fs.DS["mg01_post"]}
dV1 = DELTA * np.mean([fs.value_funcs(KAPPA, psi=[0.0, 0.0, 0.0])[i] for i in range(3)], axis=0)[-1]   # per-drug escape value (psi=0 matches headline)
def logit(x): return 1.0 / (1.0 + np.exp(-x))

# Escape-attempt rate: firms try to lift OUT of the war at a rate driven by the deepening below-cost
# pain (Fact 1 -- the loss accelerated through 2007), NOT by the (low, falling) belief; this is why
# the failed lifts RISE from 2006 to 2007.  Whether a lift HOLDS is still belief-gated (the b^2 gate).
# A_LO, A_HI rise linearly to the ban; calibrated to the record (2006: 87 reverted lifts, 2007: 123).
A_LO, A_HI = 0.0049, 0.0150
def roll(seed):
    rng = np.random.default_rng(seed)
    coord = np.zeros(J, bool); S = 0; F = 0
    bpath = np.zeros(157); fwk = np.zeros(157); swk = np.zeros(157)
    for t in range(157):                                  # week 0 = Jan 2006 ... 156 = Dec 2008
        jump = ZETA if t >= BAN else 0.0
        b = (A0 + S + jump) / (A0 + B0 + S + F + jump)     # belief with the focal jump at the ban
        bpath[t] = b
        reg = "pre" if t < BAN else "post"
        a_rate = (A_LO + (A_HI - A_LO) * t / BAN) if t < BAN else b   # escape-driven pre-ban; eager (belief) post-ban
        for j in np.where(~coord)[0]:
            if rng.random() >= min(a_rate, 0.99):          # leader tests a lift
                continue
            NG01 = G01[reg][j] - b * dV1[j]                # follower forward-looking IC
            held = (rng.random() < b * b) and (rng.random() < logit(-NG01 / TAU))   # b^2 gate + hold
            if held:
                coord[j] = True; S += 1; swk[t] += 1
            elif t < BAN:                                  # pre-ban: an unmatched lift is UNDERCUT -> reverts
                F += 1; fwk[t] += 1
            # post-ban: an unmatched lift just waits (no revert)
    return bpath, fwk, swk

NS = 30
B = np.zeros((NS, 157)); Fk = np.zeros((NS, 157)); Sk = np.zeros((NS, 157))
for s in range(NS):
    B[s], Fk[s], Sk[s] = roll(s)
bpath, fwk, swk = B.mean(0), Fk.mean(0), Sk.mean(0)

def seg(a, lo, hi): return a[lo:hi].sum()
print("=== full-path validation: pre-ban reversions by period (model vs record) ===")
print(f"  2006 discounts (wk 0-51) : model {seg(fwk,0,52):6.1f}   data ~ 87  (below-cost cuts, the war itself)")
print(f"  2007 failed lifts (wk 52-95): model {seg(fwk,52,BAN):6.1f}   data ~123  (clean lift-then-revert)")
print(f"  cartel      (wk 96-116): model {seg(fwk,BAN,OFICIO):6.1f}   data ~  4")
print(f"  post-Oficio (wk 117-156): model {seg(fwk,OFICIO,157):6.1f}   data ~ 67")
print(f"\n  pre-ban coordinated lifts that STUCK: model {seg(swk,0,BAN):5.1f}   data 0   (the war is self-fulfilling)")
print(f"  cartel successes (wk 96-156): model {seg(swk,BAN,157):6.1f}   data ~284")
print(f"\nbelief: 2006 start {bpath[0]:.4f}  ->  war-state (just before ban, wk 95) {bpath[BAN-1]:.4f}  ->  post-jump (wk 96) {bpath[BAN]:.3f}")
print(f"war-state belief feeds the experimentation horizon: at b={bpath[BAN-1]:.4f} the b^3 gate keeps it decades-long.")

# ---- figure: the belief path + the failure path over 2006-2008 ----
fs.value_funcs  # noqa
wk = np.arange(157)
mon = wk / (52/12.0)
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(7.2, 4.4), sharex=True, gridspec_kw={"height_ratios":[1.2,1]})
ax1.plot(wk, bpath, color="#1f5c8a", lw=2.0)
ax1.set_ylabel("belief $b_t$ (matched)"); ax1.set_ylim(0, 1.05)
for x, lab, c, yy, ha, dx in [(AUG,"Aug-07\ncampaign","#9e2b1e",0.46,"right",-1.2),
                              (BAN,"Nov-07 ban\n(focal jump)","0.35",0.66,"left",1.2),
                              (OFICIO,"Mar-08\nOficio","#b8860b",0.46,"left",1.2)]:
    ax1.axvline(x, color=c, ls="--", lw=0.9); ax1.text(x+dx, yy, lab, fontsize=6.2, color=c, va="top", ha=ha)
ax1.set_title("(A) The belief that a raise will be matched: low through the 2006--07 war, focal jump at the ban", fontsize=8.0, loc="left")
ax1.annotate(f"war-state b={bpath[BAN-1]:.3f}", (BAN-1, bpath[BAN-1]), (40, 0.30), fontsize=6.6,
             arrowprops=dict(arrowstyle="->", lw=0.6, color="0.4"))
ax2b = ax2.twinx()                                              # per-week reversions on their own scale, else they vanish next to the cumulative
disc = fwk.copy(); disc[52:] = 0.0                              # 2006: the war is below-cost DISCOUNTING (a cut that springs back next day), Fact 1
lift = fwk.copy(); lift[:52] = 0.0                              # 2007 pre-ban: clean failed coordination LIFTS (a raise the rivals undercut)
ax2b.bar(wk, disc, width=0.95, color="#5b8aa6", edgecolor="#3f6a82", lw=0.3, label="2006 below-cost discounts / wk")
ax2b.bar(wk, lift, width=0.95, color="#e0846a", edgecolor="#c0623a", lw=0.3, label="2007 failed lifts / wk")
ax2b.set_ylim(0, max(fwk) * 1.35); ax2b.set_ylabel("pre-ban reversions / wk", fontsize=7.6, color="0.35")
ax2b.tick_params(axis="y", labelcolor="0.35", labelsize=6.5)
ax2.plot(wk, np.cumsum(fwk), color="#7a160c", lw=2.0, zorder=5, label="cumulative (left)")
ax2.set_zorder(ax2b.get_zorder() + 1); ax2.patch.set_visible(False)   # keep the cumulative line in front of the bars
for x in (AUG, BAN, OFICIO): ax2.axvline(x, color="0.5", ls="--", lw=0.8)
ax2.set_ylabel("cumulative pre-ban reversions"); ax2.set_xlabel("")
ax2.set_xticks([0, 26, 52, 78, 104, 130, 156])
ax2.set_xticklabels(["Jan 06", "Jul 06", "Jan 07", "Jul 07", "Jan 08", "Jul 08", "Jan 09"])
ax1.set_xlim(0, 156)                                          # flush left/right, no side padding (sharex propagates to ax2)
ax2.set_title("(B) The war is self-enforcing: 2006 below-cost discounting, then 2007 failed lifts; no raise is matched", fontsize=8.4, loc="left")
h1, l1 = ax2.get_legend_handles_labels(); h2, l2 = ax2b.get_legend_handles_labels()
ax2.legend(h1 + h2, l1 + l2, fontsize=6.4, loc="upper left", framealpha=0.9)
fig.tight_layout()
fig.savefig(os.path.join(ROOT, "paper", "manuscript", "fig_full_path.pdf"), bbox_inches="tight")
print("\nwrote paper/manuscript/fig_full_path.pdf")
