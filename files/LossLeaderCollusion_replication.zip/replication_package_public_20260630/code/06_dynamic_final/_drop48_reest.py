import os,json,importlib.util,numpy as np,time
from scipy.optimize import minimize
ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
os.environ['IJ']='1';os.environ['PERP_TERMINAL']='1';os.environ['DROP_DRUGS']=ROOT+"/output/weak_collapse_drugs.txt"
spec=importlib.util.spec_from_file_location("fs",ROOT+"/code/06_dynamic_final/full_structural_mpe.py");fs=importlib.util.module_from_spec(spec);spec.loader.exec_module(fs)
fs.PSI_LEAD=[0.60,0.80,0.00];fs.CHAIN_SHARE=np.array([0.453,0.309,0.239]);fs.TAU_LEAD=3.0;fs.TAU_RENT=0.12;fs.SCRUT_LEARN=1
RHO_FIX=2.0;W=26.0
BND=dict(mu_bar=(6,14),lam=(0.05,0.95),tau_eng=(30,400),t0=(98,106),a0=(0.3,8),b0=(5,150),zeta=(40,3000),chi=(1,4),g=(0,1.5),lam_cut=(0,0.30),scrut_m=(5,60))
K=list(BND);bounds=[BND[k] for k in K]
def clip(x):return [min(max(float(x[i]),bounds[i][0]),bounds[i][1]) for i in range(len(K))]
def unpack(x):
    mb=float(x[0]);lam,te,t0,a0,b0,ze,chi,g=[float(v) for v in x[1:9]];lc,sm=float(x[9]),float(x[10])
    return [mb,lam,te,t0,a0,b0,ze,chi,RHO_FIX,g,lc],np.array([mb]*3),W,sm
def obj(x,B=14,no=3):
    th,mu,w,sm=unpack(clip(x));fs.SCRUT_M=sm
    o=fs.simulate_mpe(th,mu,B=B,n_outer=no,final_sim=False,psi=[0,0,0],onetime=True,w_window=w,arrivals_throughout=True)
    return fs.loss(o)
d=json.load(open(ROOT+"/output/hetmu_mpe.json"));th=d["theta"]
xh=[d["kappa_mean"],th["lam"],th["tau_eng"],th["t0"],th["a0"],th["b0"],th["zeta"],th["chi"],th["g"],d["lam_cut"],d["scrut_m"]]
t0=time.time();print("headline-theta loss on 172:",round(obj(xh,B=20,no=4),2),flush=True)
res=minimize(lambda x:obj(x,B=14,no=3),np.array(xh,float),method="Powell",bounds=bounds,options=dict(maxiter=25,xtol=3e-3,ftol=3e-3))
xc=clip(res.x)
th2,mu2,w2,sm2=unpack(xc);fs.SCRUT_M=sm2
M=fs.simulate_mpe(th2,mu2,B=200,n_outer=6,psi=[0,0,0],onetime=True,w_window=w2,arrivals_throughout=True);e=fs.EMP
print("[%.0fs] RE-ESTIMATED on 172: loss %.2f  mu_bar %.2f  lam_cut %.3f  scrut_m %.1f"%(time.time()-t0,fs.loss(M),xc[0],xc[9],xc[10]),flush=True)
print("  tot01 %.0f/%d  succ_cart %.0f/%d  tot12 %.0f/%d  war_mk %.2f/%.2f"%(M["tot01"],e["tot01"],M["succ_cart"],e["succ_cart"],M["tot12"],e["tot12"],M["war_mk"],e["war_mk"]))
print("  SB cart %.0f%%/%.0f%%  CV rent %.0f%%/%.0f%%"%(100*M["leadS_cart"][2],100*e["lead_sb_cart"],100*M["leadS_pl"][0],100*e["lead_cv_pl"]))
json.dump(dict(loss=float(fs.loss(M)),mu_bar=float(xc[0]),lam_cut=float(xc[9]),scrut_m=float(xc[10]),
  leadS_cart=list(M["leadS_cart"]),leadS_pl=list(M["leadS_pl"]),n_drugs=int(fs.J),
  moments={k:float(M[k]) for k in M if not isinstance(M[k],list)},empirical=e),open(ROOT+"/output/hetmu_mpe_drop48.json","w"),indent=2)
print("wrote hetmu_mpe_drop48.json (J=%d)"%fs.J,flush=True)
