"""rc_own_mpe.py -- RC-own robustness: FREE psi_SB (Salcobrand's outside option / war exposure, fixed at 0 in
the headline) and re-estimate, warm-started from the headline.  Tests whether psi_SB=0 -- the calibration
that makes SB lead the cartel escape, the structural counterpart of the Aug-2007 Southern Cross (PE)
acquisition's incentive to end the below-cost war -- is supported by the data rather than assumed.
Writes output/hetmu_mpe_rcown.json.

Run:  IJ=1 PERP_TERMINAL=1 python3 rc_own_mpe.py
"""
import os, json, importlib.util
import numpy as np
from scipy.optimize import minimize
os.environ.setdefault("IJ", "1"); os.environ.setdefault("PERP_TERMINAL", "1")
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
spec = importlib.util.spec_from_file_location("fs", os.path.join(ROOT, "code", "06_dynamic_final", "full_structural_mpe.py"))
fs = importlib.util.module_from_spec(spec); spec.loader.exec_module(fs)
fs.CHAIN_SHARE = np.array([0.453, 0.309, 0.239]); fs.TAU_LEAD = 3.0; fs.TAU_RENT = 0.12; fs.SCRUT_LEARN = 1
RHO_FIX = 2.0
BND = dict(mu_bar=(6.0, 14.0), lam=(0.05, 0.95), tau_eng=(30.0, 400.0), t0=(98, 106), a0=(0.3, 8.0),
           b0=(5.0, 150.0), zeta=(40.0, 3000.0), chi=(1.0, 4.0), g=(0.0, 1.5), lam_cut=(0.0, 0.30),
           scrut_m=(5.0, 60.0), psi_sb=(0.0, 0.60))
K = list(BND); bounds = [BND[k] for k in K]
REST = ["lam", "tau_eng", "t0", "a0", "b0", "zeta", "chi", "g"]
H = json.load(open(os.path.join(ROOT, "output", "hetmu_mpe.json")))
WARM = [float(H["mu_bar"])] + [float(H["theta"][k]) for k in REST] + [float(H["theta"]["lam_cut"]), float(H["scrut_m"]), 0.0]

def clip(x): return [min(max(float(x[i]), bounds[i][0]), bounds[i][1]) for i in range(len(K))]
def unpack(x):
    xc = clip(x)
    theta = [xc[0], xc[1], xc[2], xc[3], xc[4], xc[5], xc[6], xc[7], RHO_FIX, xc[8], xc[9]]
    return theta, np.array([xc[0]] * 3), xc[10], xc[11], xc
_DV = {"v": None}
def obj(x, B=16, n_outer=3, warm=False):
    theta, mu, sm, psi_sb, _ = unpack(x); fs.SCRUT_M = sm
    fs.PSI_LEAD = [0.60, 0.80, float(psi_sb)]                          # free SB outside option
    o, dv = fs.simulate_mpe(theta, mu, B=B, n_outer=n_outer, final_sim=False, psi=[0.0, 0.0, 0.0],
                            onetime=True, w_window=26.0, arrivals_throughout=True,
                            dv_init=(_DV["v"] if warm else None), return_dv=True)
    if warm: _DV["v"] = dv
    return fs.loss(o)
best = (obj(WARM, B=20, n_outer=4), clip(WARM)); _DV["v"] = None
res = minimize(lambda x: obj(x, B=16, n_outer=3, warm=True), np.array(WARM, float), method="Powell",
               bounds=bounds, options=dict(maxiter=70, xtol=3e-3, ftol=3e-3))
f = obj(res.x, B=20, n_outer=4)
if f < best[0]: best = (f, clip(res.x))
theta, mu, sm, psi_sb, xc = unpack(best[1]); fs.SCRUT_M = sm; fs.PSI_LEAD = [0.60, 0.80, float(psi_sb)]
M = fs.simulate_mpe(theta, mu, B=240, n_outer=6, psi=[0.0, 0.0, 0.0], onetime=True, w_window=26.0, arrivals_throughout=True)
_to = dict(zip(REST, [float(v) for v in xc[1:9]])); _to["rho"] = RHO_FIX; _to["lam_cut"] = float(xc[9])
out = dict(mu_bar=float(xc[0]), theta=_to, scrut_m=float(xc[10]), psi_sb=float(psi_sb), loss=float(fs.loss(M)),
           moments={k: float(M[k]) for k in M if not isinstance(M[k], (list, np.ndarray))}, empirical=H["empirical"])
json.dump(out, open(os.path.join(ROOT, "output", "hetmu_mpe_rcown.json"), "w"), indent=2)
print(f"WROTE rcown  psi_SB {psi_sb:.3f}  loss {out['loss']:.2f}  mu_bar {xc[0]:.2f}  tot01 {M['tot01']:.0f}  tot12 {M['tot12']:.0f}  SBcart {M['lead_sb_cart']:.2f}  CVpl {M['lead_cv_pl']:.2f}")
