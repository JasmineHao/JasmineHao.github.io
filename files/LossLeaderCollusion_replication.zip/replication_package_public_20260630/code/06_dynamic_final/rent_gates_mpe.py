"""rent_gates_mpe.py -- the appendix table tab:rent_gates under the psi-leadership + learned-belief HEADLINE.
RE-ESTIMATES the model with each gate of the rent push set to 1 (a fair horse race: every restricted spec
gets its own best-fit params, like the main-text knockouts), one gate per invocation (the gate flags are
read at model import, so the caller sets the env): RENT_NOBELIEF=1 -> the discounted-belief gate
b_rent=e^{-chi}b_coord; RENT_NOHOLD=1 -> the static-best-response gate logit(-G12/tau).  Warm-start Powell
from the headline (knockouts are perturbations of it).

Run:  IJ=1 PERP_TERMINAL=1 [RENT_NOBELIEF=1] [RENT_NOHOLD=1] python3 rent_gates_mpe.py
"""
import os, json, importlib.util
import numpy as np
from scipy.optimize import minimize
os.environ.setdefault("IJ", "1"); os.environ.setdefault("PERP_TERMINAL", "1")
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
spec = importlib.util.spec_from_file_location("fs", os.path.join(ROOT, "code", "06_dynamic_final", "full_structural_mpe.py"))
fs = importlib.util.module_from_spec(spec); spec.loader.exec_module(fs)
fs.PSI_LEAD = [0.60, 0.80, 0.00]; fs.CHAIN_SHARE = np.array([0.453, 0.309, 0.239])
fs.TAU_LEAD = 3.0; fs.TAU_RENT = 0.12; fs.SCRUT_LEARN = 1
RHO_FIX = 2.0
BND = dict(mu_bar=(6.0, 14.0), lam=(0.05, 0.95), tau_eng=(30.0, 400.0), t0=(98, 106), a0=(0.3, 8.0),
           b0=(5.0, 150.0), zeta=(40.0, 3000.0), chi=(1.0, 4.0), g=(0.0, 1.5), lam_cut=(0.0, 0.30), scrut_m=(5.0, 60.0))
K = list(BND); bounds = [BND[k] for k in K]
REST = ["lam", "tau_eng", "t0", "a0", "b0", "zeta", "chi", "g"]
H = json.load(open(os.path.join(ROOT, "output", "hetmu_mpe.json")))
WARM = [float(H["mu_bar"])] + [float(H["theta"][k]) for k in REST] + [float(H["theta"]["lam_cut"]), float(H["scrut_m"])]

def clip(x): return [min(max(float(x[i]), bounds[i][0]), bounds[i][1]) for i in range(len(K))]
def unpack(x):
    xc = clip(x)
    theta = [xc[0], xc[1], xc[2], xc[3], xc[4], xc[5], xc[6], xc[7], RHO_FIX, xc[8], xc[9]]
    return theta, np.array([xc[0]] * 3), xc[10]
_DV = {"v": None}
def obj(x, B=16, n_outer=3, warm=False):
    theta, mu, sm = unpack(x); fs.SCRUT_M = sm
    o, dv = fs.simulate_mpe(theta, mu, B=B, n_outer=n_outer, final_sim=False, psi=[0.0, 0.0, 0.0],
                            onetime=True, w_window=26.0, arrivals_throughout=True,
                            dv_init=(_DV["v"] if warm else None), return_dv=True)
    if warm: _DV["v"] = dv
    return fs.loss(o)
best = (obj(WARM, B=16, n_outer=3), clip(WARM)); _DV["v"] = None
res = minimize(lambda x: obj(x, B=16, n_outer=3, warm=True), np.array(WARM, float), method="Powell",
               bounds=bounds, options=dict(maxiter=45, xtol=4e-3, ftol=4e-3))
f = obj(res.x, B=20, n_outer=4)
if f < best[0]: best = (f, clip(res.x))
theta, mu, sm = unpack(best[1]); fs.SCRUT_M = sm
M = fs.simulate_mpe(theta, mu, B=240, n_outer=6, psi=[0.0, 0.0, 0.0], onetime=True, w_window=26.0, arrivals_throughout=True)
L = float(fs.loss(M))
tag = "both" if (os.environ.get("RENT_NOBELIEF") and os.environ.get("RENT_NOHOLD")) else \
      "nobelief" if os.environ.get("RENT_NOBELIEF") else "nohold" if os.environ.get("RENT_NOHOLD") else "headline"
row = dict(tag=tag, loss=round(L, 1), tot12=round(float(M["tot12"]), 0),
           peak2=round(float(M.get("peak2", float("nan"))), 0),
           lead_sb_cart=round(float(M["lead_sb_cart"]), 2), lead_cv_pl=round(float(M["lead_cv_pl"]), 2))
json.dump(row, open(os.path.join(ROOT, "output", f"rentgate_{tag}.json"), "w"))
print("RENTGATE_ROW " + json.dumps(row))
