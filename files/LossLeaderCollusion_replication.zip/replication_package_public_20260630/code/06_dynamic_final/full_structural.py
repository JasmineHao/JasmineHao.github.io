"""full_structural.py  --  LEGACY SHARED PRIMITIVE (NOT the headline; the headline is full_structural_mpe.py).
Retained only for sequence_predictors.py (tab:sequence_reg) and appendix_experimentation_horizon.py.
Original header below.

full_structural.py  --  DYNAMIC STRUCTURAL MODEL (v3, the spec in SIMULATION.md)
================================================================================
** HEADLINE (the paper's reported spec) = estimate_hetmu_headline.py, NOT this module's __main__. **
The reported headline calls simulate(psi=[0,0,0], kappa_chain=mu, onetime=True,
arrivals_throughout=True) with 13 params (3 chain-specific mu_i + 9 baseline + w) ->
output/hetmu_headline.json (SMM loss 22.8).  There the up-move CCP is the b^2 forward-looking IC
    p_up = pi_ij * b_t^2 * logit((b*delta*dV1 - G01)/tau)
and store traffic is chain-specific mu_i (not a common kappa, and not the b*logit(-G^harv)
static gate sketched below).  The v3 text below documents the simulate() internals; the old
9-param psi __main__ that writes full_structural.json is superseded.
================================================================================
Every drug carries its OWN tier prices, cost, demand coefficient (alpha_j) and
per-type nesting (sigma_g), lab and lab size; the ad ban enters only through alpha.

v3 mechanism (one model, war merged):
  * Per-week payoff   Pi^x_j = N_j * s^x_j * (p^x_j - c_j + kappa)   (daily->weekly).
  * Value functions   V^x_j(t) = Pi^x_j + delta V^x_j(t+1)  (backward induction, delta fixed).
  * Up-move CCP (the lift), STATIC harvest gate weighted by the belief:
        p_up = pi_ij(t) * b_t * logit(-G^harv_j/tau)
    G^harv = kappa*ds_h+mg_h is the STATIC match-vs-harvest incentive (G^harv<0 in BOTH regimes ->
    followers statically match).  b_t = the belief coordination HOLDS = the probability the future
    value delta*Delta V1 is realized -- so the value function IS in the follower's decision, but
    weighted by b_t (the operative comparison is the static gain vs b_t*delta*Delta V1).  The
    forward-looking net gain NG^harv = G^harv - delta*Delta V1 (and NG01 = G01 - delta*Delta V1) is
    the FULL-belief (b=1) object used only for the IC-slack / static-Nash-selection argument
    (delta*Delta V1 >> G, so coordination is sustainable WHEN realized); it does NOT gate the CCP
    (using it would swamp G and erase the war).  G01 = kappa*ds01+mg01 is the undercut margin that
    FLIPS at the ban (>0 war -> <0 cartel); the war's reverts are G01>0 undercuts of matched lifts.
  * Learning = FOLLOWER belief b_t = (a0+S)/(a0+b0+S+F); success iff followed, else failed attempt.
  * Rent 1->2: only drugs with Delta V2>0 (endogenous selectivity in own alpha_j) + own belief b2.
  * War merged: pre-ban G01>0 so lifts are harvested (fail); below-cost cheating intensifies with the
    Aug-2007 campaign (ratio 1+g).  Once the ban flips G01<0 the wave succeeds.
  * Leadership = OUTCOME of a chain-specific OUTSIDE OPTION psi_i (NOT estimated; read from each
    chain's documented reliance on Chilean retail).  psi insulates a fraction of the war loss:
        V0_ij = Pi0_j + psi_i*max(0,-Pi0_j) + delta V0_ij(t+1);  Delta V1_ij = V1_j - V0_ij
        leader ~ softmax_i( Delta V1_ij / tau )
    psi_SB=0 (purely domestic) -> bears the full war -> biggest escape value -> leads most.
    The leadership split is an OVER-IDENTIFYING VALIDATION, not a fitted moment.

Estimated theta = (kappa, lambda, beta, t0, a0, b0, a0_2, b0_2, g)   -- 9 params.
Fixed: delta=0.95, tau, hol; psi from reliance.
Output: output/full_structural.json (+ console).
"""
import os, json
from math import exp as _mexp
import numpy as np
import pandas as pd
from scipy.optimize import brentq, minimize_scalar, minimize
from scipy.stats import spearmanr

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
try:
    _H = json.load(open(os.path.join(ROOT, "output", "demand_params.json")))["headline"]
    SIG, OM, RHO = _H["sigma"], _H["OM"], _H["rho_mktshare"]
    A0, A_RATIO = _H["alpha0"], _H["A_RATIO"]
except Exception:
    SIG, OM, RHO = 0.393, 0.607, 0.92
    A0, A_RATIO = 0.103, 0.019 / 0.103
A_RATIO = float(os.environ.get("A_RATIO_OVERRIDE", A_RATIO))   # RJ4 demand-misspecification robustness: override the alpha-collapse (post-alpha = A0*A_RATIO)

# ---- window: Jan-2007 (war decline onset) -> mid-2008, weekly; ban Nov-2007 ----
WK0 = 52                                  # 2007-01 (war decline onset)
WK1 = 157                                 # extended to Dec-2008 so the sim reaches the post-Oficio cartel erosion
WKS = list(range(WK0, WK1))
BAN = 96                                  # 2007-11 advertising ban (alpha drops)
AUG = 84                                  # 2007-08 Cruz Verde "Desafio" campaign (war intensifies)
OFICIO = 117                              # 2008-03-31 FNE investigation notice (Oficio 419): enforcement belief-shock
_FOF = float(os.environ.get("OFICIO_BJUMP", "0"))   # EXPERIMENT: Oficio NEGATIVE belief shock magnitude (pseudo-failures); >0 replaces the linear rsc fade
_TAUOF = float(os.environ.get("OFICIO_TAU", "20"))   # EXPERIMENT: weeks over which the Oficio shock FADES (transient) -> belief re-builds -> late surge
_FRZ_S = float(os.environ.get("FREEZE_START", "9"))  # EXPERIMENT: rent-push PAUSE start (weeks after OFICIO)
_FRZ_K = float(os.environ.get("FREEZE_DUR", "9"))    # EXPERIMENT: PAUSE duration (weeks); >0 = leaders WAIT (rent holds, belief undamaged), then resume -> surge
_RENT_NB = float(os.environ.get("RENT_NOBELIEF", "0"))  # EXPERIMENT: drop the rent BELIEF gate (b_rent->1) -> test whether the rent-lag survives on rsc+timing alone
_RENT_NH = float(os.environ.get("RENT_NOHOLD", "0"))    # EXPERIMENT: drop the rent static-BR gate (hold12->1) -> test whether the rent needs the per-drug G12 match
HOL_WEEKS = set(range(108, 113))          # Feb-2008 summer holiday (engagement stalls)
REG = ["pre" if t < BAN else "post" for t in WKS]

# ---- OUTSIDE OPTION psi_i = 1 - (Chilean-retail share of firm value), from filings ----
# Chilean-retail exposure (Humphreys Oct-2007 etc.): SB pure-domestic=1.00; FASA ~0.24 (most EBITDA
# in Mexico/Peru); Cruz Verde ~0.10 (value mostly Socofar wholesale).  psi = outside option = 1-exposure.
# NOT estimated -> leadership is PREDICTED; the 76/19/5 split is an over-identifying validation.
PSI = np.array([0.90, 0.76, 0.00])        # CV / FA / SB   (SB fully exposed, leads most)
DELTA = 0.95                              # weekly discount (fixed)
TAU = 0.13                                # Type-I EV choice scale for the lift/defect CCPs (fixed)
TAU_LEAD = 3.0                            # leadership choice scale (fixed; full-horizon escape gaps are large)
# ---- INDEPENDENT leadership (each chain decides to lead on its own; >=1 leader, 2-3 simultaneous possible) ----
# Each chain i independently leads drug j in week t with prob logistic(DV1_ij/TAU_LEAD + LEAD_C0).  LEAD_C0
# offsets the average number of leaders per event (a co-leader event has 2-3 chains raising in the same week).
# When k chains lead, the 3-k followers must each match: the belief gate is b^(3-k) (k=3 -> immediate, no gate).
LEAD_INDEP = True
LEAD_C0 = -5.0                            # offset so the mean #leaders per event ~ the data's same-first-day co-leader rate (1.33)
RHO_DEF = 0.04                            # base reversion hazard, scaled by (1-belief): the cartel-erosion rate


def shares(p, phi, a, om=OM):
    p = np.asarray(p, float); e = np.exp((phi - a * p) / om); D = e.sum()
    return (e / D) * (D ** om / (1 + D ** om))


def nest(phi, a, p, om=OM):
    Dg = 3 * np.exp((phi - a * p) / om); return Dg ** om / (1 + Dg ** om)


def calib_phi(a, pbar, om=OM):
    return brentq(lambda ph: nest(ph, a, pbar, om) - RHO, -120, 120)


def dsm(pdev, pcoord, c, a, om=OM):
    """UNDERCUT: Delta s & within-drug margin of cutting pcoord->pdev (others hold)."""
    phi = calib_phi(a, pcoord, om)
    sd = shares([pdev, pcoord, pcoord], phi, a, om)[0]
    sc = shares([pcoord, pcoord, pcoord], phi, a, om)[0]
    return sd - sc, sd * (pdev - c) - sc * (pcoord - c)


def dsm_harv(pw, pcoord, c, a, om=OM):
    """HARVEST: gain to staying low (harvest) vs following a lift.  i at pw, leader at pcoord,
    other at pw; vs all-follow at pcoord.  G^harv = kappa*ds_h + mg_h.  NOTE: at the estimate
    G^harv<0 in BOTH regimes (the harvester sits below cost, so the margin penalty mg_h~-0.84
    outweighs the traffic gain kappa*ds_h~+0.59) -> followers statically MATCH; the war is carried
    by the UNDERCUT margin G01>0 (undercutting a fully-coordinated price steals more share), not by
    harvesting a single lift."""
    phi = calib_phi(a, pcoord, om)
    sh = shares([pw, pcoord, pw], phi, a, om)[0]          # i harvests (low) while leader high
    sf = shares([pcoord, pcoord, pcoord], phi, a, om)[0]  # i follows (all coordinated)
    return sh - sf, sh * (pw - c) - sf * (pcoord - c)


# ---- (i,j) PRODUCT-FIRM demand =================================================
#  Each chain i has its own mean-utility intercept phi_i (chain quality), recovered from the
#  observed within-nest shares; the IV alpha_j gives the price response.  VALIDATED out-of-sample:
#  coord-recovered phi predicts war within-shares to median 2.7pp.  Market size N_j is anchored on a
#  NORMAL-period median (NOT the war-peak max, which is the stocking-up spike -> 33% over-fit).
FIRMS = ["CV", "FA", "SB"]
_TGT_DG = (RHO / (1.0 - RHO)) ** (1.0 / OM)            # Dg s.t. inside-nest share = RHO


def phi_ij(sw, p1, a, om=OM):
    """Per-chain quality intercepts from observed within-shares sw.  The chains coordinate to a common
    coord price, so the within-share is softmax(phi/om) and the relative phi = om*log(sw); the level is
    shifted (analytic) so the inside-nest share = RHO at the common coord price p1.  Equal sw -> equal phi
    -> dsm_ij/shares reduce EXACTLY to the symmetric dsm/shares."""
    sw = np.clip(np.asarray(sw, float), 1e-4, None); sw = sw / sw.sum()
    phi = om * np.log(sw); phi -= phi.mean()
    return phi + om * np.log(_TGT_DG / np.exp((phi - a * p1) / om).sum())


def dsm_ij(i, phi, pco, pdev_i, c, a, om=OM):
    """Chain i unilaterally cuts pco[i] -> pdev_i (others hold at pco): its (Delta share, Delta margin).
    Symmetric-limit (equal phi) reproduces dsm() exactly."""
    pco = np.asarray(pco, float); pdev = pco.copy(); pdev[i] = pdev_i
    sc = shares(pco, phi, a, om)[i]; sd = shares(pdev, phi, a, om)[i]
    return sd - sc, sd * (pdev_i - c) - sc * (pco[i] - c)


# ============ DATA: per-drug panel ============================================
HOMOG = os.environ.get("HOMOG") == "1"     # robustness: every drug shares the MEDIAN alpha (homogeneous demand)


def build_panel():
    df = pd.read_csv(os.path.join(ROOT, "data", "processed", "demand_data_core.csv"))
    df["rev"] = df.Price * df.Quantity
    lab_of = df.groupby("DrugID")["Lab"].agg(lambda x: x.value_counts().index[0])
    lab_rev = df.groupby("Lab")["rev"].sum()
    e = pd.read_csv(os.path.join(ROOT, "output", "v16_events_unified.csv"), parse_dates=["date"])
    e["wk"] = ((e.date - pd.Timestamp("2006-01-01")).dt.days // 7).astype(int)
    e["c_imp"] = e.price / e.markup_c
    co = e[e.kind == "coordination"]
    war = e[e.kind == "deviation_war"].groupby("DrugID").price.median()
    t1 = co[co.to_tier == 1].groupby("DrugID").price.median()
    t2 = co[co.to_tier == 2].groupby("DrugID").price.median()
    cost = e.groupby("DrugID").c_imp.median()
    cwk = co[(co.in_window) & (co.to_tier == 1)].groupby("DrugID").wk.min()
    reached2 = co[(co.in_window) & (co.to_tier == 2)].groupby("DrugID").size()
    _csv = "r2_demand_alpha_per_drug_ols.csv" if os.environ.get("DEMAND_SPEC") == "hetOLS" else \
           "r2_demand_alpha_per_drug.csv"     # DEMAND_SPEC=hetOLS -> per-drug OLS alpha; default = rival-IV (hetIV)
    _dem = pd.read_csv(os.path.join(ROOT, "output", _csv)).set_index("DrugID")
    alpha = _dem.alpha; amed = float(alpha.median())
    if HOMOG:                              # homogeneous-demand robustness: replace per-drug alpha_j with the median
        alpha = pd.Series(amed, index=alpha.index)
    sigma_g = _dem.sigma_g if "sigma_g" in _dem.columns else None
    rows = []
    for j in sorted(set(e.DrugID)):
        pw, pc1, pc2, c = war.get(j, np.nan), t1.get(j, np.nan), t2.get(j, np.nan), cost.get(j, np.nan)
        if not (np.isfinite(pw) and np.isfinite(pc1) and np.isfinite(c)):
            continue
        pc2 = pc2 if np.isfinite(pc2) else pc1 * 1.12
        a_j = float(alpha.get(j, amed)); a_j = a_j if a_j > 1e-3 else amed
        sg_j = float(sigma_g.get(j, SIG)) if sigma_g is not None else SIG
        sg_j = sg_j if (0 < sg_j < 1) else SIG
        rows.append(dict(DrugID=j, lab=lab_of.get(j, "NA"),
                         pw=pw/1000, p1=pc1/1000, p2=pc2/1000, c=c/1000, alpha=a_j, sigma_g=sg_j,
                         coord_wk=cwk.get(j, np.nan), reached2=int(j in reached2.index)))
    D = pd.DataFrame(rows)
    # ---- RECOVERY: 4 hand-coded coord_success drugs (169/182/206/210) that v16 lacks a clean
    #      (war, Tier-1, cost) triple for, so the filter above drops them.  They are validated three-chain
    #      coordinations in the hand-coded ledger (enriched_event_panel coord_success) and are NOT defectors
    #      -- 202 is a defection_postcoord and 215 has no coordination, both correctly left dropped.  Imputed
    #      legs (output/recovered_drugs.csv, in CLP'000s to match this panel): war price = 0.82 x the drug's
    #      demand war-window (wk52--95) median (0.82 = the panel's v16-war/demand-window ratio); for 182, which
    #      has no v16 event, Tier-1 = its coordinated-period (wk>=118) demand median and cost = the panel-median
    #      c/p1 x Tier-1.  Brings the structural sample to the descriptive count of 220 coordinated drugs.
    _rec = pd.read_csv(os.path.join(ROOT, "output", "recovered_drugs.csv"))
    _rec = _rec[~_rec.DrugID.isin(D.DrugID)][list(D.columns)]
    D = pd.concat([D, _rec], ignore_index=True)
    D["W"] = D.lab.map(lab_rev)
    for reg, a_of in [("pre", lambda a: a), ("post", lambda a: a * A_RATIO)]:
        ds01 = np.zeros(len(D)); mg01 = np.zeros(len(D)); dsh = np.zeros(len(D)); mgh = np.zeros(len(D))
        ds12 = np.zeros(len(D)); mg12 = np.zeros(len(D))
        s0 = np.zeros(len(D)); s1 = np.zeros(len(D)); s2 = np.zeros(len(D))
        for i, r in enumerate(D.itertuples()):
            a = a_of(r.alpha); om = 1 - r.sigma_g
            ds01[i], mg01[i] = dsm(r.pw, r.p1, r.c, a, om)          # undercut 0<-1
            dsh[i],  mgh[i]  = dsm_harv(r.pw, r.p1, r.c, a, om)     # harvest vs follow the 0->1 lift
            ds12[i], mg12[i] = dsm(r.p1, r.p2, r.c, a, om)          # undercut 1<-2
            phi = calib_phi(a, r.p1, om)
            s0[i] = shares([r.pw, r.pw, r.pw], phi, a, om)[0]
            s1[i] = shares([r.p1, r.p1, r.p1], phi, a, om)[0]
            s2[i] = shares([r.p2, r.p2, r.p2], phi, a, om)[0]
        D[f"ds01_{reg}"], D[f"mg01_{reg}"] = ds01, mg01
        D[f"dsh_{reg}"],  D[f"mgh_{reg}"]  = dsh, mgh
        D[f"ds12_{reg}"], D[f"mg12_{reg}"] = ds12, mg12
        D[f"s0_{reg}"], D[f"s1_{reg}"], D[f"s2_{reg}"] = s0, s1, s2

    # ============ (i,j) product-firm layer: per-chain QUALITY (phi from within-shares) ============
    #  Chains coordinate to the COMMON structural tier price (r.pw / r.p1 / r.p2); the only cross-chain
    #  asymmetry is the quality phi, recovered from the observed coord within-shares.  Market size N_j on a
    #  NORMAL-period median (NOT the war-peak max = the stocking-up spike).  Equal within-shares -> the
    #  per-chain ds01_3/s_3 reduce EXACTLY to the symmetric ds01/s columns above.
    def _m(col, lo, hi):
        s = df[(df.TimeID >= lo) & (df.TimeID < hi)]
        return s.groupby(["DrugID", "Firm"])[col].median()
    SW1 = _m("ShareWithinGroup", 105, 118)
    _qt = df.groupby(["DrugID", "TimeID"]).Quantity.sum()
    _norm = _qt[(_qt.index.get_level_values(1) >= 52) & (_qt.index.get_level_values(1) < 78)].groupby(level=0).median()
    _crd = _qt[(_qt.index.get_level_values(1) >= 105) & (_qt.index.get_level_values(1) < 118)].groupby(level=0).median()
    def _nj(j):
        for v in (_norm.get(j, np.nan), _crd.get(j, np.nan)):
            if np.isfinite(v): return float(v) / RHO
        return np.nan
    SWv = []; NJ = []
    for r in D.itertuples():
        sw = np.array([SW1.get((r.DrugID, f), np.nan) for f in FIRMS])
        if (not np.all(np.isfinite(sw))) or sw.sum() <= 0:      # symmetric fallback (recovered drugs w/o demand data)
            sw = np.full(3, 1 / 3.0)
        SWv.append(sw / sw.sum()); NJ.append(_nj(r.DrugID))
    D["sw3"] = SWv; D["Nj"] = NJ
    for reg, a_of in [("pre", lambda a: a), ("post", lambda a: a * A_RATIO)]:
        D01 = []; M01 = []; D12 = []; M12 = []; SS0 = []; SS1 = []; SS2 = []
        for r in D.itertuples():
            a = a_of(r.alpha); phi = phi_ij(np.asarray(r.sw3), r.p1, a)
            pw3 = np.full(3, r.pw); p13 = np.full(3, r.p1); p23 = np.full(3, r.p2)
            SS0.append(shares(pw3, phi, a)); SS1.append(shares(p13, phi, a)); SS2.append(shares(p23, phi, a))
            d01 = np.zeros(3); m01 = np.zeros(3); d12 = np.zeros(3); m12 = np.zeros(3)
            for i in range(3):
                d01[i], m01[i] = dsm_ij(i, phi, p13, r.pw, r.c, a)   # undercut 0<-1: chain i cuts coord->war floor
                d12[i], m12[i] = dsm_ij(i, phi, p23, r.p1, r.c, a)   # undercut 1<-2: chain i cuts rent->coord
            D01.append(d01); M01.append(m01); D12.append(d12); M12.append(m12)
        D[f"ds01_3_{reg}"] = D01; D[f"mg01_3_{reg}"] = M01; D[f"ds12_3_{reg}"] = D12; D[f"mg12_3_{reg}"] = M12
        D[f"s0_3_{reg}"] = SS0; D[f"s1_3_{reg}"] = SS1; D[f"s2_3_{reg}"] = SS2
    return D


_spec_sfx = "_homog" if HOMOG else ("_hetOLS" if os.environ.get("DEMAND_SPEC") == "hetOLS" else "")
PANEL = os.path.join(ROOT, "output", "full_structural_panel_ij" + _spec_sfx + ".pkl")   # (i,j) cache: pickle (array cols)
if os.path.exists(PANEL) and os.environ.get("REBUILD") != "1" and \
   "s1_3_pre" in pd.read_pickle(PANEL).columns:
    D = pd.read_pickle(PANEL)
else:
    D = build_panel(); D.to_pickle(PANEL)
J = len(D)
print(f"panel: {J} drugs, {D.lab.nunique()} labs")

# ---- four regime sub-periods (week boundaries) over the Jan-2007 -> Dec-2008 sim window -------
#   war   wk52--99   (Jan2007--2Dec2007)   : undercutting pays (G01>0); lifts are undercut -> failed attempts
#   cart  wk100--116 (3Dec2007--30Mar2008) : the ban flips G01<0; lifts stick -> the wave, failures collapse
#   pe    wk117--138 (31Mar--Aug2008)      : FNE investigation; cartel HOLDS, rent opens, but broad re-coordination
#                                            attempts on rent-INELIGIBLE drugs revert -> failures rebound
#   pl    wk139--156 (Sep--Dec2008)        : the rent keeps deepening (CV-led); slow further successes
P_WAR, P_CART, P_PE, P_PL = (WK0, 100), (100, 117), (117, 139), (139, WK1)
PERIODS = [("war", P_WAR), ("cart", P_CART), ("pe", P_PE), ("pl", P_PL)]
def _period(t):
    for nm, (lo, hi) in PERIODS:
        if lo <= t < hi:
            return nm
    return None

# ---- empirical moments -------------------------------------------------------
DC = D.dropna(subset=["coord_wk"]).copy()
_ev = pd.read_csv(os.path.join(ROOT, "output", "v16_events_unified.csv"), parse_dates=["date"])
_ev["wk"] = ((_ev.date - pd.Timestamp("2006-01-01")).dt.days // 7).astype(int)
_co = _ev[_ev.kind == "coordination"]                  # SUCCESS = any coordination tier step (0->1 first, 1->2 rent)
_t1wk = _co[(_co.in_window) & (_co.to_tier == 1)].wk.median()
_t2wk = _co[(_co.in_window) & (_co.to_tier == 2)].wk.median()
_dw = _ev[_ev.kind == "deviation_war"]
_pre_pw = len(_dw[_dw.wk < AUG]) / max(1, _dw[_dw.wk < AUG].wk.nunique())
_late_pw = len(_dw[(_dw.wk >= AUG) & (_dw.wk < BAN)]) / max(1, (BAN - AUG))
# FAILURE and LEADERSHIP both come from the SAME canonical v16 ledger: failed_attempt is now the hand-coded
# clean set (the over-flagged detector rows were reclassified), and leadership is the initiating-chain column.
# One ledger, one source for every moment -- no second (enriched) panel is read.
_fa = _ev[_ev.kind == "failed_attempt"]
def _nc(x):
    s = str(x).upper(); return "CV" if ("CV" in s or "CRUZ" in s) else "FA" if "FA" in s else "SB" if "SB" in s else None
def _cnt(df, lohi): lo, hi = lohi; return int(((df.wk >= lo) & (df.wk < hi)).sum())
def _leaders_of(row):
    """The set of leader chains for a ledger event: the `leaders` column (pipe-separated co-leaders) if
    present, else the single `chain`.  Lets one event have 2-3 leaders."""
    lv = row.get("leaders") if hasattr(row, "get") else (row["leaders"] if "leaders" in row else None)
    if isinstance(lv, str) and lv.strip():
        return {_nc(x) for x in lv.split("|")} - {None}
    return {_nc(row["chain"])} - {None}
def _share(df, lohi, ch):
    # FIRST-MOVER leadership share: fraction of period events whose primary (earliest-crossing) leader is ch.
    # Co-leaders are reported separately via n_leaders; the leadership SHARE uses the single first mover
    # (the recorded `chain` = the documented "Salcobrand raised first" leader), so SB stays ~0.74, not 0.90.
    lo, hi = lohi; p = df[(df.wk >= lo) & (df.wk < hi)]
    return float((p.chain.map(_nc) == ch).mean()) if len(p) else 0.0
# NEW sequence moments: between-lab share of coord-week variance (ANOVA -- "labs explain the ordering",
# Fact 4) and the rank (Spearman) lab-size gradient (big labs go first, monotone not just linear).
_grand = DC.coord_wk.mean(); _g = DC.groupby("lab").coord_wk
_btw_lab = float((_g.count() * (_g.mean() - _grand) ** 2).sum() / max(1e-9, ((DC.coord_wk - _grand) ** 2).sum()))
_lab_w = np.log(DC.groupby("lab").W.first().astype(float))
_lab_t = DC.groupby("lab").coord_wk.median().astype(float)
_lab_idx = _lab_w.index.intersection(_lab_t.index)
_lab_w, _lab_t = _lab_w.loc[_lab_idx], _lab_t.loc[_lab_idx]
_lab_corr = float(np.corrcoef(_lab_w.values, _lab_t.values)[0, 1]) if len(_lab_idx) > 1 else 0.0
_spear_sz = float(spearmanr(_lab_w.values, _lab_t.values).correlation) if len(_lab_idx) > 1 else 0.0
_t2 = _co[_co.to_tier == 2].wk                 # ALL 1->2 rent-step weeks (matches tot12=143 and the model's cwk2; NOT the narrower in-window subset)
EMP = dict(
    tot01=len(DC),
    tot12=int((_co.to_tier == 2).sum()),                   # total rent steps (143); reported, not separately weighted
    onset=float(np.percentile(DC.coord_wk, 5)),
    peak=float(DC.coord_wk.round().median()),
    sd=float(DC.coord_wk.std()),
    corr_sz=_lab_corr,
    war_mk=float(((D.pw - D.c) / D.pw).median()),
    lab_sd=float(DC.groupby("lab").coord_wk.min().std()),
    tier_lag=float(_t2wk - _t1wk),
    war_ratio=float(_late_pw / max(0.1, _pre_pw)),
    # NEW time moments: 0->1 wave interquartile weeks (shape, beyond onset/peak/sd) + 1->2 rent-wave location/spread
    q25=float(np.percentile(DC.coord_wk, 25)), q75=float(np.percentile(DC.coord_wk, 75)),
    peak2=float(_t2.median()), sd2=float(_t2.std()),
    # NEW sequence moments
    btw_lab=_btw_lab, spear_sz=_spear_sz,
    # per-period SUCCESS (coordination) counts -- the rising post-cartel rent
    succ_war=_cnt(_co, P_WAR), succ_cart=_cnt(_co, P_CART), succ_pe=_cnt(_co, P_PE), succ_pl=_cnt(_co, P_PL),
    # per-period FAILURE (reverted lift) counts -- collapse in-cartel, rebound post-cartel
    fail_war=_cnt(_fa, P_WAR), fail_cart=_cnt(_fa, P_CART), fail_pe=_cnt(_fa, P_PE), fail_pl=_cnt(_fa, P_PL),
    # NEW symmetric down-move: per-period active war-deviation (deep-cut / defection) counts -- high in the war, ~0 in the cartel (endogenous stability)
    dev_war=_cnt(_dw, P_WAR), dev_cart=_cnt(_dw, P_CART), dev_pe=_cnt(_dw, P_PE), dev_pl=_cnt(_dw, P_PL),
    # leadership by period (from the v16 chain column): SB leads the wave, CV the late rent, SB fails most post-cartel
    lead_sb_cart=_share(_co, P_CART, "SB"), lead_cv_pl=_share(_co, P_PL, "CV"), lead_sb_fail_pe=_share(_fa, P_PE, "SB"),
    # SB-leadership share, success (_co) and failure (_fa), by war/cart/post (post=pe+pl): data targets for the outside-option validation
    ldS_war=_share(_co, P_WAR, "SB"), ldS_cart=_share(_co, P_CART, "SB"), ldS_post=_share(_co, (P_PE[0], P_PL[1]), "SB"),
    ldF_war=_share(_fa, P_WAR, "SB"), ldF_cart=_share(_fa, P_CART, "SB"), ldF_post=_share(_fa, (P_PE[0], P_PL[1]), "SB"),
    # average number of leaders per coordination event (co-leader rate; 1 = always solo, up to 3)
    n_leaders=float(np.mean([len(_leaders_of(r)) for _, r in _co.iterrows()])) if len(_co) else 1.0,
)
for _w in (104, 110, 116): EMP[f"w01_{_w}"] = int((DC.coord_wk <= _w).sum())   # NEW 0->1 wave-shape checkpoints
for _w in (126, 135, 148): EMP[f"w12_{_w}"] = int((_t2 <= _w).sum())              # NEW 1->2 rent-path checkpoints
print("empirical:", {k: round(v, 2) for k, v in EMP.items()})

# ---- lab + value-function structure -----------------------------------------
labs = D.lab.unique()
lab_drugs = {L: D.index[D.lab == L].to_numpy() for L in labs}
Wlab = D.groupby("lab").W.first()
Wn = (Wlab / Wlab.median()).to_dict()
logW_lab = {L: float(np.log(Wlab[L])) for L in labs}
_pw, _p1, _p2, _c = D.pw.to_numpy(), D.p1.to_numpy(), D.p2.to_numpy(), D.c.to_numpy()
_alpha = D.alpha.to_numpy()
S = {(tier, r): D[f"s{tier}_{r}"].to_numpy() for tier in (0, 1, 2) for r in ("pre", "post")}
DS = {k: D[f"{k}"].to_numpy() for k in ("ds01_pre", "ds01_post", "mg01_pre", "mg01_post",
       "dsh_pre", "dsh_post", "mgh_pre", "mgh_post", "ds12_pre", "ds12_post", "mg12_pre", "mg12_post")}
# ---- (i,j) product-firm layer: per-chain arrays [J,3] (CV,FA,SB).  When the three within-shares are
#      1/3 each, S3[:,i] == S and DS3 == DS, so the (i,j) game reduces EXACTLY to the symmetric one. ----
IJ = os.environ.get("IJ", "1") == "1"        # 1 -> (i,j) per-chain shares + all-chains-hold IC; 0 -> symmetric fallback (= full_structural.py)
S3 = {(tier, r): np.stack(D[f"s{tier}_3_{r}"].values) for tier in (0, 1, 2) for r in ("pre", "post")}
DS3 = {k: np.stack(D[f"{k}"].values) for k in ("ds01_3_pre", "ds01_3_post", "mg01_3_pre", "mg01_3_post",
        "ds12_3_pre", "ds12_3_post", "mg12_3_pre", "mg12_3_post")}
NJ3 = D.Nj.to_numpy()
Tn = len(WKS)


def value_funcs(kappa, psi=None, kappa_chain=None):
    """Backward induction for the leadership escape value.  Returns DV1ch (per chain, [Tn,J]):
    the value of escaping the war, where chain i's war value is insulated by its outside option
    psi_i from a fraction of the DRUG-MARGIN loss (pw-c<0) -- the below-cost loss the pharmacy P&L
    bears, NOT the footfall-inclusive flow (which the basket profit covers).  psi_SB=0 bears the
    full drug loss -> lowest war value -> biggest escape value -> leads (eq:mech_outside).
    ROBUSTNESS (kappa_chain = [mu_CV,mu_FA,mu_SB] given): the chain asymmetry instead comes from a
    chain-specific store-traffic value mu_i in the war flow, with psi OFF -- the editor's
    pharmacy-level spillover.  A higher mu_i makes the below-cost war less painful (more basket
    profit) -> higher war value -> smaller escape value -> leads less; the SMM tunes the 3 mu_i to
    the leadership shares, the moment they are then identified by (the circularity)."""
    pi0 = {r: S[(0, r)] * (_pw - _c + kappa) for r in ("pre", "post")}     # footfall-inclusive war flow
    pi1 = {r: S[(1, r)] * (_p1 - _c + kappa) for r in ("pre", "post")}
    dloss = {r: S[(0, r)] * np.maximum(0.0, _c - _pw) for r in ("pre", "post")}  # below-cost drug loss in the WAR (>=0)
    closs = {r: S[(1, r)] * np.maximum(0.0, _c - _p1) for r in ("pre", "post")}  # below-cost margin when COORDINATED (>=0): psi insulates it SYMMETRICALLY, so an insulated chain keeps its outside-option cushion when it coordinates a still-below-cost drug (it does not have to stay in the war to keep it)
    # TERMINAL CONDITION.  The correct continuation beyond the (stationary post-ban) window is the
    # perpetuity V_T = pi_T/(1-delta), NOT a one-period flow pi_T: the old truncation under-valued the
    # long-run cartel for late-window firms.  Switching it re-tunes the late-rent params (+22% loss at
    # the old optimum), so it is gated behind PERP_TERMINAL=1 pending a deliberate re-estimation; the
    # default reproduces the currently published flow-terminal estimates.  Core flip + SB leadership are
    # unaffected either way (escape gaps swamp TAU_LEAD; war/cart moments unchanged).
    _TERMFAC = (1.0 / (1.0 - DELTA)) if os.environ.get("PERP_TERMINAL") == "1" else 1.0
    V1 = np.zeros((Tn, J)); V1[-1] = pi1[REG[-1]] * _TERMFAC
    for t in range(Tn - 2, -1, -1):
        V1[t] = pi1[REG[t]] + DELTA * V1[t + 1]
    DV1ch = []
    if kappa_chain is not None:                                      # het-mu spec: LEADERSHIP escape value driven by the war-exposure mu_i (psi OFF).
        # NOTE: the leadership escape value uses the COMMON war share, NOT the (i,j) chain share.  The (i,j) market
        # share (CV>FA>SB) enters demand and the chain-specific IC (G01ch), but if it ALSO scaled the escape value
        # it would counterfactually make the largest chain (CV) lead; the data show the most war-EXPOSED chain (SB,
        # smallest store-traffic cushion mu) leads, so leadership is identified by mu on a common-share basis.
        for kap_i in np.asarray(kappa_chain, float):
            pi0i = {r: S[(0, r)] * (_pw - _c + kap_i) for r in ("pre", "post")}   # chain i's war flow with its own store-traffic mu_i
            V0i = np.zeros((Tn, J)); V0i[-1] = pi0i[REG[-1]] * _TERMFAC
            for t in range(Tn - 2, -1, -1):
                V0i[t] = pi0i[REG[t]] + DELTA * V0i[t + 1]
            DV1ch.append(V1 - V0i)
        return DV1ch
    for psi_i in (PSI if psi is None else np.asarray(psi, float)):   # chain i bears only (1-psi_i) of the below-cost margin in BOTH states; psi=[0,0,0] -> fully exposed -> uniform escape value
        pi1i = {r: pi1[r] + psi_i * closs[r] for r in ("pre", "post")}   # SYMMETRIC insulation: cushion the coordinated below-cost margin too
        pi0i = {r: pi0[r] + psi_i * dloss[r] for r in ("pre", "post")}
        V1i = np.zeros((Tn, J)); V1i[-1] = pi1i[REG[-1]] * _TERMFAC
        V0i = np.zeros((Tn, J)); V0i[-1] = pi0i[REG[-1]] * _TERMFAC
        for t in range(Tn - 2, -1, -1):
            V1i[t] = pi1i[REG[t]] + DELTA * V1i[t + 1]
            V0i[t] = pi0i[REG[t]] + DELTA * V0i[t + 1]
        DV1ch.append(V1i - V0i)
    return DV1ch


# ---- kappa identified by the below-cost WAR FLOOR (symmetric Bertrand-with-footfall) ----
PBAR_REP = 8.99
_A_REP, _C_REP = A0, float(D.c.median())
_PHI_REP = calib_phi(_A_REP, PBAR_REP)
_WM_CACHE = {}
def war_markup(kappa):
    key = round(float(kappa), 3)
    if key in _WM_CACHE:
        return _WM_CACHE[key]
    def br(prival):
        f = lambda p: -((p - _C_REP + kappa) * shares([p, prival, prival], _PHI_REP, _A_REP)[0])
        return minimize_scalar(f, bounds=(0.5, 30), method="bounded").x
    p = _C_REP
    for _ in range(50):
        pn = br(p)
        if abs(pn - p) < 1e-4:
            p = pn; break
        p = pn
    val = (p - _C_REP) / p
    _WM_CACHE[key] = val
    return val


def _logit(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


def _hold01_ij(j, wi, b, G01ch_r, dV1ch_arr):
    """ALL-CHAINS-HOLD forward-looking IC for a 0->1 lift (option 1): chain i holds iff its slack
    b*delta*DeltaV1_ij - G01_ij > 0.  The lift sticks iff EVERY chain holds, i.e. iff the BINDING
    (smallest-slack, most-tempted) chain holds -> logit(min_i slack_i).  Equal within-shares -> all slacks
    equal -> reduces EXACTLY to the symmetric single logit (the symmetric-model IC)."""
    s0 = b * dV1ch_arr[0][wi, j] - G01ch_r[j, 0]
    s1 = b * dV1ch_arr[1][wi, j] - G01ch_r[j, 1]
    s2 = b * dV1ch_arr[2][wi, j] - G01ch_r[j, 2]
    return _logit((s0 if (s0 <= s1 and s0 <= s2) else (s1 if s1 <= s2 else s2)) / TAU)


def _hold12_ij(j, G12ch_r):
    """ALL-CHAINS-HOLD (static) IC for a 1->2 rent step: all hold iff the most-tempted (largest G12_ij)
    chain holds -> logit(-max_i G12_ij).  Equal within-shares -> the symmetric single logit(-G12)."""
    g0, g1, g2 = G12ch_r[j, 0], G12ch_r[j, 1], G12ch_r[j, 2]
    return _logit(-(g0 if (g0 >= g1 and g0 >= g2) else (g1 if g1 >= g2 else g2)) / TAU)


def _lead_psi(DV1ch, wi, j, rng):
    """Drug-level leader by the chain escape-value (outside option psi) softmax -- psi_SB=0 bears the full
    war loss so SB has the largest escape value and lifts most (the war/wave leader).  [single-leader; kept
    for the old spec / fallback]"""
    ev = np.array([DV1ch[i][wi, j] for i in range(3)]) / TAU_LEAD
    pl = np.exp(ev - ev.max()); return int(rng.choice(3, p=pl / pl.sum()))


def _lead_mask(ev, b, mult, rng):
    """INDEPENDENT leadership: each chain i leads drug j this week ON ITS OWN with probability
        ell_i = min( b * logistic(ev_i + LEAD_C0) * mult , 0.99 ),
    where ev_i = DV1_ij/TAU_LEAD is the chain's escape-value propensity, b the follower belief (a chain
    raises only if it expects to be followed), and mult the war-campaign intensifier (1+g).  Returns a
    boolean[3] mask of leaders, which MAY BE EMPTY: when no chain leads, the drug is not lifted this week
    (even in an engaged lab some products have no leader and simply wait).  Two or three chains can lead
    the same event (co-leaders); the most war-exposed chain (SB, psi=0) leads most often."""
    p = np.minimum(b * (1.0 / (1.0 + np.exp(-(ev + LEAD_C0)))) * mult, 0.99)
    return rng.random(3) < p


def _pmove(ev, rng):
    """PRIMARY first-mover by escape-value softmax: SB (psi=0) has the largest escape value, so it moves
    first most often (the documented ``Salcobrand raised first'' order).  Drawn per lab (over the lab-mean
    escape) for the wave/rent and per drug for the war.  Pure-Python inverse-CDF (one uniform): the 3-way
    softmax draw avoiding numpy dispatch -- ~3.4x faster than rng.choice(3, p=.) and bit-identical on the
    estimate; this is the simulation hot loop (~112k calls per fit)."""
    e0 = float(ev[0]); e1 = float(ev[1]); e2 = float(ev[2])
    m = e0 if (e0 >= e1 and e0 >= e2) else (e1 if e1 >= e2 else e2)
    w0 = _mexp(e0 - m); w1 = _mexp(e1 - m); w2 = _mexp(e2 - m)
    u = rng.random() * (w0 + w1 + w2)
    return 0 if u < w0 else (1 if u < w0 + w1 else 2)


def _coleads(ev, prim, b, rng, mult=1.0):
    """Leader set for one event: the PRIMARY first-mover (always) PLUS each OTHER chain INDEPENDENTLY
    joining with prob min(b*logistic(ev_i+LEAD_C0)*mult, 0.99).  So 1-3 chains lead (co-leaders), the
    primary leads the order, and the leadership SHARE stays the primary's (SB-dominant) while the
    co-leader count matches the data."""
    led = np.zeros(3, bool); led[prim] = True
    for i in range(3):
        if i != prim and rng.random() < min(b * (1.0 / (1.0 + np.exp(-(ev[i] + LEAD_C0)))) * mult, 0.99):
            led[i] = True
    return led


def _engage(L, wi, b_now, G01r, done01, dV1ch_arr, lam, tau_eng, holf, rng):
    """ENDOGENOUS lab engagement (replaces the exogenous size hazard lam*Wn[L]^beta).  Each chain i
    reaches out to lab L when its expected coordination gain, SUMMED over the lab's not-yet-coordinated
    drugs, is high.  The per-period reach-out probability is PROPORTIONAL to that expected gain (capped):
        p_reach(i) = lam * min( (b*delta*DeltaV1_L(i) - G01_L)_+ / tau_eng , 1 ) * holiday,
    so a lab with a big coordination prize is reached almost surely each week while a marginal lab waits --
    this is what spreads the wave over time and orders it by value (replacing the old size hazard lam*W^beta).
    The lab engages if ANY chain reaches out (per-chain decision); the leader is the reaching chain with
    the largest PER-DRUG gain (most war-exposed -> SB).  Because dV1_L is a SUM over drugs, larger labs
    cross first; because the leader uses the per-chain value, the SB lead emerges -- both were ASSUMED
    before (via Wn^beta and a fixed softmax) and are now equilibrium outcomes.  Returns (reached?, leader)."""
    und = lab_drugs[L][~done01[lab_drugs[L]]]
    if len(und) == 0:
        return False, 0
    dV1_L = np.array([dV1ch_arr[i][wi, und].sum() for i in range(3)])          # SUM over drugs -> bigger labs first
    G01_L = float(G01r[und].sum())                                            # lab undercut gain (post-ban < 0)
    pr = lam * np.minimum(np.maximum(b_now * dV1_L - G01_L, 0.0) / tau_eng, 1.0) * holf   # reach-out rate ~ expected gain (capped): big labs first, marginal labs later
    reach = rng.random(3) < np.minimum(pr, 0.97)
    if not reach.any():
        return False, 0
    evm = np.where(reach, dV1_L / len(und), -1e18) / TAU_LEAD                  # MEAN per drug -> smooth leader softmax
    return True, _pmove(evm, rng)


def simulate(theta, B=40, seed=3, bmode="full", psi=None, kappa_chain=None, rho_attempt=0.0, announce=True, belief_weights=(0.0, 0.0, 0.0), onetime=False, w_window=3.0, no_alpha_collapse=False, arrivals_throughout=False, t_belief=None, zeta_sep=0.0):
    # announce DEFAULT True = the B-timing headline: ONE exogenous node at the 6-Nov BAN does BOTH the demand
    #   collapse AND the belief jump (zeta at BAN); the Dec coordination onset (t0) is the ENDOGENOUS lab-
    #   organization lag tau_eng -- not a separate belief jump.  announce=False -> the A-timing robustness (jump at t0).
    # bmode: "full" = event-update + ad-ban jump (headline); "nobel" = no belief (b==1); "jump_only" =
    #   ad-ban jump but NO event-update; "learn_only" (= full with zeta=0) = event-update but NO jump.
    # psi: outside-option vector; None -> the estimated PSI; [0,0,0] -> weighting OFF (uniform leadership), the beta=0 spec.
    kappa, lam, tau_eng, t0, a0, b0, zeta, chi, rho, g = theta[:10]   # tau_eng (was the size-tilt beta): ENDOGENOUS-engagement logit temperature
    lam_cut = float(theta[10]) if len(theta) > 10 else 0.0            # NEW: per-week SYMMETRIC down-cut (deviation/defection) rate; 0 => old up-only model (knockouts / other specs unaffected)
    t0 = int(round(t0))
    _psi = PSI if psi is None else np.asarray(psi, float)
    pl_rent = np.exp(_psi / 0.25); pl_rent = pl_rent / pl_rent.sum()   # post-Oficio rent leadership ~ outside option (CV-led handoff, v16 target 0.65)
    # ONE unified Beta-Binomial FOLLOWER belief on a SHARED (a0,b0) prior.  When the cartel switches on (t0)
    # the ad-ban public signal ADDS zeta pseudo-successes (it does NOT reset -- the war failures stay in F).
    # The rent tier sees a weaker signal Mr=zeta*exp(-chi) and learns on its OWN shared tally (S2,F2), so
    # rent steps keep opening AFTER the 0->1 wave -- the post-cartel deepening.  There is no belief-power
    # experimentation rate and no FNE decline shock: the regime change is the ad-ban incentive flip
    # (G01: + -> -, already in the demand data via A_RATIO) plus this single belief.
    Mr = float(zeta * np.exp(-chi))
    DV1ch = value_funcs(kappa, psi=_psi, kappa_chain=kappa_chain)   # chain escape values -> leadership
    if kappa_chain is not None:                    # het-mu robustness: late-rent leader = lowest-escape (highest mu_i) chain, mirroring the psi-based pl_rent
        _mesc = np.array([DV1ch[i].mean() for i in range(3)])
        pl_rent = np.exp(-_mesc / TAU_LEAD); pl_rent = pl_rent / pl_rent.sum()
    Gh  = {r: kappa * DS[f"dsh_{r}"]  + DS[f"mgh_{r}"]  for r in ("pre", "post")}   # follow-vs-harvest
    G01 = {r: kappa * DS[f"ds01_{r}"] + DS[f"mg01_{r}"] for r in ("pre", "post")}   # UNDERCUT-the-coordinated-price gain (flips +->- at ban)
    G12 = {r: kappa * DS[f"ds12_{r}"] + DS[f"mg12_{r}"] for r in ("pre", "post")}   # undercut-the-rent gain
    G01ch = {r: kappa * DS3[f"ds01_3_{r}"] + DS3[f"mg01_3_{r}"] for r in ("pre", "post")} if IJ else None   # [J,3] per-chain undercut gain (all-chains-hold IC)
    G12ch = {r: kappa * DS3[f"ds12_3_{r}"] + DS3[f"mg12_3_{r}"] for r in ("pre", "post")} if IJ else None
    if no_alpha_collapse:                          # C1 knockout: the ban shifts beliefs (zeta) but does NOT collapse price sensitivity -- the post-ban undercut gain stays at its pre-ban value, so G01 never flips
        for _G in (Gh, G01, G12): _G["post"] = _G["pre"]
        if IJ:
            for _G in (G01ch, G12ch): _G["post"] = _G["pre"]
    dV1_arr = DELTA * np.mean([DV1ch[i] for i in range(3)], axis=0)                 # FUTURE value delta*DeltaV1 per [week,drug]: the prize a hold buys
    dV1ch_arr = [DELTA * DV1ch[i] for i in range(3)]                                # PER-CHAIN delta*DeltaV1 (for the endogenous lab reach-out)
    # rent eligibility: inelastic drugs (own alpha below its ~42nd pct) whose rent flow beats the restored flow
    rent_elig = (S[(2, "post")] * (_p2 - _c + kappa) > S[(1, "post")] * (_p1 - _c + kappa))
    if not HOMOG:                         # heterogeneous: only the inelastic (low-alpha) drugs find the rent worth taking
        rent_elig = rent_elig & (_alpha < np.quantile(_alpha, 0.70))
    rng = np.random.default_rng(seed)
    PN = ["war", "cart", "pe", "pl"]
    succ = {p: 0.0 for p in PN}; fail = {p: 0.0 for p in PN}     # per-period success / failure counts
    leadS = {p: np.zeros(3) for p in PN}; leadF = {p: np.zeros(3) for p in PN}   # FIRST-MOVER leadership by period
    dev = {p: 0.0 for p in PN}; devL = {p: np.zeros(3) for p in PN}              # NEW: per-period war-deviation / defection counts + cut-leader
    nlead_sum = 0.0; nev_sum = 0.0                               # total co-leaders / total coord events -> n_leaders rate
    tot01 = tot12 = 0.0
    wave_acc = np.zeros(len(WKS)); _wkidx = {t: i for i, t in enumerate(WKS)}   # per-week 0->1 coordinations, summed over B (for the wave-fit figure)
    wave12_acc = np.zeros(len(WKS))   # per-week 1->2 rent steps (NEW markup-path / post-Oficio acceleration moment)
    onsets = []; peaks = []; sds = []; corrs = []; lab_sds = []; lags = []
    q25s = []; q75s = []; peak2s = []; sd2s = []; btws = []; spears = []   # NEW time + sequence moments
    for b in range(B):
        done01 = np.zeros(J, bool); done12 = np.zeros(J, bool); ever01 = np.zeros(J, bool)   # ever01: ever-coordinated (the UNIQUE-drug tot01 count, robust to defect-then-recoordinate churn)
        lab_on = {L: False for L in labs}; lab_arrived = {L: False for L in labs}; lab_arrival_wk = {}; lab_primary = {}   # lab_on: absorbing (headline) | lab_arrived/lab_arrival_wk: one-time arrival + short engagement window (onetime mode)
        Sc = Fc = A_count = 0.0                                # belief tally (Sc,Fc) + A_count = cumulative lift attempts (persistence-belief robustness)
        cwk = {}; cwk2 = {}                                    #   (0->1 AND 1->2 success, every revert) updates it
        for wi, t in enumerate(WKS):
            r = REG[wi]; per = _period(t)
            _tbel = t_belief if t_belief is not None else (BAN if announce else t0)   # belief-jump date: t0 (headline) | BAN (announce) | a forced date e.g. CONAR (Sep, the timing robustness)
            zt = (zeta_sep if t >= 88 else 0.0) + (zeta if t >= _tbel else 0.0)   # zeta_sep>0 adds a PARTIAL belief jump at the 7-Sep CONAR ruling (wk 88), the main jump zeta at _tbel
            if bmode == "nobel":                                # SPEC 1: no belief (b==1 -> the war floods, the b^2 gate is wide open)
                b_now = 1.0
            elif bmode == "jump_only":                          # SPEC 2: ad-ban jump only, NO event-update (drop Sc,Fc)
                b_now = (a0 + zt) / (a0 + b0 + zt)
            else:                                               # full headline (and SPEC 3 learn-only via zeta=0)
                _wF, _wL, _wD = belief_weights                        # richer (collinear) signals: +failed-attempts (Fc), +leads (~attempts), -time/discount
                b_now = (a0 + Sc + rho_attempt * A_count + _wF * Fc + _wL * A_count - _wD * (t - WK0) + zt) / (a0 + b0 + Sc + Fc + zt + (_FOF * max(0.0, 1.0 - (t - OFICIO) / _TAUOF) if t >= OFICIO else 0.0))
                b_now = min(max(b_now, 0.0), 0.999)
            # the rent belief is the SAME shared belief b_now -- it learns from ALL coordination events via the
            # common tally (Sc,Fc) -- DISCOUNTED by e^{-chi} because the supra-competitive rent tier is harder
            # to sustain.  So the rent rides the wave's learning and ACCELERATES as Sc grows (the post-cartel
            # deepening), while staying below the coordination belief at every date.
            b_rent = np.exp(-chi) * b_now if t >= t0 else 0.0
            # FNE scrutiny on the rent: strongest right after the notice (rsc=exp(-rho)) and FADING back to 1
            # by year-end as the cartel adapts -- so the rent struggles in post-early (reverts) then recovers
            # in post-late (the succ_pl surge), exactly the post-cartel success/failure crossover in the data.
            rsc = 1.0 if (_FOF > 0 or (_FRZ_K > 0 and t >= OFICIO + _FRZ_S + _FRZ_K)) else ((np.exp(-rho) + (1.0 - np.exp(-rho)) * (t - OFICIO) / (WK1 - OFICIO)) if t >= OFICIO else 1.0)
            # ---- SYMMETRIC down-move (deviation / defection): BEFORE the up-lift logic, each week the
            #      most-tempted (binding) chain undercuts when its belief-weighted future value FAILS to cover
            #      its undercut gain.  This is the MIRROR of the up-lift's all-chains-hold IC: chain i's slack is
            #      s_i = b*delta*DeltaV1_ij - G01_ij; the lift holds iff min_i s_i > 0, so the cut fires iff that
            #      binding chain CANNOT resist -- with prob lam_cut * (1 - hold) = lam_cut * logit(-min_i s_i/TAU).
            #      Cut-leader = the binding chain (smallest slack = most to gain from defecting -> the high-mu CV).
            #      War (low belief) => s<0 => cuts fire (deviation_war); cartel (high belief) => b*delta*DeltaV1
            #      swamps G01 => s>0 => no cut, so coordination holds ENDOGENOUSLY (no assumed no-defection;
            #      cartel stability is an OUTCOME of the belief, not an assumption).  A coordinated drug that is
            #      undercut REVERTS to the war floor; a tier-0 drug just records the deviation.  lam_cut=0 => skip.
            if IJ and lam_cut > 0.0:
                _g01r = G01ch[r]
                for _j in range(J):
                    if done12[_j]:                                            # rent (tier-2) drugs defect via the existing 1<->2 rent-revert channel, not the war floor
                        continue
                    _slk = b_now * dV1_arr[wi, _j] - G01[r][_j]               # REGIME slack: belief-weighted escape value vs the COMMON undercut gain.  Flips cleanly +->- at the ban (G01_common mean -1.18 post), so deviations stay WAR-CONCENTRATED -- the per-chain max would leak post-ban for the high-mu chain whose G01ch stays marginally positive.
                    if rng.random() < lam_cut * _logit(-_slk / TAU):         # fires iff the war regime cannot be resisted (low belief + G01>0); cartel (high belief, G01<0) => slack>0 => holds ENDOGENOUSLY
                        _cl = _pmove(_g01r[_j] / TAU_LEAD, rng)               # LEADER endogenous: softmax over the per-chain undercut gain (highest -> the high-mu CV, the Desafio cutter)
                        dev[per] += 1.0; devL[per][_cl] += 1
                        if done01[_j]:                                        # a coordinated drug is undercut back to war (defection); ~never post-ban (regime slack > 0), so the cartel holds without an assumed no-defection
                            done01[_j] = False; done12[_j] = False; cwk2.pop(_j, None)   # tier state drops; cwk (FIRST coord week) + ever01 stay, so tot01 + wave timing stay clean
            if t < (BAN if announce else t0):
                # ---- WAR (pre-cartel): firms test coordinated lifts at the LOW follower belief b_now, but
                #      before the cartel switches on nothing sticks -- a rival undercuts each lift and it
                #      reverts (a failed attempt).  Low belief => sporadic; each revert raises F, lowering the
                #      belief further (self-limiting), so the war failures accumulate at ~b_now x (un-coord
                #      count)/week without flooding.  The lifter is the chain escape-value leader (psi_SB=0 -> SB).
                #      The Aug-2007 Cruz Verde "Desafio" campaign intensifies the below-cost war by (1+g) (war_ratio).
                wmult = (1.0 + g) if t >= AUG else 1.0
                for j in np.where(~done01)[0]:
                    ev = np.array([DV1ch[i][wi, j] for i in range(3)]) / TAU_LEAD
                    prim = _pmove(ev, rng)                                     # who would move first (SB-dominant softmax)
                    if rng.random() >= min(b_now * wmult, 0.99):              # primary tests a lift (belief-gated); else no lift this week
                        continue
                    A_count += 1                                              # a lift attempt (persistence-belief robustness)
                    led = _coleads(ev, prim, b_now, rng); k = int(led.sum())  # primary + INDEPENDENT co-leaders
                    nf = 3 - k                                                # the 3-k followers each match (b^{nf}) AND ALL chains hold the IC (option 1)
                    hold01 = _hold01_ij(j, wi, b_now, G01ch[r], dV1ch_arr) if IJ else _logit(-(G01[r][j] - b_now * dV1_arr[wi, j]) / TAU)
                    if rng.random() < b_now ** nf and rng.random() < hold01:
                        done01[j] = True; succ[per] += 1; Sc += 1
                        if not ever01[j]: tot01 += 1; ever01[j] = True; cwk[j] = t   # count the drug ONCE, keep the FIRST coord week (robust to defect-then-recoordinate)
                        leadS[per][prim] += 1; nlead_sum += k; nev_sum += 1   # first mover = primary; +co-leader count
                    else:                                                     # not matched/held -> reverts: a failed attempt
                        Fc += 1; fail[per] += 1; leadF[per][prim] += 1
                continue
            if announce and t < t0:                                   # announce mode: post-announcement, pre-organization gap -- belief has shifted but the labs are not yet engaged, so nothing coordinates yet (the ~4-week lab cycle)
                continue
            holf = 0.4 if t in HOL_WEEKS else 1.0
            if onetime:
                # ---- ONE-TIME arrivals; each lab is then active for a SHORT engagement window (w_window weeks)
                #      and then LEAVES (not absorbing): pre-event no habit, post-event deterred.  arrivals_throughout:
                #      labs keep arriving across the whole cartel ([t0, WK1)) -- so the small/slow labs that miss the
                #      short [t0, OFICIO) window still engage, closing the coordination count -- vs only [t0, OFICIO).
                if t < (WK1 if arrivals_throughout else OFICIO):
                    for L in labs:
                        if lab_arrived[L]:
                            continue
                        ok, prim = _engage(L, wi, b_now, G01[r], done01, dV1ch_arr, lam, tau_eng, holf, rng)
                        if not ok:
                            continue
                        lab_arrived[L] = True; lab_arrival_wk[L] = t; lab_primary[L] = prim
                for L in labs:                                            # labs ACTIVE within their engagement window coordinate their drugs; then they leave
                    if not lab_arrived[L] or t >= lab_arrival_wk[L] + w_window:
                        continue
                    ds = lab_drugs[L]; prim = lab_primary[L]
                    for j in ds[~done01[ds]]:
                        ev = np.array([DV1ch[i][wi, j] for i in range(3)]) / TAU_LEAD
                        if rng.random() >= b_now:
                            continue
                        A_count += 1
                        led = _coleads(ev, prim, b_now, rng); k = int(led.sum())
                        nf = 3 - k
                        hold01 = _hold01_ij(j, wi, b_now, G01ch[r], dV1ch_arr) if IJ else _logit(-(G01[r][j] - b_now * dV1_arr[wi, j]) / TAU)
                        if rng.random() < b_now ** nf and rng.random() < hold01:
                            done01[j] = True; succ[per] += 1; Sc += 1
                            if not ever01[j]: tot01 += 1; ever01[j] = True; cwk[j] = t
                            leadS[per][prim] += 1; nlead_sum += k; nev_sum += 1
                # ---- DECOUPLED rent: each already-coordinated drug deepens 1->2 per-drug, every week (NOT lab-gated),
                #      so the rent lags the wave and keeps deepening post-Oficio with no new arrival.
                for j in (np.where(done01 & rent_elig & ~done12)[0] if not (_FRZ_K > 0 and (OFICIO + _FRZ_S) <= t < (OFICIO + _FRZ_S + _FRZ_K)) else []):
                    if rng.random() >= (1.0 if _RENT_NB else b_rent):
                        continue
                    ev = np.array([DV1ch[i][wi, j] for i in range(3)]) / TAU_LEAD
                    prim = _pmove(ev, rng); led = _coleads(ev, prim, b_rent, rng)
                    if rng.random() < rsc * (1.0 if _RENT_NH else (_hold12_ij(j, G12ch[r]) if IJ else _logit(-G12[r][j] / TAU))):
                        done12[j] = True; tot12 += 1; succ[per] += 1; cwk2[j] = t; Sc += 1
                        rl = int(rng.choice(3, p=pl_rent)) if t >= OFICIO else prim
                        leadS[per][rl] += 1; nlead_sum += int(led.sum()); nev_sum += 1
                    elif t >= OFICIO:
                        Fc += 1; fail[per] += 1; leadF[per][prim] += 1
                continue
            for L in labs:
                ds = lab_drugs[L]
                if not lab_on[L]:
                    ok, prim0 = _engage(L, wi, b_now, G01[r], done01, dV1ch_arr, lam, tau_eng, holf, rng)
                    if not ok:
                        continue
                    lab_on[L] = True; lab_primary[L] = prim0                  # Layer 1: lab engages (absorbing, endogenous)
                prim = lab_primary[L]
                # ---- RENT 1->2: the lab primary pushes a rent-eligible coordinated drug toward the supra-
                #      competitive rent at the discounted belief b_rent (else no push -> the drug waits); the OTHER
                #      chains independently co-lead.  The push STICKS iff the followers match (rsc x logit(-G12));
                #      otherwise (post-Oficio) it reverts.  Post-Oficio the most-exposed chain (SB) pulls back under
                #      scrutiny, so the rent is led by the least-exposed chain (CV) -- the SB->CV handoff.
                for j in ds[done01[ds] & rent_elig[ds] & ~done12[ds]]:
                    ev = np.array([DV1ch[i][wi, j] for i in range(3)]) / TAU_LEAD
                    if rng.random() >= b_rent:                                # primary pushes the rent (else no push this week)
                        continue
                    led = _coleads(ev, prim, b_rent, rng)                     # primary + INDEPENDENT co-leaders
                    if rng.random() < rsc * (_hold12_ij(j, G12ch[r]) if IJ else _logit(-G12[r][j] / TAU)):
                        done12[j] = True; tot12 += 1; succ[per] += 1; cwk2[j] = t; Sc += 1
                        rl = int(rng.choice(3, p=pl_rent)) if t >= OFICIO else prim   # post-Oficio CV-led handoff
                        leadS[per][rl] += 1; nlead_sum += int(led.sum()); nev_sum += 1
                    elif t >= OFICIO:                                         # a non-match REVERTS only under FNE scrutiny (post-Oficio)
                        Fc += 1; fail[per] += 1; leadF[per][prim] += 1
                # ---- WAVE 0->1: the lab primary lifts an un-coordinated drug at belief b_now (else 0 leaders ->
                #      EVEN IN AN ENGAGED LAB SOME PRODUCTS HAVE NO LEADER and wait); the OTHER chains independently
                #      co-lead.  The lift STICKS iff the 3-k followers match (b^{3-k}) and hold (logit(-NG01); ~1
                #      post-ban).  A non-match during the cartel is NOT a revert (the primary holds and retries).
                for j in ds[~done01[ds]]:
                    ev = np.array([DV1ch[i][wi, j] for i in range(3)]) / TAU_LEAD
                    if rng.random() >= b_now:                                 # primary lifts (else 0 leaders -> drug waits)
                        continue
                    A_count += 1                                              # a lift attempt (persistence-belief robustness)
                    led = _coleads(ev, prim, b_now, rng); k = int(led.sum())  # primary + INDEPENDENT co-leaders
                    nf = 3 - k
                    hold01 = _hold01_ij(j, wi, b_now, G01ch[r], dV1ch_arr) if IJ else _logit(-(G01[r][j] - b_now * dV1_arr[wi, j]) / TAU)
                    if rng.random() < b_now ** nf and rng.random() < hold01:
                        done01[j] = True; succ[per] += 1; Sc += 1
                        if not ever01[j]: tot01 += 1; ever01[j] = True; cwk[j] = t
                        leadS[per][prim] += 1; nlead_sum += k; nev_sum += 1   # first mover = lab primary
        for _t in cwk.values():                               # accumulate the 0->1 coordination wave (per-week) for the fit figure
            wave_acc[_wkidx[_t]] += 1
        for _t in cwk2.values():                              # accumulate the 1->2 rent wave (per-week)
            wave12_acc[_wkidx[_t]] += 1
        if len(cwk) > 5:
            cw = pd.Series(cwk)
            onsets.append(np.percentile(cw.values, 5)); peaks.append(cw.round().median()); sds.append(cw.values.std())
            q25s.append(np.percentile(cw.values, 25)); q75s.append(np.percentile(cw.values, 75))   # NEW: 0->1 wave IQR
            labof = D.loc[cw.index, "lab"]
            lm = cw.groupby(labof.values).median(); lf = cw.groupby(labof.values).min()
            lab_sds.append(float(lf.values.std()))
            lw = np.array([logW_lab[L] for L in lm.index])
            if len(lm) > 3 and lw.std() > 0 and lm.std() > 0:
                corrs.append(np.corrcoef(lw, lm.values)[0, 1])
                spears.append(spearmanr(lw, lm.values).correlation)                                 # NEW: rank size-gradient
            grand = cw.mean(); ssb = float((cw.groupby(labof.values).count() *               # NEW: between-lab variance share
                       (cw.groupby(labof.values).mean() - grand) ** 2).sum())
            sst = float(((cw - grand) ** 2).sum())
            if sst > 0:
                btws.append(ssb / sst)
            if len(cwk2) > 3:
                cw2 = np.array(list(cwk2.values()))
                lags.append(np.median(cw2) - np.median(cw.values))
                peak2s.append(np.median(cw2)); sd2s.append(cw2.std())                               # NEW: 1->2 rent-wave
    n = float(B)
    # PER-EVENT leadership share: fraction of period-p events in which chain ch was A leader (each chain is
    # credited at most once per event, so with co-leaders the three chains' shares can sum to >1).  Matches
    # the data, where an event's `leaders` set is searched for ch.  den = succ (for leadS) or fail (for leadF).
    def _sh(d, p, ch, den):
        return float(d[p][ch] / den[p]) if den[p] else 0.0
    out = dict(tot01=tot01 / n, tot12=tot12 / n,
               onset=float(np.mean(onsets)) if onsets else WK0,
               peak=float(np.mean(peaks)) if peaks else WK0,
               sd=float(np.mean(sds)) if sds else 0.0,
               corr_sz=float(np.mean(corrs)) if corrs else 0.0,
               war_mk=war_markup(kappa),
               lab_sd=float(np.mean(lab_sds)) if lab_sds else 0.0,
               tier_lag=float(np.mean(lags)) if lags else 0.0,
               war_ratio=float(1.0 + g),                 # Aug-2007 campaign war intensification
               q25=float(np.mean(q25s)) if q25s else WK0,         # NEW time moments
               q75=float(np.mean(q75s)) if q75s else WK0,
               peak2=float(np.mean(peak2s)) if peak2s else WK0,
               sd2=float(np.mean(sd2s)) if sd2s else 0.0,
               btw_lab=float(np.mean(btws)) if btws else 0.0,     # NEW sequence moments
               spear_sz=float(np.mean(spears)) if spears else 0.0)
    for p in PN:
        out[f"succ_{p}"] = succ[p] / n; out[f"fail_{p}"] = fail[p] / n; out[f"dev_{p}"] = dev[p] / n
    out["lead_sb_cart"] = _sh(leadS, "cart", 2, succ)   # SB leads the wave
    out["lead_cv_pl"] = _sh(leadS, "pl", 0, succ)       # CV takes over the late rent
    out["lead_sb_fail_pe"] = _sh(leadF, "pe", 2, fail)  # SB fails most post-cartel
    # leader composition (per-credit share of leads by chain) for display
    out["leadS_cart"] = (leadS["cart"] / max(1e-9, leadS["cart"].sum())).tolist()
    out["leadS_pl"] = (leadS["pl"] / max(1e-9, leadS["pl"].sum())).tolist()
    out["leadF_pe"] = (leadF["pe"] / max(1e-9, leadF["pe"].sum())).tolist()
    # average number of leaders per coordination event (co-leader rate; 1 = always solo, up to 3)
    out["n_leaders"] = float(nlead_sum / nev_sum) if nev_sum else 1.0
    # SB-leadership share for SUCCESS (leadS) and FAILURE (leadF), by war/cart/post (post=pe+pl) -- the
    # outside-option VALIDATION moments; ~1/3 (uniform) when psi=[0,0,0] (the beta=0 spec).
    def _sh2(d, ps, ch, den):
        v = sum(d[p] for p in ps); s = sum(den[p] for p in ps); return float(v[ch] / s) if s else 0.0
    out["ldS_war"] = _sh(leadS, "war", 2, succ); out["ldS_cart"] = _sh(leadS, "cart", 2, succ); out["ldS_post"] = _sh2(leadS, ("pe", "pl"), 2, succ)
    out["ldF_war"] = _sh(leadF, "war", 2, fail); out["ldF_cart"] = _sh(leadF, "cart", 2, fail); out["ldF_post"] = _sh2(leadF, ("pe", "pl"), 2, fail)
    _c01 = np.cumsum(wave_acc) / n; _c12 = np.cumsum(wave12_acc) / n
    out["wave01"] = _c01.tolist(); out["wave12"] = _c12.tolist()        # mean cumulative 0->1 / 1->2 by week
    for _w in (104, 110, 116): out[f"w01_{_w}"] = float(_c01[_w - WK0])   # NEW 0->1 wave-shape checkpoints
    for _w in (126, 135, 148): out[f"w12_{_w}"] = float(_c12[_w - WK0])   # NEW 1->2 rent-path / acceleration checkpoints
    return out


def one_path(theta, seed=7, bmode="full", onetime=False, w_window=3.0, arrivals_throughout=False, no_alpha_collapse=False, kappa_chain=None, announce=True):
    """One representative replication; returns (coord-week, rent-week, failed-week) for plotting.  Mirrors
    simulate(): the (i,j) all-chains-hold IC (_hold01_ij/_hold12_ij), the het-mu leadership escape value
    (kappa_chain), and the B-timing belief jump at the BAN (announce=True; the Dec onset t0 is endogenous).
    no_alpha_collapse: C1 knockout -- post-ban payoff stays at pre-ban, so G01 never flips."""
    kappa, lam, tau_eng, t0, a0, b0, zeta, chi, rho, g = theta[:10]
    t0 = int(round(t0)); _tbel = BAN if announce else t0       # B-timing: belief jumps at the Nov ban, not t0
    Gh = {r: kappa * DS[f"dsh_{r}"] + DS[f"mgh_{r}"] for r in ("pre", "post")}
    G01 = {r: kappa * DS[f"ds01_{r}"] + DS[f"mg01_{r}"] for r in ("pre", "post")}   # undercut gain (flips at ban)
    G12 = {r: kappa * DS[f"ds12_{r}"] + DS[f"mg12_{r}"] for r in ("pre", "post")}
    G01ch = {r: kappa * DS3[f"ds01_3_{r}"] + DS3[f"mg01_3_{r}"] for r in ("pre", "post")} if IJ else None
    G12ch = {r: kappa * DS3[f"ds12_3_{r}"] + DS3[f"mg12_3_{r}"] for r in ("pre", "post")} if IJ else None
    if no_alpha_collapse:                          # C1: ban shifts beliefs but does NOT collapse price sensitivity
        for _G in (Gh, G01, G12): _G["post"] = _G["pre"]
        if IJ:
            for _G in (G01ch, G12ch): _G["post"] = _G["pre"]
    _vf = value_funcs(kappa, kappa_chain=kappa_chain)
    dV1_arr = DELTA * np.mean(_vf, axis=0)                                          # future value delta*DeltaV1 [week,drug]
    dV1ch_arr = [DELTA * _vf[i] for i in range(3)]                                  # per-chain (endogenous lab reach-out)
    rent_elig = (S[(2, "post")] * (_p2 - _c + kappa) > S[(1, "post")] * (_p1 - _c + kappa))
    if not HOMOG:                         # heterogeneous: only the inelastic (low-alpha) drugs find the rent worth taking
        rent_elig = rent_elig & (_alpha < np.quantile(_alpha, 0.70))
    rng = np.random.default_rng(seed)
    done01 = np.zeros(J, bool); done12 = np.zeros(J, bool)
    lab_on = {L: False for L in labs}; lab_arrived = {L: False for L in labs}; lab_arrival_wk = {}   # lab_arrived/_wk: one-time bounded spells (onetime)
    Sc = Fc = 0.0; cwk = {}; cwk2 = {}; fwk = []                    # one shared belief tally (matches simulate); fwk = failed-lift weeks
    def _hold01(j, wi, b):                                          # all-chains-hold IC (i,j) -> symmetric fallback
        return _hold01_ij(j, wi, b, G01ch[r], dV1ch_arr) if IJ else _logit(-(G01[r][j] - b * dV1_arr[wi, j]) / TAU)
    for wi, t in enumerate(WKS):
        r = REG[wi]
        zt = zeta if t >= _tbel else 0.0                           # B-timing: jump at the ban (_tbel)
        if bmode == "nobel":
            b_now = 1.0
        elif bmode == "jump_only":
            b_now = (a0 + zt) / (a0 + b0 + zt)
        else:
            b_now = (a0 + Sc + zt) / (a0 + b0 + Sc + Fc + zt + (_FOF * max(0.0, 1.0 - (t - OFICIO) / _TAUOF) if t >= OFICIO else 0.0))
        b_rent = np.exp(-chi) * b_now if t >= t0 else 0.0               # shared belief discounted by e^{-chi} (matches simulate)
        rsc = 1.0 if (_FOF > 0 or (_FRZ_K > 0 and t >= OFICIO + _FRZ_S + _FRZ_K)) else ((np.exp(-rho) + (1.0 - np.exp(-rho)) * (t - OFICIO) / (WK1 - OFICIO)) if t >= OFICIO else 1.0)
        if t < _tbel:                            # war (until the ban): leader lifts (b_now), holds iff all chains hold the IC; mostly reverts
            wr = min(b_now * (1.0 + g), 0.99) if t >= AUG else b_now
            u = np.where(~done01)[0]
            for j in u[rng.random(len(u)) < wr]:
                if rng.random() < b_now ** 2 and rng.random() < _hold01(j, wi, b_now):   # b^2 ignition gate (both followers match) -- matches simulate's b_now**nf
                    done01[j] = True; cwk[j] = t; Sc += 1
                else:
                    Fc += 1; fwk.append(t)
            continue
        if announce and t < t0:                  # post-ban, pre-organization gap: belief shifted but labs not yet engaged
            continue
        holf = 0.4 if t in HOL_WEEKS else 1.0
        if onetime:                                              # one-time bounded spells (mirrors simulate)
            if t < (WK1 if arrivals_throughout else OFICIO):
                for L in labs:
                    if lab_arrived[L]:
                        continue
                    ok, _ = _engage(L, wi, b_now, G01[r], done01, dV1ch_arr, lam, tau_eng, holf, rng)
                    if not ok:
                        continue
                    lab_arrived[L] = True; lab_arrival_wk[L] = t
            for L in labs:                                       # active labs (within their w-week spell) coordinate
                if not lab_arrived[L] or t >= lab_arrival_wk[L] + w_window:
                    continue
                dsa = lab_drugs[L]
                for j in dsa[~done01[dsa]]:
                    if rng.random() < b_now ** 2 and rng.random() < _hold01(j, wi, b_now):   # b^2 ignition gate (both followers match) -- matches simulate's b_now**nf
                        done01[j] = True; cwk[j] = t; Sc += 1
            for j in (np.where(done01 & rent_elig & ~done12)[0] if not (_FRZ_K > 0 and (OFICIO + _FRZ_S) <= t < (OFICIO + _FRZ_S + _FRZ_K)) else []):  # decoupled rent (PAUSED during the post-Oficio freeze)
                if rng.random() < b_rent:
                    if rng.random() < rsc * (_hold12_ij(j, G12ch[r]) if IJ else _logit(-G12[r][j] / TAU)):
                        done12[j] = True; cwk2[j] = t; Sc += 1
                    elif t >= OFICIO:
                        Fc += 1; fwk.append(t)
            continue
        for L in labs:
            ds = lab_drugs[L]
            if not lab_on[L]:
                ok, _ = _engage(L, wi, b_now, G01[r], done01, dV1ch_arr, lam, tau_eng, holf, rng)
                if not ok:
                    continue
                lab_on[L] = True
            for j in ds[done01[ds] & rent_elig[ds] & ~done12[ds]]:   # rent step: eligible drug, sticks iff all chains hold
                if rng.random() < b_rent:
                    if rng.random() < rsc * (_hold12_ij(j, G12ch[r]) if IJ else _logit(-G12[r][j] / TAU)):
                        done12[j] = True; cwk2[j] = t; Sc += 1
                    elif t >= OFICIO:                    # reverts only post-Oficio (scrutiny); in-cartel it waits
                        Fc += 1; fwk.append(t)
            for j in ds[~done01[ds]]:                        # 0->1 wave: leader lifts (b_now), holds iff all chains hold the IC
                if rng.random() < b_now ** 2 and rng.random() < _hold01(j, wi, b_now):   # b^2 ignition gate (both followers match) -- matches simulate's b_now**nf
                    done01[j] = True; cwk[j] = t; Sc += 1
    return cwk, cwk2, fwk


# SMM weights ~ each moment's scale/SE.  This KEEPS all the prior structural moments -- the wave counts and
# timing (tot01, tot12, onset, peak, sd), the lab-size gradient and within-lab spread (corr_sz, lab_sd), the
# war floor (war_mk), the 1->2 lag (tier_lag) and the Aug-campaign war intensification (war_ratio) -- and ADDS
# the per-period SUCCESS and FAILURE counts (failures collapse in-cartel and rebound after; successes stay
# positive and rise post-cartel) plus the leadership shares (SB leads the wave, CV the late rent, SB fails
# most post-cartel).  Small-count periods (succ_war, fail_cart) are weighted loosely so they do not dominate.
# NEW (2026-06-16): richer TIME path -- the 0->1 wave interquartile weeks (q25,q75; pin the wave width, which
# the prior set undershot) and the 1->2 rent-wave location+spread (peak2,sd2) -- and richer SEQUENCE -- the
# between-lab share of coord-week variance (btw_lab; "labs explain the ordering", Fact 4) and the rank
# (Spearman) lab-size gradient (spear_sz; big labs first, monotone not just linear).
_W = dict(tot01=20, tot12=18, onset=3, peak=4, sd=1.5, corr_sz=0.16, war_mk=0.03, lab_sd=1.5,
          tier_lag=3.0, war_ratio=0.15,
          q25=3.0, q75=3.0, peak2=4.0, sd2=2.0, btw_lab=0.12, spear_sz=0.16,   # NEW time (0->1 IQR, rent peak2/sd2) + sequence (lab-variance share, rank size-gradient)
          w01_104=60, w01_110=60, w01_116=60,   # 0->1 WAVE-path checkpoints DOWN-WEIGHTED (60 vs the rent-path's 12): largely redundant with tot01/onset/peak/sd/q25/q75, so kept light -- at full weight they over-constrain the mu spread and weaken leadership (SB 0.72 -> 0.60). Dropping them entirely flips the multi-start into a worse basin (loss 23.7, SB 0.66); 60 reproducibly finds the good basin (16.5, SB 0.72).
          w12_126=12, w12_135=12, w12_148=12,   # 1->2 RENT-path checkpoints: the institutionally-fixed Pause (Oficio+9, 9 wks) gives the plateau-then-surge SHAPE; these pin its MAGNITUDE (surge to ~140/143). Dropping them reverts the rent to the old ~131/143 undershoot.
          succ_war=5, succ_cart=25, succ_pe=8, succ_pl=10,
          fail_war=15, fail_cart=4, fail_pe=10, fail_pl=7,
          dev_war=35, dev_cart=50, dev_pe=20, dev_pl=20,   # NEW symmetric down-move: dev_war (tight) PINS lam_cut; cart/pe/pl loose -- the low cartel/post deviations are an over-identifying PREDICTION of endogenous stability (one rate, period-variation from the slack gate)
          lead_sb_cart=0.10, lead_cv_pl=0.12, lead_sb_fail_pe=0.10,
          n_leaders=0.20)        # co-leader rate (avg #leaders/event): independent-lead model targets the data's 2.07
def loss(m):
    return sum(((m[k] - EMP[k]) / _W[k]) ** 2 for k in _W)


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    BND = dict(kappa=(8.0, 16.0), lam=(0.05, 0.95), beta=(0.0, 2.5), t0=(98, 106),
               a0=(0.3, 8.0), b0=(5.0, 150.0),              # shared belief prior; large b0 => low war belief (war self-limits)
               zeta=(40.0, 3000.0), chi=(1.0, 4.0),         # zeta = ad-ban pseudo-successes; HIGHER bound now -- the lift needs BOTH leader+follower belief (b^2) so the wave needs a stronger signal to fire
               rho=(0.0, 3.0),                              # rho = post-Oficio FNE-scrutiny penalty on the rent match -> the post-cartel failure rebound
               g=(0.0, 1.5))                                # g = Aug-2007 CV-campaign below-cost war intensification (war_ratio)
    K = list(BND); bounds = [BND[k] for k in K]
    def obj(x):
        xc = [min(max(float(x[i]), bounds[i][0]), bounds[i][1]) for i in range(len(K))]
        return loss(simulate(xc, B=14))
    seed = [9.371, 0.385, 0.641, 102.855, 1.315, 101.974, 1347.133, 2.524, 1.393, 0.69]   # kappa,lam,beta,t0,a0,b0,zeta,chi,rho,g (warm start = prior best on the enriched moment set)
    cand = [seed] + [[rng.uniform(*BND[k]) for k in K] for _ in range(180)]
    cand.sort(key=obj)
    best = (obj(cand[0]), cand[0])
    for x0 in ([seed] + cand[:4]):
        res = minimize(obj, np.array(x0, float), method="Powell", bounds=bounds,
                       options=dict(maxiter=200, xtol=2e-3, ftol=2e-3))
        xc = [min(max(float(res.x[i]), bounds[i][0]), bounds[i][1]) for i in range(len(K))]
        if res.fun < best[0]:
            best = (float(res.fun), xc)
    th = best[1]; M = simulate(th, B=240); L200 = float(loss(M))
    print(f"\nSMM loss(B=240) {L200:.2f}   (search-B=14 best was {best[0]:.2f}; psi from reliance -> leadership PREDICTED)")
    for k, v in zip(K, th):
        print(f"   {k:6s} = {v:.3f}")
    print(f"\n{'moment':18s}{'model':>9}{'data':>9}")
    for k, lab in [("tot01", "first coord (0->1)"), ("tot12", "rent (1->2)"), ("onset", "onset wk"),
                   ("peak", "peak wk"), ("sd", "wave SD"), ("corr_sz", "corr(logW,wk)"), ("lab_sd", "lab-wave SD"),
                   ("war_mk", "war markup"), ("tier_lag", "1->2 lag"), ("war_ratio", "war intensif."),
                   ("q25", "0->1 q25 wk"), ("q75", "0->1 q75 wk"), ("peak2", "1->2 peak wk"), ("sd2", "1->2 SD"),
                   ("btw_lab", "lab var share"), ("spear_sz", "spearman(W,wk)"),
                   ("succ_war", "succ: war"), ("succ_cart", "succ: cartel"), ("succ_pe", "succ: post-early"),
                   ("succ_pl", "succ: post-late"),
                   ("fail_war", "fail: war"), ("fail_cart", "fail: cartel"), ("fail_pe", "fail: post-early"),
                   ("fail_pl", "fail: post-late")]:
        d = EMP.get(k, float("nan"))
        print(f"  {lab:18s}{M[k]:>7.2f}{d:>9.2f}")
    print("\nLEADERSHIP by period (CV/FA/SB %):")
    print(f"   cartel success   model {'/'.join(f'{x:.0%}' for x in M['leadS_cart'])}   data 17/20/74  (target SB {EMP['lead_sb_cart']:.0%})")
    print(f"   post-late succ   model {'/'.join(f'{x:.0%}' for x in M['leadS_pl'])}   data 56/25/19  (target CV {EMP['lead_cv_pl']:.0%})")
    print(f"   post-early fail  model {'/'.join(f'{x:.0%}' for x in M['leadF_pe'])}   data 09/09/83  (target SB {EMP['lead_sb_fail_pe']:.0%})")
    out = dict(theta=dict(zip(K, th)), loss=L200, delta=DELTA, tau=TAU, psi=list(map(float, PSI)),
               moments={k: float(M[k]) for k in M if not isinstance(M[k], list)}, empirical=EMP,
               leadS_cart=M["leadS_cart"], leadS_pl=M["leadS_pl"], leadF_pe=M["leadF_pe"])
    json.dump(out, open(os.path.join(ROOT, "output", "full_structural" + ("_homog" if HOMOG else "") + ".json"), "w"), indent=2)
    print("\nwrote output/full_structural.json")
