#!/usr/bin/env python3
"""scenarios_mpe.py -- SINGLE SOURCE OF TRUTH for the paper's scenario analysis.

Headline model = the psi-leadership model in `full_structural_mpe.py`:
  * symmetric store-traffic mu carries the coordination COUNT (the IC / following);
  * the outside option psi_i selects the ESCAPE leader (Salcobrand, lowest psi);
  * market share selects the RENT leader (Cruz Verde, largest share);
  * forward-simulated continuation value (Igami-Sugaya), staged DeltaV1 (no rent foresight),
    rent belief = exp(-chi)*b_now haircut.

The 11 scenarios are PINNED below.  Each is ONE knockout of the headline.
  MAIN (7 curves, paper body)     -- switch off one COORDINATION ingredient; plot the count over time.
  APPENDIX (4 robustness checks)  -- alternative specifications / identification.

Re-run after ANY belief/param change (the headline params live in output/hetmu_mpe.json):
    IJ=1 PERP_TERMINAL=1 python3 scenarios_mpe.py [main|appendix|all]      (default: all)
Writes  output/scenarios_mpe.json  with one block per scenario (moments + count-curve points).

NOTE (status 2026-06-22): the headline re-estimate under this structure is pending, so HEADLINE
below uses the research-calibrated psi + the belief/timing base from hetmu_mpe.json.  When
estimate_hetmu_mpe.py writes hetmu_mpe.json, this file reads it automatically -- no edit needed.
"""
import os, sys, json, importlib.util
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
OUT  = os.path.join(ROOT, "output")

# ============================== HEADLINE (psi model) ==============================
HEADLINE = dict(
    mu_bar      = 9.261,                    # FALLBACK; the live value (and scrut_m) are read from theta_json.  Symmetric mu -> count only
    psi_lead    = [0.60, 0.80, 0.00],       # outside option [CV, FA, SB]; CALIBRATED from the business mix (research), NOT estimated
    chain_share = [0.453, 0.309, 0.239],    # mean within-share [CV, FA, SB]; selects the rent leader
    tau_lead    = 3.0,                       # escape-leader softmax dispersion  -> SB-cart ~0.74
    tau_rent    = 0.12,                      # rent-leader   softmax dispersion  -> CV-pl   ~0.65
    theta_json  = "hetmu_mpe.json",          # estimated headline: belief/timing + mu_bar + scrut_m (learned enforcement belief)
)
# post-Oficio recovery = LEARNED enforcement belief (fs.SCRUT_LEARN=1, fs.SCRUT_M from theta_json); set per-scenario in run_one
# headline simulate_mpe flags (psi here is the IC's psi = OFF; the leader psi is the module global PSI_LEAD)
SIM_KW  = dict(psi=[0, 0, 0], onetime=True, w_window=26, arrivals_throughout=True)
B, SEED, N_OUTER = 240, 3, 6
REST = ["lam", "tau_eng", "t0", "a0", "b0", "zeta", "chi", "rho", "g"]   # belief/timing param order in the theta vector

# ============================== THE 11 SCENARIOS (PINNED) ==============================
# Each: (name, group, knockout).  Knockout keys understood by run_one():
#   bmode            -> simulate(bmode=...)          : "nobel" | "jump_only" | "learn_only"
#   no_alpha_collapse-> simulate(no_alpha_collapse=True)
#   mu_bar           -> override the common mu (0.0 = no spillover)
#   psi_lead         -> override the leader outside-option vector (None via psi_off)
#   psi_off          -> PSI_LEAD=None  (fall back to the mu-based leader; used by mu_only_fails)
#   mu_hetero        -> asymmetric kappa_chain (the OLD mu-leadership; used by mu_only_fails)
#   grid             -> sweep the mu spread to expose the count<->leader tension
#   absorbing        -> use the fixed-tier value_funcs (simulate, NO forward-sim override)   [NEW]
#   foresight        -> firms foresee the ban (value uses the post-ban regime pre-ban)       [NEW -- TODO]
#   env              -> {VAR: val} env flags requiring a fresh import (e.g. HOMOG); run as a SUBPROCESS
SCENARIOS = [
    # ---------------- MAIN (body): seven mechanism curves ----------------
    ("estimated",           "main", {}),
    ("no_belief",           "main", {"bmode": "nobel"}),         # b==1, the b^2 gate is wide open
    ("jump_no_learning",    "main", {"bmode": "jump_only"}),     # ad-ban signal zeta enters, but no S_t/F_t update
    ("learning_no_jump",    "main", {"bmode": "learn_only"}),    # zeta=0, the tally updates but no focal signal
    ("no_demand_collapse",  "main", {"no_alpha_collapse": True}),# alpha == alpha_0, so only belief (not the static payoff) can carry coordination
    ("no_spillover",        "main", {"mu_bar": 0.0}),            # mu=0, no store-traffic value -> below-cost war does not pay
    # ---------------- APPENDIX: value-function checks (justify the dynamic structure) ----------------
    ("myopic",              "appendix", {"myopic": True}),       # delta->0: no continuation value -> loses the rent + leadership -> decisions ARE dynamic
    ("perfect_foresight",   "appendix", {"foresight": True}),    # firms anticipate the ban at the Sep CONAR precursor -> onset too early -> the ban was UNANTICIPATED
    ("absorbing_value",     "appendix", {"absorbing": True}),    # each tier valued as a permanent perpetuity -> mistimes the rent -> the value must be TRANSITION-AWARE (forward-sim)
    # ---------------- APPENDIX: other robustness ----------------
    ("mu_only_fails",       "appendix", {"psi_off": True, "mu_hetero": [10.06, 9.72, 8.11], "grid": True}),  # heterogeneous mu cannot deliver the leadership; JUSTIFIES psi
    ("homogeneous_demand",  "appendix", {"env": {"HOMOG": "1"}}),# median-alpha (misspecified) demand
    ("psi_symmetric",       "appendix", {"psi_lead": [0.5, 0.5, 0.5]}),  # no outside-option asymmetry -> leader shares collapse toward uniform, count unchanged
]

# ============================== runner ==============================
def load_fs():
    spec = importlib.util.spec_from_file_location("fs", os.path.join(HERE, "full_structural_mpe.py"))
    fs = importlib.util.module_from_spec(spec); spec.loader.exec_module(fs); return fs

def headline_theta(fs):
    """Build the theta vector: [mu_bar] + belief/timing params + lam_cut, from the re-estimate if present.
    Returns (theta, src, d) where d is the full json (carries mu_bar, scrut_m, scrut_learn)."""
    src = HEADLINE["theta_json"] if os.path.exists(os.path.join(OUT, HEADLINE["theta_json"])) else "hetmu_mpe.json"
    d = json.load(open(os.path.join(OUT, src)))
    th = d["theta"]
    base = [th[k] for k in REST]
    mu_bar = d.get("mu_bar", HEADLINE["mu_bar"])
    return [mu_bar] + base + [th["lam_cut"]], src, d

CURVE_KEYS = ["w01_104", "w01_110", "w01_116", "w12_126", "w12_135", "w12_148"]
MOMENT_KEYS = ["loss", "tot01", "tot12", "lead_sb_cart", "lead_cv_pl", "peak", "sd", "war_mk",
               "succ_cart", "fail_war", "onset", "tier_lag"]   # tab:struct_robust needs these too

def run_one(fs, name, ko):
    """Run a single in-process scenario; returns a result dict (moments + curve points)."""
    theta, src, d = headline_theta(fs)
    mu_bar = ko.get("mu_bar", d.get("mu_bar", HEADLINE["mu_bar"]));  theta = [mu_bar] + theta[1:]
    mu = np.array([mu_bar] * 3)                                   # SYMMETRIC mu (count)
    # --- leadership globals ---
    fs.PSI_LEAD    = None if ko.get("psi_off") else ko.get("psi_lead", HEADLINE["psi_lead"])
    fs.CHAIN_SHARE = np.array(HEADLINE["chain_share"])
    fs.TAU_LEAD, fs.TAU_RENT = HEADLINE["tau_lead"], HEADLINE["tau_rent"]
    # --- learned enforcement belief (micro-founded post-Oficio recovery) ---
    fs.SCRUT_LEARN = int(d.get("scrut_learn", 1))
    fs.SCRUT_M     = float(d.get("scrut_m", 18.5))
    if ko.get("mu_hetero"):                                       # mu_only_fails: the OLD chain-specific mu carries leadership
        mu = np.array(ko["mu_hetero"]);  theta = [float(mu.mean())] + theta[1:]
    # --- simulate flags ---
    kw = dict(SIM_KW);
    for k in ("bmode", "no_alpha_collapse"):
        if k in ko: kw[k] = ko[k]
    if ko.get("foresight"):
        kw["t_belief"] = 88   # perfect foresight: firms read the 7-Sep CONAR precursor as the trigger (the belief jumps there); the value already anticipates the regime -> onset pulled to September
    _delta0 = fs.DELTA
    if ko.get("myopic"):
        fs.DELTA = 0.0        # myopic: no continuation value -> DeltaV1, DeltaV2 collapse to current-period premiums
    try:
        # --- run (absorbing = fixed-tier simulate; else the forward-sim nested fixed point) ---
        if ko.get("absorbing"):
            o = fs.simulate(theta, B=B, seed=SEED, kappa_chain=mu, **kw)   # NO dv_mpe override -> the fixed-tier (absorbing) value_funcs
        else:
            o = fs.simulate_mpe(theta, mu, B=B, seed=SEED, n_outer=N_OUTER, **kw)
    finally:
        fs.DELTA = _delta0    # always restore the discount
    moms = {k: float(o.get(k, np.nan)) for k in MOMENT_KEYS if k != "loss"}
    moms["loss"] = float(fs.loss(o))                              # loss is computed, not an output key
    res = {"name": name, "theta_src": src, "moments": moms,
           "curve": {k: float(o.get(k, np.nan)) for k in CURVE_KEYS}}
    if ko.get("grid"):                                            # mu_only_fails: sweep the spread to expose the tension
        res["grid"] = mu_spread_grid(fs, theta)
    return res

def mu_spread_grid(fs, theta):
    """mu_only_fails evidence: widening the mu spread sharpens SB-cart but collapses tot01 (no psi)."""
    fs.PSI_LEAD = None
    mean, ctr = 9.297, np.array([10.06, 9.72, 8.11]) - np.mean([10.06, 9.72, 8.11])
    rows = []
    for sc in (1.0, 1.5, 2.0, 2.5, 3.0):
        mu = mean + ctr * sc; th = [float(mu.mean())] + theta[1:]
        o = fs.simulate_mpe(th, mu, B=200, seed=SEED, n_outer=N_OUTER, **SIM_KW)
        rows.append({"scale": sc, "spread": float(mu.max() - mu.min()),
                     "tot01": float(o["tot01"]), "lead_sb_cart": float(o["lead_sb_cart"])})
    return rows

def run_env_subprocess(name, ko):
    """env-flag scenarios (e.g. HOMOG) need a fresh import; run this file recursively with the env set."""
    import subprocess
    env = dict(os.environ, **ko["env"], _SCEN_ONE=name)
    subprocess.run([sys.executable, __file__, "_one", name], env=env, check=True)

def main():
    which = sys.argv[1] if len(sys.argv) > 1 else "all"
    if which == "_one":                                          # internal: run a single env scenario in this process
        fs = load_fs(); name = sys.argv[2]
        ko = dict(next(k for n, g, k in SCENARIOS if n == name)); ko.pop("env", None)
        res = run_one(fs, name, ko)
        json.dump(res, open(os.path.join(OUT, f"scenarios_mpe_{name}.json"), "w"), indent=2); return
    fs = load_fs()
    results = {}
    for name, group, ko in SCENARIOS:
        if which not in ("all", group): continue
        print(f">>> [{group}] {name}", flush=True)
        if "env" in ko:
            run_env_subprocess(name, ko)
            results[name] = json.load(open(os.path.join(OUT, f"scenarios_mpe_{name}.json")))
        else:
            results[name] = run_one(fs, name, ko)
        print(f"    {results[name].get('moments', results[name].get('status'))}", flush=True)
    json.dump(results, open(os.path.join(OUT, "scenarios_mpe.json"), "w"), indent=2)
    print(f"\nwrote output/scenarios_mpe.json  ({len([r for r in results])} scenarios)")

if __name__ == "__main__":
    main()
