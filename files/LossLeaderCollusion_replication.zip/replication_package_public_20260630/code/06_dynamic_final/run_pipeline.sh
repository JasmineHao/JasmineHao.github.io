#!/usr/bin/env bash
# =====================================================================
# Master structural pipeline -- psi-leadership MPE headline (THE paper's reported spec).
# Every structural stage imports full_structural_mpe.py and reads/writes output/hetmu_mpe.json.
# A model change = edit full_structural_mpe.py, then run this top-to-bottom.  See PIPELINE.md.
# (The older het-mu / up-down line is retired to code/06_dynamic_final/_archive/.)
#
# Usage:  bash run_pipeline.sh [stage]
#   stage = all | descriptive | demand | headline | knockouts | robust | se | welfare | figures
#   (default: all)
# =====================================================================
set -uo pipefail
export PERP_TERMINAL=1 IJ=1          # MPE headline surface: perpetuity terminal + (i,j) product-firm demand
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"; cd "$ROOT"
export MPLCONFIGDIR="${MPLCONFIGDIR:-$ROOT/output/.mplconfig}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-$ROOT/output/.cache}"
mkdir -p "$MPLCONFIGDIR" "$XDG_CACHE_HOME"
PY="${PYTHON:-python3}"; STAGE="${1:-all}"; D="code/06_dynamic_final"; F="code/09_figures"
want(){ [[ "$STAGE" == all || "$STAGE" == "$1" ]]; }
run(){ echo; echo ">>> $*"; "$PY" "$@" || { echo "!! FAILED: $*"; exit 1; }; }

want demand && { echo "===== A. demand (alpha collapse + per-drug + IV/OLS robustness) ====="
  run code/03_demand/demand.py                  # pooled + per-drug alpha, sigma -> demand_params.json, r2_demand_alpha_per_drug.csv
  run code/03_demand/per_drug_post_costiv.py    # post-ban per-drug cost-IV alpha (Table tab:demand_hetero)
  run code/03_demand/iv_ols_robust.py           # OLS / rival-IV / cost-IV robustness (Table tab:iv_robust)
  ( cd code/03_demand && "$PY" estimate_single_collapse.py ); }   # single-collapse kappa-hat/delta-hat -> single_collapse.json (app:spec_robust)

want headline && { echo "===== B. headline estimate -> output/hetmu_mpe.json ====="
  run "$D/estimate_hetmu_mpe.py"; }

want knockouts && { echo "===== C. knockouts, each RE-ESTIMATED -> output/knockouts_reest_mpe.json (tab:spec_fit) ====="
  run "$D/knockouts_reest_mpe.py"; }

want robust && { echo "===== D. structural robustness ====="
  run "$D/scenarios_mpe.py"          # solution-concept checks (myopic / foresight / absorbing) -> tab:struct_robust
  # demand-spec robustness (tab:spec_robustness): FIRST re-estimate the two non-headline specs (warm-started),
  # THEN tabulate all three.  spec_reest writes hetmu_mpe_<sfx>.json; bare (sfx="") is guarded to refuse.
  DEMAND_SPEC=hetOLS SPEC_OUT_SFX=_hetOLS run "$D/spec_reest_mpe.py"     # -> hetmu_mpe_hetOLS.json
  HOMOG=1            SPEC_OUT_SFX=_homog  run "$D/spec_reest_mpe.py"     # -> hetmu_mpe_homog.json
  run "$D/spec_robustness_mpe.py"    # tabulate hetIV / hetOLS / homog -> tab:spec_robustness
  run "$D/rc_own_mpe.py"             # macro + ownership (RC-own / RC-real) -> tab:macro_own
  run "$D/rent_gates_mpe.py"
  run "$D/_drop48_reest.py"          # drop the 48 weak-collapse drugs, re-estimate -> app:drop48_robust
  run "$D/_sens_editor.py"           # leadership-dispersion + lam_cut sensitivity -> app:lead_robust / app:lamcut_robust
  # single-collapse STRUCTURAL re-estimates (app:spec_robust): proportional kappa=0.347, additive delta=0.053 (own panel caches)
  A_RATIO_OVERRIDE=0.347 SPEC_OUT_SFX=_kappa run "$D/estimate_hetmu_mpe.py"   # -> hetmu_mpe_kappa.json (loss 16.6)
  A_DELTA_OVERRIDE=0.053 SPEC_OUT_SFX=_delta run "$D/estimate_hetmu_mpe.py"   # -> hetmu_mpe_delta.json (loss 25.2)
  run "$D/appendix_experimentation_horizon.py"; }   # experimentation-horizon counterfactual (app:experimentation)

want se && { echo "===== E. standard errors ====="
  run "$D/profile_struct_se_mpe.py"     # quick internal curvature diagnostic
  if [[ "${RUN_BOOTSTRAP:-0}" == "1" ]]; then
    run "$D/bootstrap_se_mpe.py"        # expensive/resumable; headline table SEs
  else
    echo "bootstrap skipped (set RUN_BOOTSTRAP=1 to regenerate output/bootstrap_se_mpe.json)"
  fi; }

want welfare && { echo "===== F. welfare ====="
  run "$D/welfare.py"; }

want figures && { echo "===== G. figures (structural; descriptive figs 9_1/9_2/9_5/9_6 run on their own data) ====="
  run "$F/9_10_structural_fit.py"          # fig_full_structural, fig_spillover_model
  run "$F/9_14_figure6_specs.py"           # fig_belief_specs
  run "$D/appendix_full_path.py"           # fig_full_path  (2006->2008 endogenous-war path)
  run "$D/demand_ij_gof.py"                # fig_demand_ij_gof  (out-of-sample (i,j) demand fit)
  run "$F/9_13_war_attempts.py"            # fig_war_attempts
  run code/09_predictors/sequence_predictors.py; }   # lab-size sequence regression (tab:sequence_reg)

want descriptive && { echo "===== H. descriptive figures (data-based, §2-§3; non-fatal) ====="
  for s in 9_1_wholesale_cost 9_2_failed_attempts 9_3_prices_and_loss 9_4_lab_size_timing 9_5_example_coord 9_6_order; do
    echo; echo ">>> $F/$s.py"; "$PY" "$F/$s.py" || echo "!! (descriptive) $s failed -- non-fatal, continuing"; done; }

echo; echo "===== pipeline done ($STAGE) ====="
