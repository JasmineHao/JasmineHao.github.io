# Structural pipeline

This is the current source of truth for re-running the RAND structural results.

Run from the repo root:

```bash
bash code/06_dynamic_final/run_pipeline.sh [stage]
```

`stage` can be `all`, `demand`, `headline`, `knockouts`, `robust`, `se`,
`welfare`, `figures`, or `descriptive`. The default is `all`.
The `se` stage runs the quick profile-curvature diagnostic by default; set
`RUN_BOOTSTRAP=1` to regenerate the expensive/resumable 300-draw bootstrap SEs
reported in the manuscript.

The shell driver exports:

```bash
IJ=1
PERP_TERMINAL=1
```

These flags reproduce the published product-firm `(i,j)` demand surface and the
rolling-horizon stationary-perpetuity terminal condition.

## Dependency order

### A. Demand

| Script | Output | Role |
|---|---|---|
| `code/03_demand/demand.py` | `output/demand_params.json`, per-drug alpha tables | headline nested-logit demand |
| `code/03_demand/per_drug_post_costiv.py` | `output/r2_demand_post_costiv.csv` | post-ban cost-IV demand column |
| `code/03_demand/iv_ols_robust.py` | IV/OLS robustness rows | demand identification robustness |
| `code/03_demand/estimate_single_collapse.py` | `output/single_collapse.json` | single-collapse demand robustness |

### B. Headline estimate

| Script | Output |
|---|---|
| `code/06_dynamic_final/estimate_hetmu_mpe.py` | `output/hetmu_mpe.json` |

### C. Knockouts

| Script | Output |
|---|---|
| `code/06_dynamic_final/knockouts_reest_mpe.py` | `output/knockouts_reest_mpe.json` |

### D. Robustness

| Script | Role |
|---|---|
| `code/06_dynamic_final/scenarios_mpe.py` | solution-concept checks |
| `code/06_dynamic_final/spec_reest_mpe.py` | re-estimate alternative demand specs |
| `code/06_dynamic_final/spec_robustness_mpe.py` | assemble demand-spec robustness table |
| `code/06_dynamic_final/rc_own_mpe.py` | ownership and real-price robustness |
| `code/06_dynamic_final/rent_gates_mpe.py` | rent-gate checks |
| `code/06_dynamic_final/_drop48_reest.py` | weak-collapse drug-drop robustness |
| `code/06_dynamic_final/_sens_editor.py` | leadership and lambda-cut sensitivity |
| `code/06_dynamic_final/appendix_experimentation_horizon.py` | experimentation-horizon counterfactual |

### E. Standard errors

| Script | Output |
|---|---|
| `code/06_dynamic_final/profile_struct_se_mpe.py` | `output/struct_curvature_se_mpe.json` (quick internal curvature diagnostic; default `se` stage) |
| `code/06_dynamic_final/bootstrap_se_mpe.py` | `output/bootstrap_se_mpe.json` (headline table SEs; run with `RUN_BOOTSTRAP=1 bash code/06_dynamic_final/run_pipeline.sh se`) |

### F. Welfare

| Script | Output |
|---|---|
| `code/06_dynamic_final/welfare.py` | `output/welfare.json` |

### G. Figures and sequence table

| Script | Role |
|---|---|
| `code/09_figures/9_10_structural_fit.py` | structural fit figures |
| `code/09_figures/9_14_figure6_specs.py` | specification comparison figure |
| `code/06_dynamic_final/appendix_full_path.py` | full-path appendix figure |
| `code/06_dynamic_final/demand_ij_gof.py` | `(i,j)` demand goodness-of-fit figure |
| `code/09_figures/9_13_war_attempts.py` | failed-attempt examples |
| `code/09_predictors/sequence_predictors.py` | sequence regression table |

### H. Descriptive figures

`run_pipeline.sh descriptive` runs the current descriptive figure scripts in
`code/09_figures/`. These are non-fatal inside the driver because they depend on
older figure inputs and should not block structural robustness work.

## Model files

`full_structural_mpe.py` is the current headline structural model. Supporting
scripts import it directly. `full_structural.py` is retained for the sequence
predictor table and older diagnostics, but the headline estimator is the MPE
line above.

Superseded dynamic variants are archived under `code/06_dynamic_final/_archive/`
and `code/_archive/`.
