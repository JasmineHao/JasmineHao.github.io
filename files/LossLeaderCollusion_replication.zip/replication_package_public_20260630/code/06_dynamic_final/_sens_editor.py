"""Editor sensitivity checks (Phase 1a leadership tau, Phase 1b lam_cut). Existing model, headline theta."""
import os, json, numpy as np, importlib.util
os.environ.setdefault('IJ','1'); os.environ.setdefault('PERP_TERMINAL','1')
spec=importlib.util.spec_from_file_location('fs',os.path.join(os.path.dirname(os.path.abspath(__file__)),'full_structural_mpe.py')); fs=importlib.util.module_from_spec(spec); spec.loader.exec_module(fs)
d=json.load(open(os.path.join(fs.ROOT,'output','hetmu_mpe.json')))
mu_bar=d['kappa_mean']; th=d['theta']; w=d['w_window']; scrut_m=d['scrut_m']
base=[mu_bar, th['lam'], th['tau_eng'], th['t0'], th['a0'], th['b0'], th['zeta'], th['chi'], th['rho'], th['g'], th['lam_cut']]
mu=np.array([mu_bar]*3)
fs.PSI_LEAD=[0.60,0.80,0.00]; fs.CHAIN_SHARE=np.array([0.453,0.309,0.239]); fs.SCRUT_LEARN=1; fs.SCRUT_M=scrut_m
def sim(theta11,B=60):
    return fs.simulate_mpe(theta11, mu, B=B, n_outer=6, psi=[0.0,0.0,0.0], onetime=True, w_window=w, arrivals_throughout=True)
print('=== Phase 1a: tau_lead = tau_rent leadership sensitivity (does the ORDERING survive?) ===',flush=True)
for tl,tr,lab in [(3.0,0.12,'headline 3.0/0.12'),(0.12,0.12,'common 0.12'),(3.0,3.0,'common 3.0'),(1.0,1.0,'common 1.0')]:
    fs.TAU_LEAD=tl; fs.TAU_RENT=tr; M=sim(base); lc=M['leadS_cart']; lp=M['leadS_pl']
    print(f'  {lab:18} cart CV/FA/SB={[round(100*z) for z in lc]} SBleads={lc[2]==max(lc)} | rent CV/FA/SB={[round(100*z) for z in lp]} CVleads={lp[0]==max(lp)}',flush=True)
print('=== Phase 1b: lam_cut perturbation (is cartel stability driven by the lam_cut estimate?) ===',flush=True)
fs.TAU_LEAD=3.0; fs.TAU_RENT=0.12
for mult,lab in [(0.5,'-50%'),(1.0,'headline'),(1.5,'+50%'),(2.0,'+100%')]:
    th2=list(base); th2[10]=base[10]*mult
    M=sim(th2); print(f'  lam_cut {lab:8} ({th2[10]:.3f}): succ_cart={M["succ_cart"]:.0f} (data 284) tot01={M["tot01"]:.0f} (data 220) | dev_war={M["dev_war"]:.0f} dev_cart={M["dev_cart"]:.0f} dev_pl={M["dev_pl"]:.0f}',flush=True)
print('DONE',flush=True)
