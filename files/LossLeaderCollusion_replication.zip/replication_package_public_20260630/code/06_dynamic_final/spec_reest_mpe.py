"""spec_reest_mpe.py -- WARM-STARTED gate-free re-estimate of one demand spec for tab:spec_robustness.
The fresh-scan estimator wanders into bad basins for the gate-free model; this warm-starts a single Powell
from the headline (the proven rent_gates_mpe.py pattern) so the spec optimum is found reliably.  One spec
per invocation (demand set by env): DEMAND_SPEC=hetOLS / HOMOG=1 / (neither = hetIV headline).
Writes output/hetmu_mpe_<sfx>.json in the headline format.

Run:  IJ=1 PERP_TERMINAL=1 [DEMAND_SPEC=hetOLS|HOMOG=1] SPEC_OUT_SFX=_hetOLS python3 spec_reest_mpe.py
"""
import os, json, importlib.util
import numpy as np
from scipy.optimize import minimize
os.environ.setdefault("IJ", "1"); os.environ.setdefault("PERP_TERMINAL", "1")
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
spec = importlib.util.spec_from_file_location("fs", os.path.join(ROOT, "code", "06_dynamic_final", "full_structural_mpe.py"))
fs = importlib.util.module_from_spec(spec); spec.loader.exec_module(fs)
fs.PSI_LEAD = [0.60, 0.80, 0.00]; fs.CHAIN_SHARE = np.array([0.453, 0.309, 0.239])
fs.TAU_LEAD = 3.0; fs.TAU_RENT = 0.12; fs.SCRUT_LEARN = 1
RHO_FIX = 2.0
BND = dict(mu_bar=(6.0, 14.0), lam=(0.05, 0.95), tau_eng=(30.0, 400.0), t0=(98, 106), a0=(0.3, 8.0),
           b0=(5.0, 150.0), zeta=(40.0, 3000.0), chi=(1.0, 4.0), g=(0.0, 1.5), lam_cut=(0.0, 0.30), scrut_m=(5.0, 60.0))
K = list(BND); bounds = [BND[k] for k in K]
REST = ["lam", "tau_eng", "t0", "a0", "b0", "zeta", "chi", "g"]
H = json.load(open(os.path.join(ROOT, "output", "hetmu_mpe.json")))   # gate-free headline (warm start)
WARM = [float(H["mu_bar"])] + [float(H["theta"][k]) for k in REST] + [float(H["theta"]["lam_cut"]), float(H["scrut_m"])]

def clip(x): return [min(max(float(x[i]), bounds[i][0]), bounds[i][1]) for i in range(len(K))]
def unpack(x):
    xc = clip(x)
    theta = [xc[0], xc[1], xc[2], xc[3], xc[4], xc[5], xc[6], xc[7], RHO_FIX, xc[8], xc[9]]
    return theta, np.array([xc[0]] * 3), xc[10], xc
_DV = {"v": None}
def obj(x, B=16, n_outer=3, warm=False):
    theta, mu, sm, _ = unpack(x); fs.SCRUT_M = sm
    o, dv = fs.simulate_mpe(theta, mu, B=B, n_outer=n_outer, final_sim=False, psi=[0.0, 0.0, 0.0],
                            onetime=True, w_window=26.0, arrivals_throughout=True,
                            dv_init=(_DV["v"] if warm else None), return_dv=True)
    if warm: _DV["v"] = dv
    return fs.loss(o)
# Published variant optima (verified basins).  The headline-warm Powell drifts into a WORSE basin for
# some specs (homogeneous demand: warm-Powell 33.7 vs the published 27.9), so we ALSO polish from the
# published variant seed and keep whichever start reaches the lower loss.  Order = K.
PUBLISHED = {
    "_homog":  [9.0236, 0.3416, 53.767, 102.24, 2.1092, 128.9588, 325.0913, 2.5892, 0.6443, 0.0884, 17.0827],
    "_hetOLS": [9.2612, 0.6339, 124.0338, 102.8383, 1.803, 128.8448, 306.903, 2.0846, 0.5729, 0.0885, 14.7595],
}
_pub = PUBLISHED.get(os.environ.get("SPEC_OUT_SFX", ""))
_starts = [WARM] + ([_pub] if _pub is not None else [])
best = None
for _x0 in _starts:
    _DV["v"] = None
    _f0 = obj(_x0, B=20, n_outer=4)                                   # warm baseline at HIGH B (robust)
    if best is None or _f0 < best[0]: best = (_f0, clip(_x0))
    _DV["v"] = None
    res = minimize(lambda x: obj(x, B=16, n_outer=3, warm=True), np.array(_x0, float), method="Powell",
                   bounds=bounds, options=dict(maxiter=60, xtol=3e-3, ftol=3e-3))
    f = obj(res.x, B=20, n_outer=4)
    if f < best[0]: best = (f, clip(res.x))
theta, mu, sm, xc = unpack(best[1]); fs.SCRUT_M = sm
M = fs.simulate_mpe(theta, mu, B=240, n_outer=6, psi=[0.0, 0.0, 0.0], onetime=True, w_window=26.0, arrivals_throughout=True)
_to = dict(zip(REST, [float(v) for v in xc[1:9]])); _to["rho"] = RHO_FIX; _to["lam_cut"] = float(xc[9])
out = dict(mu_bar=float(xc[0]), theta=_to, scrut_m=float(xc[10]), loss=float(fs.loss(M)),
           moments={k: float(M[k]) for k in M if not isinstance(M[k], (list, np.ndarray))}, empirical=H["empirical"])
sfx = os.environ.get("SPEC_OUT_SFX", "")
if not sfx:                                                            # guard: never clobber the headline json
    raise SystemExit("spec_reest_mpe.py: SPEC_OUT_SFX empty -> would overwrite the headline hetmu_mpe.json. "
                     "Run as  DEMAND_SPEC=hetOLS SPEC_OUT_SFX=_hetOLS  or  HOMOG=1 SPEC_OUT_SFX=_homog.")
json.dump(out, open(os.path.join(ROOT, "output", f"hetmu_mpe{sfx}.json"), "w"), indent=2)
print(f"WROTE hetmu_mpe{sfx}.json  loss {out['loss']:.2f}  mu_bar {xc[0]:.2f}  tot01 {M['tot01']:.0f}  tot12 {M['tot12']:.0f}  SBcart {M['lead_sb_cart']:.2f}")
