"""bootstrap_se_mpe.py -- nonparametric drug-resample bootstrap SEs for the psi-leadership MPE headline.

The step-function SMM criterion has no moment Jacobian, so the sandwich variance does not apply.
The paper reports these bootstrap SEs in the headline parameter table; profile-curvature SEs are
retained only as an internal diagnostic.  Design: the 220 drugs are the resampling unit (every moment is an
aggregate over drugs).  For each replication we resample 220 drugs WITH REPLACEMENT (reindexed to distinct
ids so duplicates count), recompute the empirical moments on the resample, and RE-ESTIMATE theta warm-started
at theta_hat with a tight local polish -- the warm start keeps each replicate in the theta_hat basin so the
spread is sampling variation, not the multimodal search drift.  SE = sd(theta_b).  Parallel over replications.

Run:  NBOOT=60 NPROC=8 IJ=1 PERP_TERMINAL=1 python3 bootstrap_se_mpe.py
      -> output/bootstrap_se_mpe.json
"""
import os, json, importlib.util
import numpy as np, pandas as pd
from scipy.optimize import minimize
import multiprocessing as _mp
try: _mp.set_start_method('fork', force=True)
except RuntimeError: pass
from multiprocessing import Pool
os.environ.setdefault("IJ", "1"); os.environ.setdefault("PERP_TERMINAL", "1")
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
spec = importlib.util.spec_from_file_location("fs", os.path.join(ROOT, "code", "06_dynamic_final", "full_structural_mpe.py"))
fs = importlib.util.module_from_spec(spec); spec.loader.exec_module(fs)
fs.PSI_LEAD = [0.60, 0.80, 0.00]; fs.CHAIN_SHARE = np.array([0.453, 0.309, 0.239])
fs.TAU_LEAD = 3.0; fs.TAU_RENT = 0.12; fs.SCRUT_LEARN = 1

H = json.load(open(os.path.join(ROOT, "output", "hetmu_mpe.json"))); th = H["theta"]
K   = ["mu_bar", "lam", "tau_eng", "t0", "a0", "b0", "zeta", "chi", "g", "lam_cut", "scrut_m"]
XHAT = [H["mu_bar"], th["lam"], th["tau_eng"], th["t0"], th["a0"], th["b0"], th["zeta"], th["chi"], th["g"], th["lam_cut"], H["scrut_m"]]
BND = [(6, 14), (0.05, 0.95), (30, 400), (98, 106), (0.3, 8), (5, 150), (40, 3000), (1, 4), (0, 1.5), (0, 0.30), (5, 60)]
RHO_FIX = 2.0; W = float(H["w_window"])
D0 = fs.D.copy(); EV0 = fs._ev.copy(); ORIG = D0.DrugID.values
_EVG = {d: g.copy() for d, g in EV0.groupby("DrugID")}                  # drug -> its ledger rows (fast resample)
DRAWS = os.path.join(ROOT, "output", "_boot_draws"); os.makedirs(DRAWS, exist_ok=True)

def build_emp(D, ev):
    """Recompute fs's empirical-moment dict on a resampled (D, ev) -- mirrors full_structural_mpe.py lines 325-394."""
    DC = D.dropna(subset=["coord_wk"]).copy()
    co = ev[ev.kind == "coordination"]; dw = ev[ev.kind == "deviation_war"]; fa = ev[ev.kind == "failed_attempt"]
    t1 = co[(co.in_window) & (co.to_tier == 1)].wk.median(); t2w = co[(co.in_window) & (co.to_tier == 2)].wk.median()
    pre = len(dw[dw.wk < fs.AUG]) / max(1, dw[dw.wk < fs.AUG].wk.nunique())
    late = len(dw[(dw.wk >= fs.AUG) & (dw.wk < fs.BAN)]) / max(1, fs.BAN - fs.AUG)
    t2 = co[co.to_tier == 2].wk; grand = DC.coord_wk.mean(); gg = DC.groupby("lab").coord_wk
    btw = float((gg.count() * (gg.mean() - grand) ** 2).sum() / max(1e-9, ((DC.coord_wk - grand) ** 2).sum()))
    logW = np.log(DC.groupby("lab").W.first().astype(float)); cwk = DC.groupby("lab").coord_wk.median().astype(float)
    lab_idx = logW.index.intersection(cwk.index)
    logW, cwk = logW.loc[lab_idx], cwk.loc[lab_idx]
    corr_sz = float(np.corrcoef(logW.values, cwk.values)[0, 1]) if len(lab_idx) > 1 else 0.0
    spear = float(fs.spearmanr(logW.values, cwk.values).correlation) if len(lab_idx) > 1 else 0.0
    E = dict(tot01=len(DC), tot12=int((co.to_tier == 2).sum()), onset=float(np.percentile(DC.coord_wk, 5)),
             peak=float(DC.coord_wk.round().median()), sd=float(DC.coord_wk.std()),
             corr_sz=corr_sz,
             war_mk=float(((D.pw - D.c) / D.pw).median()), lab_sd=float(DC.groupby("lab").coord_wk.min().std()),
             tier_lag=float(t2w - t1), war_ratio=float(late / max(0.1, pre)),
             q25=float(np.percentile(DC.coord_wk, 25)), q75=float(np.percentile(DC.coord_wk, 75)),
             peak2=float(t2.median()), sd2=float(t2.std()), btw_lab=btw, spear_sz=spear,
             succ_war=fs._cnt(co, fs.P_WAR), succ_cart=fs._cnt(co, fs.P_CART), succ_pe=fs._cnt(co, fs.P_PE), succ_pl=fs._cnt(co, fs.P_PL),
             fail_war=fs._cnt(fa, fs.P_WAR), fail_cart=fs._cnt(fa, fs.P_CART), fail_pe=fs._cnt(fa, fs.P_PE), fail_pl=fs._cnt(fa, fs.P_PL),
             dev_war=fs._cnt(dw, fs.P_WAR), dev_cart=fs._cnt(dw, fs.P_CART), dev_pe=fs._cnt(dw, fs.P_PE), dev_pl=fs._cnt(dw, fs.P_PL),
             lead_sb_cart=fs._share(co, fs.P_CART, "SB"), lead_cv_pl=fs._share(co, fs.P_PL, "CV"), lead_sb_fail_pe=fs._share(fa, fs.P_PE, "SB"),
             ldS_war=fs._share(co, fs.P_WAR, "SB"), ldS_cart=fs._share(co, fs.P_CART, "SB"), ldS_post=fs._share(co, (fs.P_PE[0], fs.P_PL[1]), "SB"),
             ldF_war=fs._share(fa, fs.P_WAR, "SB"), ldF_cart=fs._share(fa, fs.P_CART, "SB"), ldF_post=fs._share(fa, (fs.P_PE[0], fs.P_PL[1]), "SB"),
             n_leaders=float(np.mean([len(fs._leaders_of(r)) for _, r in co.iterrows()])) if len(co) else 1.0)
    for w in (104, 110, 116): E[f"w01_{w}"] = int((DC.coord_wk <= w).sum())
    for w in (126, 135, 148): E[f"w12_{w}"] = int((t2 <= w).sum())
    return E

def resample(seed):
    rng = np.random.default_rng(seed); idx = rng.integers(0, len(D0), len(D0))
    D = D0.iloc[idx].copy(); D["DrugID"] = range(len(D)); D = D.reset_index(drop=True)
    parts = []
    for new_i, row_i in enumerate(idx):
        ev_i = _EVG.get(ORIG[row_i])
        if ev_i is not None and len(ev_i): e = ev_i.copy(); e["DrugID"] = new_i; parts.append(e)
    ev = pd.concat(parts, ignore_index=True) if parts else EV0.iloc[:0].copy()
    return D, ev

def _clip(x): return [min(max(float(x[i]), BND[i][0]), BND[i][1]) for i in range(11)]
def unpack(x):
    xc = _clip(x); theta = [xc[0], xc[1], xc[2], xc[3], xc[4], xc[5], xc[6], xc[7], RHO_FIX, xc[8], xc[9]]
    return theta, np.array([xc[0]] * 3), xc[10], xc

def fit_one(seed):
    fp = os.path.join(DRAWS, f"d{seed:05d}.json")
    if os.path.exists(fp):                                  # resume: this replication is already saved
        return json.load(open(fp))["theta"]
    D, ev = resample(seed); fs.D = D; fs.EMP = build_emp(D, ev); dvc = {"v": None}
    def obj(x):
        theta, mu, sm, _ = unpack(x); fs.SCRUT_M = sm
        o, dv = fs.simulate_mpe(theta, mu, B=16, n_outer=(1 if dvc["v"] is not None else 3), final_sim=False,
                                psi=[0, 0, 0], onetime=True, w_window=W, arrivals_throughout=True,
                                dv_init=dvc["v"], return_dv=True)
        dvc["v"] = dv
        return fs.loss(o)
    res = minimize(obj, np.array(XHAT, float), method="Powell", bounds=BND,
                   options=dict(maxiter=10, xtol=6e-3, ftol=6e-3))
    xc = _clip(res.x)
    json.dump({"seed": int(seed), "theta": xc}, open(fp, "w"))   # SAVE every bootstrap estimate
    return xc

def aggregate():
    """Read every saved draw and write bootstrap_se_mpe.json (SE + 95% percentile CI + the full draws)."""
    files = sorted(f for f in os.listdir(DRAWS) if f.endswith(".json"))
    arr = np.array([json.load(open(os.path.join(DRAWS, f)))["theta"] for f in files]) if files else np.empty((0, 11))
    Bd = len(arr)
    if Bd < 2: print(f"only {Bd} draws so far"); return arr, Bd
    se = arr.std(axis=0, ddof=1); mean = arr.mean(axis=0)
    out = {K[i]: dict(est=round(XHAT[i], 4), boot_se=round(float(se[i]), 4), boot_mean=round(float(mean[i]), 4),
                      ci95=[round(float(np.percentile(arr[:, i], 2.5)), 4), round(float(np.percentile(arr[:, i], 97.5)), 4)])
           for i in range(11)}
    json.dump(dict(method="nonparametric drug-resample bootstrap (warm-started local polish)", n_boot=int(Bd),
                   params=out, draws={K[i]: [round(float(arr[b, i]), 5) for b in range(Bd)] for i in range(11)}),
              open(os.path.join(ROOT, "output", "bootstrap_se_mpe.json"), "w"), indent=2)
    curv = {"mu_bar": .15, "lam": .18, "tau_eng": 37, "t0": 1.2, "a0": .32, "b0": 61, "zeta": 41, "chi": .10, "g": .19, "lam_cut": .006, "scrut_m": 7.1}
    print(f"\nBOOTSTRAP SE (drug-resample, B={Bd}):")
    print(f"  {'param':9s}{'est':>9}{'boot_se':>10}{'curv_se':>9}")
    for i in range(11):
        print(f"  {K[i]:9s}{XHAT[i]:>9.3f}{se[i]:>10.3f}{curv.get(K[i],0):>9}")
    return arr, Bd

if __name__ == "__main__":
    import sys
    chk = build_emp(D0, EV0)
    diffs = {k: (chk[k], fs.EMP[k]) for k in fs.EMP if abs(chk.get(k, 0) - fs.EMP[k]) > 1e-6}
    print("build_emp reproduces fs.EMP:", "YES" if not diffs else f"NO -> {list(diffs)[:5]}", flush=True)
    if not (len(sys.argv) > 1 and sys.argv[1] == "agg"):     # "agg" = aggregate only (monitor); else run + aggregate
        B = int(os.environ.get("NBOOT", "300")); NPROC = int(os.environ.get("NPROC", "8"))
        print(f"running up to {B} drug-resample reps on {NPROC} procs (resumable; each draw saved to output/_boot_draws/) ...", flush=True)
        with Pool(NPROC) as p:
            p.map(fit_one, list(range(1, B + 1)))
    aggregate()
