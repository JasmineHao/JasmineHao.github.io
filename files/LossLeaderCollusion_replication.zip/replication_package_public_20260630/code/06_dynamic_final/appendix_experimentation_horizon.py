"""appendix_experimentation_horizon.py  --  How long would pure experimentation take?

Counterfactual: the ad ban's PAYOFF effect happens (post-ban demand, so G01<0 and the
coordinated price IS a static best response), but there is NO focal jump (zeta=0).  Firms must
experiment their way to the belief through the Beta-Binomial tally alone.  Post-ban an unmatched
lift just waits and is retried (no revert), so the belief is monotone in the success count S:
        b_t = (a0 + S_t) / (a0 + b0 + S_t).
A drug coordinates in a week iff it is tested (prob b, the leader lifts) AND both followers match
(prob b^2, the higher-order-belief gate) AND holding beats undercutting (logit, ~1 post-ban):
        p_j(b) = b * b^2 * logit( (b*delta*dV1_j - G01_post_j) / tau ).
We roll this forward and report the years until the wave ignites.  The b^2 gate makes the
low-belief war a near-absorbing trap: experimentation takes centuries; the focal jump did it in 4
months.  Run: python3 appendix_experimentation_horizon.py
"""
import os, json, importlib.util
import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
spec = importlib.util.spec_from_file_location("fs", os.path.join(ROOT, "code", "06_dynamic_final", "full_structural.py"))
fs = importlib.util.module_from_spec(spec); spec.loader.exec_module(fs)

# Paper Table-9 theta (the documented v4 estimate; result is robust to the small theta differences)
KAPPA, A0, B0 = 9.371, 1.315, 101.974
TAU, DELTA, J = fs.TAU, fs.DELTA, fs.J

# Per-drug POST-BAN undercut gain (G01<0) and forward-looking escape value dV1 (take a post-ban week).
G01_post = KAPPA * fs.DS["ds01_post"] + fs.DS["mg01_post"]          # [J], <0 post-ban
DV1ch = fs.value_funcs(KAPPA)                                       # list of 3 [Tn,J]
dV1 = DELTA * np.mean([DV1ch[i] for i in range(3)], axis=0)[-1]     # [J], last (post-ban) week
prior = A0 / (A0 + B0)
print(f"belief prior b0 = a0/(a0+b0) = {prior:.4f}   (~{prior*100:.1f}% expect a match in the war)")
print(f"post-ban G01 (median) = {np.median(G01_post):.3f}  (<0 -> coordination sustainable)")
print(f"observed wave with the focal jump: ~17 weeks (4 months) to {J} drugs\n")

WK_PER_YR = 52.0
# Static-Nash set: drugs whose post-ban undercut gain is already negative (coordination is a one-shot
# best response).  The rest -- the most-elastic drugs with G01_post>0 -- are only DYNAMICALLY
# sustainable: at any belief the tally can reach they stay undercut, so experimentation never lands them.
static_nash = G01_post < 0
n_sn = int(static_nash.sum())
print(f"static-Nash drugs (G01_post<0): {n_sn} / {J}   |   only-dynamic (most elastic): {J - n_sn}")

# Deterministic expected time: the b^2 gate makes each success a slow draw; sum the expected waits.
# E[weeks to coordinate the next drug at success count S] = 1 / sum_j(uncoordinated) b^3 * hold_j .
order = np.argsort(G01_post)                                       # easiest (most negative G01) first
E = 0.0
mile = {}
for S in range(n_sn):                                              # only the static-Nash drugs can land
    b = (A0 + S) / (A0 + B0 + S)
    unc = order[S:n_sn]                                            # remaining static-Nash drugs
    hold = 1.0 / (1.0 + np.exp((G01_post[unc] - b * dV1[unc]) / TAU))
    E += 1.0 / (b ** 3 * hold).sum()
    if S + 1 in (1, 55, 110, n_sn): mile[S + 1] = E
for n, wks in mile.items():
    tag = " (the whole static-Nash set)" if n == n_sn else ""
    print(f"  E[weeks to {n:3d} drugs]{tag:30s}: {wks:>11.0f} wk = {wks/WK_PER_YR:>8.1f} yr")
print(f"\nThe most-elastic {J - n_sn} drugs never coordinate by experimentation (need the belief jump).")
print(f"Focal jump: {J} drugs in ~17 weeks (4 months)  =>  experimentation is ~{mile[n_sn]/17:,.0f}x slower to the bulk.")
