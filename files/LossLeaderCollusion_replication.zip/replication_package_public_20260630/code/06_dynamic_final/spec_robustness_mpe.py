"""spec_robustness_mpe.py -- assemble appendix table tab:spec_robustness across THREE demand specs under the
psi-leadership + learned-belief HEADLINE.  Reads:
  output/hetmu_mpe.json          = hetIV (the headline demand, rival-price IV alpha_j)
  output/hetmu_mpe_hetOLS.json   = per-drug OLS alpha_j   (DEMAND_SPEC=hetOLS re-estimate)
  output/hetmu_mpe_homog.json    = median alpha           (HOMOG=1 re-estimate)
Prints a LaTeX-ready body (Panel A params, Panel B moments) for the appendix table.  Data column = the
empirical block in hetmu_mpe.json.  NOTE: the scrutiny param is now m (enforcement skepticism), not kappa.
"""
import os, json
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SPECS = [("", "Het.\\ IV"), ("_hetOLS", "Het.\\ OLS"), ("_homog", "Homog.")]
J = {lab: json.load(open(os.path.join(ROOT, "output", f"hetmu_mpe{sfx}.json"))) for sfx, lab in SPECS}
EMP = J["Het.\\ IV"]["empirical"]
LABS = [lab for _, lab in SPECS]

def th(d, k):
    return d["mu_bar"] if k == "mu_bar" else d["scrut_m"] if k == "scrut_m" else d["theta"][k]

PARAMS = [("mu_bar", r"$\bar\mu$\quad mean store-traffic value", 2), ("lam", r"$\lambda$\quad reach-out scale", 2),
          ("tau_eng", r"$\tau_e$\quad reach-out temperature", 0), ("t0", r"$t_0$\quad organization onset (wk)", 0),
          ("a0", r"$a_0$\quad belief prior", 2), ("b0", r"$b_0$\quad belief prior", 0),
          ("zeta", r"$\zeta$\quad ad-ban pseudo-successes", 0), ("chi", r"$\chi$\quad rent-tier discount", 2),
          ("scrut_m", r"$m$\quad enforcement skepticism", 2), ("g", r"$g$\quad Aug.\ campaign", 2)]
MOMS = [("tot01", "First coordinations", 0), ("tot12", "Rent steps", 0),
        ("fail_war", "Failed war attempts", 0), ("succ_cart", "Cartel successes", 0),
        ("succ_pl", "Post-late successes", 0), ("peak", "Peak week", 0), ("sd", "Wave SD (weeks)", 1),
        ("tier_lag", "$1\\!\\to\\!2$ lag (weeks)", 1), ("btw_lab", "Between-lab var.\\ share", 2),
        ("spear_sz", "Spearman(size, week)", 2), ("lead_sb_cart", "SB leads cartel wave", 2),
        ("lead_cv_pl", "CV leads post-invest.\\ rent", 2)]

print("losses:", {lab: round(J[lab]["loss"], 1) for lab in LABS})
print("\n=== header ===\n & Data & " + " & ".join(LABS) + r" \\")
print("\n=== Panel A (params) ===")
for k, lab, dec in PARAMS:
    print(f"{lab}  &  & " + " & ".join(f"${th(J[L], k):.{dec}f}$" for L in LABS) + r" \\")
print(r"\textbf{SMM loss}  &  & " + " & ".join(f"$\\mathbf{{{J[L]['loss']:.1f}}}$" for L in LABS) + r" \\")
print("\n=== Panel B (fit) ===")
for k, lab, dec in MOMS:
    print(f"{lab}  & ${EMP[k]:.{dec}f}$ & " + " & ".join(f"${J[L]['moments'][k]:.{dec}f}$" for L in LABS) + r" \\")
