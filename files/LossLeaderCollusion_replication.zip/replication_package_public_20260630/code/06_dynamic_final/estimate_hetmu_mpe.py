"""estimate_hetmu_mpe.py -- HEADLINE re-estimation under the psi-LEADERSHIP structure.

The chain asymmetry no longer lives in the store-traffic spillover mu.  It is split into TWO calibrated,
NON-circular leadership primitives, while mu is now SYMMETRIC and carries only the coordination COUNT:
  * ESCAPE leader (Salcobrand): the chain-specific OUTSIDE OPTION psi_i (reliance on non-drug business);
    psi is CALIBRATED from the business mix (FNE requerimiento / CMF filings / TDLC Sentencia 119/2012),
    NOT estimated from leadership -> answers the editor's FOC-inversion circularity charge.
  * RENT leader (Cruz Verde): market SHARE (the dominant chain leads the supra-competitive increase).
psi enters as the module global fs.PSI_LEAD; the within-share enters as fs.CHAIN_SHARE.  WHO-INITIATES is
psi/share-driven; WHO-FOLLOWS (the IC) stays on the symmetric mu, so the count is untouched.

13 FREE params:  mu_bar (1, symmetric) + 9 belief/timing + lam_cut + TAU_LEAD + TAU_RENT.
  TAU_LEAD  = escape-leader softmax dispersion -> sets lead_sb_cart (the cartel wave).
  TAU_RENT  = rent-leader  softmax dispersion -> sets lead_cv_pl  (the post-rent increase).
FIXED (calibrated, NOT estimated):  psi_lead, chain_share.  chi STAYS = the antitrust-exposure HAIRCUT on
the rent belief (b_rent = exp(-chi)*b_now); a rising own-learning rent belief cascades, so the cap is
structurally required (verified three ways), not a lazy discount.

Run: IJ=1 PERP_TERMINAL=1 python3 estimate_hetmu_mpe.py  ->  output/hetmu_mpe.json
"""
import os, importlib.util, json, time
import numpy as np
from scipy.optimize import minimize

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
spec = importlib.util.spec_from_file_location("fs", os.path.join(ROOT, "code", "06_dynamic_final", "full_structural_mpe.py"))
fs = importlib.util.module_from_spec(spec); spec.loader.exec_module(fs)

# ---- FIXED (calibrated, non-circular) leadership primitives ----
PSI_LEAD    = [0.60, 0.80, 0.00]                 # outside option [CV, FA, SB]; from the business mix (research brief)
CHAIN_SHARE = np.array([0.453, 0.309, 0.239])    # mean within-share [CV, FA, SB]; selects the rent leader
TAU_LEAD    = 3.0    # escape-leader dispersion -> CALIBRATED to the three leadership shares (SB cart 0.74, SB fail_pe 0.83)
TAU_RENT    = 0.12   # rent-leader   dispersion -> CALIBRATED to lead_cv_pl 0.65.  Each maps ~1:1 to one leadership moment
fs.PSI_LEAD = PSI_LEAD
fs.CHAIN_SHARE = CHAIN_SHARE
fs.TAU_LEAD = TAU_LEAD
fs.TAU_RENT = TAU_RENT
fs.SCRUT_LEARN = 1   # MICRO-FOUNDED post-Oficio recovery: the rent-match gate is a LEARNED enforcement-risk belief
                     # rsc=(1+k)/(1+k+SCRUT_M), k=quiet weeks survived since the Oficio; SCRUT_M = skeptical prior.
                     # No success term -> cannot cascade.  Replaces the ad-hoc rsc(t) calendar trend + the old rho.
RHO_FIX = 2.0        # rho fed ONLY the legacy time-trend (now off under SCRUT_LEARN); fixed, not estimated

W_FIXED = 26.0
BND = dict(mu_bar=(6.0, 14.0),
           lam=(0.05, 0.95), tau_eng=(30.0, 400.0), t0=(98, 106), a0=(0.3, 8.0), b0=(5.0, 150.0),
           zeta=(40.0, 3000.0), chi=(1.0, 4.0), g=(0.0, 1.5),
           lam_cut=(0.0, 0.30), scrut_m=(5.0, 60.0))   # 11 free: mu_bar + 8 belief/timing + lam_cut + SCRUT_M.  rho dropped (dead); leadership scales fixed
K = list(BND); bounds = [BND[k] for k in K]
REST = ["lam", "tau_eng", "t0", "a0", "b0", "zeta", "chi", "g"]   # 8 belief/timing (rho removed)
def _clip(x): return [min(max(float(x[i]), bounds[i][0]), bounds[i][1]) for i in range(len(K))]

def unpack(x):
    mu_bar = float(x[0])
    lam, tau_eng, t0, a0, b0, zeta, chi, g = [float(v) for v in x[1:9]]   # 8 belief/timing
    lam_cut, scrut_m = float(x[9]), float(x[10])
    theta11 = [mu_bar, lam, tau_eng, t0, a0, b0, zeta, chi, RHO_FIX, g, lam_cut]   # rho slot = fixed dummy (unused under SCRUT_LEARN)
    mu = np.array([mu_bar, mu_bar, mu_bar])                              # SYMMETRIC mu -> count only
    return theta11, mu, W_FIXED, scrut_m

_DV = {"v": None}                                                       # warm-start cache for the value function (RESET per Powell polish)
def obj(x, B=14, n_outer=3, warm=False):
    theta11, mu, w, scrut_m = unpack(_clip(x))
    fs.SCRUT_M = scrut_m                                                # set the enforcement-skepticism before the sim
    o, dv = fs.simulate_mpe(theta11, mu, B=B, n_outer=n_outer, final_sim=False, psi=[0.0, 0.0, 0.0], onetime=True,
                            w_window=w, arrivals_throughout=True,
                            dv_init=(_DV["v"] if warm else None), return_dv=True)
    if warm:
        _DV["v"] = dv
    return fs.loss(o)

# The SMM criterion is multi-modal.  A cold multi-start polish settles in a worse basin (mu_bar ~9.0,
# loss ~20) rather than the global optimum (mu_bar 9.26), because the random/heuristic seeds never reach
# the global basin and Powell does not cross the ridge between them.  We therefore seed the search at the
# published estimate -- the verified global optimum: it has strictly lower loss than the mu_bar~9.0 basin
# at every simulation size B (e.g. B=14: 15.1 vs 17.8; B=240: 16.2 vs 19.8).  This is a STARTING POINT,
# not a constraint -- the polish is free to move off it, and the final guard below keeps it only if no
# start strictly improves on it.  x order = [mu_bar,lam,tau_eng,t0,a0,b0,zeta,chi,g,lam_cut,scrut_m].
published = [9.2612, 0.6339, 124.0338, 102.8383, 1.803, 128.8448, 306.903, 2.0846, 0.5729, 0.0885, 14.7595]
# secondary heuristic warm start (validated sweep config; belief/timing from the previous headline) + SCRUT_M~18.
warm_head = [9.297, 0.466, 162.876, 102.945, 2.067, 117.668, 306.691, 2.039, 0.636, 0.09, 18.0]
def _seed(**ov):
    s = list(warm_head); idx = dict(zip(K, range(len(K))))
    for k, v in ov.items(): s[idx[k]] = v
    return s
# the rent is too FRONT-loaded at warm (succ_pe high, w12_148 low) -> back-load it: deepen the Oficio skepticism
# (scrut_m up) and slow the pre-Oficio rent build (chi up, zeta/a0 down) so the surge shifts into post-late
seeds = [published, warm_head,
         _seed(scrut_m=25.0, chi=3.0),
         _seed(scrut_m=30.0, chi=3.3, zeta=200.0, a0=1.0),
         _seed(scrut_m=20.0, chi=3.2, zeta=140.0, a0=1.0, b0=120.0),
         _seed(mu_bar=9.8, scrut_m=35.0, chi=3.4, zeta=160.0)]

t_start = time.time()
rng = np.random.default_rng(0)
cand = seeds + [[rng.uniform(*BND[k]) for k in K] for _ in range(20)]
cand.sort(key=lambda x: obj(x, B=10, n_outer=3, warm=False))           # FRESH n_outer=3 scan (no warm-start reliance)
best = (obj(cand[0], B=14, n_outer=3, warm=False), cand[0])
print(f"[{time.time()-t_start:.0f}s] candidate scan done; best so far {best[0]:.2f}", flush=True)
cand_best = best
for ip, x0 in enumerate([warm_head, cand[0]]):
    _DV["v"] = None                                                    # RESET warm-start cache per polish
    res = minimize(lambda x: obj(x, B=14, n_outer=3, warm=True), np.array(x0, float), method="Powell", bounds=bounds,
                   options=dict(maxiter=80, xtol=2e-3, ftol=2e-3))
    xc = _clip(res.x); f = obj(xc, B=20, n_outer=4)
    print(f"[{time.time()-t_start:.0f}s] polish {ip} -> loss {f:.2f}  (mu_bar {xc[0]:.2f} scrut_m {xc[10]:.1f} chi {xc[7]:.2f})", flush=True)
    if f < best[0]:
        best = (float(f), xc)
if best[0] > cand_best[0]:
    print(f"[{time.time()-t_start:.0f}s] Powell did not beat the candidate scan ({best[0]:.2f} > {cand_best[0]:.2f}) -> using the candidate-scan best", flush=True)
    best = cand_best

# Final guard: re-pin the verified global optimum.  The published estimate has strictly lower loss than
# the basin the cold polishes settle in; keep it unless a start strictly improves on it at matched B=40.
_pub_f = obj(published, B=40, n_outer=4); _best_f = obj(best[1], B=40, n_outer=4)
if _pub_f <= _best_f:
    print(f"[{time.time()-t_start:.0f}s] final guard: kept published global optimum ({_pub_f:.2f} <= search {_best_f:.2f})", flush=True)
    best = (float(_pub_f), list(published))
else:
    print(f"[{time.time()-t_start:.0f}s] final guard: search improved on published ({_best_f:.2f} < {_pub_f:.2f})", flush=True)

x = best[1]; theta11, mu, w, scrut_m = unpack(x)
fs.SCRUT_M = scrut_m
M = fs.simulate_mpe(theta11, mu, B=240, n_outer=6, psi=[0.0, 0.0, 0.0], onetime=True, w_window=w, arrivals_throughout=True)
L = float(fs.loss(M)); e = fs.EMP
print("\n=== HEADLINE MPE, psi-LEADERSHIP + LEARNED enforcement belief (symmetric mu; solved value function) ===")
print(f"SMM loss(B=240) {L:.2f}\n")
print(f"mu_bar   = {mu[0]:.3f}   (SYMMETRIC -> count only)")
print(f"psi      = {PSI_LEAD}  (FIXED, calibrated [CV,FA,SB])")
print(f"share    = {list(CHAIN_SHARE)}  (FIXED, rent leader)")
print(f"lam_cut  = {float(x[9]):.4f}")
print(f"scrut_m  = {scrut_m:.2f}   (Oficio enforcement-skepticism; rsc=(1+k)/(1+k+scrut_m))")
print(f"TAU_LEAD = {TAU_LEAD:.3f}   TAU_RENT = {TAU_RENT:.3f}   (calibrated)")
for k, v in zip(REST, list(x[1:9])):
    print(f"   {k:8s} = {v:.3f}")
print(f"\n{'moment':16s}{'model':>9}{'data':>9}")
for k, lab in [("tot01", "first 0->1"), ("tot12", "rent 1->2"), ("war_mk", "war markup"),
               ("dev_war", "dev war"), ("dev_cart", "dev cart"), ("dev_pe", "dev pe"), ("dev_pl", "dev pl"),
               ("succ_cart", "succ cartel"), ("fail_war", "fail war"), ("corr_sz", "corr(sz,wk)"),
               ("w12_126", "rent w126"), ("w12_135", "rent w135"), ("w12_148", "rent w148"),
               ("lead_sb_cart", "SB cart lead"), ("lead_cv_pl", "CV late lead"), ("lead_sb_fail_pe", "SB fail lead"),
               ("succ_pe", "succ post-E"), ("fail_pl", "fail post-L")]:
    print(f"  {lab:16s}{M[k]:>9.2f}{e.get(k, float('nan')):>9.2f}")
print("  leadS_cart CV/FA/SB  " + "/".join(f"{100*z:.0f}%" for z in M["leadS_cart"]) + f"   (data SB {e['lead_sb_cart']:.2f})")
print("  leadS_pl   CV/FA/SB  " + "/".join(f"{100*z:.0f}%" for z in M["leadS_pl"]) + f"   (data CV {e['lead_cv_pl']:.2f})")
_theta_out = dict(zip(REST, [float(v) for v in x[1:9]])); _theta_out["rho"] = RHO_FIX; _theta_out["lam_cut"] = float(x[9])
out = dict(mu=[float(mu[0])] * 3, mu_bar=float(mu[0]),
           theta=_theta_out, w_window=w, kappa_mean=float(mu[0]),
           lam_cut=float(x[9]), tau_lead=TAU_LEAD, tau_rent=TAU_RENT, scrut_m=float(scrut_m), scrut_learn=1,
           loss=L, mode="hetmu_mpe_psi_learn",
           psi=[0.0, 0.0, 0.0], psi_lead=PSI_LEAD, chain_share=list(CHAIN_SHARE),
           moments={k: float(M[k]) for k in M if not isinstance(M[k], list)},
           leadS_cart=list(M["leadS_cart"]), leadS_pl=list(M["leadS_pl"]), leadF_pe=list(M["leadF_pe"]), empirical=e)
_sfx = os.environ.get("SPEC_OUT_SFX", "")                          # ""=headline (hetIV); "_hetOLS"/"_homog" = demand-spec re-estimates for tab:spec_robustness
json.dump(out, open(os.path.join(ROOT, "output", f"hetmu_mpe{_sfx}.json"), "w"), indent=2)
print(f"\n[{time.time()-t_start:.0f}s] wrote output/hetmu_mpe{_sfx}.json  (psi-leadership; symmetric mu)")
