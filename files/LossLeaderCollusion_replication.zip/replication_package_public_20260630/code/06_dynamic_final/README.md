# `06_dynamic_final`

This folder contains the current structural model and its robustness checks for
the RAND revision.

## Run

```bash
bash code/06_dynamic_final/run_pipeline.sh [stage]
```

See `PIPELINE.md` for the stage map.

## Headline model

The headline structural model is:

- `full_structural_mpe.py`: psi-leadership MPE model with product-firm `(i,j)`
  demand.
- `estimate_hetmu_mpe.py`: headline SMM estimation.
- `knockouts_reest_mpe.py`: re-estimated knockout specifications.
- `scenarios_mpe.py`, `spec_reest_mpe.py`, `spec_robustness_mpe.py`,
  `rc_own_mpe.py`, `rent_gates_mpe.py`: robustness checks.
- `profile_struct_se_mpe.py` and `bootstrap_se_mpe.py`: uncertainty estimates.
- `welfare.py`: welfare calculations.

The pipeline exports `IJ=1` and `PERP_TERMINAL=1`; those flags are part of the
published surface.

## Retained support files

- `primitives.py` holds panel and primitive construction used by the structural
  scripts.
- `full_structural.py` is retained because `code/09_predictors/sequence_predictors.py`
  imports it for the sequence regression. It is not the headline MPE estimator.
- `appendix_full_path.py`, `appendix_experimentation_horizon.py`, and
  `demand_ij_gof.py` produce appendix/figure material used by the current paper.

## Archived material

Earlier belief, up/down, one-time, and standalone spillover-game versions are
archived under `code/06_dynamic_final/_archive/` and `code/_archive/`. The
2026-06-30 cleanup moved additional superseded standalone helpers into
`code/_archive/cleanup_20260630/06_dynamic_final/`.
