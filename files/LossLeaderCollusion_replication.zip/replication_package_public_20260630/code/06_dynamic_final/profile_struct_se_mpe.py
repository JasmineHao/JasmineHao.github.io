"""profile_struct_se_mpe.py -- profile-curvature (observed-information) SEs for the 11 estimated parameters
of the psi-leadership + learned-enforcement-belief HEADLINE (tab:mech_theta): mu_bar, lam, tau_eng, t0, a0,
b0, zeta, chi, g, lam_cut, and m (the enforcement skepticism, fs.SCRUT_M).  Same design as profile_struct_se.py:
hold the others fixed at theta_hat, central second difference H_k = d^2 Loss/d theta_k^2 with a 20%-relative
step (1-week absolute for t0), SE = sqrt(2/H_k).  psi/share/TAU_LEAD/TAU_RENT are CALIBRATED (not estimated),
so they are not profiled.  Output -> output/struct_curvature_se_mpe.json
"""
import os, json, importlib.util
import numpy as np
os.environ.setdefault("PERP_TERMINAL", "1"); os.environ.setdefault("IJ", "1")
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
spec = importlib.util.spec_from_file_location("fs", os.path.join(ROOT, "code", "06_dynamic_final", "full_structural_mpe.py"))
fs = importlib.util.module_from_spec(spec); spec.loader.exec_module(fs)
fs.PSI_LEAD = [0.60, 0.80, 0.00]; fs.CHAIN_SHARE = np.array([0.453, 0.309, 0.239])
fs.TAU_LEAD = 3.0; fs.TAU_RENT = 0.12; fs.SCRUT_LEARN = 1

d = json.load(open(os.path.join(ROOT, "output", "hetmu_mpe.json")))
REST = ["lam", "tau_eng", "t0", "a0", "b0", "zeta", "chi", "rho", "g"]
th = [float(d["mu_bar"])] + [float(d["theta"][k]) for k in REST] + [float(d["theta"]["lam_cut"])]  # 11-vec (rho dummy)
M0 = float(d["scrut_m"]); B = 160
mu = np.array([float(d["mu_bar"])] * 3)

def loss_at(idx, val, scrut_m=None):
    t = list(th)
    if idx is not None: t[idx] = float(val)
    m = M0 if scrut_m is None else float(scrut_m)
    t = [t[0]] + t[1:]; mloc = np.array([t[0]] * 3)
    fs.SCRUT_M = m
    o = fs.simulate_mpe(t, mloc, B=B, seed=3, n_outer=6, psi=[0.0, 0.0, 0.0], onetime=True, w_window=26.0, arrivals_throughout=True)
    return float(fs.loss(o))

# (paper symbol, index in th, est, 1-week-abs?) ; m handled separately
PROF = [("mu_bar", 0, th[0], False), ("lam", 1, th[1], False), ("tau_e", 2, th[2], False),
        ("t0", 3, th[3], True), ("a0", 4, th[4], False), ("b0", 5, th[5], False),
        ("zeta", 6, th[6], False), ("chi", 7, th[7], False), ("g", 9, th[9], False),
        ("lam_cut", 10, th[10], False)]
print(f"loss@theta_hat = {loss_at(1, th[1]):.4f}  (headline 22.74)\n")
print(f"{'param':>10}{'est':>10}{'SE':>10}{'t':>8}")
res = {}
for sym, idx, x0, weekstep in PROF:
    h = 1.0 if weekstep else 0.20 * abs(x0)
    if h < 1e-9: h = 0.02
    Lm, L0, Lp = loss_at(idx, x0 - h), loss_at(idx, x0), loss_at(idx, x0 + h)
    Hc = (Lp - 2 * L0 + Lm) / (h * h)
    se = float(np.sqrt(2.0 / Hc)) if Hc > 1e-12 else float("inf")
    t = abs(x0) / se if np.isfinite(se) and se > 0 else float("inf")
    res[sym] = dict(est=x0, se=se, tstat=t, curvature=Hc)
    print(f"{sym:>10}{x0:>10.3f}{se:>10.4g}{t:>8.2f}")
# m (scrut_m), profiled on the global
h = 0.20 * M0
Lm, L0, Lp = loss_at(None, None, M0 - h), loss_at(None, None, M0), loss_at(None, None, M0 + h)
Hc = (Lp - 2 * L0 + Lm) / (h * h); se = float(np.sqrt(2.0 / Hc)) if Hc > 1e-12 else float("inf")
res["m"] = dict(est=M0, se=se, tstat=(M0 / se if np.isfinite(se) and se > 0 else float("inf")), curvature=Hc)
print(f"{'m':>10}{M0:>10.3f}{se:>10.4g}{(M0/se if np.isfinite(se) and se>0 else 0):>8.2f}")
json.dump(dict(method="profile-curvature (observed information); SE=sqrt(2/H); psi-leadership + learned belief",
               model="hetmu_mpe_psi_learn", B=B, params=res),
          open(os.path.join(ROOT, "output", "struct_curvature_se_mpe.json"), "w"), indent=2)
print("\nwrote output/struct_curvature_se_mpe.json")
