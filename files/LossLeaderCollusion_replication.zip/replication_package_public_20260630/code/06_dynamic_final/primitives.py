"""primitives.py -- single source of truth for panel + costs + events.

Loaded once at start of the pipeline; everything downstream takes
these dicts as inputs.  No silent placeholders.
"""
from __future__ import annotations
import os, pickle
import numpy as np
import pandas as pd

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
DATA = os.path.join(ROOT, "data", "processed")
OUT  = os.path.join(ROOT, "output")

# ---------------------------------------------------------------------
# Calendar / structural constants -- single source of truth
# ---------------------------------------------------------------------
DAY0_DATE   = pd.Timestamp("2006-01-01")
T_CONAR_WK  = 84    # week of CONAR ruling 16 Sept 2007 (84*7 = 588 days)
T_FIRST_WK  = 101   # 3 Dec 2007 first successful coord
T_LAST_WK   = 119   # 7 Apr 2008 last hand-coded success
T_FNE_WK    = 117   # 31 Mar 2008 FNE Oficio 419
T_END_WK    = 158   # end of simulation horizon
J_END_WK    = 119   # last active cartel week in data

N_FIRMS = 3
FIRM_NAMES = ["CV", "FA", "SB"]

# ---------------------------------------------------------------------
# Empirical moments (targets for estimator)
# ---------------------------------------------------------------------
M_EMPIRICAL = {
    "M1a_tier01": 219.0,   # tier 0->1: 211 hand_coded + 8 detected_success (in cartel window)
    "M1b_tier12":  80.0,   # tier 1->2: hand_coded_success only (in cartel window)
    "M2_peak":   115,      # peak event week
    "M4_leader": np.array([0.052, 0.192, 0.756]),   # CV, FA, SB
    "M6_pre_cartel_fail": 36.0,   # pre-cartel failed + unilat-held
}


# ---------------------------------------------------------------------
# Loaders
# ---------------------------------------------------------------------
def load_panel():
    """Load the raw daily panel and aggregate to weekly.

    Returns dict with:
        p_wk     : (N_FIRMS, N_WK, J) weekly mean prices, kCLP
        c_j      : (J,) per-drug wholesale cost from data_objects['marginal_cost']
        attr     : DataFrame of drug attributes (Name_Catalog, Lab, ATCL4, ...)
        date_df  : DataFrame of date stamps for the daily panel
        N_WK     : number of weeks
        J        : number of drugs (222)
    """
    pkl_path = os.path.join(DATA, "data_objects.pkl")
    with open(pkl_path, "rb") as f:
        d = pickle.load(f)

    p_cv = d["price_cv"].values
    p_fa = d["price_fa"].values
    p_sb = d["price_sb"].values
    T_DAYS, J = p_cv.shape
    N_WK = T_DAYS // 7
    p_day = np.stack([p_cv, p_fa, p_sb])     # (N_FIRMS, T_DAYS, J)
    # Drop trailing partial week then aggregate to weekly mean (used for
    # the dynamic-state forecast); but keep daily panel for Lambda.
    p_wk = p_day[:, :N_WK*7, :].reshape(N_FIRMS, N_WK, 7, J).mean(axis=2)

    # Real wholesale cost panel from FNE-disclosed cost_sb (weekly, in
    # CLP -- SAME UNITS as prices). The 'marginal_cost' field in the
    # pickle is in kCLP (1000 CLP) -- 1000x off prices -- so using it
    # silently makes below-cost vacuously false. We use cost_sb instead
    # and impute missing drug-weeks with the per-drug cross-week median.
    cost_sb = d["cost_sb"].values     # shape (N_WK_cost, J_cost)
    if cost_sb.shape[1] >= J:
        cost_sb = cost_sb[:, :J]
    else:
        raise ValueError(f"cost_sb has {cost_sb.shape[1]} drugs, need {J}")
    # Pad cost_sb to T_DAYS x J by drug-level median fill and
    # broadcasting across daily ticks within each week
    c_drug_med = np.nanmedian(cost_sb, axis=0)
    if not np.all(np.isfinite(c_drug_med)):
        med_overall = float(np.nanmedian(c_drug_med))
        c_drug_med = np.where(np.isfinite(c_drug_med), c_drug_med, med_overall)
        print(f"  [primitives] some drugs all-NaN cost; filled with {med_overall:.0f} CLP")
    # Build a daily cost panel: each day uses the corresponding week's
    # cost_sb value if available; otherwise the drug median.
    N_WK_cost = cost_sb.shape[0]
    c_daily = np.tile(c_drug_med[None, :], (T_DAYS, 1))
    n_cost_days = min(T_DAYS, N_WK_cost * 7)
    cost_sb_filled = np.where(np.isfinite(cost_sb), cost_sb, c_drug_med[None, :])
    c_daily[:n_cost_days] = np.repeat(cost_sb_filled, 7, axis=0)[:n_cost_days]
    c_j = c_drug_med   # per-drug time-invariant proxy for tier table
    c_day = c_daily    # per-day per-drug cost for Lambda computation

    return {
        "p_day":  p_day,
        "p_wk":   p_wk,
        "c_j":    c_j,        # (J,) per-drug time-invariant median cost (CLP)
        "c_day":  c_day,      # (T_DAYS, J) per-day per-drug cost (CLP)
        "q_wk":   _load_real_quantity(d, N_WK, J),  # (N_FIRMS, N_WK, J)
        "attr":   d["attr"],
        "date_df": d["date_df"],
        "N_WK":   N_WK,
        "T_DAYS": T_DAYS,
        "J":      J,
    }


def _load_real_quantity(d, N_WK, J):
    """Load per-firm per-day per-drug quantities and aggregate to weekly sums.

    Median weekly quantity per drug is ~200-500 units; max ~130k.  Filling
    NaN drug-weeks with per-firm per-drug median (or 1 if all-NaN).
    """
    q_day = np.stack([
        d["quantity_cv"].values, d["quantity_fa"].values, d["quantity_sb"].values
    ])
    q_wk = q_day[:, :N_WK*7, :].reshape(N_FIRMS, N_WK, 7, J).sum(axis=2)
    for i in range(N_FIRMS):
        for j in range(J):
            col = q_wk[i, :, j]
            med = np.nanmedian(col)
            if not np.isfinite(med): med = 1.0
            q_wk[i, :, j] = np.where(np.isfinite(col), col, med)
    return q_wk


def load_events():
    """Load the enriched event panel (hand-coded + detected successes,
    plus failed/unilateral attempts).
    """
    path = os.path.join(DATA, "enriched_event_panel.csv")
    ep = pd.read_csv(path, parse_dates=["event_date"])
    ep["event_week"] = ((ep["event_date"] - DAY0_DATE).dt.days // 7)
    return ep


def compute_lambda_i(prim, t_end_wk=T_CONAR_WK):
    """Per-firm cumulative below-cost loss from day 0 to t_end_wk*7,
    using the time-varying daily cost panel c_day (CLP, same scale as p).

    Lambda_i(t) = sum_j sum_{day<t*7} max(c_day[day,j] - p_iday[day,j], 0).
    Returns array of shape (N_FIRMS,) in CLP-days.
    """
    p_day = prim["p_day"]
    c_day = prim["c_day"]    # shape (T_DAYS, J)
    t_end_day = int(t_end_wk * 7)
    Lambda = np.zeros(N_FIRMS)
    for i in range(N_FIRMS):
        p = p_day[i, :t_end_day, :]
        c = c_day[:t_end_day, :]
        below = (p < c) & np.isfinite(p) & np.isfinite(c)
        Lambda[i] = np.where(below, c - p, 0).sum()
    return Lambda


def compute_loss_wk(prim):
    """(N_FIRMS, N_WK, J) per-firm per-week per-drug below-cost loss
    aggregated from the daily panel using c_day (CLP)."""
    p_day = prim["p_day"]
    c_day = prim["c_day"]
    N_WK = prim["N_WK"]
    J = prim["J"]
    loss_day = np.zeros_like(p_day)
    for i in range(N_FIRMS):
        below = (p_day[i] < c_day) & np.isfinite(p_day[i]) & np.isfinite(c_day)
        loss_day[i] = np.where(below, c_day - p_day[i], 0)
    loss_wk = loss_day[:, :N_WK*7, :].reshape(N_FIRMS, N_WK, 7, J).sum(axis=2)
    return loss_wk
