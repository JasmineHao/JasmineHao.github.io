"""welfare.py
===========
Welfare of the equilibrium transition (Section 5.4).  The coordinated price path
is evaluated against two counterfactuals, using the estimated nested-logit
demand of section 4:
  (A) the pre-war COMPETITIVE BASELINE (2006 prices) -- the sustainable fair price;
  (B) the below-cost WAR prices (mid-2007) -- the prices consumers actually
      enjoyed just before the cartel, and the benchmark the FNE used.

For each drug we compute the consumer transfer (overcharge x quantity) and the
deadweight loss (the quantity distortion, from the nested logit), aggregated over
the cartel window and the three chains.  The key finding is that the cartel
prices sit at roughly the 2006 baseline, so the harm relative to a SUSTAINABLE
competitive benchmark is modest -- the cartel mainly ended a below-cost subsidy
rather than extracting large supra-competitive rents.

Output: output/welfare.json  (+ console)
"""
import os, json
import numpy as np
import pandas as pd
from scipy.optimize import brentq

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SIG, OM = 0.393, 0.607
RHO, PBAR = 0.92, 8.99
# post-ban price coefficient: the cartel-excluded headline estimate (consistent with the structural
# model of section 5), read from the demand calibration rather than hard-coded.
A_POST = json.load(open(os.path.join(ROOT, "output", "demand_params.json")))["headline"]["alpha_post"]
NCHAIN = 3

df = pd.read_csv(os.path.join(ROOT, "data", "processed", "demand_data_core.csv"))


def med_price(lo, hi):
    return df[(df.TimeID >= lo) & (df.TimeID < hi)].groupby("DrugID").Price.median()


pb = med_price(10, 50)      # 2006 competitive baseline
pw = med_price(78, 96)      # mid-2007 below-cost war
pc = med_price(105, 119)    # cartel window (Jan-Apr 2008)
Q = df[(df.TimeID >= 105) & (df.TimeID < 119)].groupby("DrugID").Quantity.sum()  # window qty (3 chains)
T = pd.DataFrame({"pb": pb, "pw": pw, "pc": pc, "Q": Q}).dropna()
T = T[(T.pb > 0) & (T.pw > 0) & (T.pc > 0)]

ev = pd.read_csv(os.path.join(ROOT, "output", "v16_events_unified.csv"))
coord = ev[ev.kind == "coordination"].copy()
coord["date_dt"] = pd.to_datetime(coord.date)
rent = coord[coord.to_tier == 2].copy()
rent_window = rent[rent.in_window == True]


def calib_phi(alpha, pbar):
    f = lambda ph: (lambda Dg: Dg ** OM / (1 + Dg ** OM))(NCHAIN * np.exp((ph - alpha * pbar) / OM)) - RHO
    return brentq(f, -120, 120)


def cs_per_consumer(p, phi, alpha):
    """nested-logit consumer surplus per consumer (symmetric, all chains at p)."""
    Dg = NCHAIN * np.exp((phi - alpha * p) / OM)
    return np.log(1 + Dg ** OM) / alpha


def q_share(p, phi, alpha):
    Dg = NCHAIN * np.exp((phi - alpha * p) / OM)
    return Dg ** OM / (1 + Dg ** OM)      # nest (3-chain) share of the market


phi = calib_phi(A_POST, PBAR)
rows = []
for r in T.itertuples():
    # market size implied by observed cartel quantity and nest share at the cartel price
    sg = q_share(r.pc, phi, A_POST)
    M = (r.Q) / max(sg, 1e-6)             # potential market (units), so M*sg = observed Q
    for cf, p_cf, tag in [(r.pb, r.pb, "baseline"), (r.pw, r.pw, "war")]:
        # transfer = overcharge on the quantity actually transacted
        transfer = (r.pc - p_cf) * r.Q
        # total CS change = M*(CS(cf) - CS(cartel)); DWL = CS loss - transfer
        cs_loss = M * (cs_per_consumer(p_cf, phi, A_POST) - cs_per_consumer(r.pc, phi, A_POST))
        dwl = cs_loss - transfer
        rows.append(dict(DrugID=r.Index, cf=tag, transfer=transfer, cs_loss=cs_loss, dwl=dwl,
                         oc=(r.pc - p_cf), Q=r.Q))
R = pd.DataFrame(rows)
sales = (T.pc * T.Q).sum() * 1000        # CLP

out = {"n_drugs": len(T), "cartel_window_weeks": 14,
       "structural_coord_drugs": int(coord[coord.to_tier == 1].DrugID.nunique()),
       "median_price_kCLP": {"baseline": round(float(T.pb.median()), 2),
                             "war": round(float(T.pw.median()), 2),
                             "cartel": round(float(T.pc.median()), 2)},
       "cartel_window_sales_bnCLP": round(sales / 1e9, 2)}
print(f"{len(T)} drugs | median price (CLP'000s): baseline {T.pb.median():.2f}  war {T.pw.median():.2f}  cartel {T.pc.median():.2f}")
print(f"cartel-window sales (3 chains, 14 wks): {sales/1e9:.1f} bn CLP\n")
print(f"{'counterfactual':16s}{'transfer':>12s}{'DWL':>10s}{'CS loss':>12s}{'% of sales':>12s}")
for tag in ("baseline", "war"):
    s = R[R.cf == tag]
    tr = s.transfer.sum() * 1000; dw = s.dwl.sum() * 1000; cl = s.cs_loss.sum() * 1000
    out[tag] = {"transfer_bnCLP": round(tr/1e9, 2), "dwl_bnCLP": round(dw/1e9, 3),
                "cs_loss_bnCLP": round(cl/1e9, 2), "cs_loss_pct_sales": round(100*cl/sales, 1),
                "median_overcharge_pct": round(100*float((s.oc/ (T.pb if tag=='baseline' else T.pw)).median()), 1)}
    print(f"{tag:16s}{tr/1e9:>10.2f}bn{dw/1e9:>9.3f}bn{cl/1e9:>10.2f}bn{100*cl/sales:>11.1f}%")
print()

war_transfer = R[R.cf == "war"].set_index("DrugID").transfer * 1000
rent_ids = set(rent_window.DrugID)
rent_transfer = war_transfer.loc[war_transfer.index.isin(rent_ids)].sum()
above = T[T.pc > T.pb]
baseline_gross = ((above.pc - above.pb) * above.Q).sum() * 1000
overcharge_baseline = (T.pc - T.pb) / T.pb
out["table_aux"] = {
    "rent_drugs_in_window": int(rent_window.DrugID.nunique()),
    "rent_share_structural_drugs": round(float(rent_window.DrugID.nunique() / out["structural_coord_drugs"]), 3),
    "rent_drugs_year_end": int(rent.DrugID.nunique()),
    "rent_share_year_end": round(float(rent.DrugID.nunique() / out["structural_coord_drugs"]), 3),
    "tier2_price_cost_median_in_window": round(float(rent_window.markup_c.median()), 2),
    "coord_events_gt_1p4_cost_in_window": round(float((coord[coord.in_window == True].markup_c > 1.4).mean()), 3),
    "war_transfer_rent_drugs_bnCLP": round(float(rent_transfer / 1e9), 2),
    "war_transfer_rent_drugs_share": round(float(rent_transfer / war_transfer.sum()), 3),
    "gross_rent_vs_2006_above_historical_bnCLP": round(float(baseline_gross / 1e9), 2),
    "volume_overcharge_corr_vs_2006": round(float(np.corrcoef(np.log(T.Q.to_numpy(float)),
                                                              np.asarray(overcharge_baseline, float))[0, 1]), 2),
}
print("table auxiliaries:")
print(f"  rent drugs in window: {out['table_aux']['rent_drugs_in_window']} "
      f"({100*out['table_aux']['rent_share_structural_drugs']:.1f}% of structural drugs)")
print(f"  rent-drug war-counterfactual transfer: {out['table_aux']['war_transfer_rent_drugs_bnCLP']:.2f}bn "
      f"({100*out['table_aux']['war_transfer_rent_drugs_share']:.1f}%)")
print(f"  gross rent vs 2006 baseline, above-historical drugs: "
      f"{out['table_aux']['gross_rent_vs_2006_above_historical_bnCLP']:.2f}bn")
print()
print("FNE/TDLC documented harm: ~$27 bn CLP gross-revenue increase (Requerimiento); "
      "TDLC compensation ~US$10.7M.")
print("=> Cartel prices ~= 2006 baseline: harm vs a SUSTAINABLE competitive benchmark is modest;")
print("   the large figures are measured vs the below-cost war prices consumers had enjoyed.")
json.dump(out, open(os.path.join(ROOT, "output", "welfare.json"), "w"), indent=2)
print("\nwrote output/welfare.json")
