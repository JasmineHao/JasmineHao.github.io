# Manifest

## Included

- Core analysis code used by `code/06_dynamic_final/run_pipeline.sh`.
- Synthetic-data generator and smoke test.

## Excluded

- Proprietary real data.
- Real-data derived output files.
- Archived exploratory code and local backups.
- LaTeX source files and build intermediates.

## Reproducing the paper numbers

Place the restricted real data in `data/processed/`, place the event ledger in
`output/`, and run `bash run_all.sh all`. The shipped synthetic data generator
does not reproduce the reported estimates.
