#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

if [[ ! -f data/processed/data_objects.pkl || ! -f output/v16_events_unified.csv ]]; then
  echo "No input data found; creating synthetic stand-ins."
  python3 make_synthetic_data.py
fi

bash code/06_dynamic_final/run_pipeline.sh "${1:-all}"
