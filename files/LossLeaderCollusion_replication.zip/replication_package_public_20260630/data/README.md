# Data Directory

Real data are not included in this public package.

Run `python3 make_synthetic_data.py` or `python3 smoke_test.py` from the package
root to create synthetic stand-ins under `data/processed/`.
