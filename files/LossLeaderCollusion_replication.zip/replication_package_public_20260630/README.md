# Replication Package

This directory contains the public replication code for
`Equilibrium Transition from Loss-Leader Competition to Self-Enforcing Coordination`.

The package is intentionally data-free. The proprietary chain-drug-day
price, quantity, and cost panels are not included. To let readers inspect and
smoke-test the code, the package includes `make_synthetic_data.py`, which creates
fake inputs with the same file structure and column names used by the pipeline.
Synthetic outputs are useful only for checking that the code runs. They do not
reproduce the paper's estimates.

## Quick Smoke Test

From this directory:

```bash
python3 -m pip install -r requirements.txt
python3 smoke_test.py
```

The smoke test creates synthetic inputs, compiles the Python scripts, checks that
the structural model can load the synthetic panel, and runs a subset of the
low-cost figure scripts.

## Full Pipeline

With the restricted real data in place, run:

```bash
bash run_all.sh all
```

or one stage at a time:

```bash
bash run_all.sh demand
bash run_all.sh headline
bash run_all.sh knockouts
bash run_all.sh robust
bash run_all.sh se
bash run_all.sh welfare
bash run_all.sh figures
bash run_all.sh descriptive
```

If no input data are present, `run_all.sh` creates synthetic data first. Running
the full pipeline on synthetic data may take a long time and will overwrite
`output/` with meaningless synthetic estimates.

## Contents

- `code/03_demand/`: canonical demand estimation and demand robustness scripts.
- `code/06_dynamic_final/`: current MPE structural model, estimators, robustness,
  standard errors, and welfare scripts.
- `code/09_figures/`: current figure scripts.
- `code/09_predictors/`: sequence predictor table.
- `code/shared/`: shared helper modules.
- `make_synthetic_data.py`: fake input generator for code inspection and smoke tests.

Archived exploratory scripts, stale outputs, and real data are excluded.
