"""Smoke-test the public replication package on synthetic data."""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
env = os.environ.copy()
env.setdefault("MPLCONFIGDIR", str(ROOT / "output" / ".mplconfig"))
env.setdefault("XDG_CACHE_HOME", str(ROOT / "output" / ".cache"))


def run(cmd):
    print("\n>>>", " ".join(cmd))
    subprocess.run(cmd, cwd=ROOT, env=env, check=True)


run([sys.executable, "make_synthetic_data.py"])
run([sys.executable, "-m", "compileall", "-q", "code"])

structural_check = """
import importlib.util, os
root = os.getcwd()
os.environ.setdefault('IJ', '1')
os.environ.setdefault('PERP_TERMINAL', '1')
os.environ['REBUILD'] = '1'
spec = importlib.util.spec_from_file_location(
    'fsm', os.path.join(root, 'code', '06_dynamic_final', 'full_structural_mpe.py'))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
assert mod.J >= 200, mod.J
print(f'structural panel loaded: J={mod.J}')
"""
run([sys.executable, "-c", structural_check])

for script in [
    "code/09_figures/9_1_wholesale_cost.py",
    "code/09_figures/9_2_failed_attempts.py",
    "code/09_figures/9_3_prices_and_loss.py",
    "code/09_figures/9_4_lab_size_timing.py",
    "code/09_figures/9_5_example_coord.py",
    "code/09_figures/9_6_order.py",
]:
    run([sys.executable, script])

print("\nSmoke test passed.")
