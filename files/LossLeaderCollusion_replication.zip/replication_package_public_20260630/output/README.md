# Output Directory

Real-data outputs are not included in this public package.

Running the pipeline or `python3 smoke_test.py` will write generated outputs here.
Synthetic outputs are for code checks only and do not reproduce paper estimates.
