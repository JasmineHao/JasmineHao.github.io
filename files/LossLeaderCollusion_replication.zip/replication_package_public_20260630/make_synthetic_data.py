"""Create synthetic stand-ins for the restricted pharmacy data.

The generated files match the structure used by the replication code, but the
values are fake. They are suitable for smoke tests and code inspection only.
"""
from __future__ import annotations

import json
import pickle
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "processed"
OUT = ROOT / "output"
PAPER = ROOT / "paper" / "manuscript"
DATA.mkdir(parents=True, exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)
PAPER.mkdir(parents=True, exist_ok=True)

rng = np.random.default_rng(20080101)
NJ, ND = 222, 1096
DATES = pd.date_range("2006-01-01", periods=ND, freq="D")
BAN, ONSET, RENT = 674, 705, 855


def _df(a):
    return pd.DataFrame(a, columns=np.arange(NJ))


def _attr_frame() -> pd.DataFrame:
    acols = [
        "no", "Name_Catalog", "Name_Farmazon", "Name_original", "ing_amount",
        "ing_unit", "type", "No.1", "PackageUnit", "drug_type",
        "ingredient", "chronic", "Treat", "Prescription", "Lab", "num_lab",
        "num_form", "num_dose", "ATCL6", "molecule", "num_category", "labs",
        "forms", "similar_drugs", "analogue_drugs", "ATCL4", "ATCL5",
        "ATCL4_therapeutic", "ATCL5_therapeutic", "average_price_cv",
        "average_price_sb", "average_price_fa", "Pattern", "inc_pct",
        "p_cv", "p_fa", "p_sb", "q_cv", "q_fa", "q_sb", "s_cv", "s_fa",
        "s_sb", "daily_rev", "lab", "dosis", "pills", "generics",
        "active_ingred", "substitutes_manuf", "classificationchanged",
        "compuesto1", "compuesto2", "compuesto3",
        "refill_frequency(full version)", "refill_frequency",
    ]

    def make_col(c: str):
        lc = c.lower()
        if "name" in lc:
            return [f"DRUG_{i:03d}" for i in range(NJ)]
        if any(k in lc for k in ("molecule", "ingred", "compuesto")):
            return [f"MOL_{i % 80:02d}" for i in range(NJ)]
        if "lab" in lc:
            return [f"LAB_{i % 37:02d}" for i in range(NJ)]
        if "atc" in lc:
            return [f"A{i % 8:02d}BC" for i in range(NJ)]
        if c == "no":
            return np.arange(NJ)
        if c == "num_lab":
            return [i % 37 for i in range(NJ)]
        if c in {"chronic", "Prescription", "generics", "Treat", "Pattern"}:
            return rng.integers(0, 2, NJ)
        if c in {
            "p_cv", "p_fa", "p_sb", "average_price_cv",
            "average_price_sb", "average_price_fa", "daily_rev",
        }:
            return rng.uniform(800, 18000, NJ)
        if c in {"q_cv", "q_fa", "q_sb"}:
            return rng.integers(100, 9000, NJ)
        if c in {"s_cv", "s_fa", "s_sb", "inc_pct"}:
            return rng.uniform(0.1, 0.6, NJ)
        if lc.startswith("num_") or c in {
            "type", "drug_type", "PackageUnit", "ing_amount", "ing_unit",
            "dosis", "pills", "No.1", "forms", "similar_drugs",
            "analogue_drugs", "substitutes_manuf",
        }:
            return rng.integers(1, 8, NJ)
        return [f"v{i % 10}" for i in range(NJ)]

    attr = pd.DataFrame({c: make_col(c) for c in acols})
    attr["type4"] = (
        attr["chronic"].map({0: "Acute", 1: "Chronic"})
        + "_"
        + attr["Prescription"].map({0: "OTC", 1: "Rx"})
    )
    return attr


attr = _attr_frame()
cost_base = rng.uniform(800, 18000, NJ)
drift = np.cumsum(rng.normal(0, 0.004, (ND, NJ)), axis=0)
cost_path = cost_base[None, :] * np.clip(1 + 0.05 * drift, 0.65, 1.60)
coord_day = (ONSET + rng.normal(0, 18, NJ)).clip(BAN + 5, ND - 180).astype(int)
rent_day = (RENT + rng.normal(0, 30, NJ)).clip(coord_day + 30, ND - 30).astype(int)
is_rent = rng.random(NJ) < 0.65


def chain_panels(seed: int, chain_shift: float):
    g = np.random.default_rng(seed)
    price = np.zeros((ND, NJ), dtype=float)
    quantity = np.zeros((ND, NJ), dtype=int)
    colluding = np.zeros((ND, NJ), dtype=int)
    chain_scale = g.uniform(0.96, 1.04, NJ) * chain_shift
    market = g.uniform(1500, 9000, NJ)
    for j in range(NJ):
        c = cost_path[:, j]
        pre_noise = np.cumsum(g.normal(0, 0.004, BAN))
        pre_noise -= pre_noise.mean()
        war = c[:BAN] * chain_scale[j] * (
            0.90 - 0.10 * np.linspace(0, 1, BAN) + 0.05 * pre_noise
        )
        post_len = ND - BAN
        x = np.arange(post_len)
        markup = 0.90 + 0.35 * np.clip((x - (coord_day[j] - BAN)) / 14.0, 0, 1)
        if is_rent[j]:
            markup += 0.28 * np.clip((x - (rent_day[j] - BAN)) / 18.0, 0, 1)
        post = c[BAN:] * chain_scale[j] * markup
        p = np.r_[war, post] + g.normal(0, 0.015, ND) * cost_base[j]
        p = np.clip(p, cost_base[j] * 0.35, cost_base[j] * 2.4)
        alpha = np.where(np.arange(ND) < BAN, 0.103, 0.029)
        util = -alpha * np.log(np.maximum(p, 1.0)) + g.normal(0, 0.03, ND)
        q = (market[j] * np.exp(util) / (1 + np.exp(util))).round().astype(int)
        price[:, j] = p
        quantity[:, j] = np.maximum(q, 1)
        colluding[:, j] = (p > c).astype(int)
    return price, quantity, colluding


p_cv, q_cv, col_cv = chain_panels(2001, 1.00)
p_fa, q_fa, col_fa = chain_panels(2002, 0.99)
p_sb, q_sb, col_sb = chain_panels(2003, 1.01)
tot_q = np.maximum(q_cv + q_fa + q_sb, 1)

date_df = pd.DataFrame({
    "Date": DATES,
    "Weekday": DATES.day_name(),
    "weekday": DATES.weekday,
})
date_df.to_csv(DATA / "date.csv", index=False)

cost_block = pd.DataFrame(
    cost_path[BAN:BAN + 183].round(),
    columns=[f"cost{j}" for j in range(NJ)],
)
cost_block.insert(0, "date", DATES[BAN:BAN + 183].strftime("%d.%m.%y"))
cost_block.to_csv(DATA / "CostoSB.csv", index=False)

obj = {
    "attr": attr,
    "date_df": date_df,
    "firm_list": ["cv", "sb", "fa"],
    "firm_dict": {"cv": "Chain A", "sb": "Chain B", "fa": "Chain C"},
    "price_cv": _df(p_cv),
    "quantity_cv": _df(q_cv),
    "col_cv": _df(col_cv),
    "price_sb": _df(p_sb),
    "quantity_sb": _df(q_sb),
    "col_sb": _df(col_sb),
    "price_fa": _df(p_fa),
    "quantity_fa": _df(q_fa),
    "col_fa": _df(col_fa),
    "total_quantity": _df(tot_q),
    "shares_cv": _df(q_cv / tot_q),
    "shares_fa": _df(q_fa / tot_q),
    "shares_sb": _df(q_sb / tot_q),
    "cost_sb": cost_block.drop(columns=["date"]),
    "marginal_cost": pd.Series(np.append(cost_base, cost_base.mean())),
    "col_ind": _df(((col_cv + col_fa + col_sb) >= 2).astype(int)),
    "market_size": _df(tot_q * rng.uniform(1.5, 3.0, NJ)),
}
with open(DATA / "data_objects.pkl", "wb") as f:
    pickle.dump(obj, f)


def build_weekly_core():
    rows = []
    firms = {
        "CV": (p_cv, q_cv),
        "FA": (p_fa, q_fa),
        "SB": (p_sb, q_sb),
    }
    weeks = np.arange(ND) // 7
    for w in range(int(weeks.max()) + 1):
        m = weeks == w
        total_week = sum(Q[m].sum(axis=0) for _, Q in firms.values())
        total_week = np.maximum(total_week, 1)
        for firm, (P, Q) in firms.items():
            q = Q[m].sum(axis=0)
            rev = (P[m] * Q[m]).sum(axis=0)
            price = np.divide(rev, np.maximum(q, 1), out=np.zeros_like(rev), where=q > 0)
            share = q / total_week
            for j in range(NJ):
                rows.append({
                    "DrugID": j,
                    "TimeID": w,
                    "Firm": firm,
                    "Lab": attr.loc[j, "lab"],
                    "Price": price[j] / 1000.0,
                    "Quantity": int(q[j]),
                    "ShareWithinGroup": float(share[j]),
                })
    pd.DataFrame(rows).to_csv(DATA / "demand_data_core.csv", index=False)


def build_mu_panel():
    parts = []
    firms = {
        "CV": (p_cv, q_cv),
        "FA": (p_fa, q_fa),
        "SB": (p_sb, q_sb),
    }
    for firm, (P, Q) in firms.items():
        for j in range(NJ):
            parts.append(pd.DataFrame({
                "DrugID": j,
                "TimeID": np.arange(ND),
                "Firm": firm,
                "p": P[:, j],
                "q": Q[:, j],
                "c": cost_path[:, j],
            }))
    pd.concat(parts, ignore_index=True).to_csv(OUT / "r2_mu_preban_by_firm.csv", index=False)


def build_events():
    rows_v16 = []
    rows_ep = []
    chains = ["CV", "FA", "SB"]

    def add_event(j, kind, day, chain, from_tier, to_tier, price, success, in_window=True):
        markup_c = price / cost_base[j]
        common = {
            "DrugID": j,
            "drug": f"DRUG_{j:03d}",
            "kind": kind,
            "date": DATES[day],
            "chain": chain,
            "from_tier": from_tier,
            "to_tier": to_tier,
            "price": price,
            "markup_B": markup_c,
            "markup_c": markup_c,
            "price_tier_after": to_tier if success else from_tier,
            "note": "synthetic",
            "in_window": bool(in_window),
            "leaders": chain,
            "n_leaders": 1,
        }
        rows_v16.append(common)
        rows_ep.append({
            "DrugID": j,
            "event_date": DATES[day],
            "event_day": int(day),
            "kind_clean": kind,
            "coord_success": int(success),
            "from_tier": from_tier,
            "to_tier": to_tier,
            "in_window": bool(in_window),
            "leader_firm": chain,
        })

    for j in range(NJ):
        lead = "SB" if rng.random() < 0.72 else rng.choice(chains)
        rent_lead = "CV" if rng.random() < 0.65 else rng.choice(chains)
        for _ in range(rng.integers(1, 4)):
            d = int(rng.integers(60, BAN - 10))
            add_event(j, "deviation_war", d, rng.choice(chains), 0, 0, cost_base[j] * 0.80, False)
        add_event(j, "coordination", int(coord_day[j]), lead, 0, 1, cost_base[j] * 1.22, True)
        if is_rent[j]:
            add_event(j, "coordination", int(rent_day[j]), rent_lead, 1, 2, cost_base[j] * 1.52, True)
        for _ in range(rng.integers(0, 3)):
            d = int(rng.integers(60, min(ND - 10, rent_day[j] + 60)))
            tier = int(d >= coord_day[j])
            add_event(j, "failed_attempt", d, rng.choice(chains), tier, min(tier + 1, 2),
                      cost_base[j] * (1.12 if tier == 0 else 1.42), False)

    pd.DataFrame(rows_v16).to_csv(OUT / "v16_events_unified.csv", index=False)
    pd.DataFrame(rows_ep).to_csv(DATA / "enriched_event_panel.csv", index=False)


def build_light_outputs():
    alpha = np.clip(rng.normal(0.105, 0.025, NJ), 0.025, 0.22)
    alpha_tbl = pd.DataFrame({
        "DrugID": np.arange(NJ),
        "Molecule": [f"MOL_{i % 80:02d}" for i in range(NJ)],
        "type4": attr["type4"],
        "ATC1": attr["ATCL4"].astype(str).str[0],
        "sigma_g": 0.393,
        "alpha": alpha,
        "alpha_raw": alpha,
        "delta": -0.074,
        "se_alpha": 0.01,
        "se_delta": 0.005,
        "t_alpha": alpha / 0.01,
        "t_delta": -14.8,
        "own_elas_pre": -1.2,
        "cross_elas_pre": 0.2,
        "own_elas_post": -0.35,
        "cross_elas_post": 0.06,
        "fallback": False,
        "n": 300,
        "n_post": 120,
        "has_delta": True,
        "ATCL4": attr["ATCL4"],
        "chronic": attr["chronic"],
        "Prescription": attr["Prescription"],
    })
    alpha_tbl.to_csv(OUT / "r2_demand_alpha_per_drug.csv", index=False)
    alpha_tbl.to_csv(OUT / "r2_demand_alpha_per_drug_ols.csv", index=False)
    pd.DataFrame(columns=[
        "DrugID", "lab", "pw", "p1", "p2", "c", "alpha", "sigma_g",
        "coord_wk", "reached2",
    ]).to_csv(OUT / "recovered_drugs.csv", index=False)
    (OUT / "weak_collapse_drugs.txt").write_text(" ".join(map(str, range(48))) + "\n")
    demand_params = {
        "headline": {
            "sigma": 0.393,
            "OM": 0.607,
            "rho_mktshare": 0.92,
            "alpha0": 0.103,
            "alpha_post": 0.029,
            "A_RATIO": 0.286,
        }
    }
    (OUT / "demand_params.json").write_text(json.dumps(demand_params, indent=2) + "\n")
    het = {
        "mu_bar": 9.26,
        "mu": [9.26, 9.26, 9.26],
        "scrut_m": 14.76,
        "w_window": 26,
        "theta": {
            "lam": 0.63,
            "tau_eng": 124.0,
            "t0": 103.0,
            "a0": 1.8,
            "b0": 129.0,
            "zeta": 307.0,
            "chi": 2.08,
            "rho": 0.0,
            "g": 0.57,
            "lam_cut": 0.088,
        },
    }
    (OUT / "hetmu_mpe.json").write_text(json.dumps(het, indent=2) + "\n")


build_weekly_core()
build_mu_panel()
build_events()
build_light_outputs()

print("Synthetic data written under data/processed/ and output/.")
print("These fake files are for smoke tests only; they do not reproduce paper estimates.")
