# Replication Package

Replication code and saved outputs for *A Generalized Finite Dependence
Framework for Dynamic Discrete Choice Models* (Hao, Kasahara, Shimotsu).

## Top-level layout

```
FiniteDependence/
├── REPLICATION.md          this file
├── README.md (CLAUDE.md)   project metadata
├── code/                   active replication code (see code/README.md)
├── paper/                  paper LaTeX sources
├── game_mc_results.txt     saved 1,000-rep MC output for Section 6.2
├── results.csv             FD verification results (Female Labor, p=1)
├── results_rho_12.csv      FD verification results (Entry/Exit, ρ=1,2)
├── results_rho_123.csv     FD verification results (Altug–Miller, ρ=1,2,3)
└── _archived/              older code and exploratory scripts (not used by paper)
```

## Quick start

```bash
cd code/
pip install numpy scipy joblib
python3 fd_linear_system.py      # §5 Table 1 (rank test, ten canonical models)
```

For the full reproduction of every paper output, see [`code/README.md`](code/README.md).

## Section-by-section reproduction

### §2 Model and Generalized Finite Dependence
Theoretical only; no code reproduces a numbered output here.
See [`code/UnifiedFDSolver.py`](code/UnifiedFDSolver.py) and
[`code/FD_AS_LINEAR_SYSTEM.md`](code/FD_AS_LINEAR_SYSTEM.md) for the
flow-QP and pointwise-feasibility implementations.

### §5 Applications

| Output                          | Script                                                | Wall time |
|---------------------------------|-------------------------------------------------------|-----------|
| Table 1 (ten model rank test)   | `python3 code/fd_linear_system.py`                    | < 30 s    |
| §5.3 Engine Replacement         | `python3 code/example_engine_replacement.py`          | < 1 s     |
| §5.3 Altug–Miller (p=3)         | `python3 code/example_altug_miller.py --full`         | < 5 s     |
| §5.3 Investment                 | `python3 code/example_investment.py --full`           | < 5 s     |

Each `example_*.py` script also reports the FD payoff-difference error
against the direct Bellman value-difference, demonstrating the
two-method agreement claimed in §5.

### §6 Monte Carlo Evidence

| Table                           | Script                                                | Wall time | Saved output |
|---------------------------------|-------------------------------------------------------|-----------|--------------|
| Table 2 (Investment, 30 reps)   | `python3 code/monte_carlo_investment.py`              | ~20 min   | (none)       |
| Table 3 (Game, 1,000 reps)      | `python3 code/monte_carlo_game.py`                    | ~25 min   | `game_mc_results.txt` |
| §6.3 Theorem 6 asymptotic test         | `python3 code/test_variance_optimal.py`                  | < 30 s    | (stdout)     |
| Table 4 (Variance-opt MC, MD form)     | `python3 code/monte_carlo_game_variance_opt.py --eta 1e-4` | ~3 min  | (stdout)     |
| Table 5 (Variance-opt MC, MLE form)    | `python3 code/monte_carlo_game_variance_opt_mle.py --eta 1e-4` | ~80 s | (stdout) |
| §6.3 Phi_opt CCP-noise diagnostic      | `python3 code/diagnose_phi_opt.py --eta 1e-4`            | ~80 s     | (stdout)     |

Quick checks (10 reps each) for sanity:
```bash
python3 code/monte_carlo_investment.py --quick
python3 code/monte_carlo_game.py --quick
```

The Theorem 6 demonstration (`test_variance_optimal.py`) verifies the
asymptotic trace reduction (≈96% at η=1e-4) on five representative
states of the game DGP. The two finite-sample MCs
(`monte_carlo_game_variance_opt.py` MD form,
`monte_carlo_game_variance_opt_mle.py` MLE form) both show that
GFD-Opt is dominated by the canonical Moore–Penrose anchor in
finite-sample RMSE despite the asymptotic gain. The diagnostic
(`diagnose_phi_opt.py`) identifies the cause: ||Φ_opt|| is ~6.5×
larger than ||Φ_MP||, which inflates the first-stage CCP estimation
noise in the Hotz–Miller correction by ~20×, swamping the asymptotic
information gain at N=1000.

## Dependencies

- Python 3.10+
- `numpy`, `scipy` (sparse + linalg), `joblib` (MC parallelism)

No GPU. No proprietary solvers.

## Archive notes

[`_archived/`](_archived/) contains older / exploratory scripts that are
not used by the paper:
- [`_archived/scripts_root/`](_archived/scripts_root/) — debug scripts and
  stale documentation that previously lived at the repository root.
- [`_archived/code_past/`](_archived/code_past/) — earlier (pre-paper)
  iteration of the codebase.
- [`code/_archive/`](code/_archive/) — alternative solvers, exploratory
  tests, and stale documentation removed from the active `code/`
  directory during package preparation.

[`finite dependence 0325.zip`](finite%20dependence%200325.zip) is a
March 2026 snapshot of the prior paper draft and accompanying code,
preserved for reference.
