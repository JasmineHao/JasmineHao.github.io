# Code

Replication code for the Generalized Finite Dependence (GFD) paper.
Active files only; older / exploratory scripts live in [`_archive/`](_archive/).

## Organization

```
code/
├── README.md                          this file
├── FD_AS_LINEAR_SYSTEM.md             memo: FD as pointwise linear feasibility
├── UnifiedFDSolver.py                 core flow-QP solver (Section 2.5)
├── HistoryDependentFDSolver.py        Bellman value-iteration solver (reference)
├── fd_linear_system.py                rank/feasibility test (Section 5 Table 1)
├── test_rank_condition.py             ten canonical model builders
├── utils.py                           shared utilities (transitions, payoffs, equilibrium)
├── monte_carlo_investment.py          Section 6.1 MC
├── monte_carlo_game.py                Section 6.2 MC (canonical Phi_MP input)
├── monte_carlo_game_variance_opt.py   Section 6.3 variance-optimal MC (MD form)
├── monte_carlo_game_variance_opt_mle.py  Section 6.3 variance-optimal MC (MLE form)
├── test_variance_optimal.py           Section 6.3 Theorem 6 asymptotic demonstration
├── diagnose_phi_opt.py                Section 6.3 Phi_opt CCP-noise amplification diagnostic
├── example_engine_replacement.py      Section 5.3 walkthrough (Type R)
├── example_job_search.py              Section 5 Table 1 row
├── example_labor_p1.py                Section 5 Table 1 row (Type S, p=1)
├── example_investment.py              Section 5.3 walkthrough (Type K)
├── example_inventory.py               Section 5 Table 1 row (Type K)
├── example_entry_exit.py              Section 5 Table 1 row (Type D)
├── example_altug_miller.py            Section 5.3 walkthrough (Type S, p=3)
├── example_education.py               Section 5 Table 1 row (Type S, p=4)
├── example_game.py                    Section 5 Table 1 row + Section 6.2 DGP
├── example_oligopoly.py               Section 5 Table 1 row
└── _archive/                          older / exploratory code, not used by paper
```

## Reproducing paper results

| Paper output                         | Run                                                           | Wall time |
|--------------------------------------|---------------------------------------------------------------|-----------|
| §5 Table 1 (10 model rank/feasibility test) | `python3 fd_linear_system.py`                          | < 30 s    |
| §5.3 Engine Replacement walkthrough  | `python3 example_engine_replacement.py`                       | < 1 s     |
| §5.3 Altug–Miller (p=3) walkthrough  | `python3 example_altug_miller.py --full`                      | < 5 s     |
| §5.3 Investment walkthrough          | `python3 example_investment.py --full`                        | < 5 s     |
| §6.1 Investment MC (30 reps)         | `python3 monte_carlo_investment.py` (default config)          | ~20 min   |
| §6.2 Game MC (1000 reps)             | `python3 monte_carlo_game.py`                                 | ~25 min   |
| §6.2 Game MC quick check (10 reps)   | `python3 monte_carlo_game.py --quick`                         | < 30 s    |
| §6.3 Theorem 6 asymptotic test       | `python3 test_variance_optimal.py`                            | < 30 s    |
| §6.3 Variance-opt MC (MD form)       | `python3 monte_carlo_game_variance_opt.py --eta 1e-4`         | ~3 min    |
| §6.3 Variance-opt MC (MLE form)      | `python3 monte_carlo_game_variance_opt_mle.py --eta 1e-4`     | ~80 s     |
| §6.3 Phi_opt CCP-noise diagnostic    | `python3 diagnose_phi_opt.py --eta 1e-4`                      | ~80 s     |

Saved Monte Carlo output for §6.2 (1000 reps): `../game_mc_results.txt`.

## Dependencies

Python 3.10+ with `numpy`, `scipy` (sparse + linalg), `joblib` (for MC parallelism).
No GPU, no specialized solver libraries.

## Code-to-paper map

| Section         | Files                                                            |
|-----------------|------------------------------------------------------------------|
| §2.3 Flow QP    | `UnifiedFDSolver.py`                                             |
| §2.5 Theorem 3  | `fd_linear_system.py`, `FD_AS_LINEAR_SYSTEM.md`                  |
| §3 Estimator    | `UnifiedFDSolver.py` + per-DGP utilities in `utils.py`           |
| §5 Applications | All `example_*.py` + `fd_linear_system.py` + `test_rank_condition.py` |
| §6 Monte Carlo  | `monte_carlo_investment.py`, `monte_carlo_game.py`               |
