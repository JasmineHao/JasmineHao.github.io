"""
Example: Inventory Control Model
==================================
3 actions: No Order (0), Small Order (1), Large Order (2)
State: inventory_level x demand_shock
Memory: Decay (inventory depletes stochastically)
Control: Strong (ordering replenishes inventory)
Expected: rho=1 (strong control offsets decay)

Usage:
    python example_inventory.py
"""

import numpy as np
import time
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from UnifiedFDSolver import UnifiedFDSolver
from HistoryDependentFDSolver import solve_mdp
from utils import state_transition, my_kron, my_meshgrid


def build_model():
    beta = 0.95

    # Inventory grid
    n_inv = 5
    inv_grid = np.arange(n_inv)  # 0, 1, 2, 3, 4

    # Demand shock (exogenous)
    f_d, d_grid = state_transition(0, 0.5, 1.5, 4, min_val=0, max_val=3)

    # Inventory transitions (action-dependent, deterministic)
    # Action 0: no order, inventory depletes by 1
    f_inv_0 = np.zeros((n_inv, n_inv))
    for i in range(n_inv):
        f_inv_0[i, max(i - 1, 0)] = 1.0

    # Action 1: small order, inventory stays same
    f_inv_1 = np.eye(n_inv)

    # Action 2: large order, inventory increases by 1
    f_inv_2 = np.zeros((n_inv, n_inv))
    for i in range(n_inv):
        f_inv_2[i, min(i + 1, n_inv - 1)] = 1.0

    F = np.array([my_kron([f_inv_0, f_d]),
                  my_kron([f_inv_1, f_d]),
                  my_kron([f_inv_2, f_d])])
    n_states = F.shape[1]

    # Payoff: revenue from sales - holding cost - ordering cost
    state = my_meshgrid([inv_grid, d_grid])
    u = np.zeros((3, n_states))
    for a in range(3):
        u[a] = 2.0 * np.minimum(state[:, 0], state[:, 1]) - 0.3 * state[:, 0] - 1.0 * a - 0.5 * a**2

    return F, u, beta, n_states, 3


def run():
    F, u, beta, n_states, n_actions = build_model()
    V, v, e = solve_mdp(F, u, beta)

    print(f"Inventory Control: S={n_states}, A={n_actions}, beta={beta}")
    print(f"  {'rho':>3}  {'case':<28} {'dist':>10} {'payoff_err':>12} {'time':>7}")
    print(f"  {'-'*65}")

    cases = [
        (0, 0, 1, "NoOrder vs SmallOrder"),
        (0, 0, 2, "NoOrder vs LargeOrder"),
        (0, 1, 2, "SmallOrder vs LargeOrder"),
        (10, 0, 2, "s10: NoOrder vs LargeOrd"),
    ]

    for rho in [1]:
        t0 = time.time()
        solver = UnifiedFDSolver(T=F, rho=rho, n_states=n_states, n_actions=n_actions)
        init_time = time.time() - t0
        print(f"  [rho={rho}] Init time: {init_time:.3f}s")

        for s0, k, K, desc in cases:
            true_diff = v[k, s0] - v[K, s0]
            t0 = time.time()
            phi_k, phi_K, dist, ce = solver.solve(s0, k, K)
            solve_time = time.time() - t0
            fd = solver.evaluate_value_difference(phi_k, phi_K, s0, k, K, u, e, beta)
            print(f"  {rho:>3}  {desc:<28} {dist:>10.2e} {abs(fd - true_diff):>12.2e} {solve_time:>6.3f}s")
        print()


if __name__ == "__main__":
    run()
