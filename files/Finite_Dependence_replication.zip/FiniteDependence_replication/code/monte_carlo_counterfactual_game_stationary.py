"""
Counterfactual Monte Carlo for the 3-player dynamic entry/exit game.

Empirically tests Theorem 2 (Bellman-free counterfactual CCPs) on a
multi-agent MPE. For each counterfactual structural parameter theta_cf
we compute the new equilibrium CCPs two ways:

  (i) GFD bridge (Theorem 2, multi-agent):
        Per player p, freeze dphi_p at the BASELINE perceived transition
        F_p(P_{-p}^{baseline}) = compute_ftran_game(P_eq_baseline)[p].
        Iterate p^{(m+1)}_p = Lambda(v_tilde_p^{rho-FD}(theta_cf, Phi_p_baseline, p^{(m)}))
        for each player; opponents' CCPs enter the iteration through dpi
        (the per-period payoff basis, which depends on E[N_{-p,enter}])
        but NOT through dphi.
        NO Bellman re-solve, NO flow-QP re-solve per theta_cf.

 (ii) NFXP gold standard:
        Re-solve the full MPE at theta_cf via Gauss-Seidel best-response
        iteration over all 3 players (solve_game_equilibrium). Pays the
        Bellman + best-response cost per theta_cf.

The honest question we are testing: does the frozen-dphi approximation
agree with the NFXP solution to material precision, and at what
wall-clock saving across a sweep of counterfactual regimes?

Usage:
    python monte_carlo_counterfactual_game.py            # default sweep
    python monte_carlo_counterfactual_game.py --quick    # 2 scenarios
"""
from __future__ import annotations

import sys, os, time, argparse, csv
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import contextlib, io as _io

from UnifiedFDSolver import UnifiedFDSolver
import monte_carlo_game as mcg
from monte_carlo_game import (
    build_game_model, THETA_TRUE, BETA, N_PLAYERS,
    set_state_space,
)
from utils import (
    solve_game_equilibrium, compute_ftran_game,
    compute_dpi_dtheta_game, my_meshgrid,
)

EULER = 0.5772156649


# ============================================================================
# Baseline setup: build MPE at theta_TRUE and precompute frozen Phi_p
# ============================================================================

def setup_baseline(verbose=True):
    """Build baseline MPE and precompute frozen Phi_p (rho=2) per player.

    Returns dict with:
        state, P_eq_baseline, V_eq_baseline, Ftran_baseline, dpi_baseline,
        dphi_coeff_per_player: list of (S, A, S) tensors
        S, A, K_ref, phi_setup_time
    """
    if verbose:
        print("Building baseline MPE at theta_TRUE...")
    t0 = time.time()
    with contextlib.redirect_stdout(_io.StringIO()):
        state, P_eq, V_eq, Ftran, dpi = build_game_model(THETA_TRUE)
    t_mpe_baseline = time.time() - t0

    S = Ftran[0].shape[1]
    A = 2
    K_ref = 1     # action 1 = "in"; K_ref is the reference action
    rho = 2

    if verbose:
        print(f"  Baseline MPE solved in {t_mpe_baseline:.3f}s, "
              f"|X_i|={S}, A={A}, rho={rho}")

    # Per-player frozen Phi
    if verbose:
        print("Precomputing frozen Phi_p per player (one-time cost)...")
    t0 = time.time()
    dphi_coeff_per_player = []
    for p in range(N_PLAYERS):
        F_p = Ftran[p]
        solver = UnifiedFDSolver(T=F_p, rho=rho, n_states=S, n_actions=A)
        dphi_all = solver.solve_all_states_diff_standard(0, K_ref, tol=1e-6)
        # Aggregate (S, n_j, n_k) -> (S, A, S)
        j_arr = solver.j_arr   # (n_j, rho)
        k_arr = solver.k_arr   # (n_k, rho)
        M_j = (j_arr[:, :, None] == np.arange(S)[None, None, :]).astype(float)
        M_k = (k_arr[:, :, None] == np.arange(A)[None, None, :]).astype(float)
        beta_pow = BETA ** (np.arange(rho) + 1)
        M_j_w = M_j * beta_pow[None, :, None]
        dphi_coeff = np.einsum('xjk, jtJ, ktA -> xAJ',
                                dphi_all, M_j_w, M_k)
        dphi_coeff_per_player.append(dphi_coeff)
    t_phi_setup = time.time() - t0
    if verbose:
        print(f"  Phi_p precompute (3 players): {t_phi_setup:.3f}s")

    return {
        'state': state,
        'P_eq_baseline': P_eq,
        'V_eq_baseline': V_eq,
        'Ftran_baseline': Ftran,
        'dpi_baseline': dpi,
        'dphi_coeff_per_player': dphi_coeff_per_player,
        'S': S, 'A': A, 'K_ref': K_ref, 'rho': rho,
        't_mpe_baseline': t_mpe_baseline,
        't_phi_setup': t_phi_setup,
    }


# ============================================================================
# NFXP path: re-solve MPE at theta_cf
# ============================================================================

def nfxp_counterfactual(state, theta_cf_list):
    """Re-solve the full MPE at theta_cf via Gauss-Seidel best-response."""
    t0 = time.time()
    with contextlib.redirect_stdout(_io.StringIO()):
        P_cf, V_cf = solve_game_equilibrium(
            state, theta_cf_list, mcg.F_S, [BETA] * N_PLAYERS
        )
    return P_cf, V_cf, time.time() - t0


# ============================================================================
# GFD bridge path: frozen-Phi iteration in CCP space
# ============================================================================

def gfd_bridge_counterfactual(baseline, theta_cf_list,
                                tol=1e-6, max_iter=500,
                                update_dpi_per_iter=True,
                                verbose=False):
    """Iterate p^{(m+1)} = Lambda(v_tilde^{rho-FD}(theta_cf, Phi_baseline, p^{(m)}))
    per player. dphi is FROZEN at baseline F_p; opponents' equilibrium
    responses enter through per-iteration dpi (the payoff basis depends on
    E[N_{-p, enter}]) when update_dpi_per_iter=True, else dpi is also frozen.
    """
    t0 = time.time()
    state = baseline['state']
    S = baseline['S']
    A = baseline['A']
    K_ref = baseline['K_ref']
    dphi_pp = baseline['dphi_coeff_per_player']
    P_eq_b = baseline['P_eq_baseline']
    dpi_b = baseline['dpi_baseline']

    # Warm-start at baseline equilibrium CCPs
    # P_eq_b[p] has shape (S, A); we store as (A, S) for easier psi computation
    P = [P_eq_b[p].T.copy() for p in range(N_PLAYERS)]   # P[p]: (A, S)

    for it in range(max_iter):
        # Optionally recompute dpi at current P (opponents' equilibrium
        # response on payoff basis; cheap relative to MPE re-solve)
        if update_dpi_per_iter:
            # Stack list-of-(A,S) into (n_player, S, A) numpy array
            P_for_dpi = np.stack([P[p].T for p in range(N_PLAYERS)], axis=0)
            dpi_cur = compute_dpi_dtheta_game(state, N_PLAYERS, P_for_dpi)
        else:
            dpi_cur = dpi_b

        max_diff = 0.0
        P_new = [None] * N_PLAYERS

        for p in range(N_PLAYERS):
            theta_p_cf = np.asarray(theta_cf_list[p])

            # Payoff at theta_cf with current opponents' CCPs (via dpi)
            u_p = np.zeros((A, S))
            for a in range(A):
                u_p[a] = dpi_cur[p, a] @ theta_p_cf       # (S,)

            # Hotz-Miller correction at current P_p
            log_P_p = np.log(np.clip(P[p], 1e-12, 1.0))   # (A, S)
            psi = EULER - log_P_p                           # (A, S)
            u_plus_psi = u_p + psi                          # (A, S)

            # GFD value-difference (binary: log-odds for action 0 vs K_ref=1)
            # fd_per_state[x0] = u(0, x0) - u(K_ref, x0)
            #                  + sum_{a, j} dphi_p[x0, a, j] * u_plus_psi[a, j]
            phi_p = dphi_pp[p]                              # (S, A, S)
            fd_per_state = (u_p[0] - u_p[K_ref]
                            + np.einsum('xaj,aj->x', phi_p, u_plus_psi))

            # Binary logit: P_new(0|s) = sigmoid(fd_per_state[s])
            # Use stable form:
            fd_clip = np.clip(fd_per_state, -50, 50)
            p0 = 1.0 / (1.0 + np.exp(-fd_clip))             # (S,)
            P_p_new = np.vstack([p0, 1.0 - p0])             # (A=2, S)

            diff_p = np.max(np.abs(P_p_new - P[p]))
            max_diff = max(max_diff, diff_p)
            P_new[p] = P_p_new

        P = P_new
        if verbose and (it % 20 == 0 or it < 5):
            print(f"    iter {it:3d}  max_diff = {max_diff:.2e}")
        if max_diff < tol:
            break

    n_iter = it + 1
    # Return as (S, A) per player to match P_eq convention
    P_out = [P[p].T for p in range(N_PLAYERS)]
    return P_out, time.time() - t0, n_iter


# ============================================================================
# Counterfactual grid
# ============================================================================

def make_counterfactual_grid():
    """Counterfactual sweep: shift player 0's parameters one at a time.

    Each scenario perturbs ONE parameter for player 0 from THETA_TRUE.
    Players 1, 2 keep their true parameters.
    Returns list of (label, theta_cf_list).
    """
    out = []
    th_base = [list(t) for t in THETA_TRUE]

    # Entry cost (theta_4) perturbations on player 0
    for delta in [-0.3, -0.1, +0.1, +0.3]:
        th_cf = [list(t) for t in THETA_TRUE]
        th_cf[0][3] = THETA_TRUE[0][3] * (1.0 + delta)
        out.append((f"P0.entry x {1+delta:.2f}", th_cf))

    # Fixed cost (theta_3) perturbations on player 0
    for delta in [-0.2, +0.2, +0.5]:
        th_cf = [list(t) for t in THETA_TRUE]
        th_cf[0][2] = THETA_TRUE[0][2] * (1.0 + delta)
        out.append((f"P0.fixed x {1+delta:.2f}", th_cf))

    # Competition sensitivity (theta_2) perturbations on player 0
    for delta in [-0.3, +0.3]:
        th_cf = [list(t) for t in THETA_TRUE]
        th_cf[0][1] = THETA_TRUE[0][1] * (1.0 + delta)
        out.append((f"P0.comp x {1+delta:.2f}", th_cf))

    return out


# ============================================================================
# Structural-perturbation harness: counterfactuals on F_S itself
# These REQUIRE Phi to be rebuilt; the frozen-Phi heuristic does not apply.
# ============================================================================

def make_structural_perturbation_grid():
    """Counterfactual grid that perturbs the EXOGENOUS market-size process F_S.

    Each scenario re-scales the diagonal/off-diagonal mass of F_S and
    renormalises rows. This is a STRUCTURAL counterfactual: the perceived
    transition F_p for every player changes, and Phi MUST be rebuilt at the
    new F_S. Theorem 2's strict bridge still applies because the operative
    transition kernel is structural (we hold opponents' CCPs at baseline).

    Returns list of (label, F_S_perturbed).
    """
    out = []
    F_S_baseline = mcg.F_S.copy()
    # Persistence perturbations: shift mass between diagonal and off-diagonal
    # while keeping rows normalised. New F_S = (1 - alpha) * Identity + alpha * F_S_baseline.
    # alpha < 1 -> MORE persistent; alpha > 1 (clipped) -> LESS persistent.
    n = F_S_baseline.shape[0]
    Id = np.eye(n)
    for alpha in [0.7, 0.85, 1.15, 1.30]:
        F_new = (1.0 - alpha) * Id + alpha * F_S_baseline
        F_new = np.clip(F_new, 0.0, None)
        F_new = F_new / F_new.sum(axis=1, keepdims=True)
        out.append((f"F_S persistence x {alpha:.2f}", F_new))
    return out


def nfxp_counterfactual_structural(state, theta, F_S_cf):
    """Re-solve MPE at theta_baseline with perturbed F_S (cold start)."""
    t0 = time.time()
    with contextlib.redirect_stdout(_io.StringIO()):
        P_cf, V_cf = solve_game_equilibrium(
            state, theta, F_S_cf, [BETA] * N_PLAYERS
        )
    return P_cf, V_cf, time.time() - t0


def solve_game_equilibrium_warm(state, theta, F_s, discount_factors,
                                  P_init=None, V_init=None, tol=1e-6,
                                  max_iter=1000):
    """Warm-startable variant of solve_game_equilibrium.

    The original solve_game_equilibrium initialises P=0.5 and V=0; for
    counterfactual sweeps the baseline equilibrium is a much better start.
    """
    from utils import compute_ftran_game, compute_dpi_dtheta_game
    from scipy.special import expit as logit
    n_player = len(theta)
    n_state = len(state)
    if P_init is None:
        P = np.ones((n_player, n_state, 2)) / 2
    else:
        P = P_init.copy()
    if V_init is None:
        V = np.zeros((n_player, n_state))
    else:
        V = V_init.copy()
    iter_count = 0
    dist = 10.0
    while (iter_count < max_iter) and (dist > tol):
        Ftran = compute_ftran_game(P, F_s, state, n_player)
        dpi_dtheta = compute_dpi_dtheta_game(state, n_player, P)
        P_new = np.zeros_like(P)
        V_new = np.zeros_like(V)
        for i in range(n_player):
            v_1i = dpi_dtheta[i, 1] @ theta[i] + discount_factors[i] * Ftran[i, 1] @ V[i]
            v_0i = dpi_dtheta[i, 0] @ theta[i] + discount_factors[i] * Ftran[i, 0] @ V[i]
            P_new[i, :, 1] = logit(v_1i - v_0i)
            P_new[i, :, 0] = 1 - P_new[i, :, 1]
            V_new[i] = EULER + np.log(np.exp(v_1i) + np.exp(v_0i))
        dist = np.max(np.abs(V_new - V))
        iter_count += 1
        V = V_new
        P = P_new
    return P, V, iter_count


def nfxp_counterfactual_structural_warm(state, theta, F_S_cf,
                                          P_init, V_init):
    """Warm-start NFXP from baseline P_eq, V_eq -- fair comparison
    against the GFD bridge which also warm-starts from baseline P_eq."""
    t0 = time.time()
    P_cf, V_cf, n_it = solve_game_equilibrium_warm(
        state, theta, F_S_cf, [BETA] * N_PLAYERS,
        P_init=P_init, V_init=V_init,
    )
    return P_cf, V_cf, time.time() - t0, n_it


def gfd_resolve_counterfactual_structural(state, theta, F_S_cf,
                                            P_eq_baseline, rho=2, K_ref=1,
                                            tol=1e-6, max_iter=500,
                                            verbose=False):
    """STRICT bridge: under structural perturbation F_S -> F_S_cf, rebuild
    Phi_p at the new perceived transition F_p^cf = compute_ftran_game(
    P_{-p}^baseline; F_S_cf), then iterate the bridge.

    This is the *strict* multi-agent bridge: Phi is the structurally-correct
    flow input at the new F_S. The cost is one flow-QP rebuild per player
    per counterfactual scenario.

    Returns (P_out, total_elapsed, t_phi_rebuild, n_iter)
    """
    t0 = time.time()
    A = 2
    n_state = len(state)

    # Stage 1: rebuild F_p^cf using baseline P_{-p} but NEW F_S
    # P_eq_baseline is the (n_player, S, A) array
    Ftran_cf = compute_ftran_game(P_eq_baseline, F_S_cf, state, N_PLAYERS)

    # Stage 2: rebuild Phi_p at F_p^cf for each player
    t_phi_start = time.time()
    dphi_pp = []
    for p in range(N_PLAYERS):
        F_p_cf = Ftran_cf[p]
        S = F_p_cf.shape[1]
        solver = UnifiedFDSolver(T=F_p_cf, rho=rho, n_states=S, n_actions=A)
        dphi_all = solver.solve_all_states_diff_standard(0, K_ref, tol=1e-6)
        j_arr = solver.j_arr
        k_arr = solver.k_arr
        M_j = (j_arr[:, :, None] == np.arange(S)[None, None, :]).astype(float)
        M_k = (k_arr[:, :, None] == np.arange(A)[None, None, :]).astype(float)
        beta_pow = BETA ** (np.arange(rho) + 1)
        M_j_w = M_j * beta_pow[None, :, None]
        dphi_coeff = np.einsum('xjk, jtJ, ktA -> xAJ',
                                dphi_all, M_j_w, M_k)
        dphi_pp.append(dphi_coeff)
    t_phi_rebuild = time.time() - t_phi_start

    # Stage 3: bridge iteration with rebuilt Phi
    S = dphi_pp[0].shape[0]
    P = [P_eq_baseline[p].T.copy() for p in range(N_PLAYERS)]   # (A, S) each

    for it in range(max_iter):
        P_for_dpi = np.stack([P[p].T for p in range(N_PLAYERS)], axis=0)
        dpi_cur = compute_dpi_dtheta_game(state, N_PLAYERS, P_for_dpi)

        max_diff = 0.0
        P_new = [None] * N_PLAYERS
        for p in range(N_PLAYERS):
            theta_p = np.asarray(theta[p])
            u_p = np.zeros((A, S))
            for a in range(A):
                u_p[a] = dpi_cur[p, a] @ theta_p
            log_P_p = np.log(np.clip(P[p], 1e-12, 1.0))
            psi = EULER - log_P_p
            u_plus_psi = u_p + psi
            phi_p = dphi_pp[p]
            fd_per_state = (u_p[0] - u_p[K_ref]
                            + np.einsum('xaj,aj->x', phi_p, u_plus_psi))
            fd_clip = np.clip(fd_per_state, -50, 50)
            p0 = 1.0 / (1.0 + np.exp(-fd_clip))
            P_p_new = np.vstack([p0, 1.0 - p0])
            diff_p = np.max(np.abs(P_p_new - P[p]))
            max_diff = max(max_diff, diff_p)
            P_new[p] = P_p_new
        P = P_new
        if max_diff < tol:
            break

    n_iter = it + 1
    P_out = [P[p].T for p in range(N_PLAYERS)]
    return P_out, time.time() - t0, t_phi_rebuild, n_iter


def run_structural_counterfactual_game_mc(quick=False, save_path=None):
    """Sweep over structural perturbations on F_S, comparing the strict
    Phi-resolve bridge against NFXP."""
    print("=" * 78)
    print("Counterfactual MC (STRUCTURAL): F_S perturbations on 3-player game")
    print("Strict bridge: Phi re-solved at each counterfactual F_S")
    print("=" * 78)
    print()

    # Need baseline once (for warm-start CCPs and dpi at original F_S)
    baseline = setup_baseline(verbose=True)
    state = baseline['state']
    P_eq_baseline = baseline['P_eq_baseline']
    V_eq_baseline = baseline['V_eq_baseline']
    grid = make_structural_perturbation_grid()
    if quick:
        grid = grid[:2]
    K = len(grid)
    print(f"\nStructural perturbation sweep: K = {K} scenarios")
    print()

    header = (f"{'scenario':<22} {'NFXPcold':>9} {'NFXPwarm':>9} "
              f"{'GFD-resolve':>11} {'Phi':>7} {'iters':>5} "
              f"{'sup-err':>10}")
    print(header)
    print("-" * len(header))

    rows = []
    nfxp_cold_total = 0.0
    nfxp_warm_total = 0.0
    gfd_total = 0.0
    phi_rebuild_total = 0.0
    err_worst = 0.0

    for label, F_S_cf in grid:
        # NFXP cold: re-solve MPE at perturbed F_S from scratch
        P_nfxp_cold, V_nfxp_cold, t_nfxp_cold = nfxp_counterfactual_structural(
            state, THETA_TRUE, F_S_cf,
        )
        nfxp_cold_total += t_nfxp_cold

        # NFXP warm: re-solve MPE at perturbed F_S starting from baseline
        P_nfxp_warm, V_nfxp_warm, t_nfxp_warm, nfxp_warm_iters = (
            nfxp_counterfactual_structural_warm(
                state, THETA_TRUE, F_S_cf,
                P_init=P_eq_baseline, V_init=V_eq_baseline,
            )
        )
        nfxp_warm_total += t_nfxp_warm

        # GFD-resolve: rebuild Phi at new F_S, then bridge
        P_gfd, t_total, t_phi, n_it = gfd_resolve_counterfactual_structural(
            state, THETA_TRUE, F_S_cf, P_eq_baseline,
            rho=2, K_ref=1, tol=1e-6, max_iter=500,
        )
        gfd_total += t_total
        phi_rebuild_total += t_phi

        err = 0.0
        for p in range(N_PLAYERS):
            err = max(err, np.max(np.abs(P_gfd[p] - P_nfxp_warm[p])))
        err_worst = max(err_worst, err)

        print(f"{label:<22} {t_nfxp_cold*1000:>8.1f}  {t_nfxp_warm*1000:>8.1f}  "
              f"{t_total*1000:>10.1f}  {t_phi*1000:>6.1f}  {n_it:>4}  "
              f"{err:>9.2e}")

        rows.append({
            'scenario': label,
            'nfxp_cold_ms': t_nfxp_cold * 1000,
            'nfxp_warm_ms': t_nfxp_warm * 1000,
            'nfxp_warm_iters': nfxp_warm_iters,
            'gfd_resolve_total_ms': t_total * 1000,
            'phi_rebuild_ms': t_phi * 1000,
            'gfd_iters': n_it,
            'sup_norm_err': err,
        })

    print("-" * len(header))
    speedup_vs_cold = nfxp_cold_total / gfd_total if gfd_total > 0 else float('nan')
    speedup_vs_warm = nfxp_warm_total / gfd_total if gfd_total > 0 else float('nan')
    print(f"{'TOTAL':<22} {nfxp_cold_total*1000:>8.1f}  "
          f"{nfxp_warm_total*1000:>8.1f}  {gfd_total*1000:>10.1f}  "
          f"{phi_rebuild_total*1000:>6.1f}ms")
    print(f"{'SPEEDUP cold/GFD':<22} {speedup_vs_cold:>8.2f}x")
    print(f"{'SPEEDUP warm/GFD':<22} {speedup_vs_warm:>8.2f}x")
    print(f"{'WORST sup-norm err':<22} {err_worst:>8.2e}")

    if save_path:
        with open(save_path, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            for r in rows:
                w.writerow(r)
        print(f"\nWrote {save_path}")

    return {
        'rows': rows,
        'nfxp_cold_total_s': nfxp_cold_total,
        'nfxp_warm_total_s': nfxp_warm_total,
        'gfd_total_s': gfd_total,
        'phi_rebuild_total_s': phi_rebuild_total,
        'speedup_vs_cold': speedup_vs_cold,
        'speedup_vs_warm': speedup_vs_warm,
        'worst_sup_err': err_worst,
        'K_scenarios': K,
    }


# ============================================================================
# Main MC harness
# ============================================================================

def run_counterfactual_game_mc(quick=False, save_path=None,
                                  update_dpi_per_iter=True):
    """Run the counterfactual sweep on the 3-player game.

    For each scenario:
      - NFXP wall-clock + CCP
      - GFD-bridge wall-clock + CCP + iteration count
      - sup-norm |P_GFD - P_NFXP| across players
    """
    print("=" * 78)
    print("Counterfactual Monte Carlo: 3-player entry/exit game")
    print("Bridge identity (Theorem 2) with frozen Phi_p at baseline MPE")
    print("=" * 78)
    print()

    baseline = setup_baseline(verbose=True)
    grid = make_counterfactual_grid()
    if quick:
        grid = grid[:2]
    K = len(grid)
    print(f"\nCounterfactual sweep: K = {K} scenarios")
    print(f"  dpi update during bridge iteration: {update_dpi_per_iter}")
    print()

    rows = []
    nfxp_total = 0.0
    gfd_total = 0.0
    err_max_across = 0.0

    header = (f"{'scenario':<22} {'NFXP (ms)':>10} {'GFD-bridge (ms)':>17} "
              f"{'iters':>6} {'sup-norm err':>14}")
    print(header)
    print("-" * len(header))

    for label, theta_cf in grid:
        # NFXP gold-standard
        P_nfxp, V_nfxp, t_nfxp = nfxp_counterfactual(baseline['state'], theta_cf)
        nfxp_total += t_nfxp

        # GFD bridge
        P_gfd, t_gfd, n_it = gfd_bridge_counterfactual(
            baseline, theta_cf, tol=1e-6, max_iter=500,
            update_dpi_per_iter=update_dpi_per_iter, verbose=False,
        )
        gfd_total += t_gfd

        # Compare CCPs across all players, sup-norm
        err = 0.0
        for p in range(N_PLAYERS):
            err = max(err, np.max(np.abs(P_gfd[p] - P_nfxp[p])))
        err_max_across = max(err_max_across, err)

        print(f"{label:<22} {t_nfxp*1000:>8.1f}   {t_gfd*1000:>14.1f}    "
              f"{n_it:>4}   {err:>13.4e}")

        rows.append({
            'scenario': label,
            'nfxp_ms': t_nfxp * 1000,
            'gfd_ms': t_gfd * 1000,
            'gfd_iters': n_it,
            'sup_norm_err': err,
        })

    print("-" * len(header))
    # Amortized GFD: include one-time Phi setup
    gfd_amortized = baseline['t_phi_setup'] + gfd_total
    speedup = nfxp_total / gfd_amortized if gfd_amortized > 0 else float('nan')
    print(f"{'TOTAL':<22} {nfxp_total*1000:>8.1f}   {gfd_total*1000:>14.1f}    "
          f"(+ {baseline['t_phi_setup']*1000:.1f}ms Phi setup)")
    print(f"{'AMORTIZED TOTAL GFD':<22} {'':>10} {gfd_amortized*1000:>14.1f} ms")
    print(f"{'SPEEDUP NFXP/GFD':<22} {'':>10} {speedup:>14.2f}x")
    print(f"{'WORST sup-norm err':<22} {'':>10} {err_max_across:>14.4e}")

    if save_path:
        with open(save_path, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            for r in rows:
                w.writerow(r)
        print(f"\nWrote {save_path}")

    return {
        'rows': rows,
        'nfxp_total_s': nfxp_total,
        'gfd_total_s': gfd_total,
        'gfd_amortized_s': gfd_amortized,
        'phi_setup_s': baseline['t_phi_setup'],
        'speedup': speedup,
        'worst_sup_err': err_max_across,
        'K_scenarios': K,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--quick', action='store_true',
                        help='Only 2 scenarios for smoke test')
    parser.add_argument('--state-size', choices=['small', 'big', 'xl'],
                        default='small',
                        help='Market-size grid: small (|X_i|=24), '
                             'big (|X_i|=40), xl (|X_i|=80)')
    parser.add_argument('--frozen-dpi', action='store_true',
                        help='Also freeze dpi at baseline; aggressive '
                             'partial-equilibrium approximation')
    parser.add_argument('--mode', choices=['payoff', 'structural'],
                        default='payoff',
                        help='payoff (frozen-Phi heuristic) or '
                             'structural (strict Phi-resolve)')
    parser.add_argument('--out', type=str, default=None,
                        help='CSV output path')
    args = parser.parse_args()

    set_state_space(args.state_size)
    print(f"State-space level: {args.state_size}")
    if args.mode == 'structural':
        res = run_structural_counterfactual_game_mc(
            quick=args.quick, save_path=args.out,
        )
    else:
        res = run_counterfactual_game_mc(
            quick=args.quick, save_path=args.out,
            update_dpi_per_iter=not args.frozen_dpi,
        )
    return res


if __name__ == "__main__":
    main()
