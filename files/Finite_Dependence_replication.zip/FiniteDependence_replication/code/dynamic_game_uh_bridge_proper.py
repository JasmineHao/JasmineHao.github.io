"""
dynamic_game_uh_bridge_proper.py
================================

Phase 3 main demonstration (proper bridge implementation).

This replaces the buggy `dynamic_game_uh_vsensitivity.py` whose
"bridge" estimator was actually NFXP-EM with V_terminal = 0
hard-coded.  The PROPER bridge identity at rho = 2 is V-independent
*by construction* because the flow weights Phi are chosen to make
the terminal continuation cancel.

Implementation
--------------
For each (player i, type ell, initial state x_t, period t) with
t in [0, T_obs - rho - 1]:

  1. Build the perceived transitions F_i^(ell)(t) and F_i^(ell)(t+1)
     from the empirical posterior-weighted rival CCPs at those
     periods.

  2. Build the FD linear system A_{i,ell,x_t,t} * x = b_{i,ell,x_t,t}
     with time-varying transitions [F_i^(ell)(t), F_i^(ell)(t+1)] at
     horizon rho = 2.  Solve via LSQR for the canonical
     (minimum-l2-norm) flow Phi_i^(ell)(x_t, t) of shape
     (S, S, D, D) = (4, 4, 2, 2) -- the action-difference part.
     CACHE this once per EM iteration (independent of theta).

  3. Build the CCP-correction anchors psi_i^(ell)(t+1),
     psi_i^(ell)(t+2) from the empirical posterior-weighted CCPs.
     CACHE.

  4. Per-theta evaluation in the M-step:
       v_diff(d, x_t, t; theta) = u_diff(d, x_t; theta)
         + beta * sum_{(j_1,k_1)} Phi_marg_1[(j_1,k_1)] * (u(k_1, j_1; theta) + psi(t+1)(k_1, j_1))
         + beta^2 * sum_{(j_2,k_2)} Phi_marg_2[(j_2,k_2)] * (u(k_2, j_2; theta) + psi(t+2)(k_2, j_2))
     -> logit -> log-likelihood.  NO backward induction, NO V_T.

V-sensitivity test (corrected setup)
-----------------------------------
Following the user's framing:

  * DGP fixed at V_T_true = 0.
  * NFXP-EM in the M-step uses V_T_obs = c * (l_1 + l_2) for c in
    {-3, -1, 0, +1, +3}; the analyst does not know V_T_true and must
    commit to some V_T_obs.  Each commitment produces a different
    theta_estimated -> systematic bias.
  * Proper Bridge-EM (this script) does not require any V_T_obs and
    therefore produces a single (theta, pi) estimate that is
    insensitive to V_T_obs by construction.

Note on infeasibility of V-true variation alternative
-----------------------------------------------------
An alternative setup varies V_T_true in the DGP and uses
V_T_obs = 0 in NFXP -- this demonstrates the same point.  We adopt
the equivalent V_T_obs sweep here so the cross-method comparison
matches the Phase 1b single-agent table format.
"""

from __future__ import annotations

import argparse
import time
from itertools import product

import numpy as np
from scipy.optimize import minimize
from scipy.sparse import csr_matrix, vstack
from scipy.sparse.linalg import lsqr


# =============================================================================
# Setup (same as previous Phase 3 scripts)
# =============================================================================

T_TRUE = 30
T_OBS = 15
N_PLAYERS = 2
N_ACTIONS = 2
N_STATES = N_ACTIONS ** N_PLAYERS                  # 4
BETA = 0.95
RHO = 2

THETA_TRUE = np.array([
    [1.5, 1.5, 0.3],
    [0.5, 1.5, 0.3],
])
PI_TRUE = np.array([0.6, 0.4])
K_TYPES = THETA_TRUE.shape[0]


def x_to_yvec(x): return (x >> 1) & 1, x & 1
def yvec_to_x(y1, y2): return (y1 << 1) | y2


def payoff(theta, d_i, x, i):
    if d_i == 0:
        return 0.0
    y1, y2 = x_to_yvec(x)
    y_self = y1 if i == 0 else y2
    y_other = y2 if i == 0 else y1
    rev, comp, entry = theta
    return rev - comp * y_other - entry * (1 - y_self)


def payoff_grid(theta, i):
    out = np.zeros((N_ACTIONS, N_STATES))
    for d in range(N_ACTIONS):
        for x in range(N_STATES):
            out[d, x] = payoff(theta, d, x, i)
    return out


def perceived_transition(p_other, i):
    F = np.zeros((N_ACTIONS, N_STATES, N_STATES))
    for x in range(N_STATES):
        for d_i in range(N_ACTIONS):
            for d_other in range(N_ACTIONS):
                w = p_other[d_other, x]
                if i == 0:
                    x_next = yvec_to_x(d_i, d_other)
                else:
                    x_next = yvec_to_x(d_other, d_i)
                F[d_i, x, x_next] += w
    return F


# =============================================================================
# DGP (NFXP-style backward induction in the DGP, with finite horizon)
# =============================================================================

def backward_induction_dgp(theta, p_other_by_t, i, T, V_terminal=None):
    if V_terminal is None:
        V_terminal = np.zeros(N_STATES)
    u = payoff_grid(theta, i)
    p_i = np.zeros((T, N_ACTIONS, N_STATES))
    V = V_terminal.copy()
    for t in range(T - 1, -1, -1):
        F_t = perceived_transition(p_other_by_t[t], i)
        v_t = u + BETA * (F_t * V[None, None, :]).sum(axis=2)
        m = v_t.max(axis=0)
        ev = np.exp(v_t - m)
        p_i[t] = ev / ev.sum(axis=0)
        V = m + np.log(ev.sum(axis=0))
    return p_i


def find_finite_horizon_mpe_dgp(theta, T, V_terminal=None, n_iter=300, tol=1e-8):
    p = np.full((N_PLAYERS, T, N_ACTIONS, N_STATES), 0.5)
    for _ in range(n_iter):
        p_new = np.zeros_like(p)
        for i in range(N_PLAYERS):
            p_new[i] = backward_induction_dgp(theta, p[1 - i], i, T,
                                               V_terminal=V_terminal)
        if np.max(np.abs(p_new - p)) < tol:
            return p_new
        p = p_new
    return p


def simulate_mixture_truncated(mpes_true, pi, n_markets, T_true, T_obs, rng):
    K = len(mpes_true)
    types = rng.choice(K, size=n_markets, p=pi)
    decisions = np.zeros((n_markets, T_obs, N_PLAYERS), dtype=int)
    states = np.zeros((n_markets, T_obs + 1), dtype=int)
    states[:, 0] = rng.integers(0, N_STATES, size=n_markets)
    for m in range(n_markets):
        k = types[m]
        p = mpes_true[k]
        for t in range(T_obs):
            x = states[m, t]
            d = np.zeros(N_PLAYERS, dtype=int)
            for i in range(N_PLAYERS):
                d[i] = rng.choice(N_ACTIONS, p=p[i, t, :, x])
            decisions[m, t] = d
            states[m, t + 1] = yvec_to_x(d[0], d[1])
    return {"decisions": decisions, "states": states, "types": types,
            "n_markets": n_markets, "T": T_obs}


# =============================================================================
# Posterior-weighted empirical CCPs (anchor)
# =============================================================================

def empirical_ccp_by_type_period(data, posterior, laplace=1.0):
    decisions = data["decisions"]; states = data["states"]
    M, T_obs, _ = decisions.shape
    K = posterior.shape[1]
    counts = np.full((K, T_obs, N_PLAYERS, N_ACTIONS, N_STATES), laplace)
    for m in range(M):
        w = posterior[m]
        for t in range(T_obs):
            x = states[m, t]
            for i in range(N_PLAYERS):
                d_it = decisions[m, t, i]
                counts[:, t, i, d_it, x] += w
    p = counts / counts.sum(axis=3, keepdims=True)
    return p.transpose(0, 2, 1, 3, 4)            # (K, P, T_obs, D, S)


# =============================================================================
# PROPER BRIDGE: FD linear system for 2-player rho=2 with time-varying F
# =============================================================================

# Pre-compute index arrays for (j_1, j_2) and (k_1, k_2) enumeration
_J_PAIRS = list(product(range(N_STATES), repeat=RHO))     # 16 j_seqs
_K_PAIRS = list(product(range(N_ACTIONS), repeat=RHO))    # 4 k_seqs
_N_SEQ = len(_J_PAIRS)
_M_SEQ = len(_K_PAIRS)


def build_fd_system_nonstationary(F_t, F_t1, s0, d, d_prime):
    """Construct the linear system A * x = b certifying rho=2 FD at
    (s0, d, d') with time-varying transitions F_t (used at tau=0
    transition) and F_t1 (used at tau=1 and at terminal-matching).

    Variables: x = [phi_d.flatten(), phi_d'.flatten()]  shape (2*N*M,)
    """
    S = N_STATES; D = N_ACTIONS; N = _N_SEQ; M = _M_SEQ

    rows, cols, vals = [], [], []
    r = 0

    # Block 1 (Initial flow, 2*S = 8 rows):
    #   For each j_1: marginal_d(j_1) = F_t[d, s0, j_1]; marginal_d'(j_1) = F_t[d', s0, j_1]
    for j1 in range(S):
        # k half: sum over (ji with j_seq[0]=j1) and ki of phi_d[ji, ki] = F_t[d, s0, j1]
        for ji, (j1_, j2_) in enumerate(_J_PAIRS):
            if j1_ == j1:
                for ki in range(M):
                    rows.append(r); cols.append(ji * M + ki); vals.append(1.0)
        r += 1
    for j1 in range(S):
        # K half: same but offset by N*M
        for ji, (j1_, j2_) in enumerate(_J_PAIRS):
            if j1_ == j1:
                for ki in range(M):
                    rows.append(r); cols.append(N * M + ji * M + ki); vals.append(1.0)
        r += 1

    # Block 2 (Flow conservation at tau=0, both halves):
    #   For each (j_1, k_1, j_next):
    #     sum_{k_2} phi[(j_1, j_next), (k_1, k_2)]
    #     - F_t1[k_1, j_1, j_next] * sum_{j_2', k_2} phi[(j_1, j_2'), (k_1, k_2)] = 0
    for j1 in range(S):
        for k1 in range(D):
            for jn in range(S):
                # k half
                for k2 in range(D):
                    ji_child = j1 * S + jn
                    ki = k1 * D + k2
                    rows.append(r); cols.append(ji_child * M + ki); vals.append(1.0)
                f_val = float(F_t1[k1, j1, jn])
                if abs(f_val) > 1e-15:
                    for j2p in range(S):
                        for k2 in range(D):
                            ji_par = j1 * S + j2p
                            ki = k1 * D + k2
                            rows.append(r); cols.append(ji_par * M + ki); vals.append(-f_val)
                r += 1
                # K half (offset cols by N*M)
                for k2 in range(D):
                    ji_child = j1 * S + jn
                    ki = k1 * D + k2
                    rows.append(r); cols.append(N * M + ji_child * M + ki); vals.append(1.0)
                if abs(f_val) > 1e-15:
                    for j2p in range(S):
                        for k2 in range(D):
                            ji_par = j1 * S + j2p
                            ki = k1 * D + k2
                            rows.append(r); cols.append(N * M + ji_par * M + ki); vals.append(-f_val)
                r += 1

    # Block 3 (Terminal matching at tau=rho=2):
    #   For each x':
    #     sum_{(ji, ki)} phi_d[ji, ki] * F_t1[k_seq[-1], j_seq[-1], x']
    #     - sum_{(ji, ki)} phi_d'[ji, ki] * F_t1[k_seq[-1], j_seq[-1], x']  = 0
    term_start = r
    for xp in range(S):
        for ji, (j1_, j2_) in enumerate(_J_PAIRS):
            for ki, (k1_, k2_) in enumerate(_K_PAIRS):
                f_val = float(F_t1[k2_, j2_, xp])
                if abs(f_val) > 1e-15:
                    rows.append(r); cols.append(ji * M + ki); vals.append(f_val)
                    rows.append(r); cols.append(N * M + ji * M + ki); vals.append(-f_val)
        r += 1

    A = csr_matrix((vals, (rows, cols)), shape=(r, 2 * N * M))
    # b: only the initial block has nonzero values
    b = np.zeros(r)
    b[:S] = F_t[d, s0, :]
    b[S:2 * S] = F_t[d_prime, s0, :]
    return A, b


def solve_phi_diff(F_t, F_t1, s0, d=1, d_prime=0):
    """Solve for Phi_diff (= phi_d - phi_d') of shape (S, S, D, D)."""
    A, b = build_fd_system_nonstationary(F_t, F_t1, s0, d, d_prime)
    sol = lsqr(A, b, atol=1e-12, btol=1e-12, iter_lim=20000)[0]
    NM = _N_SEQ * _M_SEQ
    phi_k = sol[:NM].reshape(_N_SEQ, _M_SEQ)
    phi_K = sol[NM:].reshape(_N_SEQ, _M_SEQ)
    phi_diff_flat = phi_k - phi_K                       # (N, M) = (16, 4)
    # Reshape to (j_1, j_2, k_1, k_2)
    phi_full = phi_diff_flat.reshape(N_STATES, N_STATES, N_ACTIONS, N_ACTIONS)
    return phi_full, A, b


# =============================================================================
# Bridge value-difference: pure algebraic, NO V_T
# =============================================================================

def bridge_value_diff_at_xt(theta, x_t, phi_full, psi_t1, psi_t2, i):
    """Compute v_i(d=1, x_t, t) - v_i(d=0, x_t, t) via the rho=2 bridge.

    phi_full : (j_1, j_2, k_1, k_2) flow-difference weights
    psi_t1   : (D, S) CCP correction at t+1 (indexed as psi[k_1, j_1])
    psi_t2   : (D, S) CCP correction at t+2 (indexed as psi[k_2, j_2])
    """
    u = payoff_grid(theta, i)                           # (D, S)
    u_diff = u[1, x_t] - u[0, x_t]
    # tau=1 marginal: sum over (j_2, k_2)
    phi_marg_1 = phi_full.sum(axis=(1, 3))              # (j_1, k_1)
    u_plus_psi_t1 = u + psi_t1                          # (D, S) -> (k_1, j_1)
    contrib_t1 = (phi_marg_1 * u_plus_psi_t1.T).sum()
    # tau=2: contract full phi against (k_2, j_2)
    u_plus_psi_t2 = u + psi_t2
    contrib_t2 = np.einsum('abcd,db->', phi_full, u_plus_psi_t2)
    return u_diff + BETA * contrib_t1 + BETA**2 * contrib_t2


# =============================================================================
# Proper bridge EM
# =============================================================================

def compute_posterior(data, p_by_type, pi):
    decisions = data["decisions"]; states = data["states"]
    M, T_obs, _ = decisions.shape
    K = p_by_type.shape[0]
    log_pi = np.log(pi + 1e-300)
    log_lik = np.zeros((M, K))
    for k in range(K):
        for t in range(T_obs):
            x_t = states[:, t]
            for i in range(N_PLAYERS):
                d_t = decisions[:, t, i]
                log_lik[:, k] += np.log(p_by_type[k, i, t, d_t, x_t] + 1e-300)
    log_post = log_lik + log_pi[None, :]
    m = log_post.max(axis=1, keepdims=True)
    post = np.exp(log_post - m)
    return post / post.sum(axis=1, keepdims=True)


def bridge_em_proper(data, K, T_obs, n_em_iter=6, theta_init=None, verbose=False):
    """Mixture EM with proper bridge identity (V-independent)."""
    rng = np.random.default_rng(0)
    if theta_init is None:
        theta = THETA_TRUE + rng.normal(0, 0.3, size=THETA_TRUE.shape)
    else:
        theta = theta_init.copy()
    pi = np.full(K, 1.0 / K)

    # Initialise CCPs from initial theta via an NFXP solve (V_T = 0 for
    # initialisation only -- the final bridge estimate is V-independent;
    # this just breaks the type-collapse symmetry of the uniform start).
    V_T_init = np.zeros(N_STATES)
    p_by_type = np.stack([predicted_ccps_nfxp(theta[k], T_obs, V_T_init)
                          for k in range(K)])

    # Bridge usable for t in [0, T_use - 1] = [0, T_obs - rho - 1]
    T_use = T_obs - RHO

    t_start = time.time()
    for em_iter in range(n_em_iter):
        # E-step posterior (uses all T_obs periods through p_by_type)
        posterior = compute_posterior(data, p_by_type, pi)
        pi = posterior.mean(axis=0)

        # Empirical anchor (K, P, T_obs, D, S)
        p_anchor = empirical_ccp_by_type_period(data, posterior)

        # Cache Phi per (k, i, x_t, t) for t in [0, T_use - 1]
        # Theta-independent
        phi_cache = np.zeros((K, N_PLAYERS, T_use, N_STATES,
                              N_STATES, N_STATES, N_ACTIONS, N_ACTIONS))
        for k in range(K):
            for i in range(N_PLAYERS):
                for t in range(T_use):
                    F_t = perceived_transition(p_anchor[k, 1 - i, t], i)
                    F_t1 = perceived_transition(p_anchor[k, 1 - i, t + 1], i)
                    for x_t in range(N_STATES):
                        phi_full, _, _ = solve_phi_diff(F_t, F_t1, x_t, d=1, d_prime=0)
                        phi_cache[k, i, t, x_t] = phi_full

        # Cache psi anchors (-log p_i^(k)(., t+1)) and (t+2)
        psi_anchor = -np.log(p_anchor + 1e-300)         # (K, P, T_obs, D, S)

        # M-step: optimise theta_k per type
        for k in range(K):
            def neg_ll(theta_k):
                ll = 0.0
                for i in range(N_PLAYERS):
                    for t in range(T_use):
                        x_t_arr = data["states"][:, t]
                        d_arr = data["decisions"][:, t, i]
                        for m_idx in range(data["n_markets"]):
                            x_t = x_t_arr[m_idx]
                            d_obs = d_arr[m_idx]
                            phi = phi_cache[k, i, t, x_t]
                            v_diff = bridge_value_diff_at_xt(
                                theta_k, x_t, phi,
                                psi_anchor[k, i, t + 1],
                                psi_anchor[k, i, t + 2], i)
                            p1 = 1.0 / (1.0 + np.exp(-v_diff))
                            p1 = max(min(p1, 1 - 1e-12), 1e-12)
                            log_p = np.log(p1) if d_obs == 1 else np.log(1.0 - p1)
                            ll += posterior[m_idx, k] * log_p
                return -ll

            res = minimize(neg_ll, theta[k].copy(), method="Nelder-Mead",
                            options={"xatol": 1e-4, "fatol": 1e-4, "maxiter": 100})
            theta[k] = res.x

        # Update p_by_type for next E-step: use bridge-predicted CCPs at t in [0, T_use-1],
        # and empirical anchors at boundary periods t in [T_use, T_obs - 1].
        for k in range(K):
            for i in range(N_PLAYERS):
                for t in range(T_use):
                    for x_t in range(N_STATES):
                        phi = phi_cache[k, i, t, x_t]
                        v_diff = bridge_value_diff_at_xt(
                            theta[k], x_t, phi,
                            psi_anchor[k, i, t + 1],
                            psi_anchor[k, i, t + 2], i)
                        p1 = 1.0 / (1.0 + np.exp(-v_diff))
                        p1 = max(min(p1, 1 - 1e-12), 1e-12)
                        p_by_type[k, i, t, 1, x_t] = p1
                        p_by_type[k, i, t, 0, x_t] = 1.0 - p1
                # Boundary periods: keep empirical anchor
                for t in range(T_use, T_obs):
                    p_by_type[k, i, t] = p_anchor[k, i, t]
        if verbose:
            print(f"  [bridge] iter {em_iter:>2}: theta_1 = {theta[0].round(3)} "
                  f"theta_2 = {theta[1].round(3)}  pi = {pi.round(3)}")

    elapsed = time.time() - t_start
    return {"theta": theta, "pi": pi, "p_by_type": p_by_type,
            "posterior": posterior, "wall_clock": elapsed}


# =============================================================================
# NFXP-EM (for V-sensitivity comparison; same as previous script)
# =============================================================================

def backward_induction_nfxp(theta, p_other_by_t, i, T_obs, V_T):
    u = payoff_grid(theta, i)
    p_i = np.zeros((T_obs, N_ACTIONS, N_STATES))
    V = V_T.copy()
    for t in range(T_obs - 1, -1, -1):
        F_t = perceived_transition(p_other_by_t[t], i)
        v_t = u + BETA * (F_t * V[None, None, :]).sum(axis=2)
        m = v_t.max(axis=0)
        ev = np.exp(v_t - m)
        p_i[t] = ev / ev.sum(axis=0)
        V = m + np.log(ev.sum(axis=0))
    return p_i


def predicted_ccps_nfxp(theta_k, T_obs, V_T, warm_start=None, n_iter=30, tol=1e-6):
    if warm_start is not None:
        p = warm_start.copy()
    else:
        p = np.full((N_PLAYERS, T_obs, N_ACTIONS, N_STATES), 0.5)
    for _ in range(n_iter):
        p_new = np.zeros_like(p)
        for i in range(N_PLAYERS):
            p_new[i] = backward_induction_nfxp(theta_k, p[1 - i], i, T_obs, V_T)
        if np.max(np.abs(p_new - p)) < tol:
            return p_new
        p = p_new
    return p


def nfxp_em(data, K, T_obs, V_T, n_em_iter=6, theta_init=None, verbose=False):
    rng = np.random.default_rng(0)
    if theta_init is None:
        theta = THETA_TRUE + rng.normal(0, 0.3, size=THETA_TRUE.shape)
    else:
        theta = theta_init.copy()
    pi = np.full(K, 1.0 / K)
    p_by_type = np.stack([predicted_ccps_nfxp(theta[k], T_obs, V_T)
                          for k in range(K)])

    t_start = time.time()
    for em_iter in range(n_em_iter):
        posterior = compute_posterior(data, p_by_type, pi)
        pi = posterior.mean(axis=0)
        for k in range(K):
            warm = p_by_type[k]
            def neg_ll(theta_k):
                p_pred = predicted_ccps_nfxp(theta_k, T_obs, V_T, warm_start=warm)
                decisions = data["decisions"]; states = data["states"]
                ll = 0.0
                for t in range(T_obs):
                    x_t = states[:, t]
                    for i in range(N_PLAYERS):
                        d_t = decisions[:, t, i]
                        log_p = np.log(p_pred[i, t, d_t, x_t] + 1e-300)
                        ll += (posterior[:, k] * log_p).sum()
                return -ll
            res = minimize(neg_ll, theta[k].copy(), method="Nelder-Mead",
                            options={"xatol": 1e-4, "fatol": 1e-4, "maxiter": 100})
            theta[k] = res.x
            p_by_type[k] = predicted_ccps_nfxp(theta[k], T_obs, V_T,
                                                warm_start=warm)
        if verbose:
            print(f"  [nfxp V={V_T[0]:+.1f}] iter {em_iter:>2}: "
                  f"theta_1 = {theta[0].round(3)} theta_2 = {theta[1].round(3)}")
    return {"theta": theta, "pi": pi, "p_by_type": p_by_type,
            "posterior": posterior, "wall_clock": time.time() - t_start}


def V_terminal_from_scale(c):
    out = np.zeros(N_STATES)
    for x in range(N_STATES):
        y1, y2 = x_to_yvec(x)
        out[x] = c * (y1 + y2)
    return out


def match_to_truth(theta_est, theta_true):
    if theta_est.shape[0] != 2:
        return np.arange(theta_est.shape[0])
    identity = np.array([0, 1]); swap = np.array([1, 0])
    err_id = np.linalg.norm(theta_est - theta_true)
    err_sw = np.linalg.norm(theta_est[swap] - theta_true)
    return identity if err_id <= err_sw else swap


# =============================================================================
# Main
# =============================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n_markets", type=int, default=400)
    parser.add_argument("--T_true", type=int, default=T_TRUE)
    parser.add_argument("--T_obs", type=int, default=T_OBS)
    parser.add_argument("--em_iter", type=int, default=6)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--V_sweep", type=str,
                        default="-3.0,-1.0,0.0,1.0,3.0")
    parser.add_argument("--reps", type=int, default=1)
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--skip_nfxp", action="store_true")
    args = parser.parse_args()

    V_sweep = [float(c) for c in args.V_sweep.split(",")]

    print("=" * 80)
    print(f"Proper Bridge vs NFXP V-sensitivity")
    print(f"  T_true = {args.T_true}, T_obs = {args.T_obs}, K = 2 types")
    print(f"  theta_true[0] = {THETA_TRUE[0]}, theta_true[1] = {THETA_TRUE[1]}")
    print(f"  pi_true = {PI_TRUE}")
    print(f"  NFXP V_T_obs sweep: c in {V_sweep}")
    print("=" * 80)

    rng_master = np.random.default_rng(args.seed)
    nfxp_b1 = {c: [] for c in V_sweep}
    nfxp_b2 = {c: [] for c in V_sweep}
    bridge_b1, bridge_b2 = [], []
    bridge_pi = []

    for rep in range(args.reps):
        rng = np.random.default_rng(rng_master.integers(0, 2**31))
        mpes_true = [find_finite_horizon_mpe_dgp(THETA_TRUE[k], args.T_true)
                     for k in range(K_TYPES)]
        data = simulate_mixture_truncated(mpes_true, PI_TRUE,
                                            args.n_markets,
                                            args.T_true, args.T_obs, rng)
        # NFXP-EM at each V_T_obs
        if not args.skip_nfxp:
            for c in V_sweep:
                V_T = V_terminal_from_scale(c)
                res = nfxp_em(data, K_TYPES, args.T_obs, V_T,
                               n_em_iter=args.em_iter, verbose=args.verbose)
                perm = match_to_truth(res["theta"], THETA_TRUE)
                nfxp_b1[c].append(res["theta"][perm][0] - THETA_TRUE[0])
                nfxp_b2[c].append(res["theta"][perm][1] - THETA_TRUE[1])

        # Proper bridge EM (no V_T)
        res_b = bridge_em_proper(data, K_TYPES, args.T_obs,
                                   n_em_iter=args.em_iter, verbose=args.verbose)
        perm_b = match_to_truth(res_b["theta"], THETA_TRUE)
        bridge_b1.append(res_b["theta"][perm_b][0] - THETA_TRUE[0])
        bridge_b2.append(res_b["theta"][perm_b][1] - THETA_TRUE[1])
        bridge_pi.append(res_b["pi"][perm_b] - PI_TRUE)
        print(f"  rep {rep+1}/{args.reps} done  (bridge {res_b['wall_clock']:.1f}s)")

    # Report
    print("\n" + "=" * 80)
    print(f"Mean biases across {args.reps} reps")
    print("=" * 80)
    print(f"{'Estimator':<32}  {'rev_1':>7}  {'comp_1':>7}  {'entry_1':>7}  "
          f"{'rev_2':>7}  {'comp_2':>7}  {'entry_2':>7}")
    print("-" * 80)
    if not args.skip_nfxp:
        for c in V_sweep:
            b1 = np.mean(np.stack(nfxp_b1[c]), axis=0)
            b2 = np.mean(np.stack(nfxp_b2[c]), axis=0)
            print(f"NFXP-EM, V_T = {c:+.1f}*(l1+l2)         "
                  f"{b1[0]:+.3f}  {b1[1]:+.3f}  {b1[2]:+.3f}  "
                  f"{b2[0]:+.3f}  {b2[1]:+.3f}  {b2[2]:+.3f}")
    print("-" * 80)
    br_b1 = np.mean(np.stack(bridge_b1), axis=0)
    br_b2 = np.mean(np.stack(bridge_b2), axis=0)
    print(f"Proper Bridge-EM (no V_T)         "
          f"{br_b1[0]:+.3f}  {br_b1[1]:+.3f}  {br_b1[2]:+.3f}  "
          f"{br_b2[0]:+.3f}  {br_b2[1]:+.3f}  {br_b2[2]:+.3f}")


if __name__ == "__main__":
    main()
