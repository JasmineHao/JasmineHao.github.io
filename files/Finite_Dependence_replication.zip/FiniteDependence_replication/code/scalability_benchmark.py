"""
scalability_benchmark.py
========================

Scalability benchmark for the GFD estimator: vary the state-space size of
the investment-with-capital-accumulation DGP and compare \emph{full
estimation} wall time of GFD against NFXP (nested fixed-point /
Bellman-in-the-inner-loop).

Reproduces (and extends to larger state) the timing claim in
Section~\ref{sec:mc_investment} and Appendix~A of the paper.

The DGP is a Tauchen-discretized AR(1) productivity x deterministic
capital grid with three actions (depreciate, maintain, invest).
Varying N_CAPITAL and N_PRODUCTIVITY scales |X| = N_CAPITAL *
N_PRODUCTIVITY. For each |X| we:

1. Simulate a panel from the true DGP (N=1000, T=15 by default).
2. Run GFD-MLE: one QP solve per state, cache effective regressors,
   Newton iteration on the multinomial-logit pseudo-likelihood.
3. Run NFXP: Nelder-Mead outer search; at every parameter trial,
   re-solve the Bellman fixed point and compute the implied logit
   likelihood.

Wall times reported are means across replications (default n_reps=5
per S, since per-S NFXP cost grows quickly).

Usage:
    python3 scalability_benchmark.py --quick   # S = 20, 60, 200, 5 reps
    python3 scalability_benchmark.py           # full sweep, longer
"""

import argparse
import os
import sys
import time

import numpy as np
from scipy.optimize import minimize

sys.path.insert(0, os.path.dirname(__file__))

from UnifiedFDSolver import UnifiedFDSolver
from utils import compute_e, state_transition


# ============================================================================
# DGP
# ============================================================================

def build_investment_transition(n_capital, n_productivity, rho_z=0.5,
                                  sigma_z=0.3):
    """Build (A, S, S) investment-model transition with S = n_capital *
    n_productivity. Capital is deterministic (depreciate / maintain /
    invest); productivity is Tauchen-discretized AR(1).
    Returns (F, o_grid).
    """
    A = 3
    S = n_capital * n_productivity
    T_z, o_grid = state_transition(0.0, rho_z, sigma_z, n_productivity)

    T_k = np.zeros((A, n_capital, n_capital))
    for k in range(n_capital):
        T_k[0, k, max(k - 1, 0)] = 1.0
        T_k[1, k, k] = 1.0
        T_k[2, k, min(k + 1, n_capital - 1)] = 1.0

    F = np.zeros((A, S, S))
    for a in range(A):
        for k in range(n_capital):
            for z in range(n_productivity):
                s = k * n_productivity + z
                for k_next in range(n_capital):
                    for z_next in range(n_productivity):
                        s_next = k_next * n_productivity + z_next
                        F[a, s, s_next] = T_k[a, k, k_next] * T_z[z, z_next]
    return F, o_grid


def payoff(theta, n_capital, n_productivity, o_grid):
    """u(s, a; theta) where theta = (theta_rev, theta_cost, theta_adj).

    z basis (linear in theta):
       u(s,a) = theta_rev * o_val[s] * k[s] - theta_cost * a - theta_adj * a^2
    """
    A = 3
    S = n_capital * n_productivity
    u = np.zeros((A, S))
    for k in range(n_capital):
        for z in range(n_productivity):
            s = k * n_productivity + z
            for a in range(A):
                u[a, s] = (theta[0] * o_grid[z] * k
                           - theta[1] * a
                           - theta[2] * a ** 2)
    return u


def solve_logit_eqm(theta, F, o_grid, n_capital, n_productivity, beta=0.95,
                     tol=1e-8, max_iter=2000):
    """Logit-discrete-choice value-function fixed point.

    p(a|s) = exp(v(s,a)) / sum_a' exp(v(s,a'))
    V(s)   = log sum_a exp(v(s,a))  (with Euler constant absorbed)
    v(s,a) = u(s,a; theta) + beta * sum_s' F[a,s,s'] V(s')
    """
    A, S, _ = F.shape
    u = payoff(theta, n_capital, n_productivity, o_grid)  # (A, S)
    V = np.zeros(S)
    for _ in range(max_iter):
        v = u + beta * (F @ V)              # (A, S)
        v_max = v.max(axis=0)
        V_new = v_max + np.log(np.exp(v - v_max).sum(axis=0))
        if np.max(np.abs(V_new - V)) < tol:
            V = V_new
            break
        V = V_new
    v = u + beta * (F @ V)
    v_max = v.max(axis=0)
    p = np.exp(v - v_max)
    p = p / p.sum(axis=0)                  # (A, S)
    return V, p


def simulate_panel(N, T, P_true, F, seed=0):
    """Simulate panel data; returns 1-d arrays states, actions of length N*T."""
    rng = np.random.default_rng(seed)
    A, S, _ = F.shape
    states = np.empty(N * T, dtype=int)
    actions = np.empty(N * T, dtype=int)
    idx = 0
    for i in range(N):
        s = rng.integers(0, S)
        for t in range(T):
            a = rng.choice(A, p=P_true[:, s])
            states[idx] = s
            actions[idx] = a
            idx += 1
            s = rng.choice(S, p=F[a, s, :])
    return states, actions


# ============================================================================
# Estimators
# ============================================================================

def _smoothed_ccp_logit(states, actions, n_capital, n_productivity, o_grid,
                          A, max_iter=50, tol=1e-8):
    """Multinomial-logit smoother for first-stage CCPs.

    Fits log p(a | k, o) - log p(0 | k, o) = z(k, o) @ gamma_a for
    a = 1, ..., A - 1 with z(k, o) = (1, k, o, k * o), by Newton
    iteration on the multinomial-logit log-likelihood. Returns
    P_hat of shape (A, S), where S = n_capital * n_productivity.
    """
    # Per-observation (k, o) covariates and basis.
    NT = states.shape[0]
    k_obs = states // n_productivity                     # (NT,)
    o_idx = states % n_productivity
    o_obs = o_grid[o_idx]                                # (NT,)
    Z_obs = np.column_stack([
        np.ones(NT), k_obs, o_obs, k_obs * o_obs,
    ])                                                   # (NT, P)
    P_dim = Z_obs.shape[1]

    # gamma has shape (A - 1, P_dim); action 0 is the reference.
    gamma = np.zeros((A - 1, P_dim))
    a_obs = actions

    for _ in range(max_iter):
        eta_obs = Z_obs @ gamma.T                         # (NT, A-1)
        eta_full = np.concatenate(
            [np.zeros((NT, 1)), eta_obs], axis=1)         # (NT, A)
        eta_max = eta_full.max(axis=1, keepdims=True)
        ev = np.exp(eta_full - eta_max)
        p_obs = ev / ev.sum(axis=1, keepdims=True)        # (NT, A)

        # Score and Hessian per non-reference action a.
        score = np.zeros_like(gamma)
        for a in range(1, A):
            r = (a_obs == a).astype(float) - p_obs[:, a]
            score[a - 1] = Z_obs.T @ r

        # Block-diagonal-ish full Hessian: H[(a,p),(b,q)] =
        #   - sum_obs Z[obs, p] * Z[obs, q] * p_obs[obs,a] *
        #             (delta_ab - p_obs[obs,b])
        Hess = np.zeros(((A - 1) * P_dim, (A - 1) * P_dim))
        for a in range(1, A):
            for b in range(1, A):
                w = p_obs[:, a] * (
                    (1.0 if a == b else 0.0) - p_obs[:, b])
                ZtWZ = Z_obs.T @ (w[:, None] * Z_obs)
                Hess[(a - 1) * P_dim:(a) * P_dim,
                     (b - 1) * P_dim:(b) * P_dim] = -ZtWZ

        score_flat = score.reshape(-1)
        try:
            step = np.linalg.solve(Hess, score_flat)
        except np.linalg.LinAlgError:
            break
        gamma_new = gamma - step.reshape(A - 1, P_dim)
        if np.max(np.abs(gamma_new - gamma)) < tol:
            gamma = gamma_new
            break
        gamma = gamma_new

    # Evaluate fitted CCPs at every state s = (k, o).
    S = n_capital * n_productivity
    k_grid = np.arange(n_capital)
    Z_states = np.column_stack([
        np.ones(S),
        np.repeat(k_grid, n_productivity),
        np.tile(o_grid, n_capital),
        np.repeat(k_grid, n_productivity) * np.tile(o_grid, n_capital),
    ])                                                   # (S, P_dim)
    eta_full = np.concatenate([
        np.zeros((S, 1)),
        Z_states @ gamma.T,
    ], axis=1)                                           # (S, A)
    eta_max = eta_full.max(axis=1, keepdims=True)
    ev = np.exp(eta_full - eta_max)
    P_hat = (ev / ev.sum(axis=1, keepdims=True)).T       # (A, S)
    return P_hat


def estimate_GFD(states, actions, F, o_grid, n_capital, n_productivity,
                  beta=0.95):
    """GFD-MLE (rho=1) with one-shot batched FD weight solve.

    The FD constraint matrix at rho=1 is the SAME across all (x, k, K_ref)
    triples (it depends on the transition structure, not on x). Only the
    initial-flow right-hand-side b depends on (x, k, K_ref). We exploit
    this by factoring the augmented constraint+objective matrix ONCE and
    then solving for all S * (A-1) right-hand sides via a single matrix
    multiplication on the (precomputed) Moore-Penrose pseudoinverse.
    """
    import scipy.sparse as _sps

    t0 = time.perf_counter()
    A, S, _ = F.shape
    K_ref = 0
    n_theta = 3

    # ---- Step 1: First-stage CCPs (smoothed multinomial logit) ----
    # The empirical-frequency estimator p_hat[s,a] = counts[s,a]/n[s] has
    # variance O(|X|/(NT)), which dominates the GFD MLE variance once
    # |X| is large relative to NT (see scaling discussion in the paper).
    # Replace it with a low-dimensional multinomial logit
    #   log p(a | k, o) = alpha_a + beta_a^k * k + beta_a^o * o
    #                                + gamma_a * k * o
    # fitted by Newton iteration on the joint log-likelihood. With S
    # potentially in the thousands but only 4 * (A - 1) free parameters,
    # this drops the per-state CCP variance by roughly a factor of
    # |X| / (4 * (A - 1)).
    P_hat = _smoothed_ccp_logit(states, actions, n_capital,
                                 n_productivity, o_grid, A)
    e_hat = compute_e(P_hat)                                  # (A, S)

    # ---- Step 2: Structured FD weight solve at rho = 1 ----
    # The investment transition factors as
    #   F[a, (k, z), (k', z')] = T_k[a, k, k'] * T_z[z, z']
    # with T_z action-invariant (Lemma 2.25). Under this Kronecker
    # structure the FD problem reduces from the full state space
    # (size S = n_capital * n_productivity) to the endogenous
    # state alone (size M = n_capital). The full FD weight then
    # factors as
    #   delta_phi_full[(k,z), a, (k',z'), kappa]
    #     = delta_phi_endo[k, a, k', kappa] * T_z[z, z']
    # so we never materialise the (S * A * S * A) tensor at large S.
    T_k = np.zeros((A, n_capital, n_capital))
    for k in range(n_capital):
        T_k[0, k, max(k - 1, 0)] = 1.0
        T_k[1, k, k] = 1.0
        T_k[2, k, min(k + 1, n_capital - 1)] = 1.0
    T_z, _ = state_transition(0.0, 0.5, 0.3, n_productivity)

    M = n_capital
    Z = n_productivity
    struct = UnifiedFDSolver(T_endo=T_k, T_exo=T_z, rho=1)
    delta_phi_endo = np.zeros((M, A, M, A))   # [m_init, k, m', kappa]
    for m_init in range(M):
        for k in range(A):
            if k == K_ref:
                continue
            phi_k_m, phi_K_m, _, _ = struct.solve(
                m_init=m_init, k_init=k, K_init=K_ref)
            delta_phi_endo[m_init, k] = phi_k_m - phi_K_m  # (M, A)

    # ---- Step 3: Effective regressors via factored Kronecker form ----
    # The payoff basis for the investment DGP is
    #   z[(k,z), a, 0] = o(z) * k        (revenue)
    #   z[(k,z), a, 1] = -a              (cost)
    #   z[(k,z), a, 2] = -a^2            (adjustment)
    # We compute H_tilde[s=(m,z), k, r] using the factored form
    # without materialising delta_phi over the full state space:
    #
    #   FD path correction
    #     = beta * sum_{m', kappa} delta_phi_endo[m, k, m', kappa]
    #              * E_{z'|z}[ z[(m', z'), kappa, r] ]
    #
    # The expectation E_{z'|z}[ z[(m', z'), kappa, r] ] decomposes
    # by component r:
    #   r = 0:  E_{z'|z}[ o(z') * m' ]   = m' * E_o[z]
    #           where E_o[z] := T_z[z, :] @ o_grid
    #   r = 1:  E_{z'|z}[ -kappa ]       = -kappa
    #   r = 2:  E_{z'|z}[ -kappa^2 ]     = -kappa^2
    E_o = T_z @ o_grid                          # (Z,)

    # Sums of delta_phi_endo over kappa, used for r = 1, r = 2:
    #   sum_kappa delta_phi_endo[m, k, m', kappa] * kappa
    #   sum_kappa delta_phi_endo[m, k, m', kappa] * kappa^2
    # and sums over m' for r = 0:
    #   sum_{m', kappa} delta_phi_endo[m, k, m', kappa] * m'
    kappas = np.arange(A)
    sum_kappa_dphi = np.einsum('mkjK,K->mkj', delta_phi_endo, kappas)
    sum_kappa2_dphi = np.einsum('mkjK,K->mkj', delta_phi_endo, kappas ** 2)
    sum_mprime_dphi = np.einsum('mkjK,j->mk', delta_phi_endo,
                                 np.arange(M).astype(float))

    # H_tilde[s, k, r]:
    #   r = 0: z[s, k, 0] - z[s, K, 0] = 0  (revenue independent of action)
    #          + beta * E_o[z] * sum_mprime_dphi[m, k]
    #   r = 1: -(k - K_ref)
    #          + beta * (-1) * sum over m' of sum_kappa_dphi[m, k, m'] all
    #              -> -beta * sum_kappa_dphi[m, k].sum(axis=-1)
    #   r = 2: -(k^2 - K_ref^2)
    #          + beta * (-1) * sum_kappa2_dphi[m, k].sum(axis=-1)
    H_tilde = np.zeros((S, A, n_theta))
    h_tilde = np.zeros((S, A))

    # Per-action sums over m' (no z dependence except through E_o for r=0):
    sum_kappa_total  = sum_kappa_dphi.sum(axis=-1)    # (M, A)
    sum_kappa2_total = sum_kappa2_dphi.sum(axis=-1)   # (M, A)

    # h_tilde requires E_e[kappa, m', z] := sum_z' T_z[z,z'] * e_hat[kappa, (m', z')]
    # e_hat is (A, S) = (A, M*Z). Reshape to (A, M, Z'-axis).
    e_hat_reshaped = e_hat.reshape(A, M, Z)            # (A, M, z')
    # einsum: E_e[kappa, m', z] = sum_p T_z[z, p] * e_hat[kappa, m', p]
    E_e = np.einsum('zp,Kjp->Kjz', T_z, e_hat_reshaped)  # (A, M, Z=current)

    for m in range(M):
        for k in range(A):
            if k == K_ref:
                continue
            # FD path corrections at the endogenous level
            fd_r1 = -beta * sum_kappa_total[m, k]
            fd_r2 = -beta * sum_kappa2_total[m, k]
            base_r1 = -(k - K_ref)
            base_r2 = -(k ** 2 - K_ref ** 2)
            for z_idx in range(Z):
                s = m * Z + z_idx
                fd_r0 = beta * E_o[z_idx] * sum_mprime_dphi[m, k]
                H_tilde[s, k, 0] = fd_r0
                H_tilde[s, k, 1] = base_r1 + fd_r1
                H_tilde[s, k, 2] = base_r2 + fd_r2
                # h_tilde[(m,z), k] = beta * sum_{m', kappa}
                #     delta_phi_endo[m, k, m', kappa] * E_e[kappa, m', z]
                h_tilde[s, k] = beta * np.einsum(
                    'jK,Kj->', delta_phi_endo[m, k], E_e[:, :, z_idx])

    # Aggregate to cells.
    n_xd = np.zeros((S, A))
    for s, a in zip(states, actions):
        n_xd[s, a] += 1
    n_x = n_xd.sum(axis=1)

    # Newton.
    theta = np.array([2.0, 1.0, 0.5])
    for _ in range(50):
        v_diff = H_tilde @ theta + h_tilde
        v_max = v_diff.max(axis=1, keepdims=True)
        exp_v = np.exp(v_diff - v_max)
        p_xd = exp_v / exp_v.sum(axis=1, keepdims=True)
        residuals = n_xd - n_x[:, None] * p_xd
        score = np.einsum('xd,xdr->r', residuals, H_tilde)
        H_bar = np.einsum('xd,xdr->xr', p_xd, H_tilde)
        H_centered = H_tilde - H_bar[:, None, :]
        weighted = (n_x[:, None, None] * p_xd[:, :, None]) * H_centered
        Hess = -np.einsum('xdr,xds->rs', weighted, H_centered)
        try:
            step = np.linalg.solve(Hess, score)
        except np.linalg.LinAlgError:
            break
        theta_new = theta - step
        if np.max(np.abs(theta_new - theta)) < 1e-7:
            theta = theta_new
            break
        theta = theta_new
    return theta, time.perf_counter() - t0


def estimate_NFXP(states, actions, F, o_grid, n_capital, n_productivity,
                   beta=0.95):
    """NFXP / NFXP: at every theta trial, solve the logit value-function
    fixed point and evaluate the conditional log-likelihood. Outer search
    by Nelder-Mead.
    """
    t0 = time.perf_counter()

    def neg_loglik(theta_vec):
        try:
            _, p = solve_logit_eqm(theta_vec, F, o_grid,
                                    n_capital, n_productivity, beta=beta)
        except Exception:
            return 1e10
        return -float(np.sum(np.log(p[actions, states] + 1e-12)))

    theta0 = np.array([2.0, 1.0, 0.5])
    result = minimize(neg_loglik, theta0, method='Nelder-Mead',
                      options={'maxiter': 200, 'xatol': 1e-3, 'fatol': 1e-3})
    return result.x, time.perf_counter() - t0


# ============================================================================
# Sweep
# ============================================================================

def run_sweep(grid, n_reps=5, N=1000, T=15):
    theta_true = np.array([2.5, 1.2, 0.8])
    print(f"True theta = {theta_true},  N = {N}, T = {T}, "
          f"n_reps = {n_reps} per S.")
    print()
    print(f"{'S':>6}  {'GFD time(s)':>12}  {'NFXP time(s)':>14}  "
          f"{'NFXP/GFD':>10}  {'GFD RMSE':>10}  {'NFXP RMSE':>11}", flush=True)
    print("-" * 76, flush=True)

    rows = []
    for n_cap, n_prod in grid:
        S = n_cap * n_prod
        F, o_grid = build_investment_transition(n_cap, n_prod)
        _, P_true = solve_logit_eqm(theta_true, F, o_grid, n_cap, n_prod)

        gfd_t, nfxp_t, gfd_e2, nfxp_e2 = [], [], [], []
        for r in range(n_reps):
            sts, acts = simulate_panel(N, T, P_true, F, seed=r)
            t_g, _ = None, None
            t_n, _ = None, None
            theta_g, t_g = estimate_GFD(sts, acts, F, o_grid,
                                         n_cap, n_prod)
            theta_n, t_n = estimate_NFXP(sts, acts, F, o_grid,
                                          n_cap, n_prod)
            gfd_t.append(t_g)
            nfxp_t.append(t_n)
            gfd_e2.append(np.sum((theta_g - theta_true) ** 2))
            nfxp_e2.append(np.sum((theta_n - theta_true) ** 2))
        gfd_mt = float(np.mean(gfd_t))
        nfxp_mt = float(np.mean(nfxp_t))
        gfd_rmse = float(np.sqrt(np.mean(gfd_e2)))
        nfxp_rmse = float(np.sqrt(np.mean(nfxp_e2)))
        ratio = nfxp_mt / gfd_mt if gfd_mt > 0 else float("inf")
        print(f"{S:>6d}  {gfd_mt:>12.3f}  {nfxp_mt:>14.3f}  "
              f"{ratio:>10.2f}  {gfd_rmse:>10.4f}  {nfxp_rmse:>11.4f}",
              flush=True)
        rows.append((S, gfd_mt, nfxp_mt, ratio, gfd_rmse, nfxp_rmse))
    return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()

    if args.quick:
        # S = 20, 60, 200; small n_reps for smoke testing
        grid = [(5, 4), (10, 6), (20, 10)]
        n_reps = 3
    else:
        # S = 20, 60, 200, 600, 2000
        grid = [(5, 4), (10, 6), (20, 10), (30, 20), (50, 40)]
        n_reps = 5

    print("Investment scalability benchmark (full estimation, GFD vs NFXP)")
    print()
    run_sweep(grid, n_reps=n_reps)
