# Finite Dependence as Pointwise Linear Feasibility

A formal companion to `code/fd_linear_system.py`. We use the notation of
`paper/FiniteDependence.tex` throughout: $\mathcal{X}=\{0,\dots,S-1\}$,
action set $\{0,\dots,A-1\}$, transition $f(x'\mid x,d)$, flow matrix
$\boldsymbol{\phi}\in\mathbb{R}^{S^\rho\times A^\rho}$ with entries
$\phi_{\mathbf{j},\mathbf{k}}$ over histories $(\mathbf{j},\mathbf{k})\in
\mathcal{X}^\rho\times\{0,\dots,A-1\}^\rho$. Equation labels prefixed by
`eq:` refer to the paper.

---

## 1. Pointwise finite dependence

**Definition 1 (Pointwise FD).** Fix $(x_0,k,K)\in\mathcal{X}\times\{0,\dots,A-1\}^2$
with $k\neq K$, and a horizon $\rho\ge 1$. Pointwise $\rho$-period finite
dependence holds at $(x_0,k,K)$ iff there exist flow matrices
$\boldsymbol{\phi}^{(k)},\boldsymbol{\phi}^{(K)}\in\mathbb{R}^{S^\rho\times A^\rho}$
satisfying

1. **Initial flow** — eq:initial\_flow with $d_0=k$ for
   $\boldsymbol{\phi}^{(k)}$ and with $d_0=K$ for $\boldsymbol{\phi}^{(K)}$;
2. **Flow conservation** — eq:flow\_conservation for both
   $\boldsymbol{\phi}^{(k)}$ and $\boldsymbol{\phi}^{(K)}$;
3. **Terminal matching** — $\kappa_{\rho+1}^{(k)}(x') = \kappa_{\rho+1}^{(K)}(x')$
   for every $x'\in\mathcal{X}$, with $\kappa_{\rho+1}$ from eq:terminal\_dist\_phi.

This is the local version of the paper's thm:fd\_existence (which is universal
over all triples). By thm:fd\_representation, Definition 1 yields the
closed-form value-difference identity at $(x_0,k,K)$.

## 2. The block linear system

Let $N=S^\rho$, $M=A^\rho$, and stack
$$
\mathbf{x} \;=\;
\begin{bmatrix}\operatorname{vec}\boldsymbol{\phi}^{(k)}\\
\operatorname{vec}\boldsymbol{\phi}^{(K)}\end{bmatrix}
\;\in\;\mathbb{R}^{2NM}.
$$

Define three sparse matrices, each acting on a single $\operatorname{vec}\boldsymbol{\phi}\in\mathbb{R}^{NM}$:

$$
(\mathbf{A}_\text{init})_{x,(\mathbf{j},\mathbf{k})}
= \mathbf{1}\{j_1 = x\},
\qquad
\mathbf{A}_\text{init}\in\{0,1\}^{S\times NM};
$$

$\mathbf{A}_\text{fc}\in\mathbb{R}^{C\times NM}$ encodes eq:flow\_conservation: it has
one row per quadruple $(\tau,\mathbf{j}_{1:\tau},\mathbf{k}_{1:\tau},j_{\tau+1})$
with $\tau\in\{1,\dots,\rho-1\}$. Each such row places $+1$ on every entry
$(\mathbf{j},\mathbf{k})$ extending the prefix $(\mathbf{j}_{1:\tau},j_{\tau+1};\mathbf{k}_{1:\tau})$
and $-f(j_{\tau+1}\mid j_\tau,k_\tau)$ on every entry extending the prefix
$(\mathbf{j}_{1:\tau};\mathbf{k}_{1:\tau})$. The total row count is

$$
C \;=\; \sum_{\tau=1}^{\rho-1} S^{\tau+1}A^{\tau}.
$$

$$
(\mathbf{T}_\text{last})_{x',(\mathbf{j},\mathbf{k})}
= f(x'\mid j_\rho,k_\rho),
\qquad
\mathbf{T}_\text{last}\in\mathbb{R}^{S\times NM};
$$

note that $\mathbf{T}_\text{last}\operatorname{vec}\boldsymbol{\phi}=\kappa_{\rho+1}$
by eq:terminal\_dist\_phi.

Finally let $f^{(u)}_x:=f(x\mid x_0,u)$ for $u\in\{k,K\}$, and assemble

$$
\boxed{\;
\mathbf{A}\;=\;
\begin{bmatrix}
\mathbf{A}_\text{init} & \mathbf{0} \\
\mathbf{0} & \mathbf{A}_\text{init} \\
\mathbf{A}_\text{fc}   & \mathbf{0} \\
\mathbf{0} & \mathbf{A}_\text{fc} \\
\mathbf{T}_\text{last} & -\mathbf{T}_\text{last}
\end{bmatrix}
\in\mathbb{R}^{(3S+2C)\times 2NM},\qquad
\mathbf{b}\;=\;
\begin{bmatrix}\mathbf{f}^{(k)}\\\mathbf{f}^{(K)}\\\mathbf{0}\\\mathbf{0}\\\mathbf{0}\end{bmatrix}
\in\mathbb{R}^{3S+2C}.\;}
$$

## 3. Main theorem

> **Theorem 1 (Pointwise FD as linear feasibility).** Let $\mathbf{A},\mathbf{b}$ be
> as in §2. Then
>
> $$
> \rho\text{-period FD holds at }(x_0,k,K)
> \quad\Longleftrightarrow\quad
> \mathbf{b}\in\operatorname{Range}(\mathbf{A}),
> $$
>
> equivalently $\operatorname{rank}\!\bigl([\mathbf{A}\mid\mathbf{b}]\bigr)=\operatorname{rank}(\mathbf{A})$,
> equivalently $(\mathbf{I}-\mathbf{A}\mathbf{A}^{+})\,\mathbf{b}=\mathbf{0}$.

**Proof.** Block rows of $\mathbf{A}\mathbf{x}$ evaluate as follows.
*Rows 1–2.* For each $x\in\mathcal{X}$,
$$(\mathbf{A}_\text{init}\operatorname{vec}\boldsymbol{\phi})_x
=\sum_{\mathbf{j}:j_1=x}\sum_{\mathbf{k}}\phi_{\mathbf{j},\mathbf{k}},$$
which equals $f(x\mid x_0,u)$ exactly when $\boldsymbol{\phi}=\boldsymbol{\phi}^{(u)}$
satisfies eq:initial\_flow (Condition 1).
*Rows 3–4.* For each $(\tau,\mathbf{j}_{1:\tau},\mathbf{k}_{1:\tau},j_{\tau+1})$,
the corresponding row of $\mathbf{A}_\text{fc}\operatorname{vec}\boldsymbol{\phi}$
is the LHS minus the RHS of eq:flow\_conservation. It vanishes for both
$\boldsymbol{\phi}^{(k)}$ and $\boldsymbol{\phi}^{(K)}$ exactly when Condition 2
holds.
*Row 5.* By eq:terminal\_dist\_phi,
$\mathbf{T}_\text{last}\operatorname{vec}\boldsymbol{\phi}^{(u)}=\kappa_{\rho+1}^{(u)}$,
so the block evaluates to $\kappa_{\rho+1}^{(k)}-\kappa_{\rho+1}^{(K)}$.
This is zero iff Condition 3 holds.

Hence $\mathbf{A}\mathbf{x}=\mathbf{b}$ is *equivalent* to the conjunction of
Conditions 1–3 of Definition 1. The two-way characterization follows.
$\hspace{2cm}\blacksquare$

> **Corollary (value identity).** Whenever Theorem 1 returns a feasible
> $\mathbf{x}$, thm:fd\_representation applies and
>
> $$
> v(x_0,k)-v(x_0,K)
> \;=\;\bigl[u(x_0,k)-u(x_0,K)\bigr]
> \;+\;\sum_{\tau=1}^{\rho}\beta^{\tau}\!
> \sum_{\mathbf{j},\mathbf{k}}\bigl(\phi^{(k)}_{\mathbf{j},\mathbf{k}}-\phi^{(K)}_{\mathbf{j},\mathbf{k}}\bigr)
> \hat{u}(j_\tau,k_\tau).
> $$

## 4. Relation to the universal rank theorem

> **Proposition 1.** Let $\mathcal{C}_\rho$ be the controllability matrix and
> $\mathbf{G}$ the gap matrix of thm:fd\_existence. Then
>
> $$
> \operatorname{rank}\!\bigl([\mathcal{C}_\rho\mid\mathbf{G}]\bigr)=\operatorname{rank}(\mathcal{C}_\rho)
> \quad\Longleftrightarrow\quad
> \forall\,(x_0,k,K):\;\mathbf{b}^{(x_0,k,K)}\in\operatorname{Range}(\mathbf{A}^{(x_0,k,K)}).
> $$
>
> The forward implication is thm:fd\_existence; the reverse is Theorem 1
> applied separately at each triple. Equivalently, Theorem 1 is the
> *pointwise refinement* of thm:fd\_existence, in which a model may admit FD
> at some $(x_0,k,K)$ even when universal FD fails.

The two `earlier` cases reported by `fd_linear_system.py` (Entry/Exit Game and
Dynamic Oligopoly: $\rho^*=2$ universally, $\rho^*=1$ pointwise) demonstrate
exactly this gap.

## 5. Numerical certification

In practice we test feasibility by sparse LSQR. Letting
$\widehat{\mathbf{x}}=\arg\min_{\mathbf{x}}\|\mathbf{A}\mathbf{x}-\mathbf{b}\|_2$ and
$\widehat r=\|\mathbf{A}\widehat{\mathbf{x}}-\mathbf{b}\|_2$, we declare the certificate
satisfied at tolerance $\varepsilon$ when
$$
\widehat r \;<\; \varepsilon\,\max\!\bigl(1,\|\mathbf{b}\|_2\bigr).
$$
Default $\varepsilon=10^{-8}$. For the canonical ten-model suite the
residual at the certified $\rho$ is between $10^{-17}$ and $10^{-13}$;
for the $S{=}3,A{=}2$ counterexample of §6 it is $\approx 0.71$.

## 6. Counterexample

We give a minimal model where universal — *and* pointwise — $\rho{=}1$ FD
fails. Let $S=3$, $A=2$, $K=1$, and

$$
\begin{aligned}
F[0]\;&=\;\begin{pmatrix}0&1&0\\1&0&0\\0&1&0\end{pmatrix},
&F[1]\;&=\;\begin{pmatrix}0&0&1\\1&0&0\\0&1&0\end{pmatrix}.
\end{aligned}
$$

Action differences satisfy $\Delta_0=(0,1,-1)$, $\Delta_1=\Delta_2=\mathbf{0}$,
hence $\operatorname{col}(\mathbf{B})=\operatorname{span}\{(0,1,-1)\}$. From
$x_0=0$ the gap (eq:gap\_def) evaluates to $g(\cdot)=(-1,1,0)$, which is
*not* in that span. By Theorem 1, $\mathbf{A}\mathbf{x}=\mathbf{b}$ has no
solution at $\rho=1$. A second period propagates the gap through $F[d]^{\!\top}$,
and feasibility is restored at $\rho=2$. The numerical run of
`fd_linear_system.py` confirms residuals
$\widehat r_{\rho=1}\approx 7.07\!\times\!10^{-1}$ and
$\widehat r_{\rho=2}\approx 4.59\!\times\!10^{-14}$.

---

*Implementation:* `code/fd_linear_system.py`. *Self-check:*
`python3 code/fd_linear_system.py`.
