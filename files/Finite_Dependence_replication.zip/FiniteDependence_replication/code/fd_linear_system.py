"""
fd_linear_system.py -- Finite Dependence as the existence of a linear system.

The rho-period Finite Dependence (FD) property at a given triple (s0, k, K)
holds **iff** there exist flow variables phi_k, phi_K (indexed by rho-length
state and action sequences) that satisfy a linear system

        A x = b                                                         (*)

where x = [ vec(phi_k); vec(phi_K) ] stacks the two flows.

This module constructs A and b **carefully** so that each row of A encodes one
of three conceptual conditions, and then checks feasibility of (*) to decide
whether FD holds.

================================================================================
Index conventions
================================================================================

S   : number of states,   indexed j     in {0, ..., S-1}
A_  : number of actions,  indexed a     in {0, ..., A_-1}    (we use A_ to avoid
                                                              name clash with A)
rho : FD horizon
N   : number of state sequences  = S^rho,  each j_seq = (j_1, ..., j_rho),
                                           enumerated by ji = 0, ..., N-1
M   : number of action sequences = A_^rho, each k_seq = (k_1, ..., k_rho),
                                           enumerated by ki = 0, ..., M-1

Flat index for a flow entry  (ji, ki)  within one half-block is  ji*M + ki.
Full x = [ phi_k ; phi_K ] lives in R^{2*N*M}, with the phi_K block offset
by N*M.

Time indexing used below (matches code/UnifiedFDSolver.py):

    t = 0   : initial state s0, initial action k (or K) -- not stored in k_seq
    t = 1   : state j_1 = j_seq[0],  action k_1 = k_seq[0]
    t = 2   : state j_2 = j_seq[1],  action k_2 = k_seq[1]
    ...
    t = rho : state j_rho = j_seq[-1], action k_rho = k_seq[-1]
    t = rho+1 : terminal state  x'   (distribution being matched)

================================================================================
Definition of phi (the decision variable)
================================================================================

phi_k[(j_1,...,j_rho), (k_1,...,k_rho)]
    = P(reach j_1,...,j_rho | s0, k)  *  omega_k(k_1,...,k_rho | j_1,...,j_rho)

i.e. a *flow* that absorbs the path probability.  Flows need not be
nonnegative -- they are signed measures in the Arcidiacono-Miller sense.

================================================================================
The three row-blocks of A
================================================================================

BLOCK 1 -- Initial-flow consistency (2*S rows)

  For each j_1 in {0,...,S-1}:

    sum over (ji : j_seq[0] = j_1) sum over ki  phi_k[ji, ki]  = F[k, s0, j_1]   (1a)
    sum over (ji : j_seq[0] = j_1) sum over ki  phi_K[ji, ki]  = F[K, s0, j_1]   (1b)

  This pins down the marginal at t=1 as the physical transition under the
  initial action.  Summing (1a) over j_1 gives total mass = 1 implicitly, so
  no extra normalisation is needed.

BLOCK 2 -- Flow conservation at each interior time step (2*C rows)

  For each tau in {0, ..., rho-2},
  each state prefix  p = (j_1, ..., j_{tau+1}),
  each action prefix q = (k_1, ..., k_{tau+1}),
  and each next state j_{tau+2}:

    sum_{suffix}
        phi_k[(p, j_{tau+2}, *), (q, *)]
      -  F[k_{tau+1}, j_{tau+1}, j_{tau+2}]  *
        sum_{j_{tau+2}', suffix}
        phi_k[(p, j_{tau+2}', *), (q, *)]
      = 0                                                                    (2a)

    same equation with phi_K.                                                (2b)

  Row count per half:  C = sum_{tau=0}^{rho-2} S^{tau+2} * A_^{tau+1}.

  These rows are *identical* in each half (same A, same right-hand side 0);
  only the decision vector they act on differs.

BLOCK 3 -- Terminal-distribution matching (S rows)  -- THE FD CONDITION

  For each terminal state x' in {0,...,S-1}:

    sum_{ji,ki} phi_k[ji, ki]  * F[k_seq[-1], j_seq[-1], x']
  - sum_{ji,ki} phi_K[ji, ki]  * F[k_seq[-1], j_seq[-1], x']
  = 0                                                                       (3)

  This is the statement that the distribution over states at time rho+1
  (after the initial action plus rho weighted follow-up transitions) is the
  same under k and under K.

================================================================================
Putting it together -- the full system
================================================================================

                      [ A_init    0    ]           [ f_k ]
                      [   0    A_init  ]           [ f_K ]
     A   =            [ A_fc      0    ]     b  =  [  0  ]
                      [   0    A_fc    ]           [  0  ]
                      [ T_last -T_last ]           [  0  ]

  A_init in R^{S x NM}      (indicator of j_seq[0] = j_1)
  A_fc   in R^{C x NM}      (flow conservation, same for both halves)
  T_last in R^{S x NM}      with T_last[x', (ji,ki)] = F[k_seq[-1], j_seq[-1], x']

  f_k in R^S,  f_k[j_1] = F[k, s0, j_1];     f_K analogously.

Total shape of A: (3*S + 2*C)  x  (2*N*M).

================================================================================
FD existence theorem
================================================================================

  rho-period FD holds at (s0, k, K)    iff    there exists x with  A x = b
                                       iff    b in range(A)
                                       iff    rank([A | b]) = rank(A).

In practice we solve (*) via sparse least squares and declare FD iff the
residual ||A x - b|| falls below a numerical tolerance.  A tiny residual
means b is (essentially) in the column span of A; a non-trivial residual
means no exact phi can make (*) hold.

================================================================================
Relation to the controllability rank test
================================================================================

  * test_rank_condition.py checks rank(C_rho) = S - 1, a *universal*
    sufficient condition that guarantees rho-FD at *every* (s0, k, K).
  * This module checks FD exactly at a *specific* (s0, k, K).  A model may
    fail the universal rank test yet still admit FD pointwise.
"""

from __future__ import annotations

from itertools import product
from dataclasses import dataclass, field

import numpy as np
import scipy.sparse as sps
import scipy.sparse.linalg as spsla


# =============================================================================
# Block builders
# =============================================================================

def _build_A_init(S: int, A_: int, rho: int, j_arr: np.ndarray) -> sps.csr_matrix:
    """Block 1 matrix: marginal over (j_seq[0] = j_1) equals one.

    Shape: (S, N*M). Value 1 at column (ji, ki) iff j_seq[ji][0] == j_1.
    """
    N = j_arr.shape[0]
    M = A_ ** rho
    rows, cols = [], []
    for j1 in range(S):
        ji_hits = np.flatnonzero(j_arr[:, 0] == j1)
        # (ji, ki) flat index = ji * M + ki, for all ki in [0, M)
        flat = (ji_hits[:, None] * M + np.arange(M)[None, :]).ravel()
        rows.extend([j1] * flat.size)
        cols.extend(flat.tolist())
    vals = np.ones(len(rows), dtype=float)
    return sps.csr_matrix((vals, (rows, cols)), shape=(S, N * M))


def _build_A_fc(F: np.ndarray, rho: int,
                j_arr: np.ndarray, k_arr: np.ndarray) -> sps.csr_matrix:
    """Block 2 matrix: flow conservation across interior time steps.

    For each tau in {0,...,rho-2}, state-prefix p of length tau+1,
    action-prefix q of length tau+1, and next state j_next:

        [sum over suffix of phi with (p, j_next, ...) and (q, ...)]
      - F[q[-1], p[-1], j_next] * [sum over j_next', suffix of phi with (p, ...) and (q, ...)]
      = 0

    Returns a (C, N*M) sparse matrix with C rows.
    """
    A_, S, _ = F.shape
    N, M = j_arr.shape[0], k_arr.shape[0]

    if rho <= 1:
        return sps.csr_matrix((0, N * M))

    rows, cols, vals = [], [], []
    r = 0

    for tau in range(rho - 1):
        p_len = tau + 1  # state-prefix length
        q_len = tau + 1  # action-prefix length

        p_list = np.unique(j_arr[:, :p_len], axis=0)
        q_list = np.unique(k_arr[:, :q_len], axis=0)

        for p in p_list:
            mask_p = np.all(j_arr[:, :p_len] == p, axis=1) if p_len > 1 \
                     else (j_arr[:, 0] == p[0])
            ji_parent = np.flatnonzero(mask_p)
            if ji_parent.size == 0:
                continue
            p_last = p[-1]

            for q in q_list:
                mask_q = np.all(k_arr[:, :q_len] == q, axis=1) if q_len > 1 \
                         else (k_arr[:, 0] == q[0])
                ki_hit = np.flatnonzero(mask_q)
                if ki_hit.size == 0:
                    continue
                q_last = q[-1]

                parent_flat = (ji_parent[:, None] * M + ki_hit[None, :]).ravel()

                for j_next in range(S):
                    f_trans = F[q_last, p_last, j_next]
                    mask_next = mask_p & (j_arr[:, tau + 1] == j_next)
                    ji_child = np.flatnonzero(mask_next)

                    # +1 on child flows
                    if ji_child.size > 0:
                        child_flat = (ji_child[:, None] * M + ki_hit[None, :]).ravel()
                        rows.extend([r] * child_flat.size)
                        cols.extend(child_flat.tolist())
                        vals.extend([1.0] * child_flat.size)

                    # -f_trans on parent flows
                    if f_trans != 0.0:
                        rows.extend([r] * parent_flat.size)
                        cols.extend(parent_flat.tolist())
                        vals.extend([-float(f_trans)] * parent_flat.size)

                    r += 1

    if r == 0:
        return sps.csr_matrix((0, N * M))
    return sps.csr_matrix((vals, (rows, cols)), shape=(r, N * M))


def _build_T_last(F: np.ndarray, j_arr: np.ndarray, k_arr: np.ndarray) -> sps.csr_matrix:
    """Block 3 matrix (one half): terminal transition for phi_k.

    Shape: (S, N*M).  Entry [x', (ji, ki)] = F[k_seq[-1], j_seq[-1], x'].
    """
    A_, S, _ = F.shape
    N, M = j_arr.shape[0], k_arr.shape[0]

    # Dense first (S, N, M) then flatten -- typically S, N, M are modest.
    last_j = j_arr[:, -1]            # (N,)
    last_k = k_arr[:, -1]            # (M,)
    # coeff[x', ji, ki] = F[last_k[ki], last_j[ji], x']
    coeff = F[last_k[None, :], last_j[:, None], :]   # (N, M, S)
    coeff = coeff.transpose(2, 0, 1).reshape(S, N * M)
    return sps.csr_matrix(coeff)


# =============================================================================
# Public data class
# =============================================================================

@dataclass
class FDSystem:
    """Container for the linear system A x = b encoding rho-FD at (s0, k, K)."""

    # Problem dimensions
    S: int
    A_: int
    rho: int
    N: int          # = S^rho
    M: int          # = A_^rho

    # Named row-blocks (handy for diagnostics)
    A_init: sps.csr_matrix       # (S, N*M)       initial flow (shared across halves)
    A_fc:   sps.csr_matrix       # (C, N*M)       flow conservation (shared)
    T_last: sps.csr_matrix       # (S, N*M)       terminal transition (shared)

    # Full assembled system (built lazily via assemble())
    A: sps.csr_matrix | None = None   # (3S + 2C) x (2*N*M)
    b: np.ndarray | None = None       # (3S + 2C,)

    # Index bookkeeping
    j_arr: np.ndarray = field(default_factory=lambda: np.empty((0, 0), dtype=int))
    k_arr: np.ndarray = field(default_factory=lambda: np.empty((0, 0), dtype=int))


def build_fd_system(F: np.ndarray, s0: int, k: int, K: int, rho: int) -> FDSystem:
    """Build the Ax=b system that certifies rho-FD at (s0, k, K).

    Parameters
    ----------
    F   : transition tensor, shape (A_, S, S), rows sum to 1.
    s0  : initial state.
    k   : alternative initial action (whose value we want to match against K).
    K   : reference initial action.
    rho : FD horizon.

    Returns
    -------
    FDSystem with A, b assembled and named sub-blocks retained.

    rho-FD at (s0, k, K) holds iff the returned linear system has a solution.
    """
    A_, S, S2 = F.shape
    assert S == S2, "F must be (A_, S, S)"
    assert 0 <= s0 < S and 0 <= k < A_ and 0 <= K < A_
    assert rho >= 1

    # Enumerate sequences
    j_arr = np.array(list(product(range(S), repeat=rho)), dtype=int)   # (N, rho)
    k_arr = np.array(list(product(range(A_), repeat=rho)), dtype=int)  # (M, rho)
    N, M = j_arr.shape[0], k_arr.shape[0]

    # Named blocks (independent of s0 / k / K)
    A_init = _build_A_init(S, A_, rho, j_arr)                # (S, NM)
    A_fc   = _build_A_fc(F, rho, j_arr, k_arr)               # (C, NM)
    T_last = _build_T_last(F, j_arr, k_arr)                  # (S, NM)
    C = A_fc.shape[0]

    # Assemble A:
    #   [ A_init    0    ]
    #   [   0    A_init  ]
    #   [ A_fc      0    ]
    #   [   0    A_fc    ]
    #   [ T_last -T_last ]
    Z_init = sps.csr_matrix((S, N * M))
    Z_fc   = sps.csr_matrix((C, N * M))
    A_mat = sps.vstack([
        sps.hstack([A_init,   Z_init]),
        sps.hstack([Z_init,   A_init]),
        sps.hstack([A_fc,     Z_fc]),
        sps.hstack([Z_fc,     A_fc]),
        sps.hstack([T_last,  -T_last]),
    ], format='csr')

    # Assemble b
    f_k = F[k, s0, :].astype(float)          # (S,)
    f_K = F[K, s0, :].astype(float)          # (S,)
    b = np.concatenate([f_k, f_K, np.zeros(C), np.zeros(C), np.zeros(S)])

    return FDSystem(S=S, A_=A_, rho=rho, N=N, M=M,
                    A_init=A_init, A_fc=A_fc, T_last=T_last,
                    A=A_mat, b=b, j_arr=j_arr, k_arr=k_arr)


# =============================================================================
# Existence check
# =============================================================================

def fd_holds(F: np.ndarray, s0: int, k: int, K: int, rho: int,
             tol: float = 1e-8, return_system: bool = False):
    """Check whether rho-FD holds at (s0, k, K) by testing Ax=b feasibility.

    Uses sparse LSQR to obtain the minimum-norm least-squares solution, then
    declares FD iff the residual ||A x - b||_2 is below tol.

    Returns
    -------
    exists   : bool                -- True iff Ax=b admits a solution (FD holds).
    residual : float               -- ||A x* - b||_2 from LSQR.
    x        : np.ndarray          -- the computed solution (flattened).
    system   : FDSystem (optional) -- returned if return_system=True.
    """
    sys = build_fd_system(F, s0, k, K, rho)

    # lsqr finds min ||Ax - b||; for consistent systems the residual is ~0.
    res = spsla.lsqr(sys.A, sys.b, atol=1e-14, btol=1e-14, iter_lim=20000)
    x = res[0]
    residual = float(np.linalg.norm(sys.A @ x - sys.b))

    exists = residual < tol * max(1.0, np.linalg.norm(sys.b))
    if return_system:
        return exists, residual, x, sys
    return exists, residual, x


def fd_holds_universal(F: np.ndarray, rho: int, K: int | None = None,
                       tol: float = 1e-8) -> tuple[bool, float, list]:
    """Check rho-FD at **every** (s0, k, K) pair with k != K.

    Returns
    -------
    universal   : bool   -- True iff FD holds for all (s0, k).
    worst_resid : float  -- largest residual encountered.
    failures    : list of (s0, k, K, residual) tuples where FD fails.
    """
    A_, S, _ = F.shape
    if K is None:
        K = A_ - 1

    worst = 0.0
    failures = []
    for s0 in range(S):
        for k in range(A_):
            if k == K:
                continue
            ok, r, _ = fd_holds(F, s0, k, K, rho, tol=tol)
            worst = max(worst, r)
            if not ok:
                failures.append((s0, k, K, r))
    return len(failures) == 0, worst, failures


# =============================================================================
# Self-check: run on the ten canonical models and compare to the rank test
# =============================================================================

if __name__ == "__main__":
    import sys, os
    sys.path.insert(0, os.path.dirname(__file__))
    from test_rank_condition import (
        build_engine_replacement, build_job_search, build_labor_p1,
        build_investment, build_inventory, build_entry_exit,
        build_altug_miller, build_education, build_game, build_oligopoly,
        compute_controllability_matrix,
    )

    builders = [
        build_engine_replacement,
        build_job_search,
        build_labor_p1,
        build_investment,
        build_inventory,
        build_entry_exit,
        build_altug_miller,
        build_education,
        build_game,
        build_oligopoly,
    ]

    print("=" * 92)
    print("FD existence via Ax=b vs. controllability rank test")
    print("=" * 92)
    print(f"{'Model':<22} {'S':>3} {'A':>2} {'Pred':>4}"
          f" {'rho_rank':>9} {'rho_exist':>10} {'worst_resid':>12}  match?")
    print("-" * 92)

    for build_fn in builders:
        F, S, A_, name, pred_rho = build_fn()
        # Normalise rows of F
        F = F.astype(float).copy()
        for a in range(A_):
            rs = F[a].sum(axis=1, keepdims=True)
            rs[rs == 0] = 1.0
            F[a] /= rs

        # --- rank test: smallest rho with rank(C_rho) >= S-1 ---
        rho_rank = None
        for rho in range(1, 6):
            _, r = compute_controllability_matrix(F, rho, K=A_ - 1)
            if r >= S - 1:
                rho_rank = rho
                break

        # --- existence test: smallest rho for which Ax=b feasible everywhere ---
        # Cap work per model:  variable count per (s0,k) is 2 * S^rho * A^rho.
        MAX_NM = 8000
        rho_exist = None
        worst_at_success = float("nan")
        for rho in range(1, 6):
            if S ** rho * A_ ** rho > MAX_NM:
                break
            ok, w, _ = fd_holds_universal(F, rho, K=A_ - 1)
            if ok:
                rho_exist = rho
                worst_at_success = w
                break
        if rho_exist is None:
            rho_exist_s = "> tested"
            match = "skip"
        elif rho_exist == pred_rho:
            rho_exist_s = str(rho_exist)
            match = "match"
        elif rho_exist < pred_rho:
            rho_exist_s = str(rho_exist)
            match = "earlier"      # pointwise FD stronger than paper's bound
        else:
            rho_exist_s = str(rho_exist)
            match = "LATER!"       # should not happen -- existence necessary+sufficient

        rho_rank_s = str(rho_rank) if rho_rank is not None else "> 5"
        worst_s = (f"{worst_at_success:.2e}"
                   if np.isfinite(worst_at_success) else "   n/a")
        print(f"{name:<22} {S:>3} {A_:>2} {pred_rho:>4}"
              f" {rho_rank_s:>9} {rho_exist_s:>10} {worst_s:>12}  {match}")

    # ------------------------------------------------------------------
    # Sanity: a hand-crafted counterexample where signed rho=1 FD fails.
    #
    #   S=3, A=2.  Actions differ only at j=0:
    #     F[0, 0, :] = (0, 1, 0)   F[1, 0, :] = (0, 0, 1)     Delta_0 = ( 0, 1,-1)
    #     F[0, 1, :] = F[1, 1, :] = (1, 0, 0)                 Delta_1 = 0
    #     F[0, 2, :] = F[1, 2, :] = (0, 1, 0)                 Delta_2 = 0
    #   Action-difference span = span{(0, 1, -1)} (1-dim).
    #   From s0=0, k=0, K=1:  required rho=1 target = (-1, 1, 0),
    #   which is NOT in that 1-dim span ==> no signed phi exists.
    #   At rho=2 the reachable span grows and FD becomes feasible.
    # ------------------------------------------------------------------
    print()
    print("Sanity counterexample (rho=1 FD should *fail*, rho=2 should hold):")
    F_bad = np.zeros((2, 3, 3))
    F_bad[0, 0] = [0, 1, 0];   F_bad[1, 0] = [0, 0, 1]
    F_bad[0, 1] = [1, 0, 0];   F_bad[1, 1] = [1, 0, 0]
    F_bad[0, 2] = [0, 1, 0];   F_bad[1, 2] = [0, 1, 0]
    ok, r, _ = fd_holds(F_bad, s0=0, k=0, K=1, rho=1)
    print(f"  rho=1  exists={ok}  residual={r:.2e}   (expected: exists=False)")
    ok2, r2, _ = fd_holds(F_bad, s0=0, k=0, K=1, rho=2)
    print(f"  rho=2  exists={ok2}  residual={r2:.2e}   (expected: exists=True)")
