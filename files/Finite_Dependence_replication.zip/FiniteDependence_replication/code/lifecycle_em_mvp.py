"""
lifecycle_em_mvp.py
===================

Phase 1 MVP for GFD-EM with non-stationary (lifecycle) DDC and unobserved
heterogeneity.  Goal: validate that a bridge-based M-step converges to the
true parameters and matches an NFXP-EM benchmark on bias / RMSE while
avoiding the per-iteration full-Bellman solve.

Setup
-----
* Lifecycle horizon T = 10 (decision periods t = 0, ..., T-1)
* Terminal value v_T(x) = 0  (no continuation past T)
* 2 unobserved types k in {0, 1} with prior pi = (0.6, 0.4)
* 2 actions d in {0, 1}  (do not work / work)
* State x_t = (l_{t-1}, l_{t-2}) is the 2-lag labour history,
  encoded as x = 2*l_{t-1} + l_{t-2}, |X| = 4
* Deterministic shift-register transition: under action d the next state
  is (d, l_{t-1}), so F[d, x, x'] = 1 iff x' encodes (d, l_{t-1})
* Type-conditional payoff:
      u_k(d, x; theta_k) = alpha_k + beta_k * d + gamma_k * d * (l1 + l2)
  with theta_k = (alpha_k, beta_k, gamma_k) and l1, l2 the digits of x.
* Action d=0 is the reference action.  Payoff at d=0 is alpha_k.

True parameters (chosen so the two types are economically distinct):
    theta_1 = (-0.5,  1.0,  0.3)  -- high work propensity, increasing in history
    theta_2 = (+0.5, -0.5, -0.2)  -- low work propensity, decreasing in history
    pi_0    = (0.6, 0.4)
    beta    = 0.95

This setup has FD horizon rho = 2 (Type S shift register with p = 2 lags).

Benchmarks
----------
* NFXP-EM    : M-step solves the type-conditional finite-horizon Bellman
              by backward induction at every theta candidate.
* GFD-EM     : M-step uses the bridge identity with previous-iteration's
              CCPs as the future anchor; no Bellman fixed point.

Both share the same E-step (posterior over types given observed paths).

Output
------
* Bias / RMSE on (theta_1, theta_2, pi) across replications
* Wall-clock per EM step
* Log-likelihood trajectories
"""

from __future__ import annotations

import argparse
import time
from dataclasses import dataclass
import sys, os

import numpy as np
from scipy.optimize import minimize


# =============================================================================
# Setup / encoding
# =============================================================================

T_HORIZON = 10
K_TYPES = 2
N_ACTIONS = 2
N_LAGS = 2
N_STATES = N_ACTIONS ** N_LAGS      # 4
BETA = 0.95
RHO = 2

# Reparameterised: u(0, x) = 0 (reference), u(1, x) = b + g * (l1 + l2).
# The level alpha was unidentified (cancels in CCP), so we drop it.
# theta_k = (b_k, g_k), 2 params per type.
THETA_TRUE = np.array([
    [ 1.0,  0.3],   # type 1: high work propensity, increasing in history
    [-0.5, -0.2],   # type 2: low work propensity, decreasing in history
])
PI_TRUE = np.array([0.6, 0.4])


def x_to_lags(x: int) -> tuple[int, int]:
    """x = 2*l1 + l2  ->  (l1, l2)."""
    return (x >> 1) & 1, x & 1


def lags_to_x(l1: int, l2: int) -> int:
    return (l1 << 1) | l2


# Deterministic shift register transition: x' = (d, l1)
F_TRANS = np.zeros((N_ACTIONS, N_STATES, N_STATES))
for d in range(N_ACTIONS):
    for x in range(N_STATES):
        l1, l2 = x_to_lags(x)
        x_next = lags_to_x(d, l1)
        F_TRANS[d, x, x_next] = 1.0


def payoff(d: int, x: int, theta: np.ndarray) -> float:
    """u_k(d, x; theta) = d * (b + g * (l1 + l2)),  with u(0, x) = 0."""
    b, g = theta
    if d == 0:
        return 0.0
    l1, l2 = x_to_lags(x)
    return b + g * (l1 + l2)


def payoff_vec(theta: np.ndarray) -> np.ndarray:
    """Vectorised: returns u[d, x] of shape (N_ACTIONS, N_STATES)."""
    out = np.empty((N_ACTIONS, N_STATES))
    for d in range(N_ACTIONS):
        for x in range(N_STATES):
            out[d, x] = payoff(d, x, theta)
    return out


# =============================================================================
# NFXP: type-conditional finite-horizon backward induction
# =============================================================================

def backward_bellman(theta: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Solve the type-conditional finite-horizon Bellman backwards.

    Returns
    -------
    v : (T, N_ACTIONS, N_STATES) action-value function v_t(x, d)
    p : (T, N_ACTIONS, N_STATES) CCP p_t(d|x) via type-1 EV logit

    With type-1 Gumbel shocks, the choice-specific value satisfies
        v_t(x, d) = u(d, x) + beta * E_x' [ V_{t+1}(x') ]
    where V_{t+1}(x) = logsumexp_d v_{t+1}(x, d), and
        p_t(d|x) = exp(v_t(x, d)) / sum_d' exp(v_t(x, d')).
    Terminal: V_T(x) = 0.
    """
    u = payoff_vec(theta)                              # (D, S)
    v = np.zeros((T_HORIZON, N_ACTIONS, N_STATES))
    p = np.zeros((T_HORIZON, N_ACTIONS, N_STATES))

    V_next = np.zeros(N_STATES)                        # V_T(x) = 0
    for t in range(T_HORIZON - 1, -1, -1):
        # v_t(x, d) = u(d, x) + beta * E_x' V_{t+1}(x')
        EV = (F_TRANS * V_next[None, None, :]).sum(axis=2)   # (D, S)
        v_t = u + BETA * EV
        # CCP via softmax over actions
        m = v_t.max(axis=0, keepdims=True)
        ev = np.exp(v_t - m)
        p_t = ev / ev.sum(axis=0, keepdims=True)
        v[t] = v_t
        p[t] = p_t
        # V_t(x) = log sum_d exp(v_t(x, d))  (Gumbel logsumexp)
        V_next = m.squeeze(0) + np.log(ev.sum(axis=0))

    return v, p


# =============================================================================
# DGP simulation
# =============================================================================

def simulate(N: int, rng: np.random.Generator) -> dict:
    """Draw N agents.  Returns dict with x, d, types, init_x."""
    # Each agent's true type
    types = rng.choice(K_TYPES, size=N, p=PI_TRUE)
    # CCPs by type
    p_by_type = np.stack([backward_bellman(THETA_TRUE[k])[1] for k in range(K_TYPES)])
    # (K_TYPES, T, D, S)

    x = np.zeros((N, T_HORIZON), dtype=int)
    d = np.zeros((N, T_HORIZON), dtype=int)
    # Initial state uniform on S
    x[:, 0] = rng.integers(0, N_STATES, size=N)

    for n in range(N):
        k_n = types[n]
        for t in range(T_HORIZON):
            p_action = p_by_type[k_n, t, :, x[n, t]]        # (D,)
            d[n, t] = rng.choice(N_ACTIONS, p=p_action)
            if t + 1 < T_HORIZON:
                # deterministic shift
                l1, l2 = x_to_lags(x[n, t])
                x[n, t + 1] = lags_to_x(d[n, t], l1)

    return {"x": x, "d": d, "types": types, "N": N}


# =============================================================================
# E-step: posterior over types
# =============================================================================

def compute_posterior(data: dict, p_by_type: np.ndarray, pi: np.ndarray) -> np.ndarray:
    """Returns posterior gamma[n, k] = P(type=k | path_n; theta, pi).

    p_by_type has shape (K, T, D, S).
    """
    N = data["N"]
    x = data["x"]; d = data["d"]
    log_pi = np.log(pi + 1e-300)

    # log p_t(d_{n,t} | x_{n,t}) per (n, t, k)
    # Indexing: p_by_type[k, t, d_{n,t}, x_{n,t}]
    log_lik = np.zeros((N, K_TYPES))
    for k in range(K_TYPES):
        # gather log p_{k, t, d_{n,t}, x_{n,t}}
        # use advanced indexing
        for t in range(T_HORIZON):
            log_lik[:, k] += np.log(p_by_type[k, t, d[:, t], x[:, t]] + 1e-300)

    log_post = log_lik + log_pi[None, :]
    m = log_post.max(axis=1, keepdims=True)
    post = np.exp(log_post - m)
    post = post / post.sum(axis=1, keepdims=True)
    return post


# =============================================================================
# NFXP-EM M-step: optimise theta_k via Bellman backward induction
# =============================================================================

def weighted_neg_log_lik_nfxp(theta_k: np.ndarray,
                              data: dict, weights_k: np.ndarray) -> float:
    """Negative weighted log-likelihood under NFXP CCPs at theta_k."""
    _, p_k = backward_bellman(theta_k)
    N = data["N"]
    x = data["x"]; d = data["d"]
    ll = 0.0
    for t in range(T_HORIZON):
        log_p = np.log(p_k[t, d[:, t], x[:, t]] + 1e-300)
        ll += (weights_k * log_p).sum()
    return -ll


# =============================================================================
# GFD bridge: compute type-conditional CCPs via bridge identity
# =============================================================================

# Pre-compute flow weights Phi_k(x; d=1, d'=0) for each x.  Under Type S
# shift-register with rho=2, the bridge at horizon 2 reduces to a closed
# form, but for MVP-clarity we use the generic LSQR feasibility solver
# from fd_linear_system.py.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fd_linear_system import build_fd_system  # noqa: E402


def compute_phi_marginals() -> dict:
    """For each (x, d=1 vs d'=0), solve the FD linear system and return the
    pointwise marginal flow at periods tau = 1, 2.

    Returns
    -------
    dict mapping x -> {'phi_diff_t1': (D, S), 'phi_diff_t2': (D, D, S, S)}
    where phi_diff_t1[k1, j1] = sum over (k2, j2) of
        [Phi_k(x; d=1)(k1,k2; j1,j2) - Phi_k(x; d'=0)(k1,k2; j1,j2)]
    captures the marginal flow at period t+1 difference between d=1 and d=0.
    Similarly phi_diff_t2[k1, k2, j1, j2] is the full joint difference for
    period t+2 contribution.

    The flow weights are type-independent here because F_TRANS does not
    depend on theta in our MVP (shift register).
    """
    out = {}
    for x in range(N_STATES):
        sys_fd = build_fd_system(F_TRANS, s0=x, k=1, K=0, rho=RHO)
        A_mat = sys_fd.A
        b_vec = sys_fd.b
        # Solve via LSQR for min-norm least-squares
        from scipy.sparse.linalg import lsqr
        sol = lsqr(A_mat, b_vec, atol=1e-12, btol=1e-12, iter_lim=20000)[0]
        # sol has length 2 * N * M = 2 * S^rho * D^rho
        # First half = phi_k (action d=1), second = phi_K (action d=0)
        NM = sys_fd.N * sys_fd.M
        phi_k = sol[:NM].reshape(sys_fd.N, sys_fd.M)        # (j_seq, k_seq)
        phi_K = sol[NM:].reshape(sys_fd.N, sys_fd.M)        # (j_seq, k_seq)
        phi_diff = phi_k - phi_K                            # (N, M)

        # Marginal at tau = 1: sum over (k_2, j_2)
        # j_seq index: (j_1, j_2) flattened.  j_1 = j_seq // S, j_2 = j_seq % S.
        # k_seq index: (k_1, k_2) flattened.  k_1 = k_seq // D, k_2 = k_seq % D.
        S, D = N_STATES, N_ACTIONS
        # Reshape phi_diff to (j_1, j_2, k_1, k_2)
        phi_arr = phi_diff.reshape(S, S, D, D)
        # Marginal at tau=1 over (k_1, j_1):
        # contribution at tau=1 uses [u(k_1, j_1) + psi(k_1, j_1)] weighted by
        # sum over (k_2, j_2) of Phi(j_1, j_2, k_1, k_2)
        marg_t1 = phi_arr.sum(axis=(1, 3))                  # (j_1, k_1)
        marg_t2 = phi_arr                                   # (j_1, j_2, k_1, k_2)
        out[x] = {"phi_diff_t1_jk": marg_t1, "phi_diff_t2_full": marg_t2}
    return out


# Cache the flow weights once (they don't depend on theta in this MVP).
_PHI_CACHE = None
def get_phi_cache() -> dict:
    global _PHI_CACHE
    if _PHI_CACHE is None:
        _PHI_CACHE = compute_phi_marginals()
    return _PHI_CACHE


def bridge_value_diff(theta_k: np.ndarray, p_anchor_k: np.ndarray) -> np.ndarray:
    """Compute v_t(x, d=1) - v_t(x, d=0) for all (t, x) under type k using
    the bridge identity with previous-iteration CCPs p_anchor_k as the
    future anchor.

    p_anchor_k has shape (T, D, S).  Returns shape (T, S).

    For t with t + RHO < T, use bridge.  For t close to terminal, fall back
    to direct backward induction (the bridge cannot run past T).
    """
    u = payoff_vec(theta_k)              # (D, S)
    phi = get_phi_cache()
    delta_v = np.zeros((T_HORIZON, N_STATES))

    # Terminal CCP correction:  psi_t(k, j) = -log p_{t, k}(k | j)
    # (Hotz-Miller inversion under type-1 EV: psi_t(k, j) = -log p_t(k|j))
    psi = -np.log(p_anchor_k + 1e-300)   # (T, D, S)

    for t in range(T_HORIZON):
        if t + RHO < T_HORIZON:
            # Bridge at rho = 2
            for x in range(N_STATES):
                phi_t1_jk = phi[x]["phi_diff_t1_jk"]      # (j_1, k_1)
                phi_t2 = phi[x]["phi_diff_t2_full"]       # (j_1, j_2, k_1, k_2)
                # tau = 1 contribution
                # sum over (k_1, j_1):  [Phi_diff_marg_t1] * (u(k_1, j_1) + psi_{t+1}(k_1, j_1))
                u_plus_psi_t1 = u + psi[t + 1]            # (D, S)  indexed as (k_1, j_1)
                # We need elementwise: phi_t1_jk(j_1, k_1) * (u + psi)(k_1, j_1)
                contrib_t1 = (phi_t1_jk * u_plus_psi_t1.T).sum()
                # tau = 2 contribution
                u_plus_psi_t2 = u + psi[t + 2]            # (D, S)  indexed as (k_2, j_2)
                # phi_t2(j_1, j_2, k_1, k_2) * (u_plus_psi_t2)(k_2, j_2)
                # axis correspondence: phi_t2 has (j_1, j_2, k_1, k_2);
                # u_plus_psi_t2[k_2, j_2] should multiply with phi_t2[..., :, k_2, :].
                # Easier: contract over j_2, k_2:
                # sum_{j_2, k_2} phi_t2(j_1, j_2, k_1, k_2) * u_plus_psi_t2(k_2, j_2)
                contrib_t2 = np.einsum('abcd,db->', phi_t2, u_plus_psi_t2)
                # Direct payoff diff
                u_diff = u[1, x] - u[0, x]
                delta_v[t, x] = (u_diff
                                 + BETA * contrib_t1
                                 + BETA**2 * contrib_t2)
        else:
            # Terminal-proximal: fall back to direct backward step.
            # At t = T-1: v(x, d) = u(d, x), so delta_v = u(1, x) - u(0, x).
            # At t = T-2 (only if RHO = 2): v(x, d) = u(d, x) + beta * V_{T-1}(x')
            # We need V_{T-1}(x) = logsumexp_d u(d, x).
            if t == T_HORIZON - 1:
                delta_v[t, :] = u[1] - u[0]
            else:
                # t in [T_HORIZON - RHO, T_HORIZON - 2]
                # Use a direct mini-Bellman from t+1 to terminal
                V = np.zeros(N_STATES)
                for s in range(T_HORIZON - 1, t, -1):
                    if s == T_HORIZON - 1:
                        V_t_actions = u                    # (D, S)
                    else:
                        EV = (F_TRANS * V[None, None, :]).sum(axis=2)  # (D, S)
                        V_t_actions = u + BETA * EV
                    m = V_t_actions.max(axis=0, keepdims=True)
                    V = (m.squeeze(0)
                         + np.log(np.exp(V_t_actions - m).sum(axis=0)))
                EV0 = (F_TRANS * V[None, None, :]).sum(axis=2)
                v_t_actions = u + BETA * EV0               # (D, S)
                delta_v[t, :] = v_t_actions[1] - v_t_actions[0]

    return delta_v


def bridge_compute_ccp(theta_k: np.ndarray, p_anchor_k: np.ndarray) -> np.ndarray:
    """CCP under bridge identity: p_t(d=1|x) = sigmoid(delta_v_t(x))."""
    dv = bridge_value_diff(theta_k, p_anchor_k)            # (T, S)
    p1 = 1.0 / (1.0 + np.exp(-dv))                          # (T, S)
    p = np.stack([1.0 - p1, p1], axis=1)                    # (T, D, S)
    return p


def weighted_neg_log_lik_gfd(theta_k: np.ndarray,
                             data: dict, weights_k: np.ndarray,
                             p_anchor_k: np.ndarray) -> float:
    """Negative weighted log-likelihood under GFD bridge CCPs at theta_k."""
    p_k = bridge_compute_ccp(theta_k, p_anchor_k)
    N = data["N"]
    x = data["x"]; d = data["d"]
    ll = 0.0
    for t in range(T_HORIZON):
        log_p = np.log(p_k[t, d[:, t], x[:, t]] + 1e-300)
        ll += (weights_k * log_p).sum()
    return -ll


# =============================================================================
# EM driver
# =============================================================================

def em_run(data: dict, method: str, n_iters: int = 30,
           theta_init: np.ndarray | None = None,
           verbose: bool = False) -> dict:
    """Run EM with the chosen M-step.

    method in {'nfxp', 'gfd'}.

    Returns dict with final theta, p, pi, log-likelihood trajectory.
    """
    assert method in ("nfxp", "gfd")
    rng = np.random.default_rng(42)
    if theta_init is None:
        # Random init away from truth, distinct per type so they don't collapse
        offset = np.array([[+0.5, +0.2], [-0.5, -0.2]])
        theta = THETA_TRUE + offset + rng.normal(0, 0.1, size=THETA_TRUE.shape)
    else:
        theta = theta_init.copy()
    pi = np.full(K_TYPES, 1.0 / K_TYPES)

    # Initialise CCPs from theta_init via backward induction (gives valid CCPs
    # to start the EM iteration regardless of method).
    p_by_type = np.stack([backward_bellman(theta[k])[1] for k in range(K_TYPES)])

    ll_traj = []
    t_start = time.time()
    for m in range(n_iters):
        # E-step
        posterior = compute_posterior(data, p_by_type, pi)        # (N, K)
        pi = posterior.mean(axis=0)

        # M-step per type
        for k in range(K_TYPES):
            w_k = posterior[:, k]
            x0 = theta[k].copy()
            if method == "nfxp":
                fobj = lambda th: weighted_neg_log_lik_nfxp(th, data, w_k)
            else:
                p_anchor_k = p_by_type[k].copy()
                fobj = lambda th: weighted_neg_log_lik_gfd(th, data, w_k, p_anchor_k)
            res = minimize(fobj, x0, method="Nelder-Mead",
                           options={"xatol": 1e-4, "fatol": 1e-4, "maxiter": 200})
            theta[k] = res.x

        # Update CCPs with new theta
        if method == "nfxp":
            p_by_type = np.stack([backward_bellman(theta[k])[1]
                                  for k in range(K_TYPES)])
        else:
            p_by_type = np.stack([bridge_compute_ccp(theta[k], p_by_type[k])
                                  for k in range(K_TYPES)])

        # Compute current log-likelihood
        ll = 0.0
        for n in range(data["N"]):
            log_p_n_k = np.zeros(K_TYPES)
            for k in range(K_TYPES):
                for t in range(T_HORIZON):
                    log_p_n_k[k] += np.log(p_by_type[k, t, data["d"][n, t],
                                                    data["x"][n, t]] + 1e-300)
            ll_n = np.logaddexp.reduce(np.log(pi + 1e-300) + log_p_n_k)
            ll += ll_n
        ll_traj.append(ll)

        if verbose:
            print(f"  [{method}] iter {m:>2}: "
                  f"ll={ll:.2f}  theta_1={theta[0]}  theta_2={theta[1]}  "
                  f"pi={pi}")

    elapsed = time.time() - t_start

    # Match types to true ordering: compare mean of theta_k with truth
    # (avoids label-switching contaminating bias/RMSE).
    perm = match_labels(theta, THETA_TRUE)
    theta = theta[perm]
    pi = pi[perm]

    return {
        "method": method,
        "theta": theta,
        "pi": pi,
        "p_by_type": p_by_type,
        "ll_traj": ll_traj,
        "wall_clock": elapsed,
        "n_iters": n_iters,
    }


def match_labels(theta_est: np.ndarray, theta_true: np.ndarray) -> np.ndarray:
    """Return permutation of types that minimises total ||theta_est[perm] -
    theta_true|| across rows.  K=2 only: just compare both permutations."""
    if K_TYPES == 2:
        identity = np.array([0, 1])
        swap = np.array([1, 0])
        err_id = np.linalg.norm(theta_est - theta_true)
        err_sw = np.linalg.norm(theta_est[swap] - theta_true)
        return identity if err_id <= err_sw else swap
    raise NotImplementedError("Use Hungarian algorithm for K > 2.")


# =============================================================================
# Main
# =============================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--N", type=int, default=1000, help="sample size")
    parser.add_argument("--reps", type=int, default=20, help="MC replications")
    parser.add_argument("--em_iters", type=int, default=20)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--single_rep", action="store_true",
                        help="run one rep verbosely (for debugging)")
    args = parser.parse_args()

    if args.single_rep:
        rng = np.random.default_rng(args.seed)
        data = simulate(args.N, rng)
        print(f"\n=== Single-rep diagnostic (N = {args.N}) ===\n")
        print("Running NFXP-EM ...")
        res_nfxp = em_run(data, "nfxp", n_iters=args.em_iters, verbose=True)
        print(f"\n  -> theta_est = {res_nfxp['theta']},  pi = {res_nfxp['pi']}")
        print(f"  -> wall-clock = {res_nfxp['wall_clock']:.2f} s\n")
        print("Running GFD-EM ...")
        res_gfd = em_run(data, "gfd", n_iters=args.em_iters, verbose=True)
        print(f"\n  -> theta_est = {res_gfd['theta']},  pi = {res_gfd['pi']}")
        print(f"  -> wall-clock = {res_gfd['wall_clock']:.2f} s\n")
        return

    # Replications
    rng_master = np.random.default_rng(args.seed)
    results = {"nfxp": [], "gfd": []}
    for rep in range(args.reps):
        rng = np.random.default_rng(rng_master.integers(0, 2**31))
        data = simulate(args.N, rng)
        for method in ("nfxp", "gfd"):
            res = em_run(data, method, n_iters=args.em_iters, verbose=False)
            results[method].append(res)
        print(f"  rep {rep+1:>3}/{args.reps}: "
              f"NFXP {results['nfxp'][-1]['wall_clock']:.1f}s  "
              f"GFD {results['gfd'][-1]['wall_clock']:.1f}s")

    # Aggregate
    print("\n" + "=" * 78)
    print(f"MC summary: N = {args.N},  reps = {args.reps},  EM iters = {args.em_iters}")
    print("=" * 78)
    print(f"\nTrue theta_1 = {THETA_TRUE[0]}")
    print(f"True theta_2 = {THETA_TRUE[1]}")
    print(f"True pi      = {PI_TRUE}\n")

    for method in ("nfxp", "gfd"):
        theta_arr = np.array([r["theta"] for r in results[method]])    # (R, K, P)
        pi_arr = np.array([r["pi"] for r in results[method]])          # (R, K)
        wc = np.array([r["wall_clock"] for r in results[method]])
        bias_theta = theta_arr.mean(axis=0) - THETA_TRUE
        rmse_theta = np.sqrt(((theta_arr - THETA_TRUE) ** 2).mean(axis=0))
        bias_pi = pi_arr.mean(axis=0) - PI_TRUE
        rmse_pi = np.sqrt(((pi_arr - PI_TRUE) ** 2).mean(axis=0))
        print(f"--- {method.upper()}-EM ---")
        print(f"  theta_1 bias: {bias_theta[0]}")
        print(f"  theta_1 RMSE: {rmse_theta[0]}")
        print(f"  theta_2 bias: {bias_theta[1]}")
        print(f"  theta_2 RMSE: {rmse_theta[1]}")
        print(f"  pi bias:      {bias_pi}")
        print(f"  pi RMSE:      {rmse_pi}")
        print(f"  wall-clock:   mean {wc.mean():.2f}s  std {wc.std():.2f}s")
        print()

    # Wall-clock ratio
    nfxp_wc = np.array([r["wall_clock"] for r in results["nfxp"]]).mean()
    gfd_wc = np.array([r["wall_clock"] for r in results["gfd"]]).mean()
    print(f"Wall-clock ratio NFXP / GFD = {nfxp_wc / gfd_wc:.2f}x")


if __name__ == "__main__":
    main()
