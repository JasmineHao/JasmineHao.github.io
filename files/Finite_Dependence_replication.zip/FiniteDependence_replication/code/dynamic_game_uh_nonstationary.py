"""
dynamic_game_uh_nonstationary.py
================================

Phase 3 main feasibility test: GFD-EM bridge estimator for the
combination targeted in the paper's Table 7 -- multi-agent dynamic
game + latent unobserved heterogeneity + non-stationary finite
horizon.  This is the cell where existing methods (NFXP-EM, NPL-EM,
AM 2011 EM, AM 2019) are not jointly applicable; finite dependence is
the enabling technology.

Setup
-----
* 2-player entry game, 4 states, finite horizon T = 20, terminal
  V = 0.
* K = 2 market types, each with its own structural primitives
  theta^(ell) = (rev^(ell), comp^(ell), entry^(ell)).
* Each type has its own finite-horizon MPE solved by per-period
  backward induction in the truth (DGP).

Two estimators on the same data
-------------------------------
1. NFXP-EM-analog: per-theta_k candidate, run full finite-horizon
   MPE solve (joint best-response iteration with backward induction at
   each iteration).  Slow.
2. GFD-EM bridge: per-theta_k candidate, replace the inner MPE solve
   with a SINGLE backward pass using *empirical* type-conditional CCPs
   from the data as the rival's beliefs.  This is the finite-dependence
   shortcut: no inner equilibrium iteration per theta trial.

We compare wall-clock and parameter recovery.

Why bridge is enabling for this cell
-------------------------------------
NFXP-EM per parameter trial does T-period backward induction within
an inner MPE solver (typically 10-50 iterations of joint best
response).  Cost: O(T * |X| * |D|^2 * inner_iter) per (theta, type).
Bridge replaces inner_iter with 1 (uses empirical rival CCPs directly).
Speedup: factor of inner_iter * (small constants).

In practice, with K types and theta_k_dim parameters, NFXP-EM becomes
intractable for moderate T and |X|; bridge stays tractable.

Validation
----------
* GFD-EM bridge: recovers (pi, theta^(ell), type-conditional CCPs).
* NFXP-EM: recovers same up to wall-clock scaling.
* Wall-clock ratio reported.
"""

from __future__ import annotations

import argparse
import time

import numpy as np
from scipy.optimize import minimize


# =============================================================================
# Setup
# =============================================================================

T_HORIZON = 20
N_PLAYERS = 2
N_ACTIONS = 2
N_STATES = N_ACTIONS ** N_PLAYERS              # 4
BETA = 0.95

# K = 2 market types with distinct revenue parameter
THETA_TRUE = np.array([
    [1.5, 1.5, 0.3],     # type 1: high revenue
    [0.5, 1.5, 0.3],     # type 2: low revenue
])
PI_TRUE = np.array([0.6, 0.4])
K_TYPES = THETA_TRUE.shape[0]


# =============================================================================
# State encoding
# =============================================================================

def x_to_yvec(x: int) -> tuple[int, int]:
    return (x >> 1) & 1, x & 1


def yvec_to_x(y1: int, y2: int) -> int:
    return (y1 << 1) | y2


def payoff(theta: np.ndarray, d_i: int, x: int, i: int) -> float:
    if d_i == 0:
        return 0.0
    y1, y2 = x_to_yvec(x)
    y_self = y1 if i == 0 else y2
    y_other = y2 if i == 0 else y1
    rev, comp, entry = theta
    return rev - comp * y_other - entry * (1 - y_self)


def payoff_vec(theta: np.ndarray, i: int) -> np.ndarray:
    out = np.zeros((N_ACTIONS, N_STATES))
    for d in range(N_ACTIONS):
        for x in range(N_STATES):
            out[d, x] = payoff(theta, d, x, i)
    return out


def perceived_transition(p_other: np.ndarray, i: int) -> np.ndarray:
    F = np.zeros((N_ACTIONS, N_STATES, N_STATES))
    for x in range(N_STATES):
        for d_i in range(N_ACTIONS):
            for d_other in range(N_ACTIONS):
                w = p_other[d_other, x]
                if i == 0:
                    x_next = yvec_to_x(d_i, d_other)
                else:
                    x_next = yvec_to_x(d_other, d_i)
                F[d_i, x, x_next] += w
    return F


# =============================================================================
# Truth: finite-horizon MPE per type via backward induction
# =============================================================================

def backward_induction_i(theta: np.ndarray, p_other_by_t: np.ndarray,
                          i: int, T: int) -> tuple[np.ndarray, np.ndarray]:
    """Player i's best responses given rival's CCPs across time.

    p_other_by_t : (T, D, S) rival CCPs per period.
    Returns (p_i_by_t (T, D, S), V_by_t (T, S))  with V_T = 0.
    """
    u = payoff_vec(theta, i)
    p_i = np.zeros((T, N_ACTIONS, N_STATES))
    V = np.zeros(N_STATES)
    Vs = np.zeros((T, N_STATES))
    for t in range(T - 1, -1, -1):
        F_t = perceived_transition(p_other_by_t[t], i)
        v_t = u + BETA * (F_t * V[None, None, :]).sum(axis=2)
        m = v_t.max(axis=0)
        ev = np.exp(v_t - m)
        p_i[t] = ev / ev.sum(axis=0)
        V = m + np.log(ev.sum(axis=0))
        Vs[t] = V
    return p_i, Vs


def find_finite_horizon_mpe(theta: np.ndarray, T: int,
                             n_iter: int = 300, tol: float = 1e-8
                             ) -> np.ndarray:
    """Iterate joint best-response to convergence.  Returns
    p_by_t : (n_players, T, D, S)."""
    p = np.full((N_PLAYERS, T, N_ACTIONS, N_STATES), 0.5)
    for _ in range(n_iter):
        p_new = np.zeros_like(p)
        for i in range(N_PLAYERS):
            p_new[i], _ = backward_induction_i(theta, p[1 - i], i, T)
        if np.max(np.abs(p_new - p)) < tol:
            return p_new
        p = p_new
    return p


# =============================================================================
# DGP
# =============================================================================

def simulate_mixture(mpes_by_type: list[np.ndarray], pi: np.ndarray,
                     n_markets: int, T: int, rng) -> dict:
    K = len(mpes_by_type)
    types = rng.choice(K, size=n_markets, p=pi)
    decisions = np.zeros((n_markets, T, N_PLAYERS), dtype=int)
    states = np.zeros((n_markets, T + 1), dtype=int)
    states[:, 0] = rng.integers(0, N_STATES, size=n_markets)
    for m in range(n_markets):
        k = types[m]
        p = mpes_by_type[k]                                # (P, T, D, S)
        for t in range(T):
            x = states[m, t]
            d = np.zeros(N_PLAYERS, dtype=int)
            for i in range(N_PLAYERS):
                d[i] = rng.choice(N_ACTIONS, p=p[i, t, :, x])
            decisions[m, t] = d
            states[m, t + 1] = yvec_to_x(d[0], d[1])
    return {"decisions": decisions, "states": states, "types": types,
            "n_markets": n_markets, "T": T}


# =============================================================================
# Empirical CCP anchor per type per period
# =============================================================================

def empirical_ccp_by_type_period(data: dict, posterior: np.ndarray,
                                  laplace: float = 1.0) -> np.ndarray:
    """Posterior-weighted empirical CCPs per type per period per player.

    Returns p : (K, T, P, D, S).
    """
    decisions = data["decisions"]; states = data["states"]
    M, T, _ = decisions.shape
    K = posterior.shape[1]
    counts = np.full((K, T, N_PLAYERS, N_ACTIONS, N_STATES), laplace)
    for m in range(M):
        w = posterior[m]
        for t in range(T):
            x = states[m, t]
            for i in range(N_PLAYERS):
                d_it = decisions[m, t, i]
                counts[:, t, i, d_it, x] += w
    return counts / counts.sum(axis=3, keepdims=True)


# =============================================================================
# GFD-EM bridge M-step: per-theta_k candidate, no inner MPE iteration
# =============================================================================

def predicted_ccps_bridge(theta_k: np.ndarray, p_anchor_k: np.ndarray,
                          T: int) -> np.ndarray:
    """Compute predicted CCPs for both players under theta_k, using the
    EMPIRICAL anchor of the rival's CCPs (no joint best-response
    iteration).

    This is the bridge shortcut: each player's CCPs are best responses
    to the *data-anchored* rival CCPs, computed in a single backward
    pass per player.

    Cost: O(2 players * T * S * D).  No inner MPE iteration.

    p_anchor_k : (P, T, D, S)  type-k anchor CCPs.
    Returns p_pred : (P, T, D, S).
    """
    p_pred = np.zeros_like(p_anchor_k)
    for i in range(N_PLAYERS):
        p_pred[i], _ = backward_induction_i(theta_k, p_anchor_k[1 - i], i, T)
    return p_pred


def neg_log_lik_bridge(theta_k: np.ndarray, data: dict,
                       weights_k: np.ndarray,
                       p_anchor_k: np.ndarray, T: int) -> float:
    """Posterior-weighted neg log-lik at theta_k under bridge prediction."""
    p_pred = predicted_ccps_bridge(theta_k, p_anchor_k, T)
    decisions = data["decisions"]; states = data["states"]
    ll = 0.0
    for t in range(T):
        x_t = states[:, t]
        for i in range(N_PLAYERS):
            d_t = decisions[:, t, i]
            log_p = np.log(p_pred[i, t, d_t, x_t] + 1e-300)
            ll += (weights_k * log_p).sum()
    return -ll


# =============================================================================
# NFXP-EM M-step: full MPE solve per theta candidate
# =============================================================================

def predicted_ccps_nfxp(theta_k: np.ndarray, T: int,
                        warm_start: np.ndarray | None = None,
                        n_iter: int = 50, tol: float = 1e-6) -> np.ndarray:
    """Solve the finite-horizon MPE at theta_k from scratch.  Used in
    the NFXP-EM-style M-step for wall-clock comparison."""
    if warm_start is not None:
        p = warm_start.copy()
    else:
        p = np.full((N_PLAYERS, T, N_ACTIONS, N_STATES), 0.5)
    for _ in range(n_iter):
        p_new = np.zeros_like(p)
        for i in range(N_PLAYERS):
            p_new[i], _ = backward_induction_i(theta_k, p[1 - i], i, T)
        if np.max(np.abs(p_new - p)) < tol:
            return p_new
        p = p_new
    return p


def neg_log_lik_nfxp(theta_k: np.ndarray, data: dict,
                     weights_k: np.ndarray,
                     warm_start: np.ndarray | None, T: int) -> float:
    p_pred = predicted_ccps_nfxp(theta_k, T, warm_start=warm_start)
    decisions = data["decisions"]; states = data["states"]
    ll = 0.0
    for t in range(T):
        x_t = states[:, t]
        for i in range(N_PLAYERS):
            d_t = decisions[:, t, i]
            log_p = np.log(p_pred[i, t, d_t, x_t] + 1e-300)
            ll += (weights_k * log_p).sum()
    return -ll


# =============================================================================
# EM driver
# =============================================================================

def compute_posterior(data: dict, p_by_type: np.ndarray,
                      pi: np.ndarray) -> np.ndarray:
    decisions = data["decisions"]; states = data["states"]
    M, T, _ = decisions.shape
    K = p_by_type.shape[0]
    log_pi = np.log(pi + 1e-300)
    log_lik = np.zeros((M, K))
    for k in range(K):
        for t in range(T):
            x_t = states[:, t]
            for i in range(N_PLAYERS):
                d_t = decisions[:, t, i]
                log_lik[:, k] += np.log(p_by_type[k, i, t, d_t, x_t] + 1e-300)
    log_post = log_lik + log_pi[None, :]
    m = log_post.max(axis=1, keepdims=True)
    post = np.exp(log_post - m)
    return post / post.sum(axis=1, keepdims=True)


def em_run(data: dict, method: str, K: int, T: int,
           theta_init: np.ndarray | None = None,
           n_em_iter: int = 10, verbose: bool = False) -> dict:
    """method in {'bridge', 'nfxp'}."""
    assert method in ("bridge", "nfxp")
    rng = np.random.default_rng(0)
    if theta_init is None:
        theta = THETA_TRUE + rng.normal(0, 0.3, size=THETA_TRUE.shape)
    else:
        theta = theta_init.copy()
    pi = np.full(K, 1.0 / K)
    # Initial CCPs: solve MPE per type at init theta (one-time cost)
    p_by_type = np.stack([find_finite_horizon_mpe(theta[k], T) for k in range(K)])
    # p_by_type shape: (K, P, T, D, S) -> reshape to (K, P, T, D, S)
    # but compute_posterior uses (K, P, T, D, S) indexing  k, i, t, d, x.
    # find_finite_horizon_mpe returns (P, T, D, S).  Stacking gives (K, P, T, D, S).

    ll_traj = []
    t_start = time.time()
    for m_iter in range(n_em_iter):
        # E-step
        posterior = compute_posterior(data, p_by_type, pi)
        pi = posterior.mean(axis=0)

        # M-step: optimise theta_k per type
        if method == "bridge":
            p_anchor = empirical_ccp_by_type_period(data, posterior)
            # p_anchor: (K, T, P, D, S) -> need (K, P, T, D, S) for indexing
            p_anchor = p_anchor.transpose(0, 2, 1, 3, 4)
            for k in range(K):
                res = minimize(
                    lambda th: neg_log_lik_bridge(
                        th, data, posterior[:, k], p_anchor[k], T),
                    theta[k].copy(),
                    method="Nelder-Mead",
                    options={"xatol": 1e-4, "fatol": 1e-4, "maxiter": 150},
                )
                theta[k] = res.x
                p_by_type[k] = predicted_ccps_bridge(
                    theta[k], p_anchor[k], T)
        else:
            for k in range(K):
                warm = p_by_type[k]
                res = minimize(
                    lambda th: neg_log_lik_nfxp(
                        th, data, posterior[:, k], warm, T),
                    theta[k].copy(),
                    method="Nelder-Mead",
                    options={"xatol": 1e-4, "fatol": 1e-4, "maxiter": 150},
                )
                theta[k] = res.x
                p_by_type[k] = predicted_ccps_nfxp(theta[k], T, warm_start=warm)
        # log-lik via posterior
        log_lik_total = 0.0
        for m in range(data["n_markets"]):
            log_p_each = np.zeros(K)
            for k in range(K):
                ll_k = 0.0
                for t in range(T):
                    x_t = data["states"][m, t]
                    for i in range(N_PLAYERS):
                        d_it = data["decisions"][m, t, i]
                        ll_k += np.log(p_by_type[k, i, t, d_it, x_t] + 1e-300)
                log_p_each[k] = np.log(pi[k] + 1e-300) + ll_k
            log_lik_total += np.logaddexp.reduce(log_p_each)
        ll_traj.append(log_lik_total)
        if verbose:
            print(f"  [{method}] iter {m_iter:>2}: "
                  f"theta_1 = {theta[0].round(3)}  "
                  f"theta_2 = {theta[1].round(3)}  "
                  f"pi = {pi.round(3)}  ll = {log_lik_total:.1f}")
    elapsed = time.time() - t_start
    return {"theta": theta, "pi": pi, "p_by_type": p_by_type,
            "posterior": posterior, "ll_traj": ll_traj,
            "wall_clock": elapsed}


def match_to_truth(theta_est: np.ndarray,
                   theta_true: np.ndarray) -> np.ndarray:
    if theta_est.shape[0] != 2:
        return np.arange(theta_est.shape[0])
    identity = np.array([0, 1]); swap = np.array([1, 0])
    err_id = np.linalg.norm(theta_est - theta_true)
    err_sw = np.linalg.norm(theta_est[swap] - theta_true)
    return identity if err_id <= err_sw else swap


# =============================================================================
# Main
# =============================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n_markets", type=int, default=300)
    parser.add_argument("--T", type=int, default=T_HORIZON)
    parser.add_argument("--em_iter", type=int, default=8)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--methods", default="bridge,nfxp",
                        help="comma-separated list of methods")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    methods = args.methods.split(",")
    print("=" * 78)
    print(f"GFD-EM for non-stationary multi-agent game with latent UH")
    print(f"  theta_true[0] = {THETA_TRUE[0]}  (high-revenue)")
    print(f"  theta_true[1] = {THETA_TRUE[1]}  (low-revenue)")
    print(f"  pi_true = {PI_TRUE}")
    print(f"  T = {args.T}, n_markets = {args.n_markets}, K = {K_TYPES}")
    print("=" * 78)

    rng = np.random.default_rng(args.seed)

    print("\n[1] DGP: per-type finite-horizon MPE")
    mpes = [find_finite_horizon_mpe(THETA_TRUE[k], args.T) for k in range(K_TYPES)]
    for k in range(K_TYPES):
        print(f"    Type {k}: player 0 enter probs at t=0, S=[0..3] = "
              f"{mpes[k][0, 0, 1, :].round(3)}")
        print(f"            player 0 enter probs at t=T-1            = "
              f"{mpes[k][0, args.T - 1, 1, :].round(3)}")

    print(f"\n[2] Simulating mixture: pi = {PI_TRUE}")
    data = simulate_mixture(mpes, PI_TRUE, args.n_markets, args.T, rng)
    print(f"    DGP type prevalence: {(np.bincount(data['types']) / args.n_markets).round(3)}")

    results = {}
    for method in methods:
        print(f"\n[3] Running EM with method = {method.upper()}")
        res = em_run(data, method, K_TYPES, args.T,
                     n_em_iter=args.em_iter, verbose=args.verbose)
        results[method] = res
        perm = match_to_truth(res["theta"], THETA_TRUE)
        theta_est = res["theta"][perm]
        pi_est = res["pi"][perm]
        print(f"    theta_est[0] = {theta_est[0].round(3)}  "
              f"bias = {(theta_est[0] - THETA_TRUE[0]).round(3)}")
        print(f"    theta_est[1] = {theta_est[1].round(3)}  "
              f"bias = {(theta_est[1] - THETA_TRUE[1]).round(3)}")
        print(f"    pi_est       = {pi_est.round(3)}  "
              f"bias = {(pi_est - PI_TRUE).round(3)}")
        accuracy = (res["posterior"][:, perm].argmax(axis=1) == data["types"]).mean()
        print(f"    classification accuracy = {accuracy:.3f}")
        print(f"    wall-clock = {res['wall_clock']:.1f}s")

    if "bridge" in results and "nfxp" in results:
        ratio = results["nfxp"]["wall_clock"] / results["bridge"]["wall_clock"]
        print(f"\n[4] NFXP / Bridge wall-clock ratio = {ratio:.1f}x")


if __name__ == "__main__":
    main()
