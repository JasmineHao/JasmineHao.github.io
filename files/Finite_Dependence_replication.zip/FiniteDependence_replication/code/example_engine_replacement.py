"""
Example: Engine Replacement (Rust 1987)
========================================
2 actions: Keep (0), Replace (1)
State: mileage bin (discretized odometer reading)
Memory: Renewal (Replace resets mileage to 0)
Control: Full
Expected: rho=1 (renewal action resets state)

Usage:
    python example_engine_replacement.py
"""

import numpy as np
import time
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from UnifiedFDSolver import UnifiedFDSolver
from HistoryDependentFDSolver import solve_mdp


def build_model():
    beta = 0.95
    n_states = 10  # Mileage bins
    n_actions = 2  # Keep, Replace

    # Keep: mileage increases stochastically
    F_keep = np.zeros((n_states, n_states))
    for i in range(n_states):
        if i < n_states - 2:
            F_keep[i, i] = 0.3
            F_keep[i, i + 1] = 0.5
            F_keep[i, i + 2] = 0.2
        elif i < n_states - 1:
            F_keep[i, i] = 0.3
            F_keep[i, i + 1] = 0.7
        else:
            F_keep[i, i] = 1.0  # Absorbing at max mileage

    # Replace: mileage resets to 0 (renewal action)
    F_replace = np.zeros((n_states, n_states))
    F_replace[:, 0] = 1.0  # All states reset to mileage 0

    F = np.array([F_keep, F_replace])

    # Payoff: cost increases with mileage, replace has fixed cost
    mileage = np.linspace(0, 1, n_states)
    u = np.zeros((n_actions, n_states))
    u[0] = -0.5 * mileage  # Keep: maintenance cost grows
    u[1] = -2.0 * np.ones(n_states)  # Replace: fixed replacement cost

    return F, u, beta, n_states, n_actions


def run():
    F, u, beta, n_states, n_actions = build_model()
    V, v, e = solve_mdp(F, u, beta)

    print(f"Engine Replacement: S={n_states}, A={n_actions}, beta={beta}")
    print(f"  {'rho':>3}  {'case':<28} {'dist':>10} {'payoff_err':>12} {'time':>7}")
    print(f"  {'-'*65}")

    cases = [
        (0, 0, 1, "s0: Keep vs Replace"),
        (3, 0, 1, "s3: Keep vs Replace"),
        (5, 0, 1, "s5: Keep vs Replace"),
        (8, 0, 1, "s8: Keep vs Replace"),
    ]

    for rho in [1]:
        t0 = time.time()
        solver = UnifiedFDSolver(T=F, rho=rho, n_states=n_states, n_actions=n_actions)
        init_time = time.time() - t0
        print(f"  [rho={rho}] Init time: {init_time:.3f}s")

        for s0, k, K, desc in cases:
            true_diff = v[k, s0] - v[K, s0]
            t0 = time.time()
            phi_k, phi_K, dist, ce = solver.solve(s0, k, K)
            solve_time = time.time() - t0
            fd = solver.evaluate_value_difference(phi_k, phi_K, s0, k, K, u, e, beta)
            print(f"  {rho:>3}  {desc:<28} {dist:>10.2e} {abs(fd - true_diff):>12.2e} {solve_time:>6.3f}s")
        print()


if __name__ == "__main__":
    run()
