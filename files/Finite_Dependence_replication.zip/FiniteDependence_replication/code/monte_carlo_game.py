"""
Monte Carlo Simulation for Dynamic Entry/Exit Game
===================================================

3-player entry/exit game with strategic interactions.
Each player's effective transition integrates out opponents' equilibrium strategies.
GFD uses rho=2 (strategic ripple requires two periods).

Usage:
    python monte_carlo_game.py --quick   # 10 reps, quick test
    python monte_carlo_game.py           # full 1000 reps
"""

import numpy as np
import time
from scipy.optimize import minimize
import sys, os, argparse
sys.path.insert(0, os.path.dirname(__file__))
from UnifiedFDSolver import UnifiedFDSolver
from utils import (
    solve_game_equilibrium, compute_ftran_game,
    compute_dpi_dtheta_game, compute_e, my_meshgrid,
)
from itertools import product as iterproduct

# ============================================================================
# Model
# ============================================================================

N_PLAYERS = 3
BETA = 0.9
THETA_TRUE = [
    [1.0, 1.0, 1.0, 1.0],   # Player 0
    [1.0, 1.0, 1.0, 0.9],   # Player 1
    [1.0, 1.0, 1.0, 0.8],   # Player 2
]

_S_GRID_3 = np.array([2, 6, 10])
_F_S_3 = np.array([
    [0.8, 0.2, 0.0],
    [0.0, 0.6, 0.4],
    [0.0, 0.2, 0.8],
])
_S_GRID_5 = np.array([2, 4, 6, 8, 10])
_F_S_5 = np.array([
    [0.8, 0.2, 0.0, 0.0, 0.0],
    [0.1, 0.6, 0.3, 0.0, 0.0],
    [0.0, 0.2, 0.6, 0.2, 0.0],
    [0.0, 0.0, 0.3, 0.6, 0.1],
    [0.0, 0.0, 0.0, 0.2, 0.8],
])
# 10-level market-size grid: stresses the exogenous-state scaling of NFXP
# (whose Bellman re-solve grows as |X_i|^3) while leaving GFD's flow QP
# essentially unchanged in iteration count.
_S_GRID_10 = np.linspace(1, 12, 10)
def _tauchen_band(n, persistence=0.7):
    """Banded persistent transition: prob persistence on diagonal, rest
    spread to neighbours."""
    F = np.zeros((n, n))
    spread = (1.0 - persistence) / 2.0
    for i in range(n):
        F[i, i] = persistence
        if i - 1 >= 0:
            F[i, i-1] = spread
        if i + 1 < n:
            F[i, i+1] = spread
        # Fix boundary mass
        F[i] /= F[i].sum()
    return F
_F_S_10 = _tauchen_band(10, persistence=0.7)
# Default state space; switched at runtime via --big-state flag
S_SPACE = _S_GRID_3.copy()
F_S = _F_S_3.copy()
A_SPACE = np.array([0, 1])


def set_state_space(level: str = 'small'):
    """Set the market-size grid.

    level='small' → |X_i|=24 (3 market sizes)
    level='big' or True → |X_i|=40 (5 market sizes)
    level='xl' → |X_i|=80 (10 market sizes; stresses NFXP scaling)
    """
    global S_SPACE, F_S
    if level == 'xl':
        S_SPACE = _S_GRID_10.copy()
        F_S = _F_S_10.copy()
    elif level == 'big' or level is True:
        S_SPACE = _S_GRID_5.copy()
        F_S = _F_S_5.copy()
    else:
        S_SPACE = _S_GRID_3.copy()
        F_S = _F_S_3.copy()


def build_game_model(theta=None):
    """Build game model and solve MPE."""
    if theta is None:
        theta = THETA_TRUE
    state = my_meshgrid([S_SPACE] + [A_SPACE] * N_PLAYERS)
    P_eq, V_eq = solve_game_equilibrium(state, theta, F_S, [BETA]*N_PLAYERS)
    Ftran = compute_ftran_game(P_eq, F_S, state, N_PLAYERS)
    dpi = compute_dpi_dtheta_game(state, N_PLAYERS, P_eq)
    return state, P_eq, V_eq, Ftran, dpi


def simulate_game_data(N, T, state, P_eq, Ftran, player=0, seed=None):
    """Simulate panel data for one player. Returns arrays, not dicts."""
    if seed is not None:
        np.random.seed(seed)

    S = Ftran[player].shape[1]
    A = 2
    F_p = Ftran[player]
    P_p = P_eq[player]  # (A, S) from solve_game_equilibrium

    states = np.zeros(N * T, dtype=int)
    actions = np.zeros(N * T, dtype=int)
    idx = 0
    for i in range(N):
        s = np.random.choice(S)
        for t in range(T):
            a = np.random.choice(A, p=P_p[s, :])
            states[idx] = s
            actions[idx] = a
            s = np.random.choice(S, p=F_p[a, s, :])
            idx += 1
    return states, actions


def estimate_ccps_game(states, actions, S, A=2):
    """Estimate CCPs from data. Returns (S, A)."""
    counts = np.zeros((S, A))
    for s, a in zip(states, actions):
        counts[s, a] += 1
    counts += 0.1
    return counts / counts.sum(axis=1, keepdims=True)


# ============================================================================
# Solver cache: in MC, the same F_p (perceived MPE transitions) is used
# across all reps, so the canonical-input UnifiedFDSolver and its cached
# A_aug can be reused.  Key on F_p.tobytes() so the cache is content-addressed.
# ============================================================================

_SOLVER_CACHE = {}

def _get_cached_solver(F_p, rho, S, A):
    key = (F_p.shape, F_p.tobytes(), rho, S, A)
    s = _SOLVER_CACHE.get(key)
    if s is None:
        s = UnifiedFDSolver(T=F_p, rho=rho, n_states=S, n_actions=A)
        _SOLVER_CACHE[key] = s
    return s


# ============================================================================
# GFD Estimator (rho=2)
# ============================================================================

def estimate_GFD_game(states, actions, F_p, S, beta, player, dpi, P_eq):
    """GFD estimator for one player in the game (rho=2).

    Implementation note. The flow-QP at rho=2 is heavily rank-deficient
    (the augmented matrix has rank ~2300 against ~4600 columns for S=24,
    A=2), so the pseudoinverse-based batched solve used for the rho=1
    investment model returns a different (and much larger-norm) point in
    the optimum set than per-state penalised LSQR with implicit
    early-stopping regularisation. We therefore keep the per-state
    LSQR loop here. The dphi -> dphi_coeff aggregation is, however,
    fully vectorised via einsum.
    """
    start_time = time.time()
    A = 2
    rho = 2

    P_hat = estimate_ccps_game(states, actions, S, A)  # (S, A)
    e_hat = compute_e(P_hat.T)  # compute_e wants (A,S), returns (A,S)

    K_ref = 1

    # Solve flow variables at rho=2.  Constraint+objective matrix A_aug is
    # the same for every initial state AND for every MC replication (F_p
    # comes from the equilibrium that does not change across reps), so we
    # cache both the solver and A_aug on a module-level dict keyed by F_p.
    solver = _get_cached_solver(F_p, rho, S, A)
    n_j = solver.n_j
    n_k = solver.n_k
    # solve_all_states_diff_standard exploits that we only need
    # Δφ = φ_k − φ_K and halves the LSMR problem size.  tol=1e-6
    # is the empirical sweet spot: theta_GFD agrees to 3 decimals
    # with the tol=1e-8 reference, at ~13x lower LSMR iterations
    # (consistency-for-any-FD-input result of Section sec:gfd_def
    # absorbs the residual tolerance variation in the asymptotic
    # variance without affecting the probability limit).
    dphi_all = solver.solve_all_states_diff_standard(0, K_ref, tol=1e-6)

    # Vectorised dphi_coeff[x0, at, jt]:
    #   dphi_coeff[x0, at, jt] = sum_{tau} beta^{tau+1} *
    #       sum_{ji, ki} dphi[x0, ji, ki] *
    #           I{j_arr[ji, tau] == jt} * I{k_arr[ki, tau] == at}
    j_arr = solver.j_arr  # (n_j, rho)
    k_arr = solver.k_arr  # (n_k, rho)
    M_j = (j_arr[:, :, None] == np.arange(S)[None, None, :]).astype(float)
    M_k = (k_arr[:, :, None] == np.arange(A)[None, None, :]).astype(float)
    beta_pow = beta ** (np.arange(rho) + 1)         # (rho,)
    M_j_w = M_j * beta_pow[None, :, None]           # discount absorbed
    dphi_coeff = np.einsum('xjk, jtJ, ktA -> xAJ',
                            dphi_all, M_j_w, M_k)

    # Select observations where a != K_ref
    mask = actions != K_ref
    obs_s = states[mask]

    def gmm_objective(theta_vec):
        u_p = np.zeros((A, S))
        u_p[1] = dpi[player, 1] @ theta_vec
        u_p[0] = dpi[player, 0] @ theta_vec
        hat_u = u_p + e_hat  # (A, S)

        # For each x0: fd_diff = u(0,x0)-u(1,x0) + sum_{a,j} dphi_coeff[x0,a,j]*hat_u[a,j]
        fd_per_state = np.zeros(S)
        for x0 in range(S):
            fd_per_state[x0] = u_p[0, x0] - u_p[K_ref, x0]
            fd_per_state[x0] += np.sum(dphi_coeff[x0] * hat_u)

        log_odds = np.log(P_hat[:, 0] + 1e-10) - np.log(P_hat[:, K_ref] + 1e-10)  # (S,)
        residuals = fd_per_state[obs_s] - log_odds[obs_s]
        return np.sum(residuals**2)

    theta0 = np.array([1.0, 1.0, 1.0, 1.0])
    result = minimize(gmm_objective, theta0, method='Nelder-Mead',
                     options={'maxiter': 500, 'xatol': 1e-4})

    elapsed = time.time() - start_time
    return result.x, elapsed


# ============================================================================
# NPL Estimator (Aguirregabiria-Mira 2007)
# ============================================================================

def estimate_NPL_game(states, actions, F_p, S, beta, player, dpi, state, P_eq):
    """
    Nested Pseudo-Likelihood (Aguirregabiria-Mira 2007).
    Iterates: (1) estimate theta given CCPs, (2) update CCPs given theta.
    """
    start_time = time.time()
    A = 2

    P_hat = estimate_ccps_game(states, actions, S, A)  # (S, A)

    # Precompute log-likelihood indexing
    obs_s = states
    obs_a = actions

    for npl_iter in range(20):
        e_hat = compute_e(P_hat.T)  # (A, S)

        def neg_pseudo_ll(theta_vec):
            u_p = np.zeros((A, S))
            u_p[1] = dpi[player, 1] @ theta_vec
            u_p[0] = dpi[player, 0] @ theta_vec

            F_bar = sum(P_hat[:, a:a+1] * F_p[a] for a in range(A))
            flow = sum(P_hat[:, a] * (u_p[a, :] + e_hat[a, :]) for a in range(A))
            try:
                V_hat = np.linalg.solve(np.eye(S) - beta * F_bar, flow)
            except np.linalg.LinAlgError:
                return 1e10

            v_hat = np.zeros((S, A))
            for a in range(A):
                v_hat[:, a] = u_p[a, :] + beta * F_p[a] @ V_hat

            v_max = v_hat.max(axis=1, keepdims=True)
            exp_v = np.exp(v_hat - v_max)
            P_theta = exp_v / exp_v.sum(axis=1, keepdims=True)

            # Vectorized log-likelihood
            ll = np.sum(np.log(P_theta[obs_s, obs_a] + 1e-10))
            return -ll

        theta0 = np.array([1.0, 1.0, 1.0, 1.0])
        result = minimize(neg_pseudo_ll, theta0, method='Nelder-Mead',
                         options={'maxiter': 200, 'xatol': 1e-3, 'fatol': 1e-4})
        theta_est = result.x

        # Update CCPs
        u_p = np.zeros((A, S))
        u_p[1] = dpi[player, 1] @ theta_est
        u_p[0] = dpi[player, 0] @ theta_est

        F_bar = sum(P_hat[:, a:a+1] * F_p[a] for a in range(A))
        flow = sum(P_hat[:, a] * (u_p[a, :] + e_hat[a, :]) for a in range(A))
        try:
            V_hat = np.linalg.solve(np.eye(S) - beta * F_bar, flow)
        except np.linalg.LinAlgError:
            break

        v_hat = np.zeros((S, A))
        for a in range(A):
            v_hat[:, a] = u_p[a, :] + beta * F_p[a] @ V_hat

        v_max = v_hat.max(axis=1, keepdims=True)
        exp_v = np.exp(v_hat - v_max)
        P_new = exp_v / exp_v.sum(axis=1, keepdims=True)

        if np.max(np.abs(P_new - P_hat)) < 1e-6:
            break
        P_hat = P_new

    elapsed = time.time() - start_time
    return theta_est, elapsed


# ============================================================================
# Hotz-Miller CCP-2step (one-pass, no NPL outer iteration)
# ============================================================================

def estimate_HM_game(states, actions, F_p, S, beta, player, dpi, state, P_eq):
    """
    Hotz-Miller two-step CCP estimator for one player in the game.

    Same inner step as NPL but with NO outer CCP update loop: the
    nonparametric first-stage CCPs are used once to build the Hotz-Miller
    value function V(theta), and a single Newton/Nelder-Mead minimization
    on the pseudo log-likelihood returns theta.  This is the games analogue
    of the single-agent CCP-2step in Hotz-Miller (1993).
    """
    start_time = time.time()
    A = 2

    P_hat = estimate_ccps_game(states, actions, S, A)  # (S, A)
    e_hat = compute_e(P_hat.T)                          # (A, S)
    obs_s = states
    obs_a = actions

    def neg_pseudo_ll(theta_vec):
        u_p = np.zeros((A, S))
        u_p[1] = dpi[player, 1] @ theta_vec
        u_p[0] = dpi[player, 0] @ theta_vec

        F_bar = sum(P_hat[:, a:a+1] * F_p[a] for a in range(A))
        flow  = sum(P_hat[:, a] * (u_p[a, :] + e_hat[a, :]) for a in range(A))
        try:
            V_hat = np.linalg.solve(np.eye(S) - beta * F_bar, flow)
        except np.linalg.LinAlgError:
            return 1e10

        v_hat = np.zeros((S, A))
        for a in range(A):
            v_hat[:, a] = u_p[a, :] + beta * F_p[a] @ V_hat

        v_max = v_hat.max(axis=1, keepdims=True)
        exp_v = np.exp(v_hat - v_max)
        P_theta = exp_v / exp_v.sum(axis=1, keepdims=True)
        ll = np.sum(np.log(P_theta[obs_s, obs_a] + 1e-10))
        return -ll

    theta0 = np.array([1.0, 1.0, 1.0, 1.0])
    result = minimize(neg_pseudo_ll, theta0, method='Nelder-Mead',
                      options={'maxiter': 200, 'xatol': 1e-3, 'fatol': 1e-4})
    return result.x, time.time() - start_time


# ============================================================================
# NFXP Estimator (full nested fixed point: re-solve MPE at every theta trial)
# ============================================================================

import contextlib, io as _io


def estimate_NFXP_game(obs_s, obs_a, state, F_S, player, theta_others_truth):
    """
    Nested Fixed-Point estimator for one player in the game.

    At every candidate theta_player, this routine re-solves the full MPE
    via solve_game_equilibrium (a Gauss-Seidel best-response iteration over
    all N_PLAYERS, typically 100-200 iterations to convergence). The
    resulting equilibrium CCP profile is used to evaluate the player-specific
    log-likelihood. theta values for the other players are held fixed at
    their true values (the standard NFXP convention when only one player's
    parameters are estimated).

    This is the "honest" Bellman-fixed-point benchmark: every parameter
    trial pays the cost of solving the equilibrium fixed point. Wall-clock
    time is therefore dominated by the MPE solver inside the optimizer.
    """
    start_time = time.time()
    _devnull = _io.StringIO()  # swallow solve_game_equilibrium's prints

    def neg_loglik(theta_vec):
        theta_list = [list(t) for t in theta_others_truth]
        theta_list[player] = list(theta_vec)
        try:
            with contextlib.redirect_stdout(_devnull):
                P_eq_t, _ = solve_game_equilibrium(
                    state, theta_list, F_S, [BETA] * len(theta_list)
                )
        except Exception:
            return 1e10
        P_player = P_eq_t[player]            # (S, A)
        ll = np.sum(np.log(P_player[obs_s, obs_a] + 1e-10))
        return -ll

    theta0 = np.array([1.0, 1.0, 1.0, 1.0])
    result = minimize(
        neg_loglik, theta0, method='Nelder-Mead',
        options={'maxiter': 200, 'xatol': 1e-3, 'fatol': 1e-3},
    )
    elapsed = time.time() - start_time
    return result.x, elapsed


# ============================================================================
# Monte Carlo
# ============================================================================

def _dump_results(results, path):
    """Write a CSV with one row per (rep, method): bias/time/theta."""
    import csv
    methods = sorted({m for r in results for m in r.keys()})
    with open(path, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['rep', 'method', 'theta1', 'theta2', 'theta3', 'theta4', 'time_s'])
        for i, r in enumerate(results):
            for m in methods:
                if m not in r:
                    continue
                th = r[m]['theta']
                w.writerow([i, m, *[f"{x:.6f}" for x in th], f"{r[m]['time']:.4f}"])


def run_single_rep(r, N, T, state, P_eq, V_eq, Ftran, dpi, player=0,
                   gfd_only=False, include_nfxp=False, F_S_for_nfxp=None,
                   theta_others_truth=None):
    """One MC replication for one player."""
    S = Ftran[player].shape[1]
    obs_s, obs_a = simulate_game_data(N, T, state, P_eq, Ftran, player, seed=r)

    results = {}

    # GFD
    theta_gfd, time_gfd = estimate_GFD_game(
        obs_s, obs_a, Ftran[player], S, BETA, player, dpi, P_eq)
    results['GFD'] = {'theta': theta_gfd, 'time': time_gfd}

    # Hotz-Miller CCP-2step (one-pass, no iteration)
    if not gfd_only:
        theta_hm, time_hm = estimate_HM_game(
            obs_s, obs_a, Ftran[player], S, BETA, player, dpi, state, P_eq)
        results['HM'] = {'theta': theta_hm, 'time': time_hm}

    # NPL (Aguirregabiria-Mira 2007)
    if not gfd_only:
        theta_npl, time_npl = estimate_NPL_game(
            obs_s, obs_a, Ftran[player], S, BETA, player, dpi, state, P_eq)
        results['NPL'] = {'theta': theta_npl, 'time': time_npl}

    # NFXP (full nested fixed point: re-solve MPE per parameter trial)
    if include_nfxp:
        theta_nfxp, time_nfxp = estimate_NFXP_game(
            obs_s, obs_a, state, F_S_for_nfxp, player, theta_others_truth)
        results['NFXP'] = {'theta': theta_nfxp, 'time': time_nfxp}

    return results


def run_monte_carlo(n_reps=1000, sample_sizes=None, player=0, gfd_only=False,
                    include_nfxp=False, save_path=None):
    if sample_sizes is None:
        sample_sizes = [(2000, 20)]

    print("Building game model and solving MPE...", flush=True)
    state, P_eq, V_eq, Ftran, dpi = build_game_model()
    S = Ftran[player].shape[1]
    theta_true = np.array(THETA_TRUE[player])

    print(f"Player {player}, S={S}, A=2, rho=2", flush=True)
    print(f"True theta = {theta_true}", flush=True)

    for N, T in sample_sizes:
        print(f"\n{'='*60}")
        print(f"N={N}, T={T}, {n_reps} replications")
        if gfd_only:
            print("(GFD only — skipping NFXP)")
        if include_nfxp:
            print("(Including NFXP — slow, re-solves MPE per parameter trial)")
        print(f"{'='*60}", flush=True)

        results = []
        for r in range(n_reps):
            if (r+1) % 5 == 0 or r == 0:
                print(f"  Rep {r+1}/{n_reps}...", flush=True)
            res = run_single_rep(
                r, N, T, state, P_eq, V_eq, Ftran, dpi, player, gfd_only,
                include_nfxp=include_nfxp,
                F_S_for_nfxp=F_S, theta_others_truth=THETA_TRUE,
            )
            results.append(res)
            # Checkpoint every 20 reps so a long run can be analyzed mid-stream
            if save_path is not None and (r+1) % 20 == 0:
                _dump_results(results, save_path)
        if save_path is not None:
            _dump_results(results, save_path)

        # Statistics
        methods = ['GFD']
        if not gfd_only:
            methods.extend(['HM', 'NPL'])
        if include_nfxp:
            methods.append('NFXP')
        for method in methods:
            thetas = np.array([r[method]['theta'] for r in results])
            times = np.array([r[method]['time'] for r in results])
            bias = thetas.mean(axis=0) - theta_true
            rmse = np.sqrt(((thetas - theta_true)**2).mean(axis=0))
            print(f"\n  {method}:")
            print(f"    Bias: {bias}")
            print(f"    RMSE: {rmse}")
            print(f"    Avg time: {times.mean():.3f}s")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--quick', action='store_true', help='10 reps only')
    parser.add_argument('--gfd-only', action='store_true', help='Skip HM/NPL')
    parser.add_argument('--nfxp', action='store_true',
                        help='Also run NFXP (full MPE re-solve per theta trial; slow)')
    parser.add_argument('--big-state', action='store_true',
                        help='Use 5-level market size grid (|X_i|=40) instead of default 3-level (|X_i|=24)')
    parser.add_argument('--xl-state', action='store_true',
                        help='Use 10-level market size grid (|X_i|=80; stresses NFXP scaling)')
    parser.add_argument('--N', type=int, default=None,
                        help='Override sample size N (default: 2000)')
    parser.add_argument('--T', type=int, default=None,
                        help='Override time periods T (default: 20)')
    parser.add_argument('--reps', type=int, default=None,
                        help='Override replication count (default: 1000 full, 10 quick)')
    parser.add_argument('--save', type=str, default=None,
                        help='CSV path to dump per-rep, per-method results (checkpointed)')
    args = parser.parse_args()

    if args.xl_state:
        set_state_space('xl')
    elif args.big_state:
        set_state_space('big')
    else:
        set_state_space('small')
    if args.reps is not None:
        n_reps = args.reps
    else:
        n_reps = 10 if args.quick else 1000
    if args.N is not None or args.T is not None:
        sample_sizes = [(args.N or 2000, args.T or 20)]
    else:
        sample_sizes = [(500, 10)] if args.quick else [(2000, 20)]

    run_monte_carlo(n_reps=n_reps, sample_sizes=sample_sizes,
                    gfd_only=args.gfd_only, include_nfxp=args.nfxp,
                    save_path=args.save)
