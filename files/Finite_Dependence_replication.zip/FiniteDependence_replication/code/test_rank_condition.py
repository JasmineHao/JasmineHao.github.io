"""
Test the Controllability Rank Condition across all 10 examples.

The rank test (Corollary in the paper):
  C_1 = B, where B collects transition differences Delta_j^T for all j
  C_rho = [C_{rho-1} | F[0]^T C_{rho-1} | ... | F[A-1]^T C_{rho-1}]
  If rank(C_rho) = S, then rho-period FD holds for ALL states and action pairs.

Usage:
    python test_rank_condition.py
"""

import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from utils import state_transition, my_kron


def compute_controllability_matrix(F, rho, K=None):
    """
    Compute the controllability matrix C_rho.

    B collects Delta_j^T for all states j, where
    Delta_j = [F[a,j,:] - F[K,j,:]] for a != K.

    C_1 = B
    C_tau = [C_{tau-1} | F[0]^T C_{tau-1} | ... | F[A-1]^T C_{tau-1}]
    """
    A, S, _ = F.shape
    if K is None:
        K = A - 1

    # B: collect Delta_j^T columns for all j and all a != K
    # Delta_j^T is a column vector (S x 1): (F[a,j,:] - F[K,j,:])^T
    B_cols = []
    for j in range(S):
        for a in range(A):
            if a == K:
                continue
            diff = F[a, j, :] - F[K, j, :]  # (S,) = one column of Delta_j^T
            B_cols.append(diff)

    B = np.column_stack(B_cols)  # S x (S*(A-1))

    C = B.copy()
    for tau in range(1, rho):
        new_blocks = []
        for a in range(A):
            new_blocks.append(F[a].T @ C)
        C = np.column_stack([C] + new_blocks)

    return C, np.linalg.matrix_rank(C, tol=1e-8)


# ============================================================================
# Build all 10 models (just transition matrices)
# ============================================================================

def build_engine_replacement():
    S, A = 10, 2
    F_keep = np.zeros((S, S))
    for i in range(S):
        if i < S - 2:
            F_keep[i, i] = 0.3; F_keep[i, i+1] = 0.5; F_keep[i, i+2] = 0.2
        elif i < S - 1:
            F_keep[i, i] = 0.3; F_keep[i, i+1] = 0.7
        else:
            F_keep[i, i] = 1.0
    F_replace = np.zeros((S, S))
    F_replace[:, 0] = 1.0
    return np.array([F_keep, F_replace]), S, A, "Engine Replacement", 1


def build_job_search():
    n_status, n_wage = 2, 5
    f_wage, _ = state_transition(0.5, 0.3, 1.0, n_wage)
    F_reject = np.array([[1.0, 0.0], [1.0, 0.0]])  # status -> unemployed
    F_accept = np.array([[0.0, 1.0], [0.0, 1.0]])  # status -> employed
    F = np.array([my_kron([F_reject, f_wage]), my_kron([F_accept, f_wage])])
    return F, n_status * n_wage, 2, "Job Search", 1


def build_labor_p1():
    # Shift register p=1: state = l_{t-1}, action sets l_t
    n_labor = 2
    F_nowork = np.zeros((n_labor, n_labor))
    F_nowork[:, 0] = 1.0  # next state = 0 regardless
    F_work = np.zeros((n_labor, n_labor))
    F_work[:, 1] = 1.0  # next state = 1 regardless
    return np.array([F_nowork, F_work]), n_labor, 2, "Female Labor (p=1)", 1


def build_investment():
    ngrid_k = 5
    f_o, _ = state_transition(0, 0.5, 1.5, 4, min_val=0, max_val=2)
    f_k = []
    for shift in [-1, 0, 1]:  # depreciate, maintain, invest
        m = np.zeros((ngrid_k, ngrid_k))
        for i in range(ngrid_k):
            m[i, max(0, min(ngrid_k-1, i+shift))] = 1.0
        f_k.append(m)
    F = np.array([my_kron([f_k[a], f_o]) for a in range(3)])
    return F, ngrid_k * 4, 3, "Investment", 1


def build_inventory():
    ngrid_inv = 5
    f_d, _ = state_transition(0, 0.5, 1.5, 4, min_val=0, max_val=2)
    f_inv = []
    for shift in [-1, 0, 1]:  # deplete, maintain, restock
        m = np.zeros((ngrid_inv, ngrid_inv))
        for i in range(ngrid_inv):
            m[i, max(0, min(ngrid_inv-1, i+shift))] = 1.0
        f_inv.append(m)
    F = np.array([my_kron([f_inv[a], f_d]) for a in range(3)])
    return F, ngrid_inv * 4, 3, "Inventory Control", 1


def build_entry_exit():
    F_exit_m = np.array([[1.0, 0.0], [1.0, 0.0]])
    F_enter_m = np.array([[0.0, 1.0], [0.0, 1.0]])
    # Action-dependent productivity (triple connector)
    f_o_out, _ = state_transition(0, 0.3, 2.0, 4, min_val=0.5, max_val=3.5)
    f_o_in, _ = state_transition(0.8, 0.3, 2.0, 4, min_val=0.5, max_val=3.5)
    f_z, _ = state_transition(0.9, 1.0, 0.0, 2, min_val=-2, max_val=2)
    F = np.array([
        my_kron([F_exit_m, f_o_out, f_z]),
        my_kron([F_enter_m, f_o_in, f_z])
    ])
    return F, 2 * 4 * 2, 2, "Entry/Exit (Endo)", 2


def build_altug_miller():
    """p=3 lag shift register (deterministic)."""
    p = 3
    n_hours = 2
    S = n_hours ** p
    A = n_hours
    F = np.zeros((A, S, S))
    for a in range(A):
        for s in range(S):
            # state = (l_{t-3}, l_{t-2}, l_{t-1}) in base n_hours
            bits = []
            tmp = s
            for _ in range(p):
                bits.append(tmp % n_hours)
                tmp //= n_hours
            bits.reverse()  # [l_{t-3}, l_{t-2}, l_{t-1}]
            # shift: new state = (l_{t-2}, l_{t-1}, a)
            new_bits = bits[1:] + [a]
            s_new = sum(b * (n_hours ** (p - 1 - i)) for i, b in enumerate(new_bits))
            F[a, s, s_new] = 1.0
    return F, S, A, "Altug-Miller (p=3)", 3


def build_education():
    """p=4 lag shift register."""
    p = 4
    S = 2 ** p
    A = 2
    F = np.zeros((A, S, S))
    for a in range(A):
        for s in range(S):
            bits = [(s >> (p - 1 - i)) & 1 for i in range(p)]
            new_bits = bits[1:] + [a]
            s_new = sum(b << (p - 1 - i) for i, b in enumerate(new_bits))
            F[a, s, s_new] = 1.0
    return F, S, A, "Education (p=4)", 4


def build_game():
    """3-player entry/exit game - simplified effective transition for player 1."""
    n_market = 3
    f_market = np.array([[0.7, 0.2, 0.1], [0.2, 0.6, 0.2], [0.1, 0.2, 0.7]])
    # Player status transitions
    F_exit = np.array([[1.0, 0.0], [1.0, 0.0]])
    F_enter = np.array([[0.0, 1.0], [0.0, 1.0]])
    # Opponents: each has 50/50 CCP, independent
    n_opp_each = 2
    p_opp = 0.5
    f_opp_single = np.array([[1-p_opp, p_opp], [1-p_opp, p_opp]])
    f_opp = my_kron([f_opp_single, f_opp_single])  # 4x4 for 2 opponents
    F = np.array([
        my_kron([F_exit, f_opp, f_market]),
        my_kron([F_enter, f_opp, f_market])
    ])
    return F, 2 * 4 * 3, 2, "Entry/Exit Game", 2


def build_oligopoly():
    """2-firm dynamic oligopoly with action-dependent transitions."""
    n_prod = 4
    f1_no, _ = state_transition(0.8, 0.3, 2.0, n_prod)
    f1_inv, _ = state_transition(0.8, 0.3, 2.5, n_prod)
    f2, _ = state_transition(0.8, 0.3, 2.0, n_prod)
    S = n_prod * n_prod
    F = np.zeros((2, S, S))
    for s in range(S):
        w1, w2 = s // n_prod, s % n_prod
        for sn in range(S):
            w1n, w2n = sn // n_prod, sn % n_prod
            F[0, s, sn] = f1_no[w1, w1n] * f2[w2, w2n]
            F[1, s, sn] = f1_inv[w1, w1n] * f2[w2, w2n]
    return F, S, 2, "Dynamic Oligopoly", 2


# ============================================================================
# Endogenous-only builders (strip exogenous component from Kronecker models)
# ============================================================================

def build_investment_endo():
    ngrid_k = 5
    f_k = []
    for shift in [-1, 0, 1]:
        m = np.zeros((ngrid_k, ngrid_k))
        for i in range(ngrid_k): m[i, max(0, min(ngrid_k-1, i+shift))] = 1.0
        f_k.append(m)
    return np.array(f_k), ngrid_k, 3

def build_inventory_endo():
    ngrid = 5
    f = []
    for shift in [-1, 0, 1]:
        m = np.zeros((ngrid, ngrid))
        for i in range(ngrid): m[i, max(0, min(ngrid-1, i+shift))] = 1.0
        f.append(m)
    return np.array(f), ngrid, 3

def build_job_search_endo():
    F_reject = np.array([[1.0, 0.0], [1.0, 0.0]])
    F_accept = np.array([[0.0, 1.0], [0.0, 1.0]])
    return np.array([F_reject, F_accept]), 2, 2

def build_entry_exit_endo():
    # Endogenous = market status only (but triple connector means exo matters too)
    F_exit = np.array([[1.0, 0.0], [1.0, 0.0]])
    F_enter = np.array([[0.0, 1.0], [0.0, 1.0]])
    return np.array([F_exit, F_enter]), 2, 2

def build_game_endo():
    # Player 1's own status
    F_exit = np.array([[1.0, 0.0], [1.0, 0.0]])
    F_enter = np.array([[0.0, 1.0], [0.0, 1.0]])
    return np.array([F_exit, F_enter]), 2, 2

def build_oligopoly_endo():
    # Firm 1's own productivity only
    n_prod = 4
    f1_no, _ = state_transition(0.8, 0.3, 2.0, n_prod)
    f1_inv, _ = state_transition(0.8, 0.3, 2.5, n_prod)
    return np.array([f1_no, f1_inv]), n_prod, 2


# ============================================================================
# Main
# ============================================================================

if __name__ == "__main__":
    builders = [
        build_engine_replacement,
        build_job_search,
        build_labor_p1,
        build_investment,
        build_inventory,
        build_entry_exit,
        build_altug_miller,
        build_education,
        build_game,
        build_oligopoly,
    ]

    # --- Endogenous-only rank test for Kronecker models ---
    print("\n" + "=" * 80)
    print("Endogenous-only rank test (for Kronecker models F[d] = F_endo[d] x F_exo)")
    print("=" * 80)

    endo_models = [
        ("Investment (endo)", build_investment_endo, 1),
        ("Inventory (endo)", build_inventory_endo, 1),
        ("Job Search (endo)", build_job_search_endo, 1),
        ("Entry/Exit (endo only)", build_entry_exit_endo, 2),
        ("Game (endo)", build_game_endo, 2),
        ("Oligopoly (endo)", build_oligopoly_endo, 2),
    ]

    print(f"{'Model':<25} {'S':>4} {'S-1':>4} {'A':>3} {'Pred':>5}", end="")
    for rho in range(1, 6):
        print(f" {'r(C'+str(rho)+')':>7}", end="")
    print(f"  {'rank=S-1':>9}  {'OK?':>4}")
    print("-" * 100)

    for name, build_fn, pred_rho in endo_models:
        try:
            F_endo, S_endo, A = build_fn()
        except Exception as ex:
            print(f"  ERROR: {ex}")
            continue
        for a in range(A):
            rs = F_endo[a].sum(axis=1, keepdims=True)
            rs[rs == 0] = 1
            F_endo[a] /= rs
        target = S_endo - 1
        print(f"{name:<25} {S_endo:>4} {target:>4} {A:>3} {pred_rho:>5}", end="")
        min_rho = None
        for rho in range(1, 6):
            C, r = compute_controllability_matrix(F_endo, rho, K=A-1)
            print(f" {r:>7}", end="")
            if r >= target and min_rho is None:
                min_rho = rho
        if min_rho is not None:
            match = "YES" if min_rho <= pred_rho else "no"
            print(f"  {'rho='+str(min_rho):>9}  {match:>4}")
        else:
            print(f"  {'> 5':>9}  {'FAIL':>4}")

    print()

    # Note: since F[a,j,:] - F[K,j,:] sums to 0, all columns of B lie in the
    # (S-1)-dimensional subspace orthogonal to 1. So the effective target rank
    # is S-1 (the probability simplex has dimension S-1).

    print(f"{'Model':<25} {'S':>4} {'S-1':>4} {'A':>3} {'Pred':>5}", end="")
    for rho in range(1, 6):
        print(f" {'r(C'+str(rho)+')':>7}", end="")
    print(f"  {'rank=S-1':>9}  {'OK?':>4}")
    print("-" * 100)

    for build_fn in builders:
        try:
            F, S, A, name, pred_rho = build_fn()
        except Exception as ex:
            print(f"  ERROR building {build_fn.__name__}: {ex}")
            continue

        # Normalize
        for a in range(A):
            rs = F[a].sum(axis=1, keepdims=True)
            rs[rs == 0] = 1
            F[a] /= rs

        target = S - 1  # effective dimension (probability simplex)

        print(f"{name:<25} {S:>4} {target:>4} {A:>3} {pred_rho:>5}", end="")

        min_rho = None
        for rho in range(1, 6):
            C, r = compute_controllability_matrix(F, rho, K=A-1)
            print(f" {r:>7}", end="")
            if r >= target and min_rho is None:
                min_rho = rho

        if min_rho is not None:
            match = "YES" if min_rho <= pred_rho else "no"
            print(f"  {'rho='+str(min_rho):>9}  {match:>4}")
        else:
            print(f"  {'> 5':>9}  {'FAIL':>4}")
