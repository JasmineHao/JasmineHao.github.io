"""
Example: Entry/Exit Model with Endogenous Productivity
========================================================
2 actions: Exit/Stay Out (0), Enter/Stay In (1)
State: market_status x productivity x Z_lags
Memory: Nilpotent (Shift), Control: Weak, Topology: Triple Connector
Expected: rho=2 (action affects both state and shock distribution)

Usage:
    python example_entry_exit.py          # Quick demo (rho=1 only)
    python example_entry_exit.py --full   # Full test (rho=1,2)
"""

import numpy as np
import time
import sys, os
import argparse
sys.path.insert(0, os.path.dirname(__file__))
from UnifiedFDSolver import UnifiedFDSolver
from HistoryDependentFDSolver import solve_mdp
from utils import state_transition, my_kron, my_meshgrid


def build_model():
    beta = 0.95

    # Market status transition (deterministic)
    f_x_0 = np.array([[1, 0], [1, 0]])  # Exit -> Out
    f_x_1 = np.array([[0, 1], [0, 1]])  # Enter -> In

    # Productivity (ACTION-DEPENDENT = Triple Connector)
    ngrid_o = 4
    f_o_0, o_grid = state_transition(0, 0.3, 2, ngrid_o, min_val=0, max_val=1)
    f_o_1, _ = state_transition(1, 0.3, 2, ngrid_o, min_val=0, max_val=1)

    # Z shock
    ngrid_z = 2
    f_z, z_grid = state_transition(0, 0.9, 1, ngrid_z)

    F = np.array([my_kron([f_x_0, f_o_0, f_z]),
                  my_kron([f_x_1, f_o_1, f_z])])
    n_states = F.shape[1]

    # Payoff
    state = my_meshgrid([np.array([0, 1]), o_grid, z_grid])
    u = np.zeros((2, n_states))
    u[0] = 0.5 * state[:, 1] - 0.5                          # Exit
    u[1] = 1.0 * state[:, 1] - 1.0 - 1.0 * (1 - state[:, 0])  # Enter (+ entry cost if out)

    return F, u, beta, n_states, 2


def run(full=False):
    F, u, beta, n_states, n_actions = build_model()
    V, v, e = solve_mdp(F, u, beta)

    print(f"Entry/Exit Model: S={n_states}, A={n_actions}, beta={beta}")
    print(f"  {'rho':>3}  {'case':<28} {'dist':>10} {'payoff_err':>12} {'time':>7}")
    print(f"  {'-'*65}")

    cases = [(s, 0, 1, f"s{s}: Exit vs Enter") for s in [0, 4, 8, 12]]

    rhos = [1, 2] if full else [1]
    
    for rho in rhos:
        if rho == 2:
            print(f"  [rho={rho}] Building solver (this may take 10-30s due to NAC constraints)...")
        else:
            print(f"  [rho={rho}] Building solver...")
        t0 = time.time()
        solver = UnifiedFDSolver(T=F, rho=rho, n_states=n_states, n_actions=n_actions)
        init_time = time.time() - t0
        print(f"          Init time: {init_time:.3f}s")
        
        for s0, k, K, desc in cases:
            true_diff = v[k, s0] - v[K, s0]
            t0 = time.time()
            phi_k, phi_K, dist, ce = solver.solve(s0, k, K)
            solve_time = time.time() - t0
            fd = solver.evaluate_value_difference(phi_k, phi_K, s0, k, K, u, e, beta)
            print(f"  {rho:>3}  {desc:<28} {dist:>10.2e} {abs(fd - true_diff):>12.2e} {solve_time:>6.3f}s")
        print()
    
    if not full:
        print("  (Skipping rho=2. Use --full flag to enable)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Entry/Exit Model Example')
    parser.add_argument('--full', action='store_true', 
                        help='Run full test including rho=2 (slow, may take minutes)')
    args = parser.parse_args()
    run(full=args.full)
