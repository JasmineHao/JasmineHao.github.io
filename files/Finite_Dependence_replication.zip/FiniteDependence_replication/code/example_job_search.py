"""
Example: Job Search Model
==========================
2 actions: Reject (0), Accept (1)
State: employment_status x wage_offer
Memory: Renewal (Accept resets to employed state)
Control: Full
Expected: rho=1 (renewal action resets employment status)

Usage:
    python example_job_search.py
"""

import numpy as np
import time
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from UnifiedFDSolver import UnifiedFDSolver
from HistoryDependentFDSolver import solve_mdp


def build_model():
    beta = 0.95
    n_wage = 5  # Wage offer levels
    n_status = 2  # 0=unemployed, 1=employed
    n_states = n_status * n_wage  # 10
    n_actions = 2  # Reject, Accept

    wage_grid = np.linspace(0.5, 2.5, n_wage)

    # Wage offer transitions (exogenous)
    F_wage = np.zeros((n_wage, n_wage))
    for i in range(n_wage):
        for j in range(n_wage):
            F_wage[i, j] = np.exp(-0.5 * (i - j)**2)
        F_wage[i] /= F_wage[i].sum()

    F = np.zeros((n_actions, n_states, n_states))

    for a in range(n_actions):
        for s_status in range(n_status):
            for s_wage in range(n_wage):
                s = s_status * n_wage + s_wage
                for w_next in range(n_wage):
                    if a == 0:  # Reject: stay/become unemployed
                        s_next = 0 * n_wage + w_next  # status=0
                    else:  # Accept: become employed (renewal)
                        s_next = 1 * n_wage + w_next  # status=1
                    F[a, s, s_next] += F_wage[s_wage, w_next]

    # Payoff
    u = np.zeros((n_actions, n_states))
    for s_status in range(n_status):
        for s_wage in range(n_wage):
            s = s_status * n_wage + s_wage
            if s_status == 1:  # Employed
                u[0, s] = wage_grid[s_wage]  # Reject (quit): get current wage then unemployed
                u[1, s] = wage_grid[s_wage]  # Accept (stay): get current wage
            else:  # Unemployed
                u[0, s] = 0.3  # Reject: unemployment benefit
                u[1, s] = wage_grid[s_wage] - 0.2  # Accept: wage minus search cost

    return F, u, beta, n_states, n_actions


def run():
    F, u, beta, n_states, n_actions = build_model()
    V, v, e = solve_mdp(F, u, beta)

    print(f"Job Search: S={n_states}, A={n_actions}, beta={beta}")
    print(f"  {'rho':>3}  {'case':<28} {'dist':>10} {'payoff_err':>12} {'time':>7}")
    print(f"  {'-'*65}")

    cases = [
        (0, 0, 1, "s0(unemp,low): Rej vs Acc"),
        (2, 0, 1, "s2(unemp,mid): Rej vs Acc"),
        (5, 0, 1, "s5(emp,low): Rej vs Acc"),
        (7, 0, 1, "s7(emp,mid): Rej vs Acc"),
    ]

    for rho in [1]:
        t0 = time.time()
        solver = UnifiedFDSolver(T=F, rho=rho, n_states=n_states, n_actions=n_actions)
        init_time = time.time() - t0
        print(f"  [rho={rho}] Init time: {init_time:.3f}s")

        for s0, k, K, desc in cases:
            true_diff = v[k, s0] - v[K, s0]
            t0 = time.time()
            phi_k, phi_K, dist, ce = solver.solve(s0, k, K)
            solve_time = time.time() - t0
            fd = solver.evaluate_value_difference(phi_k, phi_K, s0, k, K, u, e, beta)
            print(f"  {rho:>3}  {desc:<28} {dist:>10.2e} {abs(fd - true_diff):>12.2e} {solve_time:>6.3f}s")
        print()


if __name__ == "__main__":
    run()
