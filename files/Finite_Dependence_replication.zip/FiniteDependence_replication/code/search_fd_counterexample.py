"""
search_fd_counterexample.py
===========================

Search for an explicit DDC model that:

  (i)  fails Type R (no renewal action: no F[a] with row-equal rows)
  (ii) fails Type S (transition is not deterministic shift-register)
  (iii) fails Type K (no non-trivial Kronecker factorization with
        action-invariant exogenous factor)
  (iv) satisfies Theorem 1's range condition  b in Range(A)  at rho = 2
       (universally, i.e. at every (s0, k, K) pair).

If such a model exists, it certifies that Theorem 1 strictly generalizes
the union of AM 2007 (Type R), AM-Klein 2002 (Type S), and AM 2019
(Type K) sufficient conditions.

Design choices to streamline the failure-of-prior-conditions checks:

  * S = 5 (prime).  The only Kronecker factorizations of dim-5 are
    1x5 and 5x1, both of which give trivial/degenerate Type K
    (action-invariance or no exo factor) -- so any non-action-invariant
    F automatically fails Type K.
  * Random F with all entries in (0, 1) (no zeros), normalized rows.
    Non-deterministic by construction -> Type S fails automatically.
  * Reject if any action a has F[a, j, :] = F[a, j', :] for all j, j'
    (rank-one rows) -> Type R fails by rejection.
  * Run Theorem 1 universal check at rho = 1 (should fail) and rho = 2
    (must succeed for counterexample to be valid).

Run:
    python code/search_fd_counterexample.py
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
from fd_linear_system import fd_holds_universal, fd_holds


# =============================================================================
# Algebraic predicates for Type R / S / K
# =============================================================================

def is_type_R(F: np.ndarray, tol: float = 1e-10) -> tuple[bool, int | None]:
    """Type R (AM 2007): exists action K with F[K, j, :] independent of j.

    Returns (is_type_R, renewal_action_index_or_None).
    """
    A_, S, _ = F.shape
    for a in range(A_):
        rows = F[a]                          # (S, S)
        # Check whether all rows equal row 0
        if np.allclose(rows, rows[0][None, :], atol=tol):
            return True, a
    return False, None


def is_type_S(F: np.ndarray, tol: float = 1e-10) -> tuple[bool, str]:
    """Type S (AM-Klein 2002): deterministic shift-register over p lags.

    Necessary conditions:
      (a) F is deterministic (each F[a, j, :] is a unit vector).
      (b) The state space size S is a perfect power of some
          alphabet size Z >= 2: S = Z^p for some integer p >= 1.
      (c) There exists an injection sigma: A -> Z such that
          F[a, (z_1,...,z_p), :] puts mass 1 on (z_2,...,z_p, sigma(a)).

    Returns (is_type_S, reason_string).
    """
    A_, S, _ = F.shape

    # (a) determinism
    is_det = True
    for a in range(A_):
        for j in range(S):
            row = F[a, j]
            # row must be a unit vector: one entry ~1, rest ~0
            if not np.isclose(row.sum(), 1.0, atol=tol):
                is_det = False; break
            if not (np.isclose(row.max(), 1.0, atol=tol)
                    and np.isclose(row.min(), 0.0, atol=tol)):
                is_det = False; break
        if not is_det:
            break

    if not is_det:
        return False, "F is non-deterministic; Type S requires deterministic shift"

    # (b) S = Z^p for some Z >= max(2, A_)
    candidates = []
    for Z in range(max(2, A_), S + 1):
        p = 1
        prod = Z
        while prod < S:
            prod *= Z; p += 1
        if prod == S:
            candidates.append((Z, p))
    if not candidates:
        return False, f"S={S} is not Z^p for any Z >= max(2, A)={max(2, A_)}"

    # (c) try each (Z, p) with each injection sigma: A -> Z
    from itertools import permutations
    for Z, p in candidates:
        # state j  <->  (z_1, ..., z_p)  via base-Z big-endian
        def decode(j):
            digits = []
            for _ in range(p):
                digits.append(j % Z); j //= Z
            digits.reverse()
            return tuple(digits)
        def encode(digits):
            j = 0
            for d in digits:
                j = j * Z + d
            return j

        # next-state map under action a from state j
        next_of = np.zeros((A_, S), dtype=int)
        for a in range(A_):
            for j in range(S):
                next_of[a, j] = int(np.argmax(F[a, j]))

        # For each injection sigma : A -> {0,...,Z-1}, check the shift law
        for sigma in permutations(range(Z), A_):
            ok = True
            for a in range(A_):
                for j in range(S):
                    z = decode(j)
                    expected = z[1:] + (sigma[a],)
                    if next_of[a, j] != encode(expected):
                        ok = False; break
                if not ok:
                    break
            if ok:
                return True, f"Type S with Z={Z}, p={p}, sigma={sigma}"

    return False, "No (Z, p, sigma) realises shift-register law"


def is_type_K(F: np.ndarray, tol: float = 1e-8) -> tuple[bool, str]:
    """Type K (AM 2019): F[a] = F_endo[a] kron F_exo with F_exo action-invariant
    and the exo factor of dimension >= 2 (so the cancellation has bite).

    Tries every factorization S = m * n with n >= 2 and tests whether each
    F[a] block-decomposes Kronecker-style with a common right factor.
    """
    A_, S, _ = F.shape

    # Enumerate factorizations
    divisors = [n for n in range(2, S + 1) if S % n == 0 and n < S]
    if not divisors:
        return False, (f"S={S} has no non-trivial divisor >= 2 with quotient >= 2; "
                       "no non-degenerate Kronecker decomposition exists")

    # For each (m, n) with m * n = S, try to factor F[a] = F_endo[a] kron F_exo.
    # If F[a] = G_a kron H with H mxm... wait we want F[a] of shape SxS=mn x mn.
    # Convention: F[a] = G_a (m x m) kron H (n x n), so F[a][(i,k),(j,l)] = G_a[i,j] H[k,l].
    # We test: for each a, the (S/n, S/n) "block sums" reveal G_a and inner blocks all
    # are scaled copies of a single H.
    for n in divisors:
        m = S // n
        # Reshape each F[a] into (m, n, m, n)
        reshape_ok = True
        endo_blocks = []   # G_a[i,j] = scale factor
        exo_block = None   # H (n x n)
        for a in range(A_):
            arr = F[a].reshape(m, n, m, n)
            # arr[i,k,j,l] should equal G_a[i,j] * H[k,l].
            G_a = np.zeros((m, m))
            H_candidate = None
            consistent = True
            for i in range(m):
                for j in range(m):
                    block = arr[i, :, j, :]   # (n, n)
                    # Determine G_a[i, j] and corresponding H
                    s = block.sum()
                    if abs(s) < tol:
                        G_a[i, j] = 0.0
                        continue
                    # block must be a scalar multiple of H
                    # candidate H from this block: block / G  for some G
                    # Use Frobenius normalisation: pick G = sum(block) / sum(H_ref)
                    # but H is unknown; just record block / |block|_F  as a candidate.
                    if H_candidate is None:
                        H_candidate = block / s     # sum-normalised
                        G_a[i, j] = s
                    else:
                        # block should equal G * H_candidate for some scalar G
                        # i.e. block = (block.sum()) * H_candidate  iff H_candidate * sum equals block.
                        # Check: block / s ~= H_candidate.
                        if not np.allclose(block / s, H_candidate, atol=tol):
                            consistent = False; break
                        G_a[i, j] = s
                if not consistent:
                    break
            if not consistent or H_candidate is None:
                reshape_ok = False; break
            endo_blocks.append((G_a, H_candidate))

        if not reshape_ok:
            continue

        # Check that H is identical (up to tol) across all actions
        H_ref = endo_blocks[0][1]
        all_H_match = all(np.allclose(eb[1], H_ref, atol=tol) for eb in endo_blocks)
        if not all_H_match:
            continue

        return True, f"Type K with m={m}, n={n}"

    return False, "No (m, n) factorization yields F[a] = G_a kron H with action-invariant H"


# =============================================================================
# Counterexample search
# =============================================================================

def random_F(S: int, A_: int, rng: np.random.Generator,
             dirichlet_alpha: float = 1.0) -> np.ndarray:
    """Draw a random transition tensor F[a, j, :] ~ Dirichlet(alpha, ..., alpha)
    independently for each (a, j).  All entries strictly positive in (0, 1).
    """
    F = rng.dirichlet([dirichlet_alpha] * S, size=(A_, S))
    return F


def random_F_constrained_rank1(S: int, A_: int, rng: np.random.Generator,
                               dirichlet_alpha: float = 1.0,
                               noise_scale: float = 0.0) -> np.ndarray:
    """Draw a random F[K, j, :] for reference action K = A_-1, then construct
    F[a, j, :] = F[K, j, :] + c_{a, j} * delta_a  with delta_a a fixed S-vector
    (summing to zero) and c_{a, j} scalars in [-1, 1].  This forces all column
    differences F[a, j, :] - F[K, j, :] to lie in the (A_-1)-dimensional span
    of {delta_a : a < A_-1}, so rank(B) <= A_-1 < S-1 generically and
    rho=1 universal FD fails.

    Then add small dense noise scaled by noise_scale to avoid Type K
    accidental factorization (irrelevant for S prime).

    All entries are clipped/projected onto the simplex; if any negative entry
    survives the projection (rare for small c), the draw is rejected.
    """
    K = A_ - 1

    # Reference action's transitions: each row Dirichlet
    F = rng.dirichlet([dirichlet_alpha] * S, size=(A_, S))   # start with full random

    # Fix the reference action
    F_K = F[K].copy()

    # Generate A_-1 fixed direction vectors, each summing to 0
    deltas = []
    for _ in range(A_ - 1):
        d = rng.standard_normal(S)
        d = d - d.mean()              # ensure sum to zero
        d = d / (np.linalg.norm(d) + 1e-12)
        deltas.append(d)
    deltas = np.stack(deltas, axis=0)   # (A_-1, S)

    # For each non-reference action a, set F[a, j, :] = F_K[j, :] + c_{a, j} * delta_a
    # Compute exact feasible range for c so that F_K[j] + c*d stays in [0, 1]^S.
    #   For d[k] > 0: c in [-F_K[j,k]/d[k],  (1-F_K[j,k])/d[k]]
    #   For d[k] < 0: c in [(1-F_K[j,k])/d[k],  -F_K[j,k]/d[k]]
    #   For d[k] = 0: no constraint.
    for a in range(A_ - 1):
        d = deltas[a]
        for j in range(S):
            fkj = F_K[j]
            up = np.full(S, np.inf)
            lo = np.full(S, -np.inf)
            pos = d > 0
            neg = d < 0
            if pos.any():
                up[pos] = (1.0 - fkj[pos]) / d[pos]
                lo[pos] = (-fkj[pos]) / d[pos]
            if neg.any():
                up[neg] = (-fkj[neg]) / d[neg]            # both numerator and denom flip
                lo[neg] = (1.0 - fkj[neg]) / d[neg]
            c_upper = up.min()
            c_lower = lo.max()
            # Pick c interior to [c_lower, c_upper], leave 5% safety margin
            margin = 0.05 * (c_upper - c_lower)
            c = rng.uniform(c_lower + margin, c_upper - margin)
            F[a, j, :] = fkj + c * d

    # Renormalise (should already sum to 1, but guard against fp drift)
    for a in range(A_):
        rs = F[a].sum(axis=1, keepdims=True)
        rs[rs == 0] = 1
        F[a] = F[a] / rs

    return F


def evaluate(F: np.ndarray, K_ref: int | None = None, tol_residual: float = 1e-7):
    """Return a dict of all predicate results for a single F."""
    A_, S, _ = F.shape
    if K_ref is None:
        K_ref = A_ - 1

    typeR, K_idx = is_type_R(F)
    typeS, reasonS = is_type_S(F)
    typeK, reasonK = is_type_K(F)

    rho1_ok, rho1_resid, _ = fd_holds_universal(F, rho=1, K=K_ref, tol=tol_residual)
    rho2_ok, rho2_resid, _ = fd_holds_universal(F, rho=2, K=K_ref, tol=tol_residual)

    return {
        "S": int(S),
        "A": int(A_),
        "Type_R": bool(typeR),
        "Type_R_action": K_idx,
        "Type_S": bool(typeS),
        "Type_S_reason": reasonS,
        "Type_K": bool(typeK),
        "Type_K_reason": reasonK,
        "rho1_FD": bool(rho1_ok),
        "rho1_residual": float(rho1_resid),
        "rho2_FD": bool(rho2_ok),
        "rho2_residual": float(rho2_resid),
    }


def search(n_trials: int = 200, S: int = 5, A_: int = 3, seed: int = 0,
           verbose: bool = False, generator: str = "random",
           require_rho1_fail: bool = True) -> tuple[np.ndarray | None, dict | None, list]:
    """Search for a random F satisfying the counterexample criteria.

    Parameters
    ----------
    generator : "random" or "rank1_delta"
        "random"      : i.i.d. Dirichlet rows; ρ=1 generically holds for S>=3.
        "rank1_delta" : action differences forced into (A-1)-dim subspace; ρ=1
                        generically fails (good for the "ρ=2-needed" counterexample).
    require_rho1_fail : if True, demand rho1 universal FD to fail.

    Returns (F_winner, eval_dict_winner, history) where history collects the
    eval dicts of the first few attempts for diagnostic logging.
    """
    rng = np.random.default_rng(seed)
    history = []
    winner = None
    winner_eval = None

    for trial in range(n_trials):
        if generator == "random":
            F = random_F(S, A_, rng, dirichlet_alpha=1.0)
        elif generator == "rank1_delta":
            F = random_F_constrained_rank1(S, A_, rng, dirichlet_alpha=1.0)
        else:
            raise ValueError(f"Unknown generator: {generator}")
        ev = evaluate(F)
        if trial < 5 or verbose:
            history.append({"trial": trial, **ev})

        # Counterexample criteria
        cond_classical_all_fail = (not ev["Type_R"]
                                   and not ev["Type_S"]
                                   and not ev["Type_K"])
        cond_rho1 = (not ev["rho1_FD"]) if require_rho1_fail else True
        cond_rho2 = ev["rho2_FD"]

        if cond_classical_all_fail and cond_rho1 and cond_rho2:
            winner = F
            winner_eval = {"trial": trial, **ev}
            history.append({"trial": trial, "STATUS": "WINNER", **ev})
            break

    return winner, winner_eval, history


# =============================================================================
# Reporting
# =============================================================================

def print_F_pretty(F: np.ndarray, fmt: str = "{:7.4f}") -> str:
    """Format F[a] matrices for inclusion in paper / log."""
    A_, S, _ = F.shape
    out_lines = []
    for a in range(A_):
        out_lines.append(f"F[{a}] =")
        for j in range(S):
            row = " ".join(fmt.format(F[a, j, k]) for k in range(S))
            out_lines.append("  [" + row + "]")
        out_lines.append("")
    return "\n".join(out_lines)


def print_pointwise_residuals(F: np.ndarray, rho: int, K: int) -> str:
    """Per-(s0, k) residuals at given rho."""
    A_, S, _ = F.shape
    lines = [f"Pointwise residuals at rho={rho}, K (reference) = {K}:"]
    lines.append(f"  {'s0':>3} {'k':>3}    residual")
    for s0 in range(S):
        for k in range(A_):
            if k == K:
                continue
            ok, r, _ = fd_holds(F, s0, k, K, rho)
            mark = "  OK" if ok else "  ** FAIL **"
            lines.append(f"  {s0:>3} {k:>3}   {r:.3e}{mark}")
    return "\n".join(lines)


# =============================================================================
# Main
# =============================================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--trials", type=int, default=200)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--S", type=int, default=5)
    parser.add_argument("--A", type=int, default=3)
    parser.add_argument("--out", type=str,
                        default=str(Path(__file__).resolve().parent.parent
                                    / "data" / "fd_counterexample.json"))
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--generator", choices=["random", "rank1_delta"],
                        default="random",
                        help="random = i.i.d. Dirichlet; rank1_delta = forced rho1 failure")
    parser.add_argument("--require_rho1_fail", action="store_true",
                        help="require rho=1 universal FD to fail (drama version)")
    args = parser.parse_args()

    print("=" * 78)
    print("Searching for a Theorem 1 strict-nesting counterexample")
    print(f"  S = {args.S}, A = {args.A}, max trials = {args.trials}, seed = {args.seed}")
    print("  Reject if Type R / Type S / Type K holds, or rho=2 FD fails")
    print("=" * 78)

    F_win, ev_win, history = search(n_trials=args.trials, S=args.S, A_=args.A,
                                    seed=args.seed, verbose=args.verbose,
                                    generator=args.generator,
                                    require_rho1_fail=args.require_rho1_fail)

    print("\nFirst few attempts:")
    for h in history[:6]:
        print(f"  trial {h['trial']:>3}: "
              f"Type_R={h['Type_R']} Type_S={h['Type_S']} Type_K={h['Type_K']} "
              f"rho1={h['rho1_FD']} (resid {h['rho1_residual']:.2e}) "
              f"rho2={h['rho2_FD']} (resid {h['rho2_residual']:.2e})")

    if F_win is None:
        print("\nNo counterexample found in given trials. Try increasing --trials or"
              " adjusting S, A.")
        sys.exit(1)

    print(f"\n=== COUNTEREXAMPLE FOUND at trial {ev_win['trial']} ===\n")
    print(f"S = {ev_win['S']}, A = {ev_win['A']}")
    print(f"  Type R: {ev_win['Type_R']}")
    print(f"  Type S: {ev_win['Type_S']}  ({ev_win['Type_S_reason']})")
    print(f"  Type K: {ev_win['Type_K']}  ({ev_win['Type_K_reason']})")
    print(f"  rho=1 universal FD: {ev_win['rho1_FD']} "
          f"(residual {ev_win['rho1_residual']:.3e})")
    print(f"  rho=2 universal FD: {ev_win['rho2_FD']} "
          f"(residual {ev_win['rho2_residual']:.3e})\n")
    print("Transition matrices:\n")
    print(print_F_pretty(F_win))
    print()
    print(print_pointwise_residuals(F_win, rho=1, K=args.A - 1))
    print()
    print(print_pointwise_residuals(F_win, rho=2, K=args.A - 1))

    # Persist
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    payload = {
        "metadata": {
            "S": int(args.S), "A": int(args.A), "seed": int(args.seed),
            "trials_used": int(ev_win['trial']) + 1,
        },
        "predicates": {
            "Type_R": ev_win["Type_R"], "Type_S": ev_win["Type_S"],
            "Type_K": ev_win["Type_K"],
            "Type_S_reason": ev_win["Type_S_reason"],
            "Type_K_reason": ev_win["Type_K_reason"],
        },
        "FD_universal_test": {
            "rho1_FD": ev_win["rho1_FD"], "rho1_residual": ev_win["rho1_residual"],
            "rho2_FD": ev_win["rho2_FD"], "rho2_residual": ev_win["rho2_residual"],
        },
        "F": F_win.tolist(),
    }
    with open(args.out, "w") as fp:
        json.dump(payload, fp, indent=2)
    print(f"\nSaved counterexample to {args.out}")
