"""
Example: Female Labor Supply with 1 Lag
=========================================
2 actions: Not Work (0), Work (1)
State: labor_history (l_{t-1}) -- single lag
Memory: Nilpotent (Shift Register, lag p=1)
Control: Input-Only
Expected: rho=1 (shift register with p=1 flushes in 1 step)

Usage:
    python example_labor_p1.py
"""

import numpy as np
import time
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from UnifiedFDSolver import UnifiedFDSolver
from HistoryDependentFDSolver import solve_mdp


def build_model():
    beta = 0.95
    n_hours = 2  # Binary: {0=not work, 1=work}
    n_lags = 1
    n_states = n_hours ** n_lags  # 2^1 = 2
    n_actions = n_hours  # 2

    # Transition: deterministic shift register
    # State 0 = last period not work, State 1 = last period work
    # Action 0 (not work) -> state 0, Action 1 (work) -> state 1
    F = np.zeros((n_actions, n_states, n_states))
    F[0, :, 0] = 1.0  # Not work -> state 0
    F[1, :, 1] = 1.0  # Work -> state 1

    # Payoff: work pays wage that depends on experience
    u = np.zeros((n_actions, n_states))
    u[0, 0] = 0.0   # Not work, no experience
    u[0, 1] = 0.0   # Not work, had experience
    u[1, 0] = 0.8   # Work, no experience: lower wage
    u[1, 1] = 1.2   # Work, had experience: higher wage

    return F, u, beta, n_states, n_actions


def run():
    F, u, beta, n_states, n_actions = build_model()
    V, v, e = solve_mdp(F, u, beta)

    print(f"Female Labor (p=1): S={n_states}, A={n_actions}, beta={beta}")
    print(f"  {'rho':>3}  {'case':<28} {'dist':>10} {'payoff_err':>12} {'time':>7}")
    print(f"  {'-'*65}")

    cases = [
        (0, 0, 1, "s0(no exp): NoWork vs Work"),
        (0, 1, 0, "s0(no exp): Work vs NoWork"),
        (1, 0, 1, "s1(exp): NoWork vs Work"),
        (1, 1, 0, "s1(exp): Work vs NoWork"),
    ]

    for rho in [1]:
        t0 = time.time()
        solver = UnifiedFDSolver(T=F, rho=rho, n_states=n_states, n_actions=n_actions)
        init_time = time.time() - t0
        print(f"  [rho={rho}] Init time: {init_time:.3f}s")

        for s0, k, K, desc in cases:
            true_diff = v[k, s0] - v[K, s0]
            t0 = time.time()
            phi_k, phi_K, dist, ce = solver.solve(s0, k, K)
            solve_time = time.time() - t0
            fd = solver.evaluate_value_difference(phi_k, phi_K, s0, k, K, u, e, beta)
            print(f"  {rho:>3}  {desc:<28} {dist:>10.2e} {abs(fd - true_diff):>12.2e} {solve_time:>6.3f}s")
        print()


if __name__ == "__main__":
    run()
