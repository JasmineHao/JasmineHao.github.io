"""
UnifiedFDSolver.py - Unified Finite Dependence Solver (Flow Parameterization)
==============================================================================

Uses flow variables instead of pure weights. The decision variable phi_{j,k}
represents the joint probability of reaching history j AND taking actions k:

    phi_{j,k} = P(path j,k) * omega(k|j)

This absorbs the path probability into the weight, so the terminal distribution
objective becomes simply: kappa(x') = sum_{j,k} phi_{j,k} * f(x'|j_rho, k_rho)

Constraints enforce flow conservation (consistency across time steps) rather
than normalization-to-1.

Constraints:
1. Initial flow: For each j1, sum over all suffixes gives f(j1|x0, d0)
2. Flow conservation: For each prefix (j1,...,j_tau, k1,...,k_tau) and j_{tau+1},
   the marginal flow through (prefix, j_{tau+1}) equals the marginal flow through
   (prefix) times f(j_{tau+1} | j_tau, k_tau).

Integrates two solving approaches:
1. Standard Solver: For general MDP models (full state space)
2. Structured Solver: For models with separable endo/exo states (optimized)

Author: Unified framework based on OptimalFDSolver and StructuredSolver
Date: 2026-02-12
"""

import numpy as np
import scipy.sparse as sps
import scipy.sparse.linalg as spsla
from itertools import product
from scipy.special import logsumexp


class UnifiedFDSolver:
    """
    Unified Finite Dependence Solver with flow parameterization.

    The flow variable phi_{j,k} represents Pr(reach history j) * omega(actions k | j).
    This absorbs path probabilities, so the objective needs no separate P matrix.

    Constraints:
    - Initial flow: marginal of phi at tau=1 equals the arrival probability f(j1|x0,d0)
    - Flow conservation: at each step, the conditional on the next state must match
      the transition probability

    Modes:
    - 'standard': Full state space solver (for general models)
    - 'structured': Decomposed state solver (for endo/exo separable models)

    Usage:
        # Standard mode
        solver = UnifiedFDSolver(T=T_full, rho=2, n_states=S, n_actions=A)

        # Structured mode (automatic when T_endo and T_exo provided)
        solver = UnifiedFDSolver(T_endo=T_endo, T_exo=T_exo, rho=2)
    """

    def __init__(self, T=None, rho=1, n_states=None, n_actions=None,
                 T_endo=None, T_exo=None):
        """
        Initialize unified solver

        Args:
            T: Full transition matrix (A, S, S) - for standard mode
            rho: Memory horizon
            n_states: Number of states - for standard mode
            n_actions: Number of actions - for standard mode
            T_endo: Endogenous transition (A, M, M) - for structured mode
            T_exo: Exogenous transition (Z, Z) - for structured mode
        """
        self.rho = rho

        # Determine mode
        if T_endo is not None and T_exo is not None:
            self.mode = 'structured'
            self._init_structured(T_endo, T_exo)
        elif T is not None:
            self.mode = 'standard'
            self._init_standard(T, n_states, n_actions)
        else:
            raise ValueError("Must provide either T or (T_endo, T_exo)")

    def _init_standard(self, T, n_states, n_actions):
        """Initialize standard solver (full state space)"""
        self.T = T
        self.S = n_states
        self.A = n_actions

        # Generate sequences as numpy arrays for vectorized operations
        self.j_seqs = list(product(range(self.S), repeat=self.rho))
        self.k_seqs = list(product(range(self.A), repeat=self.rho))
        self.n_j = len(self.j_seqs)
        self.n_k = len(self.k_seqs)
        self.j_arr = np.array(self.j_seqs)  # (n_j, rho)
        self.k_arr = np.array(self.k_seqs)  # (n_k, rho)
        self.n_vars_half = self.n_j * self.n_k
        self.n_vars = 2 * self.n_vars_half

        # Cache for flow conservation constraints (independent of init_s)
        self._flow_conservation_cache = None

        print(f"[Standard Mode] S={self.S}, A={self.A}, rho={self.rho}")
        print(f"  State sequences: {self.n_j}, Action sequences: {self.n_k}")

    def _init_structured(self, T_endo, T_exo):
        """Initialize structured solver (endo/exo decomposition)"""
        self.T_endo = T_endo
        self.T_exo = T_exo

        self.A = T_endo.shape[0]
        self.M = T_endo.shape[1]  # Endogenous states
        self.Z = T_exo.shape[0]    # Exogenous states
        self.S = self.M * self.Z   # Full state space

        # Generate sequences (only for endogenous states)
        self.m_seqs = list(product(range(self.M), repeat=self.rho))
        self.k_seqs = list(product(range(self.A), repeat=self.rho))
        self.n_m = len(self.m_seqs)
        self.n_k = len(self.k_seqs)
        self.n_vars_half = self.n_m * self.n_k
        self.n_vars = 2 * self.n_vars_half

        # Cache for flow conservation constraints
        self._flow_conservation_cache_structured = None

        print(f"[Structured Mode] M={self.M} (endo), Z={self.Z} (exo), A={self.A}, rho={self.rho}")
        print(f"  Endo sequences: {self.n_m}, Action sequences: {self.n_k}")
        print(f"  State space reduction: {self.S} -> {self.M} (solving only on endogenous)")

    def solve(self, init_s=None, k_init=None, K_init=None,
              m_init=None, reg=1e-10):
        """
        Solve for optimal phi_k and phi_K (flow variables)

        Args:
            init_s: Initial full state (standard mode) or not used (structured)
            k_init: First action choice
            K_init: Alternative action choice
            m_init: Initial endogenous state (structured mode)
            reg: Regularization parameter

        Returns:
            phi_k: Optimal flow weights for action k (n_j x n_k or n_m x n_k)
            phi_K: Optimal flow weights for action K
            min_dist: Terminal distribution difference
            constr_err: Constraint violation
        """
        if self.mode == 'structured':
            return self._solve_structured(m_init, k_init, K_init, reg)
        else:
            return self._solve_standard(init_s, k_init, K_init, reg)

    def _solve_standard(self, init_s, k_init, K_init, reg):
        """Standard solver with flow parameterization via penalized LSQR.

        phi is a flow variable: phi_{j,k} includes the path probability.
        Constraint: marginal at tau=1 = arrival prob, + flow conservation.
        Objective: kappa = sum phi * F_terminal (no P needed).

        Solves: min ||C x||^2 s.t. A_eq x = b_eq
        via penalized least squares: min ||[sqrt(w)*A_eq; C] x - [sqrt(w)*b; 0]||^2
        """
        A_eq, b_eq = self._build_constraints_standard(init_s, k_init, K_init)
        C = self._build_objective_standard()

        # Penalized LSQR: constraints as high-weight rows
        w = 1e6
        A_aug = sps.vstack([np.sqrt(w) * A_eq, C], format='csr')
        b_aug = np.concatenate([np.sqrt(w) * b_eq, np.zeros(C.shape[0])])

        result = spsla.lsqr(A_aug, b_aug, atol=1e-12, btol=1e-12)
        x_opt = result[0]

        # Extract solutions
        phi_k = x_opt[:self.n_vars_half].reshape(self.n_j, self.n_k)
        phi_K = x_opt[self.n_vars_half:].reshape(self.n_j, self.n_k)

        # Quality metrics
        dist_diff = np.linalg.norm(C @ x_opt)
        constraint_err = np.linalg.norm(A_eq @ x_opt - b_eq)

        return phi_k, phi_K, dist_diff, constraint_err

    def solve_all_states_standard(self, k_init, K_init, tol=1e-8):
        """Batched solver: solve for every init_s using cached factorization.

        Key observation: in standard mode, the constraint matrix A_eq, the
        objective matrix C, and hence the augmented matrix
        A_aug = [sqrt(w) A_eq; C] are *identical* across initial states --
        only the RHS b_aug depends on init_s through the initial-flow
        constraint.  We therefore (i) build A_aug once, (ii) compute its
        QR factorization once via sparse direct least squares (lsmr) on the
        first state to warm-start, then (iii) reuse the same lsmr setup
        with looser tolerance for the remaining S-1 states.

        Returns dphi_all of shape (S, n_j, n_k) with dphi_all[x0] =
        phi_k(x0) - phi_K(x0).
        """
        if self.mode == 'structured':
            raise NotImplementedError("Use _solve_structured per-state in structured mode.")

        # Build A_aug *once* (independent of init_s).  Cached on the solver
        # object across calls -- F and rho determine it fully.
        if not hasattr(self, '_cached_A_aug'):
            C = self._build_objective_standard()
            A_fc_half, b_fc = self._build_flow_conservation_standard()
            A_init_half = self._build_initial_flow_matrix_standard()
            if A_fc_half is not None:
                A_half = sps.vstack([A_init_half, A_fc_half], format='csr')
            else:
                A_half = A_init_half
            A_eq = sps.block_diag([A_half, A_half], format='csr')
            w = 1e6
            sqrt_w = np.sqrt(w)
            A_aug = sps.vstack([sqrt_w * A_eq, C], format='csr')
            self._cached_A_aug = A_aug
            self._cached_n_fc = b_fc.shape[0] if A_fc_half is not None else 0
            self._cached_sqrt_w = sqrt_w
        A_aug = self._cached_A_aug
        n_init = self.S
        n_fc = self._cached_n_fc
        sqrt_w = self._cached_sqrt_w

        # Build the constant block of b_aug: flow-conservation rows are 0,
        # objective rows are 0.  Only the initial-flow slots vary with init_s.
        b_template = np.zeros(A_aug.shape[0])  # zeros for fc and C blocks

        dphi_all = np.zeros((self.S, self.n_j, self.n_k))

        # Pre-extract the T slice we need: T[k_init, x0, j1] and T[K_init, x0, j1]
        Tk = self.T[k_init]   # (S, S)
        TK = self.T[K_init]   # (S, S)

        for x0 in range(self.S):
            b_aug = b_template.copy()
            # Initial-flow constraint rows: first S rows of A_half block-1 (phi_k),
            # next n_fc rows are zero, then S rows of A_half block-2 (phi_K), then n_fc zero.
            # A_init block has shape (S, n_vars_half), so block_diag([A_half, A_half])
            # places A_init at rows [0..S) for phi_k and [S+n_fc..2S+n_fc) for phi_K.
            b_aug[0:n_init] = sqrt_w * Tk[x0]
            b_aug[n_init + n_fc : 2*n_init + n_fc] = sqrt_w * TK[x0]

            x_opt, *_ = spsla.lsmr(A_aug, b_aug, atol=tol, btol=tol)
            phi_k = x_opt[:self.n_vars_half].reshape(self.n_j, self.n_k)
            phi_K = x_opt[self.n_vars_half:].reshape(self.n_j, self.n_k)
            dphi_all[x0] = phi_k - phi_K

        return dphi_all

    def _solve_structured(self, m_init, k_init, K_init, reg):
        """Structured solver with flow parameterization via penalized LSQR."""
        A_eq, b_eq = self._build_constraints_structured(m_init, k_init, K_init)
        C = self._build_objective_structured()

        w = 1e6
        A_aug = sps.vstack([np.sqrt(w) * A_eq, C], format='csr')
        b_aug = np.concatenate([np.sqrt(w) * b_eq, np.zeros(C.shape[0])])

        result = spsla.lsqr(A_aug, b_aug, atol=1e-12, btol=1e-12)
        x_opt = result[0]

        phi_k = x_opt[:self.n_vars_half].reshape(self.n_m, self.n_k)
        phi_K = x_opt[self.n_vars_half:].reshape(self.n_m, self.n_k)

        dist_diff = np.linalg.norm(C @ x_opt)
        constraint_err = np.linalg.norm(A_eq @ x_opt - b_eq)

        return phi_k, phi_K, dist_diff, constraint_err

    def solve_all_states_diff_standard(self, k_init, K_init, tol=1e-6):
        """Batched solver that returns Δφ = φ_k − φ_K directly.

        The original ``solve_all_states_standard`` solves a block-diagonal
        system in (φ_k, φ_K) jointly.  Because the constraint matrix is
        block-diagonal in (φ_k, φ_K) and the objective penalises the
        *difference* of terminal-distribution flows
        ``C[vec φ_k; vec φ_K] = coeffs (vec φ_k − vec φ_K)``, the entire
        QP can be rewritten in the single unknown
        ``x_diff = vec φ_k − vec φ_K``:

            min || coeffs · x_diff ||²
            s.t.  A_half · x_diff = (b_k − b_K)
                  (flow-conservation rows: 0 = 0)

        This halves the variable count (n_vars → n_vars_half) and removes
        the φ_K block of constraints entirely.  For (S, ρ) = (40, 2)
        the augmented matrix shrinks from (6520, 12800) to (3280, 6400)
        and the LSMR solve runs roughly 2–3× faster per initial state.

        Returns dphi_all of shape (S, n_j, n_k) directly.
        """
        if self.mode == 'structured':
            raise NotImplementedError("structured mode uses solve_all_states_structured.")

        if not hasattr(self, '_cached_A_aug_diff'):
            # Build the diff-QP augmented matrix once.
            # C_half = the coeffs block (the +coeffs side of the full C =
            # [coeffs, -coeffs]).
            terminal_trans = self.T[self.k_arr[None, :, -1],
                                    self.j_arr[:, None, -1], :]  # (n_j, n_k, S)
            C_half = sps.csr_matrix(
                terminal_trans.reshape(self.n_j * self.n_k, self.S).T
            )
            A_fc_half, b_fc = self._build_flow_conservation_standard()
            A_init_half = self._build_initial_flow_matrix_standard()
            if A_fc_half is not None:
                A_half = sps.vstack([A_init_half, A_fc_half], format='csr')
            else:
                A_half = A_init_half
            w = 1e6
            sqrt_w = np.sqrt(w)
            A_aug_diff = sps.vstack([sqrt_w * A_half, C_half], format='csr')
            self._cached_A_aug_diff = A_aug_diff
            self._cached_n_fc_diff = b_fc.shape[0] if A_fc_half is not None else 0
            self._cached_sqrt_w_diff = sqrt_w

        A_aug_diff = self._cached_A_aug_diff
        n_init = self.S
        n_fc = self._cached_n_fc_diff
        sqrt_w = self._cached_sqrt_w_diff

        # Difference of initial-flow RHS: delta_T[x0, j1] = T[k_init,x0,j1] - T[K_init,x0,j1]
        delta_T = self.T[k_init] - self.T[K_init]  # (S, S)

        dphi_all = np.zeros((self.S, self.n_j, self.n_k))
        for x0 in range(self.S):
            b_aug = np.zeros(A_aug_diff.shape[0])
            b_aug[0:n_init] = sqrt_w * delta_T[x0]
            # remaining rows (flow-conservation block + objective block) are 0
            x_diff, *_ = spsla.lsmr(A_aug_diff, b_aug, atol=tol, btol=tol)
            dphi_all[x0] = x_diff.reshape(self.n_j, self.n_k)
        return dphi_all

    def solve_all_states_structured(self, k_init, K_init, tol=1e-8):
        """Batched structured solver: solve for every endogenous initial m_init.

        When the model is Type-K (Kronecker with action-invariant exogenous
        factor), the flow QP need only be solved on the endogenous component
        x_endo (M states), not on the full state space S = M * Z.  The flow
        input then tensors with identity on the exogenous component when
        used in the GFD identity.  This is the *Kronecker reduction* of
        Lemma~\ref{lem:action_invariant} in the paper.

        Returns dphi_all of shape (M, n_m, n_k) with dphi_all[m0] =
        phi_k(m0) - phi_K(m0).  Caller must tensor with identity on the
        exogenous dimension if the downstream GFD identity expects the
        full-state input.
        """
        if self.mode != 'structured':
            raise NotImplementedError("solve_all_states_structured requires structured mode.")

        # Build A_aug *once* across all m_init.  Same as standard batched
        # solver, but on the smaller endogenous-only constraint system.
        if not hasattr(self, '_cached_A_aug_structured'):
            C = self._build_objective_structured()
            # Build constraint half (endo-only flow conservation) once
            # using the existing per-state builder; we just reuse it as a
            # template by passing a dummy m_init=0.  The constraint matrix
            # is in fact independent of m_init -- only the RHS varies.
            A_eq0, _ = self._build_constraints_structured(0, k_init, K_init)
            w = 1e6
            sqrt_w = np.sqrt(w)
            A_aug = sps.vstack([sqrt_w * A_eq0, C], format='csr')
            self._cached_A_aug_structured = A_aug
            self._cached_sqrt_w_structured = sqrt_w

        A_aug = self._cached_A_aug_structured
        sqrt_w = self._cached_sqrt_w_structured

        dphi_all = np.zeros((self.M, self.n_m, self.n_k))
        for m_init in range(self.M):
            _, b_eq = self._build_constraints_structured(m_init, k_init, K_init)
            b_aug = np.concatenate([sqrt_w * b_eq, np.zeros(A_aug.shape[0] - b_eq.shape[0])])
            x_opt, *_ = spsla.lsmr(A_aug, b_aug, atol=tol, btol=tol)
            phi_k = x_opt[:self.n_vars_half].reshape(self.n_m, self.n_k)
            phi_K = x_opt[self.n_vars_half:].reshape(self.n_m, self.n_k)
            dphi_all[m_init] = phi_k - phi_K

        return dphi_all

    # ========================================
    # Constraint Building (Flow Parameterization)
    # ========================================

    def _build_constraints_standard(self, init_s, k_init, K_init):
        """
        Build flow constraints for standard mode.

        Constraint 1 (Initial flow, tau=0):
            For each j1: sum_{j2,...,j_rho, k1,...,k_rho} phi_{(j1,...),(k1,...)} = f(j1|x0,d0)

        Constraint 2 (Flow conservation, for each tau in 0..rho-2):
            For each state prefix (j0,...,j_tau), action prefix (k0,...,k_tau), and j_{tau+1}:
            sum_{j_{tau+2},..., k_{tau+1},...} phi[(j0,...,j_{tau+1},...), (k0,...,k_tau,...)]
              = f(j_{tau+1}|j_tau, k_tau) *
                sum_{j_{tau+1}',..., k_{tau+1},...} phi[(j0,...,j_tau,j_{tau+1}',...), (k0,...,k_tau,...)]

        The b vector for the initial flow constraint differs between phi_k and phi_K
        because the arrival probabilities depend on the initial action.
        """
        # --- Initial flow constraint ---
        A_init_half = self._build_initial_flow_matrix_standard()
        b_init_k = np.array([self.T[k_init, init_s, j1] for j1 in range(self.S)])
        b_init_K = np.array([self.T[K_init, init_s, j1] for j1 in range(self.S)])

        # --- Flow conservation constraints (same for both halves) ---
        A_fc_half, b_fc = self._build_flow_conservation_standard()

        # Combine for each half
        if A_fc_half is not None:
            A_half = sps.vstack([A_init_half, A_fc_half], format='csr')
            b_half_k = np.concatenate([b_init_k, b_fc])
            b_half_K = np.concatenate([b_init_K, b_fc])
        else:
            A_half = A_init_half
            b_half_k = b_init_k
            b_half_K = b_init_K

        # Block diagonal for phi_k and phi_K (same A matrix, different b)
        A_full = sps.block_diag([A_half, A_half], format='csr')
        b_full = np.concatenate([b_half_k, b_half_K])

        return A_full, b_full

    def _build_initial_flow_matrix_standard(self):
        """
        Build the initial flow constraint matrix for standard mode.

        For each j1 in {0,...,S-1}:
            sum over all (j,k) where j[0]==j1 of phi[j,k] = f(j1|x0,d0)

        Returns A matrix of shape (S, n_vars_half). The b vector depends on
        init_s and init_a, so it is built separately.
        """
        row_idx, col_idx, vals = [], [], []
        for j1 in range(self.S):
            j_indices = np.where(self.j_arr[:, 0] == j1)[0]
            for ji in j_indices:
                for ki in range(self.n_k):
                    row_idx.append(j1)
                    col_idx.append(ji * self.n_k + ki)
                    vals.append(1.0)

        return sps.csr_matrix(
            (vals, (row_idx, col_idx)),
            shape=(self.S, self.n_vars_half)
        )

    def _build_flow_conservation_standard(self):
        """
        Build flow conservation constraints for standard mode.

        For each tau in {0, ..., rho-2}, each state prefix (j0,...,j_tau) of length
        tau+1, each action prefix (k0,...,k_tau) of length tau+1, and each j_{tau+1}:

        sum_{suffixes} phi[j with j_{tau+1} at pos tau+1, k with k_prefix]
          - f(j_{tau+1} | j_tau, k_tau) *
            sum_{j_{tau+1}', suffixes} phi[j with j_tau prefix, k with k_prefix]
          = 0

        This is linear in phi: both sides are linear functions of phi.
        """
        if self.rho <= 1:
            return None, None

        if self._flow_conservation_cache is not None:
            return self._flow_conservation_cache

        j_arr = self.j_arr
        k_arr = self.k_arr

        row_idx, col_idx, vals = [], [], []
        row_counter = 0

        for tau in range(self.rho - 1):
            # Fix state prefix of length tau+1: (j0, ..., j_tau)
            # Fix action prefix of length tau+1: (k0, ..., k_tau)
            # Vary j_{tau+1}

            j_prefix_len = tau + 1
            k_prefix_len = tau + 1

            j_prefixes = np.unique(j_arr[:, :j_prefix_len], axis=0)
            k_prefixes = np.unique(k_arr[:, :k_prefix_len], axis=0)

            for jp in j_prefixes:
                if j_prefix_len == 1:
                    mask_jp = (j_arr[:, 0] == jp[0])
                else:
                    mask_jp = np.all(j_arr[:, :j_prefix_len] == jp, axis=1)

                j_matched_all = np.where(mask_jp)[0]
                if len(j_matched_all) == 0:
                    continue

                j_tau = jp[-1]  # Last state in the prefix

                for kp in k_prefixes:
                    if k_prefix_len == 1:
                        mask_kp = (k_arr[:, 0] == kp[0])
                    else:
                        mask_kp = np.all(k_arr[:, :k_prefix_len] == kp, axis=1)

                    k_matched = np.where(mask_kp)[0]
                    if len(k_matched) == 0:
                        continue

                    k_tau = kp[-1]  # Last action in the prefix

                    # Precompute flat column indices for parent group
                    parent_ji_ki = np.add.outer(
                        j_matched_all * self.n_k, k_matched).ravel()

                    for j_next in range(self.S):
                        f_trans = self.T[k_tau, j_tau, j_next]

                        mask_j_next = mask_jp & (j_arr[:, tau + 1] == j_next)
                        j_matched_next = np.where(mask_j_next)[0]

                        # Child group flat indices
                        if len(j_matched_next) > 0:
                            child_ji_ki = np.add.outer(
                                j_matched_next * self.n_k, k_matched).ravel()
                            n_child = len(child_ji_ki)
                            row_idx.extend([row_counter] * n_child)
                            col_idx.extend(child_ji_ki.tolist())
                            vals.extend([1.0] * n_child)

                        # Parent group
                        if f_trans != 0:
                            n_parent = len(parent_ji_ki)
                            row_idx.extend([row_counter] * n_parent)
                            col_idx.extend(parent_ji_ki.tolist())
                            vals.extend([-f_trans] * n_parent)

                        row_counter += 1

        if row_counter == 0:
            self._flow_conservation_cache = (None, None)
            return None, None

        A_fc = sps.csr_matrix(
            (vals, (row_idx, col_idx)),
            shape=(row_counter, self.n_vars_half)
        )
        b_fc = np.zeros(row_counter)

        self._flow_conservation_cache = (A_fc, b_fc)
        return A_fc, b_fc

    def _build_constraints_structured(self, m_init, k_init, K_init):
        """
        Build flow constraints for structured mode (endogenous only).
        Same structure as standard but using endogenous transitions T_endo.
        """
        # --- Initial flow constraint ---
        A_init_half = self._build_initial_flow_matrix_structured()
        b_init_k = np.array([self.T_endo[k_init, m_init, m1] for m1 in range(self.M)])
        b_init_K = np.array([self.T_endo[K_init, m_init, m1] for m1 in range(self.M)])

        # --- Flow conservation constraints ---
        A_fc_half, b_fc = self._build_flow_conservation_structured()

        if A_fc_half is not None:
            A_half = sps.vstack([A_init_half, A_fc_half], format='csr')
            b_half_k = np.concatenate([b_init_k, b_fc])
            b_half_K = np.concatenate([b_init_K, b_fc])
        else:
            A_half = A_init_half
            b_half_k = b_init_k
            b_half_K = b_init_K

        A_full = sps.block_diag([A_half, A_half], format='csr')
        b_full = np.concatenate([b_half_k, b_half_K])

        return A_full, b_full

    def _build_initial_flow_matrix_structured(self):
        """
        Build initial flow constraint matrix for structured mode.

        For each m1 in {0,...,M-1}:
            sum over all (m,k) where m[0]==m1 of phi[m,k] = f(m1|m0,d0)
        """
        m_arr = np.array(self.m_seqs)
        row_idx, col_idx, vals = [], [], []

        for m1 in range(self.M):
            m_indices = np.where(m_arr[:, 0] == m1)[0]
            for mi in m_indices:
                for ki in range(self.n_k):
                    row_idx.append(m1)
                    col_idx.append(mi * self.n_k + ki)
                    vals.append(1.0)

        return sps.csr_matrix(
            (vals, (row_idx, col_idx)),
            shape=(self.M, self.n_vars_half)
        )

    def _build_flow_conservation_structured(self):
        """Build flow conservation constraints for structured mode."""
        if self.rho <= 1:
            return None, None

        if self._flow_conservation_cache_structured is not None:
            return self._flow_conservation_cache_structured

        m_arr = np.array(self.m_seqs)
        k_arr = np.array(self.k_seqs)

        row_idx, col_idx, vals = [], [], []
        row_counter = 0

        for tau in range(self.rho - 1):
            m_prefix_len = tau + 1
            k_prefix_len = tau + 1

            m_prefixes = np.unique(m_arr[:, :m_prefix_len], axis=0)
            k_prefixes = np.unique(k_arr[:, :k_prefix_len], axis=0)

            for mp in m_prefixes:
                if m_prefix_len == 1:
                    mask_mp = (m_arr[:, 0] == mp[0])
                else:
                    mask_mp = np.all(m_arr[:, :m_prefix_len] == mp, axis=1)

                m_matched_all = np.where(mask_mp)[0]
                if len(m_matched_all) == 0:
                    continue

                m_tau = mp[-1]

                for kp in k_prefixes:
                    if k_prefix_len == 1:
                        mask_kp = (k_arr[:, 0] == kp[0])
                    else:
                        mask_kp = np.all(k_arr[:, :k_prefix_len] == kp, axis=1)

                    k_matched = np.where(mask_kp)[0]
                    if len(k_matched) == 0:
                        continue

                    k_tau = kp[-1]

                    parent_mi_ki = np.add.outer(
                        m_matched_all * self.n_k, k_matched).ravel()

                    for m_next in range(self.M):
                        f_trans = self.T_endo[k_tau, m_tau, m_next]

                        mask_m_next = mask_mp & (m_arr[:, tau + 1] == m_next)
                        m_matched_next = np.where(mask_m_next)[0]

                        if len(m_matched_next) > 0:
                            child_mi_ki = np.add.outer(
                                m_matched_next * self.n_k, k_matched).ravel()
                            n_child = len(child_mi_ki)
                            row_idx.extend([row_counter] * n_child)
                            col_idx.extend(child_mi_ki.tolist())
                            vals.extend([1.0] * n_child)

                        if f_trans != 0:
                            n_parent = len(parent_mi_ki)
                            row_idx.extend([row_counter] * n_parent)
                            col_idx.extend(parent_mi_ki.tolist())
                            vals.extend([-f_trans] * n_parent)

                        row_counter += 1

        if row_counter == 0:
            self._flow_conservation_cache_structured = (None, None)
            return None, None

        A_fc = sps.csr_matrix(
            (vals, (row_idx, col_idx)),
            shape=(row_counter, self.n_vars_half)
        )
        b_fc = np.zeros(row_counter)

        self._flow_conservation_cache_structured = (A_fc, b_fc)
        return A_fc, b_fc

    # ========================================
    # Objective Building (Flow Parameterization)
    # ========================================

    def _build_objective_standard(self):
        """
        Build objective for standard mode (flow parameterization).

        Terminal distribution: kappa(x') = sum_{j,k} phi_{j,k} * f(x' | j_rho, k_rho)

        No path probability P is needed because phi already absorbs it.
        The objective matrix is independent of init_s and init_a.
        """
        # terminal_trans[ji, ki, x] = T[k_arr[ki,-1], j_arr[ji,-1], x]
        terminal_trans = self.T[self.k_arr[None, :, -1],
                                self.j_arr[:, None, -1], :]  # (n_j, n_k, S)

        # coeffs[x, ji*n_k+ki] = terminal_trans[ji, ki, x]
        coeffs = terminal_trans.reshape(self.n_j * self.n_k, self.S).T  # (S, n_j*n_k)

        C = sps.hstack([sps.csr_matrix(coeffs),
                         sps.csr_matrix(-coeffs)], format='csr')
        return C

    def _build_objective_structured(self):
        """
        Build objective for structured mode (flow parameterization).

        Terminal distribution on endogenous states only.
        No path probability needed -- phi absorbs it.
        The objective matrix is independent of m_init and init_a.
        """
        row_idx, col_idx, vals = [], [], []

        for m_final in range(self.M):
            for mi, m_seq in enumerate(self.m_seqs):
                last_m = m_seq[-1]
                for ki, k_seq in enumerate(self.k_seqs):
                    last_a = k_seq[-1]
                    trans = self.T_endo[last_a, last_m, m_final]

                    if trans > 0:
                        idx_k = mi * self.n_k + ki
                        idx_K = self.n_vars_half + mi * self.n_k + ki

                        # phi_k contribution
                        row_idx.append(m_final)
                        col_idx.append(idx_k)
                        vals.append(trans)

                        # phi_K contribution (negative)
                        row_idx.append(m_final)
                        col_idx.append(idx_K)
                        vals.append(-trans)

        C = sps.csr_matrix((vals, (row_idx, col_idx)),
                          shape=(self.M, self.n_vars))
        return C

    # ========================================
    # Path Probability (kept for evaluation)
    # ========================================

    def _get_path_prob_standard(self, init_s, init_a, j_seq, k_seq):
        """Compute path probability in standard mode"""
        prob = self.T[init_a, init_s, j_seq[0]]
        for t in range(self.rho - 1):
            prob *= self.T[k_seq[t], j_seq[t], j_seq[t+1]]
        return prob

    def _compute_P_mat_standard(self, init_s, init_a):
        """Vectorized computation of path probability matrix P_mat[ji, ki]"""
        # Step 0: init_s -> j_seq[0] via init_a (independent of k_seq)
        P_mat = np.broadcast_to(
            self.T[init_a, init_s, self.j_arr[:, 0]][:, None],
            (self.n_j, self.n_k)
        ).copy()
        # Steps 1..rho-1: j_seq[t] -> j_seq[t+1] via k_seq[t]
        for t in range(self.rho - 1):
            P_mat *= self.T[self.k_arr[None, :, t],
                            self.j_arr[:, None, t],
                            self.j_arr[:, None, t + 1]]
        return P_mat

    def _get_path_prob_structured(self, init_m, init_a, m_seq, k_seq):
        """Compute path probability in structured mode (endogenous only)"""
        prob = self.T_endo[init_a, init_m, m_seq[0]]
        for t in range(self.rho - 1):
            prob *= self.T_endo[k_seq[t], m_seq[t], m_seq[t+1]]
        return prob

    # ========================================
    # Value Difference Evaluation (Flow Parameterization)
    # ========================================

    def evaluate_value_difference(self, phi_k, phi_K, init_s, k_init, K_init,
                                  u, e, beta, z_init=None, m_init=None):
        """
        Evaluate value difference using FD approximation (flow parameterization).

        Since phi is a flow variable (absorbs path probability), the evaluation
        is simply: sum phi_{j,k} * payoff(j,k) without separate path probs.

        Args:
            phi_k, phi_K: Solved flow weight matrices
            init_s: Initial state (standard) or None (structured)
            k_init, K_init: Actions to compare
            u: Flow utility
            e: CCP correction terms
            beta: Discount factor
            z_init: Initial exogenous state (structured mode)
            m_init: Initial endogenous state (structured mode)

        Returns:
            fd_diff: Finite dependence approximation of value difference
        """
        if self.mode == 'structured':
            return self._evaluate_structured(
                phi_k, phi_K, z_init, m_init, k_init, K_init, u, e, beta
            )
        else:
            return self._evaluate_standard(
                phi_k, phi_K, init_s, k_init, K_init, u, e, beta
            )

    def _evaluate_standard(self, phi_k, phi_K, init_s, k_init, K_init, u, e, beta):
        """
        Evaluate value difference in standard mode (flow parameterization).

        No path probability multiplication -- phi already contains it.
        """
        # Immediate payoff difference
        diff_immediate = u[k_init, init_s] - u[K_init, init_s]

        # Compute cumulative discounted payoff for all paths (vectorized)
        flow_matrix = u + e
        path_payoffs = np.zeros((self.n_j, self.n_k))

        for tau in range(self.rho):
            s_idx = self.j_arr[:, tau][:, None]
            a_idx = self.k_arr[:, tau][None, :]
            flows_tau = flow_matrix[a_idx, s_idx]
            path_payoffs += (beta ** (tau + 1)) * flows_tau

        # Flow parameterization: phi already contains path probability
        expected_future_k = np.sum(phi_k * path_payoffs)
        expected_future_K = np.sum(phi_K * path_payoffs)

        fd_diff = diff_immediate + expected_future_k - expected_future_K
        return fd_diff

    def _evaluate_structured(self, phi_k, phi_K, z_init, m_init, k_init, K_init,
                            u_full, e_full, beta):
        """
        Evaluate value difference in structured mode (flow parameterization).

        No path probability multiplication -- phi already contains it.
        """
        # 1. Evolve exogenous state distribution
        z_probs = np.zeros((self.rho, self.Z))
        curr_dist = np.zeros(self.Z)
        curr_dist[z_init] = 1.0

        for t in range(self.rho):
            curr_dist = curr_dist @ self.T_exo
            z_probs[t, :] = curr_dist

        # 2. Integrate out Z to get reduced flows
        reduced_flows = np.zeros((self.rho, self.A, self.M))
        full_flow = u_full + e_full

        for t in range(self.rho):
            prob_z = z_probs[t, :]
            weighted = full_flow * prob_z[None, :, None]
            reduced_flows[t] = np.sum(weighted, axis=1)

        # 3. Immediate payoff
        diff_immediate = u_full[k_init, z_init, m_init] - u_full[K_init, z_init, m_init]

        # 4. Future value -- no path probability needed
        val_k = self._calc_future_structured(phi_k, reduced_flows, beta)
        val_K = self._calc_future_structured(phi_K, reduced_flows, beta)

        return diff_immediate + (val_k - val_K)

    def _calc_future_structured(self, phi, reduced_flows, beta):
        """
        Future value calculation for structured mode (flow parameterization).

        No path probability multiplication -- phi absorbs it.
        """
        m_arr = np.array(self.m_seqs)
        k_arr = np.array(self.k_seqs)

        # Path payoffs
        V_mat = np.zeros((self.n_m, self.n_k))
        for t in range(self.rho):
            u_table = reduced_flows[t]  # (A, M)
            payoff_t = u_table[k_arr[:, t][None, :], m_arr[:, t][:, None]]
            V_mat += (beta ** (t + 1)) * payoff_t

        return np.sum(phi * V_mat)


# ==========================================
# Helper: Solve MDP for ground truth
# ==========================================
def solve_mdp(T, u, beta):
    """
    Solve MDP using value iteration

    Args:
        T: Transition matrix (A, S, S)
        u: Flow utility (A, S)
        beta: Discount factor

    Returns:
        V: Ex-ante value function (S,)
        v: Choice-specific value (A, S)
        e: CCP correction terms (A, S)
    """
    A, S, _ = T.shape
    V = np.zeros(S)
    Euler = 0.5772156649

    for _ in range(2000):
        Q = u + beta * (T @ V)
        V_new = logsumexp(Q, axis=0) + Euler
        if np.max(np.abs(V_new - V)) < 1e-12:
            break
        V = V_new

    v = u + beta * (T @ V)

    v_max = np.max(v, axis=0)
    probs = np.exp(v - v_max) / np.sum(np.exp(v - v_max), axis=0)
    e = Euler - np.log(probs + 1e-100)

    return V, v, e


def generate_ground_truth_structured(T_endo, T_exo, A, Z, M, beta=0.95):
    """
    Generate ground truth for structured models

    Args:
        T_endo: Endogenous transition (A, M, M)
        T_exo: Exogenous transition (Z, Z)
        A: Number of actions
        Z: Number of exogenous states
        M: Number of endogenous states
        beta: Discount factor

    Returns:
        u_full: Flow utility (A, Z, M)
        e_full: CCP correction (A, Z, M)
        v_true: Choice-specific value (A, Z, M)
    """
    S_full = Z * M
    T_full = np.zeros((A, S_full, S_full))

    # Kronecker product for full transition
    for a in range(A):
        T_full[a] = np.kron(T_exo, T_endo[a])

    # Random utility
    u_full = np.random.rand(A, S_full).reshape(A, Z, M)
    u_flat = u_full.reshape(A, S_full)

    # Solve MDP
    V, v_flat, e_flat = solve_mdp(T_full, u_flat, beta)

    # Reshape
    e_full = e_flat.reshape(A, Z, M)
    v_true = v_flat.reshape(A, Z, M)

    return u_full, e_full, v_true
