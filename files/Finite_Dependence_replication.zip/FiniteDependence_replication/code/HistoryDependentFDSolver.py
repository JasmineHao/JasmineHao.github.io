"""
HistoryDependentFDSolver.py - Flow-based Finite Dependence Solver

Uses flow variables w_tau(h, d) = prob(reaching h) * omega(d|h) to formulate
the FD problem as a convex QP (Quadratic Program) with linear constraints.

Key properties:
    - ALL constraints are LINEAR (flow conservation)
    - Terminal distribution is LINEAR in w -> QP for any rho
    - Preserves per-step normalization -> correct payoff (telescoping identity)
    - More flexible than NAC: strong_NAC ⊊ flow ⊊ no_NAC

Mathematical basis:
    In logit models, u(d,x) + e(d,x) + beta * E_d[V] = V(x) for all d.
    Per-step normalized weights preserve this telescoping identity.
    The flow formulation linearizes the recursive omega product via:
        w_tau(h, d) = prob(reaching h) * omega(d|h)
    making flow conservation constraints linear in w.

Flow conservation constraints:
    Step 0:   sum_d w_0(j, d) = T[init_a, init_s, j]
    Step tau: sum_d w_tau(h, d) = w_{tau-1}(parent, d_prev) * T[d_prev, j_prev, j]

Terminal distribution (linear in w):
    kappa(x) = sum_{h,d} w_{rho-1}(h, d) * T[d, j_last, x]

Objective: minimize ||kappa^A - kappa^B||^2  (QP)

Solved via sparse KKT system -> one linear solve, global optimum guaranteed.
"""

import numpy as np
import scipy.sparse as sps
import scipy.sparse.linalg as spsla
from scipy.optimize import minimize
from scipy.special import logsumexp


def solve_mdp(T, u, beta):
    """Solve MDP using value iteration for ground truth."""
    A, S, _ = T.shape
    V = np.zeros(S)
    Euler = 0.5772156649015328606065120900824

    for _ in range(2000):
        Q = u + beta * (T @ V)
        V_new = logsumexp(Q, axis=0) + Euler
        if np.max(np.abs(V_new - V)) < 1e-12:
            break
        V = V_new

    v = u + beta * (T @ V)
    v_max = np.max(v, axis=0)
    probs = np.exp(v - v_max) / np.sum(np.exp(v - v_max), axis=0)
    e = Euler - np.log(probs + 1e-100)
    return V, v, e


class FlowFDSolver:
    """
    Flow-based Finite Dependence Solver.

    Define flow variables w_tau(h, d) = prob(reaching h) * omega(d|h).
    All constraints become linear, terminal distribution is linear in w,
    so the problem is a convex QP solvable via sparse KKT.

    Args:
        T: Transition matrix (A, S, S)
        rho: Memory horizon (number of omega steps)
        n_states: Number of states S
        n_actions: Number of actions A
    """

    def __init__(self, T, rho, n_states, n_actions, prune_threshold=50000):
        self.T = T
        self.rho = rho
        self.S = n_states
        self.A = n_actions

        # Estimate full tree size: S + S*A*S + S*(A*S)^2 + ...
        full_nodes = sum(self.S * (self.A * self.S) ** tau
                         for tau in range(self.rho))
        self.pruned = full_nodes > prune_threshold
        if self.pruned:
            # Precompute reachable next-states per (action, state) pair
            self._reachable = {}
            for d in range(self.A):
                for s in range(self.S):
                    self._reachable[(d, s)] = [
                        j for j in range(self.S) if self.T[d, s, j] > 1e-15
                    ]
            self._build_structure_pruned()
            pruned_nodes = sum(len(ns) for ns in self.nodes)
            print(f"  [Pruning] full={full_nodes}, pruned={pruned_nodes} "
                  f"({100*pruned_nodes/full_nodes:.1f}%), "
                  f"flow_vars={self.n_w}")
        else:
            self._build_structure_full()

    def _build_structure_full(self):
        """Build full (unpruned) history tree."""
        self.nodes = []
        self.offsets = []

        offset = 0
        for tau in range(self.rho):
            nodes_tau = []
            offsets_tau = {}

            if tau == 0:
                for j in range(self.S):
                    node = (j,)
                    nodes_tau.append(node)
                    offsets_tau[node] = offset
                    offset += self.A
            else:
                for prev_node in self.nodes[tau - 1]:
                    for d in range(self.A):
                        for j in range(self.S):
                            node = prev_node + (d, j)
                            nodes_tau.append(node)
                            offsets_tau[node] = offset
                            offset += self.A

            self.nodes.append(nodes_tau)
            self.offsets.append(offsets_tau)

        self.n_w = offset           # flow vars per path
        self.n_total = 2 * offset   # both paths

    def _build_structure_pruned(self):
        """
        Build pruned history tree — only expand branches where T > 0.

        Same structure as full tree but skips zero-probability transitions,
        which dramatically reduces size for sparse/deterministic models.
        """
        self.nodes = []
        self.offsets = []

        offset = 0
        for tau in range(self.rho):
            nodes_tau = []
            offsets_tau = {}

            if tau == 0:
                for j in range(self.S):
                    node = (j,)
                    nodes_tau.append(node)
                    offsets_tau[node] = offset
                    offset += self.A
            else:
                for prev_node in self.nodes[tau - 1]:
                    parent_state = prev_node[-1]
                    for d in range(self.A):
                        for j in self._reachable[(d, parent_state)]:
                            node = prev_node + (d, j)
                            nodes_tau.append(node)
                            offsets_tau[node] = offset
                            offset += self.A

            self.nodes.append(nodes_tau)
            self.offsets.append(offsets_tau)

        self.n_w = offset
        self.n_total = 2 * offset

    def _get_node_state(self, node):
        """Extract current state (last element) from history node."""
        return node[-1]

    def _get_parent_info(self, node):
        """Extract (parent_node, action, parent_state) from a child node."""
        parent = node[:-2]
        action = node[-2]
        parent_state = parent[-1]
        return parent, action, parent_state

    def _build_constraints_for_path(self, init_s, init_a):
        """
        Build linear flow conservation constraints for one path.

        Returns sparse (A_eq, b_eq) such that A_eq @ w = b_eq.
        """
        rows, cols, vals = [], [], []
        b_vals = []
        row_idx = 0

        for tau in range(self.rho):
            for node in self.nodes[tau]:
                state = self._get_node_state(node)

                # LHS: sum_d w_tau(node, d)
                for d in range(self.A):
                    col = self.offsets[tau][node] + d
                    rows.append(row_idx)
                    cols.append(col)
                    vals.append(1.0)

                if tau == 0:
                    # RHS: T[init_a, init_s, j]
                    b_vals.append(self.T[init_a, init_s, state])
                else:
                    # RHS: w_{tau-1}(parent, d_prev) * T[d_prev, parent_state, j]
                    parent, d_prev, parent_state = self._get_parent_info(node)
                    trans = self.T[d_prev, parent_state, state]
                    parent_col = self.offsets[tau - 1][parent] + d_prev

                    # Move to LHS: ... - trans * w_{tau-1}(parent, d_prev) = 0
                    rows.append(row_idx)
                    cols.append(parent_col)
                    vals.append(-trans)
                    b_vals.append(0.0)

                row_idx += 1

        n_eq = row_idx
        A_eq = sps.csr_matrix((vals, (rows, cols)), shape=(n_eq, self.n_w))
        b_eq = np.array(b_vals)
        return A_eq, b_eq

    def _build_terminal_matrix(self, init_s, init_a):
        """
        Build terminal distribution matrix: kappa = M @ w.

        kappa(x) = sum_{h,d at last step} w(h, d) * T[d, state(h), x]
        """
        rows, cols, vals = [], [], []
        last_tau = self.rho - 1

        for node in self.nodes[last_tau]:
            state = self._get_node_state(node)
            for d in range(self.A):
                col = self.offsets[last_tau][node] + d
                for x in range(self.S):
                    trans = self.T[d, state, x]
                    if abs(trans) > 1e-20:
                        rows.append(x)
                        cols.append(col)
                        vals.append(trans)

        return sps.csr_matrix((vals, (rows, cols)), shape=(self.S, self.n_w))

    def solve(self, init_s, k_init, K_init, reg=1e-10, nonneg=False):
        """
        Solve for optimal flow weights.

        Args:
            init_s: Initial state
            k_init, K_init: Actions to compare
            reg: Regularization parameter
            nonneg: If True, enforce w >= 0 (uses SLSQP, slower)

        Returns:
            w_A, w_B: Flow weight vectors for paths A and B
            dist: Terminal distribution distance ||kappa^A - kappa^B||
            constr_err: Constraint violation ||A_eq @ w - b_eq||
        """
        # Build per-path constraints
        A_eq_A, b_eq_A = self._build_constraints_for_path(init_s, k_init)
        A_eq_B, b_eq_B = self._build_constraints_for_path(init_s, K_init)

        # Block diagonal for joint system
        A_eq = sps.block_diag([A_eq_A, A_eq_B], format='csr')
        b_eq = np.concatenate([b_eq_A, b_eq_B])

        # Terminal distribution: kappa_diff = C @ [w_A; w_B]
        M_A = self._build_terminal_matrix(init_s, k_init)
        M_B = self._build_terminal_matrix(init_s, K_init)
        C = sps.hstack([M_A, -M_B], format='csr')

        if nonneg:
            return self._solve_nonneg(A_eq, b_eq, C, reg)
        else:
            return self._solve_kkt(A_eq, b_eq, C, reg)

    def _solve_kkt(self, A_eq, b_eq, C, reg):
        """
        Solve QP via sparse KKT system (no non-negativity).

        For small problems, directly compute H = 2*C'C + reg*I.
        For large problems (n_total > 10000), use LSQR to avoid
        forming the dense C'C product which can exhaust memory.
        """
        if self.n_total <= 5000:
            return self._solve_kkt_direct(A_eq, b_eq, C, reg)
        else:
            return self._solve_lsqr(A_eq, b_eq, C, reg)

    def _solve_kkt_direct(self, A_eq, b_eq, C, reg):
        """Direct KKT solve for small problems."""
        H = 2 * (C.T @ C) + reg * sps.eye(self.n_total, format='csr')
        n_eq = A_eq.shape[0]

        KKT = sps.bmat([
            [H, A_eq.T],
            [A_eq, -1e-12 * sps.eye(n_eq, format='csr')]
        ], format='csr')

        rhs = np.zeros(self.n_total + n_eq)
        rhs[self.n_total:] = b_eq

        sol = spsla.spsolve(KKT, rhs)
        x_opt = sol[:self.n_total]

        w_A = x_opt[:self.n_w]
        w_B = x_opt[self.n_w:]

        dist = np.linalg.norm(C @ x_opt)
        constr_err = np.linalg.norm(A_eq @ x_opt - b_eq)

        return w_A, w_B, dist, constr_err

    def _solve_lsqr(self, A_eq, b_eq, C, reg):
        """
        LSQR-based solve for large problems.

        Reformulate as: min ||C @ x||^2 + reg*||x||^2
                        s.t. A_eq @ x = b_eq

        Solved via stacked least squares:
            min || [C; sqrt(reg)*I; 0] @ x - [0; 0; 0] ||^2
            with A_eq @ x = b_eq enforced via null-space projection.

        Actually we use the augmented system approach:
            [sqrt(2)*C ]         [0   ]
            [sqrt(r)*I ] @ x  =  [0   ]   (objective rows)
            [  A_eq    ]         [b_eq]   (constraint rows, high weight)
        """
        import scipy.sparse.linalg as sla

        n = self.n_total
        n_eq = A_eq.shape[0]
        sqrt_reg = np.sqrt(reg)
        penalty = 1e6  # Large weight to enforce equality constraints

        # Stack: [sqrt(2)*C; sqrt(reg)*I; penalty*A_eq]
        stacked = sps.vstack([
            np.sqrt(2) * C,
            sqrt_reg * sps.eye(n, format='csr'),
            penalty * A_eq,
        ], format='csr')

        rhs = np.concatenate([
            np.zeros(C.shape[0]),
            np.zeros(n),
            penalty * b_eq,
        ])

        result = sla.lsqr(stacked, rhs, atol=1e-12, btol=1e-12, iter_lim=5000)
        x_opt = result[0]

        w_A = x_opt[:self.n_w]
        w_B = x_opt[self.n_w:]

        dist = np.linalg.norm(C @ x_opt)
        constr_err = np.linalg.norm(A_eq @ x_opt - b_eq)

        return w_A, w_B, dist, constr_err

    def _solve_nonneg(self, A_eq, b_eq, C, reg):
        """Solve QP with non-negativity via SLSQP."""
        C_d = C.toarray()
        A_d = A_eq.toarray()
        H = 2 * C_d.T @ C_d + reg * np.eye(self.n_total)

        result = minimize(
            lambda x: 0.5 * x @ H @ x,
            x0=np.maximum(np.linalg.lstsq(A_d, b_eq, rcond=None)[0], 1e-6),
            jac=lambda x: H @ x,
            method='SLSQP',
            bounds=[(0, None)] * self.n_total,
            constraints={'type': 'eq', 'fun': lambda x: A_d @ x - b_eq,
                         'jac': lambda x: A_d},
            options={'maxiter': 3000, 'ftol': 1e-15, 'disp': False}
        )

        x_opt = result.x
        w_A = x_opt[:self.n_w]
        w_B = x_opt[self.n_w:]

        dist = np.linalg.norm(C_d @ x_opt)
        constr_err = np.linalg.norm(A_d @ x_opt - b_eq)

        return w_A, w_B, dist, constr_err

    def evaluate_value_difference(self, w_A, w_B, init_s, k_init, K_init,
                                  u, e, beta):
        """
        Compute FD approximation of v(k, init_s) - v(K, init_s).

        Formula (no double counting):
            E[payoff] = sum_tau sum_{node,d} w_tau(node,d) * beta^{tau+1} * (u+e)(d, state)

        Each w already encodes full path probability, so only current-step
        flow payoff is added.
        """
        flow = u + e  # (A, S)

        def _expected_payoff(w):
            total = 0.0
            for tau in range(self.rho):
                discount = beta ** (tau + 1)
                for node in self.nodes[tau]:
                    state = self._get_node_state(node)
                    for d in range(self.A):
                        w_val = w[self.offsets[tau][node] + d]
                        if abs(w_val) > 1e-20:
                            total += w_val * discount * flow[d, state]
            return total

        payoff_A = _expected_payoff(w_A)
        payoff_B = _expected_payoff(w_B)

        return (u[k_init, init_s] - u[K_init, init_s]) + payoff_A - payoff_B
