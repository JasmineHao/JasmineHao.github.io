"""
Example: Altug-Miller Female Labor Supply Model
=================================================
2 actions: Not Work (0), Work (1)
State: labor_history (l_{t-3}, l_{t-2}, l_{t-1})
Memory: Shift Register (Nilpotent, lag p=3)
Expected: rho=3 (shift register flushes initial difference after p steps)

Usage:
    python example_altug_miller.py          # Quick demo (rho=1 only)
    python example_altug_miller.py --full   # Full test (rho=1,2,3)
"""

import numpy as np
import time
import sys, os
import argparse
sys.path.insert(0, os.path.dirname(__file__))
from UnifiedFDSolver import UnifiedFDSolver
from HistoryDependentFDSolver import solve_mdp
from utils import build_transition_matrices_altug_miller, compute_payoff_altug_miller


def build_model():
    beta = 0.95
    n_hours = 2           # Binary: {0=not work, 1=work}
    n_lags = 3
    n_states = n_hours ** n_lags  # 2^3 = 8
    n_actions = n_hours           # 2

    hours_grid = list(range(n_hours))
    F = build_transition_matrices_altug_miller(hours_grid, n_states)
    u = compute_payoff_altug_miller(n_states, n_actions, hours_grid)

    return F, u, beta, n_states, n_actions


def run(full=False):
    F, u, beta, n_states, n_actions = build_model()
    V, v, e = solve_mdp(F, u, beta)

    print(f"Altug-Miller Model: S={n_states}, A={n_actions}, beta={beta}, lags=3")
    print(f"  {'rho':>3}  {'case':<28} {'dist':>10} {'payoff_err':>12} {'time':>7}")
    print(f"  {'-'*65}")

    cases = [
        (0, 0, 1, "s0(000): NoWork vs Work"),
        (3, 0, 1, "s3(011): NoWork vs Work"),
        (7, 1, 0, "s7(111): Work vs NoWork"),
    ]

    rhos = [1, 2, 3] if full else [1]
    
    for rho in rhos:
        if rho > 1:
            print(f"  [rho={rho}] Building solver (this may take time due to NAC constraints)...")
        else:
            print(f"  [rho={rho}] Building solver...")
        t0 = time.time()
        solver = UnifiedFDSolver(T=F, rho=rho, n_states=n_states, n_actions=n_actions)
        init_time = time.time() - t0
        print(f"          Init time: {init_time:.3f}s")
        
        for s0, k, K, desc in cases:
            true_diff = v[k, s0] - v[K, s0]
            t0 = time.time()
            phi_k, phi_K, dist, ce = solver.solve(s0, k, K)
            solve_time = time.time() - t0
            fd = solver.evaluate_value_difference(phi_k, phi_K, s0, k, K, u, e, beta)
            print(f"  {rho:>3}  {desc:<28} {dist:>10.2e} {abs(fd - true_diff):>12.2e} {solve_time:>6.3f}s")
        print()
    
    if not full:
        print("  (Skipping rho=2,3. Use --full flag to enable)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Altug-Miller Labor Model Example')
    parser.add_argument('--full', action='store_true', 
                        help='Run full test including rho=2,3 (slow, may take minutes)')
    args = parser.parse_args()
    run(full=args.full)
