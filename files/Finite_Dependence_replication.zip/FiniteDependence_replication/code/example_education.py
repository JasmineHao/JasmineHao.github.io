"""
Example: Education/Occupation Choice (Keane-Wolpin 1994 style)
================================================================
2 actions: Work (0), School (1)
State: schooling_history (s_{t-4}, s_{t-3}, s_{t-2}, s_{t-1})
Memory: Nilpotent (Shift Register, lag p=4)
Control: Input-Only
Expected: rho=4 (shift register flushes initial difference after p=4 steps)

Usage:
    python example_education.py          # Quick demo (rho=1 only)
    python example_education.py --full   # Full test (rho=1,2,3,4)
"""

import numpy as np
import time
import sys, os
import argparse
sys.path.insert(0, os.path.dirname(__file__))
from UnifiedFDSolver import UnifiedFDSolver
from HistoryDependentFDSolver import solve_mdp


def build_model():
    beta = 0.95
    n_choices = 2  # Work=0, School=1
    n_lags = 4
    n_states = n_choices ** n_lags  # 2^4 = 16
    n_actions = n_choices

    # Transition: deterministic shift register
    # State encodes (s_{t-4}, s_{t-3}, s_{t-2}, s_{t-1}) in binary
    F = np.zeros((n_actions, n_states, n_states))

    for s in range(n_states):
        # Decode current state
        bits = []
        temp = s
        for _ in range(n_lags):
            bits.append(temp % n_choices)
            temp //= n_choices
        bits.reverse()  # bits[0]=s_{t-4}, ..., bits[3]=s_{t-1}

        for a in range(n_actions):
            # Shift: drop oldest, append new action
            new_bits = bits[1:] + [a]
            # Encode new state
            new_s = 0
            for b in new_bits:
                new_s = new_s * n_choices + b
            F[a, s, new_s] = 1.0

    # Payoff: human capital depends on schooling history
    u = np.zeros((n_actions, n_states))
    for s in range(n_states):
        bits = []
        temp = s
        for _ in range(n_lags):
            bits.append(temp % n_choices)
            temp //= n_choices
        bits.reverse()
        experience = sum(bits)  # Total schooling in window

        # Work: wage depends on human capital
        u[0, s] = 1.0 + 0.3 * experience
        # School: cost of schooling, but builds human capital
        u[1, s] = -0.5 + 0.1 * experience

    return F, u, beta, n_states, n_actions


def run(full=False):
    F, u, beta, n_states, n_actions = build_model()
    V, v, e = solve_mdp(F, u, beta)

    print(f"Education/Occupation (p=4): S={n_states}, A={n_actions}, beta={beta}")
    print(f"  {'rho':>3}  {'case':<28} {'dist':>10} {'payoff_err':>12} {'time':>7}")
    print(f"  {'-'*65}")

    cases = [
        (0, 0, 1, "s0(0000): Work vs School"),
        (5, 0, 1, "s5(0101): Work vs School"),
        (15, 1, 0, "s15(1111): School vs Work"),
    ]

    rhos = [1, 2, 3, 4] if full else [1]

    for rho in rhos:
        if rho > 1:
            print(f"  [rho={rho}] Building solver (this may take time)...")
        else:
            print(f"  [rho={rho}] Building solver...")
        t0 = time.time()
        solver = UnifiedFDSolver(T=F, rho=rho, n_states=n_states, n_actions=n_actions)
        init_time = time.time() - t0
        print(f"          Init time: {init_time:.3f}s")

        for s0, k, K, desc in cases:
            true_diff = v[k, s0] - v[K, s0]
            t0 = time.time()
            phi_k, phi_K, dist, ce = solver.solve(s0, k, K)
            solve_time = time.time() - t0
            fd = solver.evaluate_value_difference(phi_k, phi_K, s0, k, K, u, e, beta)
            print(f"  {rho:>3}  {desc:<28} {dist:>10.2e} {abs(fd - true_diff):>12.2e} {solve_time:>6.3f}s")
        print()

    if not full:
        print("  (Skipping rho=2,3,4. Use --full flag to enable)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Education/Occupation Model Example')
    parser.add_argument('--full', action='store_true',
                        help='Run full test including rho=2,3,4 (slow)')
    args = parser.parse_args()
    run(full=args.full)
