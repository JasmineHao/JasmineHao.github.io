"""
test_variance_optimal.py
=========================

Demonstration: when the FD QP has multiple feasible solutions
(non-trivial null space), we can pick the one that strictly reduces the
GFD asymptotic variance trace.

This is a numerical verification of Theorem 6 (FD-class trace optimality,
Section 4.4): the canonical Moore-Penrose flow input Phi_MP is generally
NOT the variance-optimal input; tuning the null-space coordinate q in
the descent direction of tr(Sigma(Phi(q))) at q=0 strictly reduces the
asymptotic variance trace.

We verify this by computing tr(Sigma) at a one-step descent in the
gradient direction and comparing to tr(Sigma_MP), without solving the
full (high-dimensional) variance-minimization problem.

DGP: 3-player entry/exit game (per-player projection, S=24, A=2, rho=2),
the same DGP as Section 6.2 of the paper. We use a small subset of
initial states (5 chosen across the state space) to make J full rank
(d_theta = 4) while keeping the demo memory-light.

Run:
    python3 test_variance_optimal.py
"""

import numpy as np
from itertools import product as iterproduct
from scipy.linalg import null_space, lstsq, pinv
import time
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from UnifiedFDSolver import UnifiedFDSolver
from utils import (
    solve_game_equilibrium, compute_ftran_game,
    compute_dpi_dtheta_game, my_meshgrid
)


def build_game_dgp():
    n_player = 3
    theta_all = [
        [1.0, 1.0, 1.0, 1.0],
        [1.0, 1.0, 1.0, 0.9],
        [1.0, 1.0, 1.0, 0.8],
    ]
    discount_factors = [0.9, 0.9, 0.9]
    s_space = np.array([2, 6, 10])
    a_i_space = np.array([0, 1])
    F_s = np.array([[0.8, 0.2, 0], [0, 0.6, 0.4], [0, 0.2, 0.8]])
    state = my_meshgrid([s_space] + [a_i_space] * n_player)
    P_eq, V_eq = solve_game_equilibrium(state, theta_all, F_s, discount_factors)
    Ftran_all = compute_ftran_game(P_eq, F_s, state, n_player)
    dpi = compute_dpi_dtheta_game(state, n_player, P_eq)
    return {
        'beta': discount_factors[0],
        'F_p0': Ftran_all[0],
        'P_eq_p0': P_eq[0],
        'dpi_p0': dpi[0],
    }


def H_diff(phi_k, phi_K, x0, beta, dgp, S, A, rho):
    """H_diff(x0; Phi) = grad_theta of [v(x0,0;theta) - v(x0,1;theta)]."""
    dpi_p0 = dgp['dpi_p0']
    H = dpi_p0[0, x0] - dpi_p0[1, x0]
    dphi = phi_k - phi_K
    j_seqs = np.array(list(iterproduct(range(S), repeat=rho)))
    k_seqs = np.array(list(iterproduct(range(A), repeat=rho)))
    for tau in range(rho):
        for jt in range(S):
            jmask = (j_seqs[:, tau] == jt)
            for at in range(A):
                kmask = (k_seqs[:, tau] == at)
                w = dphi[np.ix_(jmask, kmask)].sum()
                H = H + (beta ** (tau + 1)) * w * dpi_p0[at, jt]
    return H


def H_jacobian_wrt_phi(x0, beta, dgp, S, A, rho):
    """
    Compute the Jacobian dH(x0; Phi) / d(vec phi_k - vec phi_K) of shape
    (d_theta, n_j * n_k). H is linear in dphi = phi_k - phi_K.

    For the joint vec [phi_k; phi_K] of length 2*n_j*n_k, the Jacobian is
        [J_dphi, -J_dphi]
    where J_dphi has shape (d_theta, n_j*n_k).
    """
    dpi_p0 = dgp['dpi_p0']
    d_theta = dpi_p0.shape[-1]
    n_j = S ** rho
    n_k = A ** rho
    j_seqs = np.array(list(iterproduct(range(S), repeat=rho)))
    k_seqs = np.array(list(iterproduct(range(A), repeat=rho)))

    # J_dphi[k, ji * n_k + ki] = sum_{tau} beta^{tau+1} * dpi_p0[k_arr[ki, tau],
    #                                                          j_arr[ji, tau], k]
    J_dphi = np.zeros((d_theta, n_j * n_k))
    for ji in range(n_j):
        for ki in range(n_k):
            contrib = np.zeros(d_theta)
            for tau in range(rho):
                jt = j_seqs[ji, tau]
                at = k_seqs[ki, tau]
                contrib += (beta ** (tau + 1)) * dpi_p0[at, jt]
            J_dphi[:, ji * n_k + ki] = contrib
    return J_dphi


def precompute_state(x0, dgp, S, A, rho):
    F_p0 = dgp['F_p0']
    solver = UnifiedFDSolver(T=F_p0, rho=rho, n_states=S, n_actions=A)
    A_sparse, b = solver._build_constraints_standard(x0, k_init=0, K_init=1)
    A_arr = A_sparse.toarray() if hasattr(A_sparse, 'toarray') else np.asarray(A_sparse)
    x_MP, _, _, _ = lstsq(A_arr, b, lapack_driver='gelsd')
    N = null_space(A_arr, rcond=1e-10)
    return {'x0': x0, 'x_MP': x_MP, 'N': N, 'd_q': N.shape[1]}


def H_at_x(x_vec, x0, n_j, n_k, beta, dgp, S, A, rho):
    n_half = n_j * n_k
    phi_k = x_vec[:n_half].reshape(n_j, n_k)
    phi_K = x_vec[n_half:].reshape(n_j, n_k)
    return H_diff(phi_k, phi_K, x0, beta, dgp, S, A, rho)


def grad_trSigma_wrt_q_state(cache_entry, J_dphi_x0, J_total, dgp, beta,
                              S, A, rho):
    """
    For one cached state x0, compute dH(x0)/dq_x0 via
        dH/dq = [J_dphi, -J_dphi] @ N_x0
    Then the contribution to ∇_{q_x0} tr(Sigma) is
        -2 * weight_x0 * p1 * p0 * (Sigma @ H) @ (dH/dq^T)^T
    where Sigma = pinv(J_total).

    Returns dtr/dq_x0 of length d_q_x0.
    """
    x0 = cache_entry['x0']
    n_half = J_dphi_x0.shape[1]
    # J wrt full vec [phi_k; phi_K]: [J_dphi, -J_dphi]
    J_full = np.concatenate([J_dphi_x0, -J_dphi_x0], axis=1)
    # dH/dq_x0 = J_full @ N_x0, shape (d_theta, d_q_x0)
    dH_dq = J_full @ cache_entry['N']
    # H at current Phi(x_MP)
    H = H_at_x(cache_entry['x_MP'], x0,
               n_j=S**rho, n_k=A**rho, beta=beta, dgp=dgp,
               S=S, A=A, rho=rho)
    p1 = dgp['P_eq_p0'][x0, 1]
    p0 = dgp['P_eq_p0'][x0, 0]
    Sigma = pinv(J_total, atol=1e-14, rtol=1e-14)
    # d tr(Sigma) / dH = -2 * weight_x * p1 * p0 * (Sigma @ Sigma) @ H
    # Actually tr(Sigma) = tr(J^{-1}); dJ = weight * p1 * p0 * (dH H^T + H dH^T)
    # => d tr(J^{-1}) = -tr(J^{-1} dJ J^{-1}) = -tr(Sigma^2 dJ)
    #                 = -2 * weight * p1 * p0 * H^T Sigma^2 H ... wait let me redo
    # Each rank-1 update dJ = weight * p1 * p0 * (dH H^T + H dH^T)
    # So d tr(Sigma) = -tr(Sigma * dJ * Sigma) = -2 * weight * p1 * p0 *
    #                  H^T Sigma^2 dH
    grad = -2.0 * p1 * p0 * (Sigma @ Sigma @ H)  # (d_theta,)
    # Project onto dH/dq_x0: dtr/dq_x0 = grad @ dH_dq
    return grad @ dH_dq, dH_dq


def main():
    print("=" * 72, flush=True)
    print("Variance-optimal GFD: trace-variance reduction (Theorem 6 demo)",
          flush=True)
    print("=" * 72, flush=True)

    print("\n[1/4] DGP and target initial states ...", flush=True)
    t0 = time.time()
    dgp = build_game_dgp()
    F_p0 = dgp['F_p0']
    S = F_p0.shape[1]
    A = 2
    rho = 2
    d_theta = dgp['dpi_p0'].shape[-1]
    print(f"      S = {S}, A = {A}, rho = {rho}, d_theta = {d_theta}",
          flush=True)
    target_states = [3, 9, 12, 17, 21]
    weights = np.ones(len(target_states)) / len(target_states)
    print(f"      Target x_0: {target_states} (uniform weights)",
          flush=True)
    print(f"      DGP build: {time.time() - t0:.2f}s", flush=True)

    print(f"\n[2/4] Pre-computing Phi_MP and null spaces ...", flush=True)
    t0 = time.time()
    caches = [precompute_state(x0, dgp, S, A, rho) for x0 in target_states]
    print(f"      Per-state d_q: {[c['d_q'] for c in caches]}", flush=True)
    print(f"      Pre-computation: {time.time() - t0:.2f}s", flush=True)

    # H at Phi_MP and J_MP
    n_j = S ** rho
    n_k = A ** rho
    H_MP = np.array([H_at_x(c['x_MP'], c['x0'], n_j, n_k,
                            dgp['beta'], dgp, S, A, rho) for c in caches])
    J_MP = np.zeros((d_theta, d_theta))
    for i, c in enumerate(caches):
        x0 = c['x0']
        p1 = dgp['P_eq_p0'][x0, 1]
        p0 = dgp['P_eq_p0'][x0, 0]
        J_MP += weights[i] * p1 * p0 * np.outer(H_MP[i], H_MP[i])
    Sigma_MP = pinv(J_MP, atol=1e-14, rtol=1e-14)
    tr_MP = np.trace(Sigma_MP)
    print(f"\n[3/4] At canonical Phi_MP (q=0):", flush=True)
    print(f"      tr(Sigma_MP) = {tr_MP:.6e}", flush=True)
    print(f"      eig(J_MP)    = {np.round(np.linalg.eigvalsh(J_MP), 6)}",
          flush=True)

    # Compute one-step gradient descent from q=0 in each x_0 independently
    print(f"\n[4/4] Computing analytic gradient at q=0 and one-step descent ...",
          flush=True)
    t0 = time.time()
    # Build the Jacobian dH/dphi for each state once
    J_dphi_per_state = []
    for x0 in target_states:
        J_dphi_per_state.append(H_jacobian_wrt_phi(x0, dgp['beta'], dgp,
                                                    S, A, rho))
    print(f"      H Jacobians built: {time.time() - t0:.2f}s", flush=True)

    # For each state, compute partial gradient and update q_x0 in -grad direction
    grads = []
    for i, c in enumerate(caches):
        # weighted partial: weights[i] * d/d q_x0 [tr(Sigma)]
        # since J_total decomposes additively across states, the partial w.r.t. q_x0
        # only changes the i-th state's H_x H_x^T contribution.
        x0 = c['x0']
        p1 = dgp['P_eq_p0'][x0, 1]
        p0 = dgp['P_eq_p0'][x0, 0]
        # dH/dq_x0 = [J_dphi, -J_dphi] @ N_x0
        J_full = np.concatenate([J_dphi_per_state[i], -J_dphi_per_state[i]],
                                axis=1)
        dH_dq = J_full @ c['N']  # (d_theta, d_q_x0)
        H_i = H_MP[i]
        # d/dq_x0 of tr(Sigma) at current Sigma: -weights[i] * p1 * p0 * 2 *
        # (Sigma_MP @ Sigma_MP @ H_i) @ dH_dq
        coef = -2.0 * weights[i] * p1 * p0
        grad_xi = coef * (Sigma_MP @ Sigma_MP @ H_i) @ dH_dq
        grads.append(grad_xi)
    grad_norms = [np.linalg.norm(g) for g in grads]
    print(f"      Per-state ||∇_{{q_x0}} tr(Sigma)||: "
          f"{np.round(grad_norms, 4)}", flush=True)

    # One step in -grad direction with fixed step size eta
    eta_grid = [1e-4, 1e-3, 1e-2, 1e-1]
    print(f"\n      Trying descent step sizes: {eta_grid}", flush=True)
    print(f"\n      {'eta':<10} {'tr(Sigma_eta)':<16} "
          f"{'reduction':<12}", flush=True)
    print(f"      {'---':<10} {'---':<16} {'---':<12}", flush=True)
    best_red = -np.inf
    best_eta = None
    for eta in eta_grid:
        # Build perturbed H
        H_eta = []
        for i, c in enumerate(caches):
            q_x0 = -eta * grads[i]
            x_pert = c['x_MP'] + c['N'] @ q_x0
            H_eta.append(H_at_x(x_pert, c['x0'], n_j, n_k,
                                 dgp['beta'], dgp, S, A, rho))
        H_eta = np.array(H_eta)
        # Build J at perturbed Phi
        J_eta = np.zeros((d_theta, d_theta))
        for i, c in enumerate(caches):
            x0 = c['x0']
            p1 = dgp['P_eq_p0'][x0, 1]
            p0 = dgp['P_eq_p0'][x0, 0]
            J_eta += weights[i] * p1 * p0 * np.outer(H_eta[i], H_eta[i])
        Sigma_eta = pinv(J_eta, atol=1e-14, rtol=1e-14)
        tr_eta = np.trace(Sigma_eta)
        red = (tr_MP - tr_eta) / tr_MP
        marker = "  <-- best" if red > best_red else ""
        if red > best_red:
            best_red = red
            best_eta = eta
        print(f"      {eta:<10.0e} {tr_eta:<16.6e} {red:<12.4%}"
              f"{marker}", flush=True)

    print("\n" + "=" * 72, flush=True)
    print(f"Summary: best descent step at eta = {best_eta:.0e}",
          flush=True)
    print(f"  tr(Sigma_MP)  = {tr_MP:.6e}", flush=True)
    print(f"  tr(Sigma_eta) = {tr_MP * (1 - best_red):.6e}", flush=True)
    print(f"  Reduction     = {best_red:.4%}  "
          f"(strict improvement over canonical input)", flush=True)
    print("\nNotes:", flush=True)
    print("  * Theorem 6 (FD-class trace optimality, Section 4.4) asserts that",
          flush=True)
    print("    tr(Sigma(Phi(q))) is generically minimized at some q_opt strictly",
          flush=True)
    print("    different from q = 0 (the Moore-Penrose anchor).", flush=True)
    print("  * This script verifies the FOC version: at q=0, the analytic",
          flush=True)
    print("    gradient ∇_q tr(Sigma) is non-zero, and a single descent step",
          flush=True)
    print("    strictly decreases the trace asymptotic variance.", flush=True)
    print("  * The full optimum q_opt requires multi-step descent (or a",
          flush=True)
    print("    bounded sub-region for finiteness, since unconstrained scaling",
          flush=True)
    print("    of q drives tr(Sigma) -> 0). The variance-optimal Monte Carlo",
          flush=True)
    print("    in Section 6.2 (Table 3) implements this.", flush=True)
    print("=" * 72, flush=True)


if __name__ == "__main__":
    main()
