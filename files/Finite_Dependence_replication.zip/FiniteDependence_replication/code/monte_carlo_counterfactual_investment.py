"""
Counterfactual Monte Carlo for the single-agent investment model.

Empirically demonstrates Theorem 2 (Bellman-free counterfactual CCPs).
For each counterfactual structural parameter θ_1 we compute the new
equilibrium CCPs two ways:

  (i) GFD bridge (Theorem 2):
        p^{(m+1)} = Λ( ṽ^{ρ-FD}( · ; θ_1, Φ, p^{(m)} ) )
      with Φ FROZEN at the canonical Moore-Penrose flow input
      pre-computed from the baseline transition.  No Bellman re-solve
      per θ.

 (ii) NFXP gold standard:
        Solve the Bellman fixed-point at θ_1 via value-function
        iteration.  Yields the ground-truth equilibrium CCPs.

The exercise mimics a typical applied counterfactual exercise: take a
fitted DDC model and ask what CCPs would prevail under K alternative
policy regimes (here a sweep over investment-cost parameter
θ^{cost}).  GFD pays the Φ-build cost ONCE; NFXP pays a Bellman
re-solve PER counterfactual θ.  As K grows, GFD's amortized per-θ cost
strictly dominates.

Usage:
    python monte_carlo_counterfactual.py
    python monte_carlo_counterfactual.py --quick
"""
from __future__ import annotations

import sys, os, time, argparse, csv
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np

from UnifiedFDSolver import UnifiedFDSolver
import monte_carlo_investment as mci
from monte_carlo_investment import (
    BETA, N_ACTIONS, THETA_TRUE,
    build_transition_matrix, compute_payoff_matrix,
    solve_equilibrium, build_phi_cache, compute_payoff_investment,
    build_capital_transition, tauchen_discretization,
    DELTA, RHO_PRODUCTIVITY, SIGMA_PRODUCTIVITY, N_CAPITAL,
)


# ============================================================================
# GFD bridge: counterfactual CCPs without Bellman re-solve
# ============================================================================

def gfd_bridge_counterfactual_ccp(theta_1, F, z, cache, K_ref=0,
                                    P_init=None, tol=1e-8, max_iter=200):
    """Compute counterfactual CCPs at θ_1 via the Theorem 2 bridge.

    The flow-cache `cache` is built ONCE from the baseline transition F
    and frozen across the iteration.  Per iteration we form the GFD
    pseudo value-difference and apply the multinomial-logit map Λ.

    Returns (P_final, elapsed_seconds, n_outer_iters).
    """
    t0 = time.time()
    A = N_ACTIONS
    S = F.shape[1]
    u_th = np.einsum('sar,r->sa', z, theta_1)      # (S, A) — payoff at θ_1

    # Initial CCP iterate
    if P_init is None:
        P = np.ones((A, S)) / A
    else:
        P = P_init.copy()

    # cache[(x0, k)] is Δφ for action k vs K_ref at initial state x0.
    # Shape: (S, A) — index into next-state and action distribution.
    # We pre-stack cache into a (S, A, S, A) tensor for vectorised lookup.
    dphi_tensor = np.zeros((S, A, S, A))
    for x0 in range(S):
        for k in range(A):
            if k == K_ref:
                continue
            dphi_tensor[x0, k] = cache[(x0, k)]

    EULER = 0.5772156649

    for it in range(max_iter):
        # Hotz-Miller correction at current P
        # ψ_a(s) = γ_E - log p_a(s)
        log_P = np.log(np.clip(P, 1e-12, 1.0))    # (A, S)
        psi = EULER - log_P                        # (A, S)
        u_plus_psi = u_th + psi.T                  # (S, A) flow + correction

        # GFD pseudo value-difference: ṽ(s, k) - ṽ(s, K_ref)
        # = u(s, k) - u(s, K_ref)
        #   + β Σ_{s', a'} Δφ[s, k, s', a'] * (u(s', a') + ψ_{a'}(s'))
        fd_diff = np.zeros((S, A))
        for k in range(A):
            if k == K_ref:
                continue
            fd_diff[:, k] = u_th[:, k] - u_th[:, K_ref]
            fd_diff[:, k] += BETA * np.einsum('xsa,sa->x',
                                               dphi_tensor[:, k],
                                               u_plus_psi)
        # K_ref column stays 0 by normalisation.

        # Multinomial logit: p(k|s) = exp(fd_diff[s,k]) / Σ_a exp(fd_diff[s,a])
        v_max = fd_diff.max(axis=1, keepdims=True)
        ev = np.exp(fd_diff - v_max)
        P_new = (ev / ev.sum(axis=1, keepdims=True)).T   # (A, S)

        if np.max(np.abs(P_new - P)) < tol:
            P = P_new
            return P, time.time() - t0, it + 1
        P = P_new

    return P, time.time() - t0, max_iter


# ============================================================================
# NFXP: Bellman re-solve at θ_1
# ============================================================================

def nfxp_counterfactual_ccp(theta_1, F, z):
    """Solve Bellman fixed-point at θ_1 via value-function iteration."""
    t0 = time.time()
    V, P = solve_equilibrium(theta_1, F, z)
    return P, time.time() - t0


# ============================================================================
# Counterfactual MC harness
# ============================================================================

THETA_BASELINE = np.array([THETA_TRUE['theta_rev'],
                             THETA_TRUE['theta_cost'],
                             THETA_TRUE['theta_adj']])


def make_counterfactual_grid(scales_cost=(1.5, 2.0, 3.0, 5.0),
                              scales_adj=(0.5, 0.0, -0.5)):
    """Build a grid of K counterfactual θ_1 values around THETA_BASELINE.

    For each cost-scale and adj-scale combination we shift θ from baseline:
        θ_1 = (θ^{rev}, scale_cost * θ^{cost}, θ^{adj} + scale_adj * |θ^{adj}|)
    Returns list of (label, θ_1)."""
    out = []
    th = THETA_BASELINE
    out.append(("baseline", th.copy()))
    for sc in scales_cost:
        th1 = th.copy()
        th1[1] = sc * th[1]
        out.append((f"cost×{sc}", th1))
    for sa in scales_adj:
        th1 = th.copy()
        th1[2] = th[2] + sa * abs(th[2])
        out.append((f"adj+{sa}|adj|", th1))
    return out


def build_investment_at_z(Z):
    """Rebuild investment-model objects (F, z-payoff basis, T_endo, T_prod,
    cache) at productivity-grid size Z, overriding the module-level
    N_PRODUCTIVITY = 4 default.  This lets the counterfactual sweep run
    across multiple state-space sizes without reloading."""
    M = N_CAPITAL
    S = M * Z
    o_grid, T_prod = tauchen_discretization(RHO_PRODUCTIVITY,
                                              SIGMA_PRODUCTIVITY, Z)
    T_endo = np.zeros((N_ACTIONS, M, M))
    for a in range(N_ACTIONS):
        for k in range(M):
            T_endo[a, k, :] = build_capital_transition(k, a, DELTA)
    F = np.zeros((N_ACTIONS, S, S))
    for a in range(N_ACTIONS):
        for k in range(M):
            for o in range(Z):
                s = k * Z + o
                for kn in range(M):
                    for on in range(Z):
                        F[a, s, kn * Z + on] = T_endo[a, k, kn] * T_prod[o, on]
    # Payoff basis z (S, A, 3): must match _compute_payoff_matrix at this Z
    # We compute it inline to avoid touching the module global.
    Z_basis = np.zeros((S, N_ACTIONS, 3))
    INVESTMENT_AMOUNTS = mci.INVESTMENT_AMOUNTS
    for s in range(S):
        k_idx, o_idx = divmod(s, Z)
        o_val = o_grid[o_idx]
        for a in range(N_ACTIONS):
            Z_basis[s, a, 0] = o_val * k_idx       # revenue
            Z_basis[s, a, 1] = INVESTMENT_AMOUNTS[a] ** 2  # cost
            Z_basis[s, a, 2] = (INVESTMENT_AMOUNTS[a]
                                if INVESTMENT_AMOUNTS[a] > 0 else 0.0)  # adj
    # Temporarily patch module globals so build_phi_cache + solve_equilibrium
    # build constraints at the right size.
    mci.N_PRODUCTIVITY = Z
    mci.N_STATES = S
    cache = build_phi_cache(F, K_ref=0, T_endo=T_endo, T_prod=T_prod)
    return F, Z_basis, T_endo, T_prod, cache, S


def run_counterfactual_mc(n_reps=5, save_path=None, Z_values=(4, 10, 20, 40)):
    """Sweep over Z (productivity-grid size) and run the counterfactual
    grid at each Z.  Records per-Z aggregate timing to show how the
    GFD-vs-NFXP gap widens with state-space size."""
    print(f"Counterfactual MC: state-space scaling sweep, "
          f"M = N_capital = {N_CAPITAL} fixed; Z ∈ {Z_values}")
    print()

    grid = make_counterfactual_grid()
    K = len(grid)
    all_results = []

    print(f"{'Z':>3} {'S=MZ':>5} {'K':>3} | "
          f"{'NFXP sweep':>11} {'GFD sweep':>11} "
          f"{'Φ setup':>9} {'GFD/iter':>10} | {'speedup':>9}")
    print("-" * 80)
    for Z in Z_values:
        F, z_basis, T_endo, T_prod, cache, S = build_investment_at_z(Z)
        # GFD Φ setup
        t0 = time.time()
        cache = build_phi_cache(F, K_ref=0, T_endo=T_endo, T_prod=T_prod)
        t_phi_setup = time.time() - t0

        # Per regime: NFXP and GFD timings
        nfxp_total = 0.0
        gfd_total = 0.0
        gfd_iters_total = 0
        err_max = 0.0
        for label, th_1 in grid:
            nfxp_reps = []
            for _ in range(n_reps):
                _, t_nf = nfxp_counterfactual_ccp(th_1, F, z_basis)
                nfxp_reps.append(t_nf)
            nfxp_total += np.mean(nfxp_reps)

            # Gold standard CCPs once
            P_gold, _ = nfxp_counterfactual_ccp(th_1, F, z_basis)

            gfd_reps = []
            iters = []
            for _ in range(n_reps):
                P_init = np.ones((N_ACTIONS, S)) / N_ACTIONS
                P_gfd, t_gfd, n_it = gfd_bridge_counterfactual_ccp(
                    th_1, F, z_basis, cache, K_ref=0, P_init=P_init,
                    max_iter=500)
                gfd_reps.append(t_gfd)
                iters.append(n_it)
            gfd_total += np.mean(gfd_reps)
            gfd_iters_total += int(np.mean(iters))
            err_max = max(err_max, np.max(np.abs(P_gfd - P_gold)))

        gfd_total_amortized = t_phi_setup + gfd_total
        speedup = nfxp_total / gfd_total_amortized
        gfd_per_iter = gfd_total / max(gfd_iters_total, 1)
        print(f"{Z:>3} {S:>5} {K:>3} | "
              f"{nfxp_total*1000:>9.1f}ms "
              f"{gfd_total_amortized*1000:>9.1f}ms "
              f"{t_phi_setup*1000:>7.1f}ms "
              f"{gfd_per_iter*1e6:>8.1f}μs | "
              f"{speedup:>7.2f}×")
        all_results.append({
            'Z': Z, 'S': S, 'K_regimes': K,
            'nfxp_sweep_s': nfxp_total,
            'gfd_sweep_s': gfd_total_amortized,
            'phi_setup_s': t_phi_setup,
            'gfd_per_iter_us': gfd_per_iter * 1e6,
            'speedup': speedup,
            'max_sup_err': err_max,
        })
    print("-" * 80)

    if save_path:
        with open(save_path, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=list(all_results[0].keys()))
            w.writeheader()
            for r in all_results:
                w.writerow(r)
        print(f"\nWrote {save_path}")
    return all_results


def _run_single_state_counterfactual_mc(n_reps=5, save_path=None):
    """Run the counterfactual sweep, averaging GFD bridge wall-clock over
    n_reps repetitions to smooth Python noise.  NFXP is deterministic at
    each θ so its time is reported as a single measurement."""

    F, o_grid, T_endo, T_prod = build_transition_matrix()
    z = compute_payoff_matrix(o_grid)
    print(f"Investment model: S = {N_STATES} = {T_endo.shape[1]}×{T_prod.shape[0]}, "
          f"A = {N_ACTIONS}, ρ = 1")
    print(f"Baseline θ = {THETA_BASELINE}")
    print()

    # Build Φ-cache ONCE from baseline transitions (this is the upfront
    # cost GFD amortizes across counterfactuals).
    t0 = time.time()
    cache_struct = build_phi_cache(F, K_ref=0, T_endo=T_endo, T_prod=T_prod)
    t_phi_setup = time.time() - t0
    print(f"Φ-cache build (structured Kronecker mode, one-time): "
          f"{t_phi_setup*1000:.1f}ms")
    print()

    grid = make_counterfactual_grid()
    print(f"Counterfactual grid: {len(grid)} regimes")
    print(f"  baseline + cost ∈ {{1.5×, 2×, 3×, 5×}} + adj ∈ {{+0.5, 0, -0.5}}|adj|")
    print()
    print(f"{'regime':<14} {'NFXP (ms)':>10} {'GFD bridge (ms)':>16} "
          f"{'iter':>5} {'sup-norm err':>14} {'speedup':>9}")
    print("-" * 80)

    results = []
    for label, th_1 in grid:
        # NFXP gold standard
        P_gold, t_nfxp_solo = nfxp_counterfactual_ccp(th_1, F, z)

        # GFD bridge (multiple reps, average)
        gfd_times = []
        gfd_iters = []
        gfd_errs = []
        for rep in range(n_reps):
            P_init = np.ones((N_ACTIONS, N_STATES)) / N_ACTIONS
            P_gfd, t_gfd, n_iter = gfd_bridge_counterfactual_ccp(
                th_1, F, z, cache_struct, K_ref=0, P_init=P_init)
            gfd_times.append(t_gfd)
            gfd_iters.append(n_iter)
            gfd_errs.append(np.max(np.abs(P_gfd - P_gold)))

        # NFXP rep'd too for fair timing
        nfxp_times = []
        for rep in range(n_reps):
            _, t_nf = nfxp_counterfactual_ccp(th_1, F, z)
            nfxp_times.append(t_nf)

        t_gfd_mean = np.mean(gfd_times)
        t_nfxp_mean = np.mean(nfxp_times)
        err_mean = np.mean(gfd_errs)
        speedup = t_nfxp_mean / t_gfd_mean
        n_iter_mean = np.mean(gfd_iters)
        print(f"{label:<14} {t_nfxp_mean*1000:>9.2f}  "
              f"{t_gfd_mean*1000:>14.2f}  {n_iter_mean:>5.0f}  "
              f"{err_mean:>14.2e}  {speedup:>7.2f}×")
        results.append({
            'regime': label,
            'theta': th_1.tolist(),
            'nfxp_time_s': t_nfxp_mean,
            'gfd_time_s': t_gfd_mean,
            'gfd_iter': n_iter_mean,
            'gfd_err_sup': err_mean,
            'speedup': speedup,
        })

    # Amortization summary
    K = len(grid)
    nfxp_total = sum(r['nfxp_time_s'] for r in results)
    gfd_total_amortized = t_phi_setup + sum(r['gfd_time_s'] for r in results)
    print("-" * 80)
    print(f"Sweep total ({K} regimes):")
    print(f"  NFXP: {nfxp_total*1000:.1f}ms (Bellman re-solve per regime)")
    print(f"  GFD:  {gfd_total_amortized*1000:.1f}ms "
          f"(= {t_phi_setup*1000:.0f}ms Φ-setup ONCE + "
          f"{(gfd_total_amortized-t_phi_setup)*1000:.1f}ms bridge iters)")
    print(f"  GFD speedup over full sweep: "
          f"{nfxp_total/gfd_total_amortized:.2f}×")

    if save_path:
        with open(save_path, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=list(results[0].keys()))
            w.writeheader()
            for r in results:
                w.writerow(r)
        print(f"\nWrote {save_path}")
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--quick', action='store_true',
                        help='2 reps per regime')
    parser.add_argument('--reps', type=int, default=None)
    parser.add_argument('--save', type=str,
                        default='data/mc_counterfactual.csv')
    args = parser.parse_args()
    n_reps = args.reps if args.reps else (2 if args.quick else 10)
    run_counterfactual_mc(n_reps=n_reps, save_path=args.save)
