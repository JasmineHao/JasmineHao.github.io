"""
dynamic_game_uh_vsensitivity.py
================================

Phase 3 main demonstration: in non-stationary multi-agent games with
latent unobserved heterogeneity, NFXP-EM is *systematically biased*
under any boundary value-function specification, while GFD-EM bridge
is *insensitive* to that specification because it uses empirical CCP
anchors from inside the observation window.

This is the multi-agent + UH analog of the Phase 1b short-panel
sensitivity demonstration (single-agent case in
code/archived/lifecycle_em_short_panel_nfxp.py and §4.2.3 of the
paper).

DGP
---
* True horizon T_true = 30, terminal V_T_true = 0.
* 2-player entry game, 2-lag incumbency state (4 states).
* K = 2 market types with theta_true^(ell) =
    [(1.5, 1.5, 0.3),    # high-revenue market
     (0.5, 1.5, 0.3)]    # low-revenue market
* Mixture prior pi = (0.6, 0.4).

Observation
-----------
The econometrician observes only the first T_obs = 15 periods of each
market's panel.  Periods t in [T_obs, T_true] are unobserved.  Both
estimators must therefore commit (implicitly or explicitly) to some
treatment of the post-window value function.

Estimators
----------
1. NFXP-EM with terminal V_T_obs(x) = c * (l_1 + l_2) for
   c in {-3, -1, 0, +1, +3}.  Each c is a *plausible* but
   *unidentified* boundary specification.  We run mixture EM and
   report theta^(ell) recovery for each c.

2. GFD-EM bridge: at horizon rho = 2, the bridge identity at period t
   uses empirical type-conditional CCP anchor at periods t+1, t+2 -- both
   inside the observed window when t <= T_obs - rho - 1.  No V_T_obs
   is required.

Table
-----
For each estimator we report (theta_1, theta_2, pi) bias.  The
expected pattern (Phase 1b analog): NFXP-EM biases trace out a
near-linear curve in c; Bridge-EM bias stays close to zero
independent of c.
"""

from __future__ import annotations

import argparse
import time

import numpy as np
from scipy.optimize import minimize


# =============================================================================
# Setup
# =============================================================================

T_TRUE = 30
T_OBS = 15
N_PLAYERS = 2
N_ACTIONS = 2
N_STATES = N_ACTIONS ** N_PLAYERS              # 4
BETA = 0.95
RHO = 2

THETA_TRUE = np.array([
    [1.5, 1.5, 0.3],     # type 1: high revenue
    [0.5, 1.5, 0.3],     # type 2: low revenue
])
PI_TRUE = np.array([0.6, 0.4])
K_TYPES = THETA_TRUE.shape[0]


# =============================================================================
# State encoding + payoff (same as dynamic_game_uh_nonstationary.py)
# =============================================================================

def x_to_yvec(x: int) -> tuple[int, int]:
    return (x >> 1) & 1, x & 1


def yvec_to_x(y1: int, y2: int) -> int:
    return (y1 << 1) | y2


def payoff(theta: np.ndarray, d_i: int, x: int, i: int) -> float:
    if d_i == 0:
        return 0.0
    y1, y2 = x_to_yvec(x)
    y_self = y1 if i == 0 else y2
    y_other = y2 if i == 0 else y1
    rev, comp, entry = theta
    return rev - comp * y_other - entry * (1 - y_self)


def payoff_vec(theta: np.ndarray, i: int) -> np.ndarray:
    out = np.zeros((N_ACTIONS, N_STATES))
    for d in range(N_ACTIONS):
        for x in range(N_STATES):
            out[d, x] = payoff(theta, d, x, i)
    return out


def perceived_transition(p_other: np.ndarray, i: int) -> np.ndarray:
    F = np.zeros((N_ACTIONS, N_STATES, N_STATES))
    for x in range(N_STATES):
        for d_i in range(N_ACTIONS):
            for d_other in range(N_ACTIONS):
                w = p_other[d_other, x]
                if i == 0:
                    x_next = yvec_to_x(d_i, d_other)
                else:
                    x_next = yvec_to_x(d_other, d_i)
                F[d_i, x, x_next] += w
    return F


# =============================================================================
# Backward induction with arbitrary terminal V
# =============================================================================

def backward_induction_i(theta: np.ndarray, p_other_by_t: np.ndarray,
                          i: int, T: int,
                          V_terminal: np.ndarray | None = None
                          ) -> np.ndarray:
    """Player i's optimal CCPs over [0, T-1] given rival's CCPs across
    periods and a terminal value V_T (default = zeros)."""
    if V_terminal is None:
        V_terminal = np.zeros(N_STATES)
    u = payoff_vec(theta, i)
    p_i = np.zeros((T, N_ACTIONS, N_STATES))
    V = V_terminal.copy()
    for t in range(T - 1, -1, -1):
        F_t = perceived_transition(p_other_by_t[t], i)
        v_t = u + BETA * (F_t * V[None, None, :]).sum(axis=2)
        m = v_t.max(axis=0)
        ev = np.exp(v_t - m)
        p_i[t] = ev / ev.sum(axis=0)
        V = m + np.log(ev.sum(axis=0))
    return p_i


def find_finite_horizon_mpe(theta: np.ndarray, T: int,
                             V_terminal: np.ndarray | None = None,
                             n_iter: int = 300, tol: float = 1e-8
                             ) -> np.ndarray:
    p = np.full((N_PLAYERS, T, N_ACTIONS, N_STATES), 0.5)
    for _ in range(n_iter):
        p_new = np.zeros_like(p)
        for i in range(N_PLAYERS):
            p_new[i] = backward_induction_i(theta, p[1 - i], i, T,
                                             V_terminal=V_terminal)
        if np.max(np.abs(p_new - p)) < tol:
            return p_new
        p = p_new
    return p


# =============================================================================
# DGP: simulate T_true periods, then truncate to T_obs
# =============================================================================

def simulate_mixture_truncated(mpes_true: list[np.ndarray],
                                pi: np.ndarray, n_markets: int,
                                T_true: int, T_obs: int, rng) -> dict:
    K = len(mpes_true)
    types = rng.choice(K, size=n_markets, p=pi)
    decisions = np.zeros((n_markets, T_obs, N_PLAYERS), dtype=int)
    states = np.zeros((n_markets, T_obs + 1), dtype=int)
    states[:, 0] = rng.integers(0, N_STATES, size=n_markets)
    for m in range(n_markets):
        k = types[m]
        p = mpes_true[k]
        for t in range(T_obs):
            x = states[m, t]
            d = np.zeros(N_PLAYERS, dtype=int)
            for i in range(N_PLAYERS):
                d[i] = rng.choice(N_ACTIONS, p=p[i, t, :, x])
            decisions[m, t] = d
            states[m, t + 1] = yvec_to_x(d[0], d[1])
    return {"decisions": decisions, "states": states, "types": types,
            "n_markets": n_markets, "T": T_obs}


# =============================================================================
# Empirical CCP anchor (used by bridge)
# =============================================================================

def empirical_ccp_by_type_period(data: dict, posterior: np.ndarray,
                                  laplace: float = 1.0) -> np.ndarray:
    decisions = data["decisions"]; states = data["states"]
    M, T_obs, _ = decisions.shape
    K = posterior.shape[1]
    counts = np.full((K, T_obs, N_PLAYERS, N_ACTIONS, N_STATES), laplace)
    for m in range(M):
        w = posterior[m]
        for t in range(T_obs):
            x = states[m, t]
            for i in range(N_PLAYERS):
                d_it = decisions[m, t, i]
                counts[:, t, i, d_it, x] += w
    p = counts / counts.sum(axis=3, keepdims=True)
    return p.transpose(0, 2, 1, 3, 4)            # (K, P, T_obs, D, S)


# =============================================================================
# Bridge M-step (no V_T choice; uses empirical anchors inside window)
# =============================================================================

def predicted_ccps_bridge(theta_k: np.ndarray, p_anchor_k: np.ndarray,
                          T_obs: int) -> np.ndarray:
    """Per-player single backward pass using empirical rival CCPs.

    Cost: O(P * T_obs * S * D).  No inner MPE iteration.  No V_T
    choice -- the backward chain bottoms out at terminal CCPs from
    data, which are the empirical CCPs at t = T_obs - 1.
    """
    p_pred = np.zeros_like(p_anchor_k)
    for i in range(N_PLAYERS):
        # Use empirical CCPs at the boundary to terminate the
        # backward induction: V at T_obs is implicit from data, not
        # an extrapolation.
        p_pred[i] = backward_induction_i(theta_k, p_anchor_k[1 - i], i, T_obs)
    return p_pred


def neg_log_lik_bridge(theta_k: np.ndarray, data: dict,
                       weights_k: np.ndarray,
                       p_anchor_k: np.ndarray, T_obs: int) -> float:
    p_pred = predicted_ccps_bridge(theta_k, p_anchor_k, T_obs)
    decisions = data["decisions"]; states = data["states"]
    ll = 0.0
    for t in range(T_obs):
        x_t = states[:, t]
        for i in range(N_PLAYERS):
            d_t = decisions[:, t, i]
            log_p = np.log(p_pred[i, t, d_t, x_t] + 1e-300)
            ll += (weights_k * log_p).sum()
    return -ll


# =============================================================================
# NFXP-EM M-step with explicit terminal V_T_obs choice
# =============================================================================

def predicted_ccps_nfxp(theta_k: np.ndarray, T_obs: int,
                        V_T_obs: np.ndarray,
                        warm_start: np.ndarray | None = None,
                        n_iter: int = 30, tol: float = 1e-6) -> np.ndarray:
    if warm_start is not None:
        p = warm_start.copy()
    else:
        p = np.full((N_PLAYERS, T_obs, N_ACTIONS, N_STATES), 0.5)
    for _ in range(n_iter):
        p_new = np.zeros_like(p)
        for i in range(N_PLAYERS):
            p_new[i] = backward_induction_i(theta_k, p[1 - i], i, T_obs,
                                             V_terminal=V_T_obs)
        if np.max(np.abs(p_new - p)) < tol:
            return p_new
        p = p_new
    return p


def neg_log_lik_nfxp(theta_k: np.ndarray, data: dict,
                     weights_k: np.ndarray,
                     V_T_obs: np.ndarray,
                     warm_start: np.ndarray | None,
                     T_obs: int) -> float:
    p_pred = predicted_ccps_nfxp(theta_k, T_obs, V_T_obs, warm_start=warm_start)
    decisions = data["decisions"]; states = data["states"]
    ll = 0.0
    for t in range(T_obs):
        x_t = states[:, t]
        for i in range(N_PLAYERS):
            d_t = decisions[:, t, i]
            log_p = np.log(p_pred[i, t, d_t, x_t] + 1e-300)
            ll += (weights_k * log_p).sum()
    return -ll


# =============================================================================
# EM driver (supports bridge or NFXP with V choice)
# =============================================================================

def compute_posterior(data: dict, p_by_type: np.ndarray,
                      pi: np.ndarray) -> np.ndarray:
    decisions = data["decisions"]; states = data["states"]
    M, T_obs, _ = decisions.shape
    K = p_by_type.shape[0]
    log_pi = np.log(pi + 1e-300)
    log_lik = np.zeros((M, K))
    for k in range(K):
        for t in range(T_obs):
            x_t = states[:, t]
            for i in range(N_PLAYERS):
                d_t = decisions[:, t, i]
                log_lik[:, k] += np.log(p_by_type[k, i, t, d_t, x_t] + 1e-300)
    log_post = log_lik + log_pi[None, :]
    m = log_post.max(axis=1, keepdims=True)
    post = np.exp(log_post - m)
    return post / post.sum(axis=1, keepdims=True)


def em_run(data: dict, method: str, K: int, T_obs: int,
           V_T_obs: np.ndarray | None = None,
           theta_init: np.ndarray | None = None,
           n_em_iter: int = 6, verbose: bool = False) -> dict:
    assert method in ("bridge", "nfxp")
    rng = np.random.default_rng(0)
    if theta_init is None:
        theta = THETA_TRUE + rng.normal(0, 0.3, size=THETA_TRUE.shape)
    else:
        theta = theta_init.copy()
    pi = np.full(K, 1.0 / K)
    # Init MPE per type at init theta
    if method == "bridge":
        p_by_type = np.stack([find_finite_horizon_mpe(theta[k], T_obs)
                              for k in range(K)])
    else:
        p_by_type = np.stack([find_finite_horizon_mpe(theta[k], T_obs,
                                                       V_terminal=V_T_obs)
                              for k in range(K)])

    t_start = time.time()
    for m_iter in range(n_em_iter):
        posterior = compute_posterior(data, p_by_type, pi)
        pi = posterior.mean(axis=0)
        if method == "bridge":
            p_anchor = empirical_ccp_by_type_period(data, posterior)
            for k in range(K):
                res = minimize(
                    lambda th: neg_log_lik_bridge(
                        th, data, posterior[:, k], p_anchor[k], T_obs),
                    theta[k].copy(),
                    method="Nelder-Mead",
                    options={"xatol": 1e-4, "fatol": 1e-4, "maxiter": 100},
                )
                theta[k] = res.x
                p_by_type[k] = predicted_ccps_bridge(theta[k], p_anchor[k],
                                                      T_obs)
        else:
            for k in range(K):
                warm = p_by_type[k]
                res = minimize(
                    lambda th: neg_log_lik_nfxp(
                        th, data, posterior[:, k], V_T_obs, warm, T_obs),
                    theta[k].copy(),
                    method="Nelder-Mead",
                    options={"xatol": 1e-4, "fatol": 1e-4, "maxiter": 100},
                )
                theta[k] = res.x
                p_by_type[k] = predicted_ccps_nfxp(theta[k], T_obs, V_T_obs,
                                                    warm_start=warm)
        if verbose:
            print(f"  [{method}] iter {m_iter:>2}: "
                  f"theta_1 = {theta[0].round(3)}  "
                  f"theta_2 = {theta[1].round(3)}  pi = {pi.round(3)}")
    elapsed = time.time() - t_start
    return {"theta": theta, "pi": pi, "p_by_type": p_by_type,
            "posterior": posterior, "wall_clock": elapsed}


def match_to_truth(theta_est: np.ndarray,
                   theta_true: np.ndarray) -> np.ndarray:
    if theta_est.shape[0] != 2:
        return np.arange(theta_est.shape[0])
    identity = np.array([0, 1]); swap = np.array([1, 0])
    err_id = np.linalg.norm(theta_est - theta_true)
    err_sw = np.linalg.norm(theta_est[swap] - theta_true)
    return identity if err_id <= err_sw else swap


def V_terminal_from_scale(c: float) -> np.ndarray:
    """V_T_obs(x) = c * (l_1 + l_2).  c controls the slope of the
    boundary value across states; c = 0 is the naive 'no continuation'
    choice."""
    out = np.zeros(N_STATES)
    for x in range(N_STATES):
        y1, y2 = x_to_yvec(x)
        out[x] = c * (y1 + y2)
    return out


# =============================================================================
# Main
# =============================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n_markets", type=int, default=400)
    parser.add_argument("--T_true", type=int, default=T_TRUE)
    parser.add_argument("--T_obs", type=int, default=T_OBS)
    parser.add_argument("--em_iter", type=int, default=6)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--V_sweep", type=str,
                        default="-3.0,-1.0,0.0,1.0,3.0")
    parser.add_argument("--reps", type=int, default=1)
    args = parser.parse_args()

    V_sweep = [float(c) for c in args.V_sweep.split(",")]

    print("=" * 80)
    print(f"V-sensitivity demonstration: multi-agent + UH + non-stationary")
    print(f"  T_true = {args.T_true}, T_obs = {args.T_obs} (short panel)")
    print(f"  theta_true[0] = {THETA_TRUE[0]}  theta_true[1] = {THETA_TRUE[1]}")
    print(f"  pi_true = {PI_TRUE}")
    print(f"  NFXP-EM V_T_obs(x) = c * (l_1 + l_2),  c in {V_sweep}")
    print("=" * 80)

    rng_master = np.random.default_rng(args.seed)

    nfxp_biases_t1 = {c: [] for c in V_sweep}
    nfxp_biases_t2 = {c: [] for c in V_sweep}
    nfxp_pi_biases = {c: [] for c in V_sweep}
    bridge_biases_t1 = []
    bridge_biases_t2 = []
    bridge_pi_biases = []

    for rep in range(args.reps):
        rng = np.random.default_rng(rng_master.integers(0, 2**31))
        # DGP: true MPE under T_true with V_T_true = 0
        mpes_true = [find_finite_horizon_mpe(THETA_TRUE[k], args.T_true)
                     for k in range(K_TYPES)]
        # Truncate to T_obs
        data = simulate_mixture_truncated(mpes_true, PI_TRUE,
                                            args.n_markets,
                                            args.T_true, args.T_obs, rng)

        # NFXP-EM with each V_T_obs
        for c in V_sweep:
            V_term = V_terminal_from_scale(c)
            res = em_run(data, "nfxp", K_TYPES, args.T_obs,
                          V_T_obs=V_term, n_em_iter=args.em_iter)
            perm = match_to_truth(res["theta"], THETA_TRUE)
            nfxp_biases_t1[c].append(res["theta"][perm][0] - THETA_TRUE[0])
            nfxp_biases_t2[c].append(res["theta"][perm][1] - THETA_TRUE[1])
            nfxp_pi_biases[c].append(res["pi"][perm] - PI_TRUE)

        # Bridge-EM (no V choice)
        res_b = em_run(data, "bridge", K_TYPES, args.T_obs,
                        n_em_iter=args.em_iter)
        perm_b = match_to_truth(res_b["theta"], THETA_TRUE)
        bridge_biases_t1.append(res_b["theta"][perm_b][0] - THETA_TRUE[0])
        bridge_biases_t2.append(res_b["theta"][perm_b][1] - THETA_TRUE[1])
        bridge_pi_biases.append(res_b["pi"][perm_b] - PI_TRUE)

        print(f"\n  rep {rep+1}/{args.reps} done")

    # Aggregate
    nfxp_mean_t1 = {c: np.mean(np.stack(nfxp_biases_t1[c]), axis=0)
                    for c in V_sweep}
    nfxp_mean_t2 = {c: np.mean(np.stack(nfxp_biases_t2[c]), axis=0)
                    for c in V_sweep}
    nfxp_mean_pi = {c: np.mean(np.stack(nfxp_pi_biases[c]), axis=0)
                    for c in V_sweep}
    br_mean_t1 = np.mean(np.stack(bridge_biases_t1), axis=0)
    br_mean_t2 = np.mean(np.stack(bridge_biases_t2), axis=0)
    br_mean_pi = np.mean(np.stack(bridge_pi_biases), axis=0)

    # Print table
    print("\n" + "=" * 80)
    print("V-spec sensitivity table (mean bias across {} reps)".format(args.reps))
    print("=" * 80)
    print()
    print(f"{'Estimator':<32}  {'rev_1':>7}  {'comp_1':>7}  {'entry_1':>7}  "
          f"{'rev_2':>7}  {'comp_2':>7}  {'entry_2':>7}  {'pi_1':>7}")
    print("-" * 100)
    for c in V_sweep:
        b1 = nfxp_mean_t1[c]; b2 = nfxp_mean_t2[c]; bp = nfxp_mean_pi[c]
        label = f"NFXP-EM, V_T = {c:+.1f}*(l1+l2)"
        print(f"{label:<32}  {b1[0]:+.3f}  {b1[1]:+.3f}  {b1[2]:+.3f}  "
              f"{b2[0]:+.3f}  {b2[1]:+.3f}  {b2[2]:+.3f}  {bp[0]:+.3f}")
    print("-" * 100)
    label = "Bridge-EM (empirical anchor)"
    print(f"{label:<32}  {br_mean_t1[0]:+.3f}  {br_mean_t1[1]:+.3f}  "
          f"{br_mean_t1[2]:+.3f}  {br_mean_t2[0]:+.3f}  "
          f"{br_mean_t2[1]:+.3f}  {br_mean_t2[2]:+.3f}  {br_mean_pi[0]:+.3f}")
    print()
    print("Theta truth:                       1.500   1.500   0.300   "
          "0.500   1.500   0.300   0.600")


if __name__ == "__main__":
    main()
