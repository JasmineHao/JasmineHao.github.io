"""
multiplicity_em_synthetic.py
============================

Phase 3 feasibility test: can a GFD-EM mixture estimator recover
(common theta, mixture weights pi, type-conditional CCPs) when the
data are generated from a dynamic game with multiple Markov-perfect
equilibria?

Setup
-----
Symmetric 2-player dynamic entry game.  Each player chooses
d_{i,t} in {0, 1} (exit / enter); state x_t = (y_{1,t}, y_{2,t}) is
the incumbency profile (4 states).  Transition is deterministic:
y_{i,t+1} = d_{i,t}.  Per-period payoff with Type-I EV shocks:

    u_i(d_i = 0, x) = 0
    u_i(d_i = 1, x) = rev - comp * y_{-i} - entry * (1 - y_i)

theta = (rev, comp, entry); discount beta = 0.95.

With strong enough competition penalty `comp`, the symmetric game
admits multiple MPE:
  * "Symmetric coexistence": both players enter with the same
    probability.
  * "Asymmetric dominance pair": player 1 enters often, player 2
    rarely (and the mirror version with roles swapped).

We treat the equilibrium that each market plays as a *latent type*
ell ∈ {1,...,K}, drawn from mixture prior pi.  Across markets,
*structural primitives theta are common* and only the equilibrium
selection differs.  This is the multiplicity-as-UH framework of
Aguirregabiria--Mira 2019 QE.

Estimator
---------
Standard mixture EM with:
  * E-step:  posterior gamma[m, ell] = P(market m plays equilibrium
    ell | data, theta, pi, p^(ell))  using joint log-likelihood over
    both players' decisions.
  * M-step:
      - Update pi = posterior mean.
      - Update type-conditional CCP anchor p^(ell) as posterior-
        weighted cell frequencies (this is the "representative CCP"
        per type).
      - Optimize *common* theta to maximize the bridge-implied
        likelihood: given theta and p^(ell) as the anchor, the
        best-response CCP under that anchor is what each market
        should obey; total likelihood sums over (market, type, time)
        weighted by posterior.

Validation
----------
After EM convergence, compare estimated to truth:
  * pi
  * theta
  * type-conditional CCPs p^(ell)_i(d|x)
  * market-to-equilibrium classification accuracy

If recovery works, GFD-EM bridge for the multiplicity-as-UH setting
is viable.
"""

from __future__ import annotations

import argparse
import time

import numpy as np
from scipy.optimize import minimize


# =============================================================================
# Setup
# =============================================================================

N_PLAYERS = 2
N_ACTIONS = 2
N_STATES = N_ACTIONS ** N_PLAYERS              # 4 = (y1, y2)
BETA = 0.95

# True structural parameters (common across markets / equilibria).
# Choose comp > rev so duopoly payoff is negative -> anti-coordination
# game with multiple MPE: "monopoly for player 1" vs "monopoly for
# player 2" vs (sometimes) a mixed-strategy interior.
THETA_TRUE = np.array([1.0, 2.0, 0.3])         # (rev, comp, entry)


# =============================================================================
# State encoding
# =============================================================================

def x_to_yvec(x: int) -> tuple[int, int]:
    return (x >> 1) & 1, x & 1


def yvec_to_x(y1: int, y2: int) -> int:
    return (y1 << 1) | y2


def payoff(theta: np.ndarray, d_i: int, x: int, i: int) -> float:
    if d_i == 0:
        return 0.0
    y1, y2 = x_to_yvec(x)
    y_self = y1 if i == 0 else y2
    y_other = y2 if i == 0 else y1
    rev, comp, entry = theta
    return rev - comp * y_other - entry * (1 - y_self)


def payoff_vec(theta: np.ndarray, i: int) -> np.ndarray:
    """(D, S) payoff array."""
    out = np.zeros((N_ACTIONS, N_STATES))
    for d in range(N_ACTIONS):
        for x in range(N_STATES):
            out[d, x] = payoff(theta, d, x, i)
    return out


def perceived_transition(p_other: np.ndarray, i: int) -> np.ndarray:
    """Player i's perceived transition after integrating out player -i.

    p_other[d_-i, x] is the rival's CCP in state x.
    Returns F[d_i, x, x'].
    """
    F = np.zeros((N_ACTIONS, N_STATES, N_STATES))
    for x in range(N_STATES):
        for d_i in range(N_ACTIONS):
            for d_other in range(N_ACTIONS):
                w = p_other[d_other, x]
                if i == 0:
                    x_next = yvec_to_x(d_i, d_other)
                else:
                    x_next = yvec_to_x(d_other, d_i)
                F[d_i, x, x_next] += w
    return F


# =============================================================================
# MPE finder: best-response iteration
# =============================================================================

def best_response_i(theta: np.ndarray, p_other: np.ndarray, i: int,
                    max_iter: int = 1000, tol: float = 1e-10) -> np.ndarray:
    """Player i's optimal CCPs holding p_other fixed (Type-I EV)."""
    F_i = perceived_transition(p_other, i)
    u_i = payoff_vec(theta, i)
    V = np.zeros(N_STATES)
    for _ in range(max_iter):
        v_t = u_i + BETA * (F_i * V[None, None, :]).sum(axis=2)
        m = v_t.max(axis=0)
        V_new = m + np.log(np.exp(v_t - m).sum(axis=0))
        if np.max(np.abs(V_new - V)) < tol:
            V = V_new
            break
        V = V_new
    v_t = u_i + BETA * (F_i * V[None, None, :]).sum(axis=2)
    m = v_t.max(axis=0)
    ev = np.exp(v_t - m)
    return ev / ev.sum(axis=0)


def find_mpe(theta: np.ndarray, p_init: np.ndarray,
             max_iter: int = 500, tol: float = 1e-7) -> tuple[np.ndarray, int]:
    """Iterate best responses to convergence.  p_init shape (player, action, state)."""
    p = p_init.copy()
    for it in range(max_iter):
        p_new = np.zeros_like(p)
        for i in range(N_PLAYERS):
            p_new[i] = best_response_i(theta, p[1 - i], i)
        delta = np.max(np.abs(p_new - p))
        p = p_new
        if delta < tol:
            return p, it + 1
    return p, max_iter


def find_distinct_mpe(theta: np.ndarray, n_starts: int = 50,
                      mpe_tol: float = 1e-3, rng=None) -> list[np.ndarray]:
    """Try random starts.  In smooth-logit symmetric games the MPE is
    typically unique; for the multiplicity-as-UH test we use
    construct_two_quasi_equilibria below instead.  Kept for diagnostic
    purposes."""
    if rng is None:
        rng = np.random.default_rng(0)
    mpes = []
    for _ in range(n_starts):
        p_init = rng.dirichlet([1, 1], size=(N_PLAYERS, N_STATES))
        p_init = p_init.transpose(0, 2, 1)
        p_final, _ = find_mpe(theta, p_init, max_iter=300)
        is_new = True
        for mpe in mpes:
            if np.max(np.abs(p_final - mpe)) < mpe_tol:
                is_new = False
                break
        if is_new:
            mpes.append(p_final)
    return mpes


def construct_two_quasi_equilibria(theta: np.ndarray) -> list[np.ndarray]:
    """Construct two distinct CCP profiles representing different
    'equilibrium selections' on the same primitives.  Each is the
    best-response of one player against a *committed deferential*
    strategy of the other (Stackelberg-like dominance equilibrium).

    Equilibrium A: player 1 commits to mostly exit (p_1(1|x) = 0.10),
    player 0 best-responds (will tend to dominate).
    Equilibrium B: roles swapped (player 0 deferential, player 1
    dominates).

    These are NOT exact MPE since the deferential player is not
    best-responding, but they are observationally well-separated and
    behaviourally consistent with the multiplicity-as-UH narrative:
    different markets play different equilibrium selections of the
    same underlying game.
    """
    eps_def = 0.10
    p_def = np.zeros((N_ACTIONS, N_STATES))
    p_def[0, :] = 1 - eps_def      # mostly exit
    p_def[1, :] = eps_def          # rarely enter

    # Equilibrium A: player 1 deferential, player 0 best-responds
    p_a = np.zeros((N_PLAYERS, N_ACTIONS, N_STATES))
    p_a[1] = p_def
    p_a[0] = best_response_i(theta, p_def, 0)

    # Equilibrium B: player 0 deferential, player 1 best-responds
    p_b = np.zeros_like(p_a)
    p_b[0] = p_def
    p_b[1] = best_response_i(theta, p_def, 1)

    return [p_a, p_b]


# =============================================================================
# DGP: mixture over equilibria
# =============================================================================

def simulate_mixture(mpes: list[np.ndarray], pi: np.ndarray,
                     n_markets: int, T: int, rng) -> dict:
    """For each market draw equilibrium ~ pi, then simulate T periods."""
    K = len(mpes)
    types = rng.choice(K, size=n_markets, p=pi)
    decisions = np.zeros((n_markets, T, N_PLAYERS), dtype=int)
    states = np.zeros((n_markets, T + 1), dtype=int)
    states[:, 0] = rng.integers(0, N_STATES, size=n_markets)
    for m in range(n_markets):
        p_mpe = mpes[types[m]]
        for t in range(T):
            x = states[m, t]
            d = np.zeros(N_PLAYERS, dtype=int)
            for i in range(N_PLAYERS):
                d[i] = rng.choice(N_ACTIONS, p=p_mpe[i, :, x])
            decisions[m, t] = d
            states[m, t + 1] = yvec_to_x(d[0], d[1])
    return {"decisions": decisions, "states": states, "types": types,
            "n_markets": n_markets, "T": T}


# =============================================================================
# Mixture EM estimator
# =============================================================================

def compute_posterior(data: dict, p_by_type: np.ndarray,
                      pi: np.ndarray) -> np.ndarray:
    """gamma[m, ell] = P(market m in equilibrium ell | data, theta, pi)."""
    decisions = data["decisions"]; states = data["states"]
    M, T, _ = decisions.shape
    K = p_by_type.shape[0]
    log_pi = np.log(pi + 1e-300)
    log_lik = np.zeros((M, K))
    for k in range(K):
        for t in range(T):
            x_t = states[:, t]
            for i in range(N_PLAYERS):
                d_t = decisions[:, t, i]
                log_lik[:, k] += np.log(p_by_type[k, i, d_t, x_t] + 1e-300)
    log_post = log_lik + log_pi[None, :]
    m = log_post.max(axis=1, keepdims=True)
    post = np.exp(log_post - m)
    return post / post.sum(axis=1, keepdims=True)


def empirical_ccp_by_type(data: dict, posterior: np.ndarray,
                          laplace: float = 1.0) -> np.ndarray:
    """Posterior-weighted cell frequencies per type per player."""
    decisions = data["decisions"]; states = data["states"]
    M, T, _ = decisions.shape
    K = posterior.shape[1]
    counts = np.full((K, N_PLAYERS, N_ACTIONS, N_STATES), laplace)
    for m in range(M):
        for t in range(T):
            x_t = states[m, t]
            for i in range(N_PLAYERS):
                d_it = decisions[m, t, i]
                counts[:, i, d_it, x_t] += posterior[m, :]
    return counts / counts.sum(axis=2, keepdims=True)


def predicted_ccps_under_theta(theta: np.ndarray,
                                p_anchor_k: np.ndarray) -> np.ndarray:
    """Given theta and the type-k CCP anchor of *other* players, compute
    each player's best-response CCPs (single iteration of best response).

    This is the M-step likelihood object: each market is supposed to be
    in equilibrium k, so each player's CCPs equal best-response to the
    other players' k-conditional CCPs.

    Returns (n_players, n_actions, n_states).
    """
    p = np.zeros_like(p_anchor_k)
    for i in range(N_PLAYERS):
        p[i] = best_response_i(theta, p_anchor_k[1 - i], i)
    return p


def neg_log_lik_total(theta: np.ndarray, data: dict,
                      posterior: np.ndarray,
                      p_anchor: np.ndarray) -> float:
    """Sum over (m, ell, t, player) of posterior * log p_pred_ell.

    p_pred[k, i, d, x] computed via best_response with the type-k anchor.
    """
    decisions = data["decisions"]; states = data["states"]
    M, T, _ = decisions.shape
    K = posterior.shape[1]
    p_pred = np.zeros_like(p_anchor)
    for k in range(K):
        p_pred[k] = predicted_ccps_under_theta(theta, p_anchor[k])
    ll = 0.0
    for k in range(K):
        for t in range(T):
            x_t = states[:, t]
            for i in range(N_PLAYERS):
                d_t = decisions[:, t, i]
                log_p = np.log(p_pred[k, i, d_t, x_t] + 1e-300)
                ll += (posterior[:, k] * log_p).sum()
    return -ll


def em_run(data: dict, K: int, theta_init: np.ndarray | None = None,
           n_em_iter: int = 20, verbose: bool = False) -> dict:
    rng = np.random.default_rng(42)
    if theta_init is None:
        theta = THETA_TRUE + rng.normal(0, 0.3, size=THETA_TRUE.shape)
    else:
        theta = theta_init.copy()
    pi = np.full(K, 1.0 / K)
    # Initial anchor: random Dirichlet per type, makes types distinct
    p_anchor = rng.dirichlet([1, 1], size=(K, N_PLAYERS, N_STATES))
    p_anchor = p_anchor.transpose(0, 1, 3, 2)  # (K, P, D, S)
    p_by_type = p_anchor.copy()

    ll_traj = []
    t_start = time.time()
    for m_iter in range(n_em_iter):
        # E-step
        posterior = compute_posterior(data, p_by_type, pi)
        pi = posterior.mean(axis=0)
        # M-step (standard mixture-EM):
        #   - Type-conditional CCPs := posterior-weighted empirical
        #   - This is the bridge "anchor" identification: each type's
        #     CCPs are estimated nonparametrically from data with
        #     posterior weights.
        p_by_type = empirical_ccp_by_type(data, posterior)
        ll = sum_log_lik_under_anchor(data, posterior, p_by_type)
        ll_traj.append(ll)
        if verbose:
            print(f"  EM iter {m_iter:>2}: "
                  f"pi = {pi.round(3)}  ll = {ll:.1f}  "
                  f"p[0,0] = {p_by_type[0, 0, 1, :].round(2)}  "
                  f"p[1,1] = {p_by_type[1, 1, 1, :].round(2)}")
    # Now optimize common theta as a *separate* step using converged
    # type-conditional CCPs as anchors.  Optional structural overlay.
    res = minimize(
        lambda th: neg_log_lik_total(th, data, posterior, p_by_type),
        theta.copy(),
        method="Nelder-Mead",
        options={"xatol": 1e-4, "fatol": 1e-4, "maxiter": 300},
    )
    theta = res.x
    elapsed = time.time() - t_start
    return {
        "theta": theta, "pi": pi, "p_anchor": p_by_type,
        "p_by_type": p_by_type, "posterior": posterior,
        "ll_traj": ll_traj, "wall_clock": elapsed,
    }


def sum_log_lik_under_anchor(data: dict, posterior: np.ndarray,
                              p_anchor: np.ndarray) -> float:
    """Posterior-weighted log-lik using anchor directly (for ll reporting)."""
    decisions = data["decisions"]; states = data["states"]
    K = posterior.shape[1]
    M, T, _ = decisions.shape
    ll = 0.0
    for k in range(K):
        for t in range(T):
            x_t = states[:, t]
            for i in range(N_PLAYERS):
                d_t = decisions[:, t, i]
                log_p = np.log(p_anchor[k, i, d_t, x_t] + 1e-300)
                ll += (posterior[:, k] * log_p).sum()
    return ll


# =============================================================================
# Label matching for K = 2 (avoid label switching artifacts)
# =============================================================================

def match_to_truth(p_est: np.ndarray, p_true: np.ndarray) -> np.ndarray:
    """For K=2, return permutation that aligns estimated to true types."""
    if p_est.shape[0] != 2:
        return np.arange(p_est.shape[0])
    identity = np.array([0, 1]); swap = np.array([1, 0])
    err_id = np.linalg.norm(p_est - p_true)
    err_sw = np.linalg.norm(p_est[swap] - p_true)
    return identity if err_id <= err_sw else swap


# =============================================================================
# Main
# =============================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n_markets", type=int, default=300)
    parser.add_argument("--T", type=int, default=20)
    parser.add_argument("--pi", type=float, default=0.6,
                        help="prior on equilibrium 1; equilibrium 2 gets 1-pi")
    parser.add_argument("--em_iter", type=int, default=20)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    print("=" * 78)
    print("Multiplicity-as-UH synthetic test (2-player entry game, K=2)")
    print(f"  theta_true (common) = {THETA_TRUE}  (rev, comp, entry)")
    print(f"  beta = {BETA}, n_markets = {args.n_markets}, T = {args.T}")
    print("=" * 78)

    rng = np.random.default_rng(args.seed)

    # Step 1: construct two quasi-equilibria for the multiplicity-as-UH demo
    print("\n[1] Constructing two distinct equilibrium selections...")
    mpes = construct_two_quasi_equilibria(THETA_TRUE)
    for k, m_ in enumerate(mpes):
        print(f"    Equilibrium {k}: player 0 enter probs = {m_[0, 1, :].round(3)}")
        print(f"                  player 1 enter probs = {m_[1, 1, :].round(3)}")

    # Step 2: simulate from mixture
    pi_true = np.array([args.pi, 1 - args.pi])
    print(f"\n[2] Simulating {args.n_markets} markets, T = {args.T} each, "
          f"pi_true = {pi_true}")
    data = simulate_mixture(mpes, pi_true, args.n_markets, args.T, rng)
    print(f"    Type prevalence in DGP: "
          f"{np.bincount(data['types']) / args.n_markets}")

    # Step 3: run EM
    print(f"\n[3] Running mixture EM with K=2 latent types, {args.em_iter} iters")
    res = em_run(data, K=2, n_em_iter=args.em_iter, verbose=args.verbose)

    # Step 4: align labels and report
    p_true_stack = np.stack(mpes)
    perm = match_to_truth(res["p_by_type"], p_true_stack)
    pi_est = res["pi"][perm]
    p_est = res["p_by_type"][perm]
    posterior_aligned = res["posterior"][:, perm]

    print(f"\n[4] Results:")
    print(f"    theta_true  = {THETA_TRUE}")
    print(f"    theta_est   = {res['theta'].round(3)}")
    print(f"    theta_bias  = {(res['theta'] - THETA_TRUE).round(3)}")
    print(f"    pi_true     = {pi_true}")
    print(f"    pi_est      = {pi_est.round(3)}")
    print(f"    pi_bias     = {(pi_est - pi_true).round(3)}")

    print(f"\n    CCP recovery (RMSE per type per player):")
    for k in range(2):
        for i in range(N_PLAYERS):
            rmse = np.sqrt(((p_est[k, i] - p_true_stack[k, i]) ** 2).mean())
            print(f"      type {k}, player {i}: RMSE = {rmse:.3f}")

    # Type classification accuracy
    hard_assignment = posterior_aligned.argmax(axis=1)
    accuracy = (hard_assignment == data["types"]).mean()
    print(f"\n    Market->equilibrium classification accuracy: {accuracy:.3f}")
    print(f"    (Hard MAP assignment vs. true type)")

    print(f"\n    Wall-clock: {res['wall_clock']:.1f}s for {args.em_iter} EM iters")
    print(f"    Log-lik final: {res['ll_traj'][-1]:.1f}")


if __name__ == "__main__":
    main()
