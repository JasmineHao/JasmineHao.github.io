"""
Example: Investment Model with Capital Accumulation
=====================================================
3 actions: Depreciate (0), Maintain (1), Invest (2)
State: capital x productivity x Z_lags
Memory: Decay (capital persists), Control: Strong
Expected: rho=1 (strong control offsets decay)

Usage:
    python example_investment.py          # Quick demo (rho=1 only)
    python example_investment.py --full   # Full test (rho=1,2,3)
"""

import numpy as np
import time
import sys, os
import argparse
sys.path.insert(0, os.path.dirname(__file__))
from UnifiedFDSolver import UnifiedFDSolver
from HistoryDependentFDSolver import solve_mdp
from utils import state_transition, my_kron, my_meshgrid


def build_model():
    beta = 0.95
    # Capital grid
    ngrid_k = 5
    k_grid = np.linspace(0.5, 3.0, ngrid_k)

    # Productivity (exogenous AR(1))
    f_o, o_grid = state_transition(0, 0.5, 1.5, 4, min_val=0, max_val=2)

    # Capital transitions (action-dependent)
    f_k_0 = np.zeros((ngrid_k, ngrid_k))  # Depreciate
    for i in range(ngrid_k):
        f_k_0[i, max(i - 1, 0)] = 1.0

    f_k_1 = np.eye(ngrid_k)  # Maintain

    f_k_2 = np.zeros((ngrid_k, ngrid_k))  # Invest
    for i in range(ngrid_k):
        f_k_2[i, min(i + 1, ngrid_k - 1)] = 1.0

    F = np.array([my_kron([f_k_0, f_o]),
                  my_kron([f_k_1, f_o]),
                  my_kron([f_k_2, f_o])])
    n_states = F.shape[1]

    # Payoff: revenue * productivity * sqrt(capital) - cost * action
    state = my_meshgrid([k_grid, o_grid])
    u = np.zeros((3, n_states))
    for a in range(3):
        u[a] = 2.5 * state[:, 1] * np.sqrt(state[:, 0]) - 1.2 * a - 0.8 * a**2

    return F, u, beta, n_states, 3


def run(full=False):
    F, u, beta, n_states, n_actions = build_model()
    V, v, e = solve_mdp(F, u, beta)

    print(f"Investment Model: S={n_states}, A={n_actions}, beta={beta}")
    print(f"  {'rho':>3}  {'case':<28} {'dist':>10} {'payoff_err':>12} {'time':>7}")
    print(f"  {'-'*65}")

    cases = [
        (0, 0, 1, "Depreciate vs Maintain"),
        (0, 0, 2, "Depreciate vs Invest"),
        (0, 1, 2, "Maintain vs Invest"),
        (10, 0, 2, "s10: Deprec vs Invest"),
    ]

    rhos = [1, 2, 3] if full else [1]
    
    for rho in rhos:
        if rho > 1:
            print(f"  [rho={rho}] Building solver (this may take time due to NAC constraints)...")
        else:
            print(f"  [rho={rho}] Building solver...")
        t0 = time.time()
        solver = UnifiedFDSolver(T=F, rho=rho, n_states=n_states, n_actions=n_actions)
        init_time = time.time() - t0
        print(f"          Init time: {init_time:.3f}s")
        
        for s0, k, K, desc in cases:
            true_diff = v[k, s0] - v[K, s0]
            t0 = time.time()
            phi_k, phi_K, dist, ce = solver.solve(s0, k, K)
            solve_time = time.time() - t0
            fd = solver.evaluate_value_difference(phi_k, phi_K, s0, k, K, u, e, beta)
            print(f"  {rho:>3}  {desc:<28} {dist:>10.2e} {abs(fd - true_diff):>12.2e} {solve_time:>6.3f}s")
        print()
    
    if not full:
        print("  (Skipping rho=2,3. Use --full flag to enable)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Investment Model Example')
    parser.add_argument('--full', action='store_true', 
                        help='Run full test including rho=2,3 (slow, may take minutes)')
    args = parser.parse_args()
    run(full=args.full)
