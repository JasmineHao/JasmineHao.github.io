"""
lifecycle_em_am_benchmark.py
============================

Phase 1b (rewritten): GFD-EM vs AM 1998-style bridge under unobserved
heterogeneity in a non-stationary lifecycle DDC.

Why the previous Phase 1b (vs NFXP) was wrong
---------------------------------------------
AM 1998 explicitly does NOT use NFXP / dynamic programming (page 46:
"we do not employ dynamic programming methods"). They use a finite-
dependence bridge identity (their Proposition 1, Eq 5.5-5.7) that
substitutes empirical CCPs for the continuation value, and crucially
exploits shift-register state-flushing to make the terminal
continuation cancel from the value difference. So in their framework
there is no terminal-V to be sensitive to.

The previous Phase 1b's "NFXP terminal-V sensitivity" was attacking a
benchmark AM 1998 already abandoned. The current rewrite attacks the
real benchmark: AM 1998's two-step bridge + MaCurdy (1981) projection
of unobserved heterogeneity onto observables.

What AM 1998 actually does (precise)
------------------------------------
1. State psi_{nt} = (z_{nt}, nu_n eta_n lambda_t omega_t)' where
   z_{nt} = (l_{n,t-rho}, ..., l_{n,t-1}, x'_{nt}). rho = 3 in their
   application.
2. Bridge identity (Eq 5.5): conditional valuation V_k(psi_nt) is
   expressed as the current utility u_k plus rho periods of bridge
   contributions u_0(.) + phi_0(p) + p[q(p)+phi_1(p)-phi_0(p)], plus
   a terminal V_0 term at period rho+1 that CANCELS in the difference
   V_1 - V_0 because shift register makes the two psi histories merge.
3. Type-I extreme value shocks (Sec 6.1) give q(p) = ln[p/(1-p)],
   phi_0(p) = zeta - ln(1-p), phi_1(p) = zeta - ln(p); the dynamic
   selection terms in Eq 5.7 drop out.
4. CCPs p^(s,N)_{knt} are nonparametrically estimated by kernel
   regression on (z_{nt}, nu_n eta_n) (Sec 5.2, Eq 5.9).
5. Individual heterogeneity (nu_n eta_n) is recovered either by
   fixed effects from log-linear residuals (Sec 4.4 Method 1) or by
   MaCurdy-style nonparametric kernel regression on observables x_n
   (Sec 4.4 Method 2, Eq 4.10).

Key limitation: AM 1998's MaCurdy projection (Method 2) ASSUMES
nu_n eta_n is a deterministic function of observables. If true
heterogeneity has dimensions not captured by observables (latent
"types" in the mixture sense), MaCurdy is misspecified.

The GFD-EM contribution
-----------------------
Replace MaCurdy projection with EM-mixture handling of unobserved
discrete types. The bridge identity is the same; the difference is
that GFD-EM treats type membership as latent rather than as a
projection of observables.

DGP (this script)
-----------------
* Finite-horizon T = 10 lifecycle (non-stationary in the sense that
  CCPs vary by t; same bridge identity applies)
* 2 unobserved types with payoff (b_k, g_k):
    type 1: (+1.0, +0.3)  -- high work propensity, increasing in history
    type 2: (-0.5, -0.2)  -- low work propensity, decreasing in history
* Type prior pi = (0.6, 0.4)
* No observable correlated with type -- types are truly LATENT
  (this is where MaCurdy projection breaks)
* 2-lag shift register state, deterministic transitions, |X| = 4
* beta = 0.95, rho = 2 (shift register depth)

Estimators
----------
* AM 1998-bridge-homogeneous:
    bridge identity + empirical CCP anchor + ASSUME HOMOGENEOUS theta
    across all individuals. Single MLE on pooled data.
    -- This is what AM 1998's framework reduces to when MaCurdy
       projection has nothing to project onto (no informative
       observables) or when true heterogeneity is orthogonal to
       observables.
* GFD-EM (K = 2 mixture):
    bridge identity + empirical CCP anchor + EM over latent types.
    Posterior-weighted empirical CCPs per type as anchor.

Output
------
* Bias / RMSE for AM-bridge-homogeneous single-theta estimate vs
  each true type (showing it's biased toward neither and lies in
  between).
* Bias / RMSE for GFD-EM type-conditional theta_1, theta_2, pi
  (showing it correctly recovers heterogeneity).
"""

from __future__ import annotations

import argparse
import os
import sys
import time

import numpy as np
from scipy.optimize import minimize
from scipy.sparse.linalg import lsqr

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fd_linear_system import build_fd_system


# =============================================================================
# Setup
# =============================================================================

T_HORIZON = 10
K_TYPES = 2
N_ACTIONS = 2
N_LAGS = 2
N_STATES = N_ACTIONS ** N_LAGS         # 4
BETA = 0.95
RHO = 2

# theta_k = (b_k, g_k):  u_k(1, x) = b_k + g_k * (l_1 + l_2),  u_k(0, x) = 0
THETA_TRUE = np.array([
    [ 1.0,  0.3],
    [-0.5, -0.2],
])
PI_TRUE = np.array([0.6, 0.4])
THETA_POOLED = (PI_TRUE[:, None] * THETA_TRUE).sum(axis=0)   # population mean


def x_to_lags(x: int) -> tuple[int, int]:
    return (x >> 1) & 1, x & 1


def lags_to_x(l1: int, l2: int) -> int:
    return (l1 << 1) | l2


F_TRANS = np.zeros((N_ACTIONS, N_STATES, N_STATES))
for d in range(N_ACTIONS):
    for x in range(N_STATES):
        l1, l2 = x_to_lags(x)
        F_TRANS[d, x, lags_to_x(d, l1)] = 1.0


def payoff_vec(theta: np.ndarray) -> np.ndarray:
    out = np.zeros((N_ACTIONS, N_STATES))
    b, g = theta
    for x in range(N_STATES):
        l1, l2 = x_to_lags(x)
        out[1, x] = b + g * (l1 + l2)
    return out


# =============================================================================
# Type-conditional CCPs (for DGP only)
# =============================================================================

def backward_bellman(theta: np.ndarray, T: int = T_HORIZON
                      ) -> tuple[np.ndarray, np.ndarray]:
    """Used only to generate DGP CCPs.  Estimators below never call this."""
    u = payoff_vec(theta)
    v = np.zeros((T, N_ACTIONS, N_STATES))
    p = np.zeros((T, N_ACTIONS, N_STATES))
    V_next = np.zeros(N_STATES)
    for t in range(T - 1, -1, -1):
        EV = (F_TRANS * V_next[None, None, :]).sum(axis=2)
        v_t = u + BETA * EV
        m = v_t.max(axis=0, keepdims=True)
        ev = np.exp(v_t - m)
        p_t = ev / ev.sum(axis=0, keepdims=True)
        v[t] = v_t
        p[t] = p_t
        V_next = m.squeeze(0) + np.log(ev.sum(axis=0))
    return v, p


# =============================================================================
# DGP
# =============================================================================

def simulate(N: int, rng: np.random.Generator) -> dict:
    """Generate N agents from the true K-type DGP."""
    types = rng.choice(K_TYPES, size=N, p=PI_TRUE)
    p_by_type_true = np.stack([backward_bellman(THETA_TRUE[k])[1]
                               for k in range(K_TYPES)])
    x = np.zeros((N, T_HORIZON), dtype=int)
    d = np.zeros((N, T_HORIZON), dtype=int)
    x[:, 0] = rng.integers(0, N_STATES, size=N)
    for n in range(N):
        k_n = types[n]
        for t in range(T_HORIZON):
            p_action = p_by_type_true[k_n, t, :, x[n, t]]
            d[n, t] = rng.choice(N_ACTIONS, p=p_action)
            if t + 1 < T_HORIZON:
                l1, l2 = x_to_lags(x[n, t])
                x[n, t + 1] = lags_to_x(d[n, t], l1)
    return {"x": x, "d": d, "types": types, "N": N}


# =============================================================================
# Empirical CCPs (the bridge anchor)
# =============================================================================

def empirical_ccp_pooled(data: dict, laplace: float = 0.5) -> np.ndarray:
    """Pooled empirical CCP per period.  Shape (T, D, S).

    This is the AM 1998 nonparametric anchor when MaCurdy projection
    has no informative observables to condition on -- it reduces to
    pooled cell frequencies.
    """
    N = data["N"]
    x = data["x"]; d = data["d"]
    p = np.full((T_HORIZON, N_ACTIONS, N_STATES), 1.0 / N_ACTIONS)
    for t in range(T_HORIZON):
        for xv in range(N_STATES):
            idx = (x[:, t] == xv)
            n_x = idx.sum()
            if n_x == 0:
                continue
            for dv in range(N_ACTIONS):
                n_dx = (idx & (d[:, t] == dv)).sum()
                p[t, dv, xv] = (n_dx + laplace) / (n_x + laplace * N_ACTIONS)
            p[t, :, xv] /= p[t, :, xv].sum()
    return p


def empirical_ccp_by_type(data: dict, posterior: np.ndarray,
                          laplace: float = 0.5) -> np.ndarray:
    """Posterior-weighted empirical CCPs.  Shape (K, T, D, S)."""
    x = data["x"]; d = data["d"]
    p = np.full((K_TYPES, T_HORIZON, N_ACTIONS, N_STATES),
                1.0 / N_ACTIONS)
    for k in range(K_TYPES):
        w = posterior[:, k]
        for t in range(T_HORIZON):
            for xv in range(N_STATES):
                idx = (x[:, t] == xv)
                w_x = w[idx].sum()
                if w_x < 1e-8:
                    continue
                for dv in range(N_ACTIONS):
                    w_dx = w[idx & (d[:, t] == dv)].sum()
                    p[k, t, dv, xv] = ((w_dx + laplace)
                                       / (w_x + laplace * N_ACTIONS))
                p[k, t, :, xv] /= p[k, t, :, xv].sum()
    return p


# =============================================================================
# Flow weights (cached once)
# =============================================================================

_PHI_CACHE: dict | None = None


def get_phi_cache() -> dict:
    global _PHI_CACHE
    if _PHI_CACHE is not None:
        return _PHI_CACHE
    cache = {}
    for x in range(N_STATES):
        sys_fd = build_fd_system(F_TRANS, s0=x, k=1, K=0, rho=RHO)
        sol = lsqr(sys_fd.A, sys_fd.b, atol=1e-12, btol=1e-12, iter_lim=20000)[0]
        NM = sys_fd.N * sys_fd.M
        phi_k = sol[:NM].reshape(sys_fd.N, sys_fd.M)
        phi_K = sol[NM:].reshape(sys_fd.N, sys_fd.M)
        phi_diff = (phi_k - phi_K).reshape(N_STATES, N_STATES, N_ACTIONS, N_ACTIONS)
        cache[x] = {
            "marg_t1_jk": phi_diff.sum(axis=(1, 3)),
            "full_t2":   phi_diff,
        }
    _PHI_CACHE = cache
    return cache


# =============================================================================
# Bridge identity: v_t(x, 1) - v_t(x, 0) given theta and CCP anchor
# =============================================================================

def bridge_value_diff(theta: np.ndarray, p_anchor: np.ndarray) -> np.ndarray:
    """Bridge identity: returns (T_use, S) value differences.

    Bridge at horizon RHO uses anchor at t+1 and t+2 (shape (T, D, S)).
    The flow weights cancel V terminal under shift-register flushing
    (AM 1998 Proposition 1 mechanism), so no V_terminal needed.

    Usable at t in [0, T_HORIZON - RHO - 1]; for terminal-proximal t
    the bridge degenerates and we fall back to direct value difference
    using the same anchor (consistent treatment as in the previous
    Phase 1b script).
    """
    u = payoff_vec(theta)
    phi = get_phi_cache()
    psi = -np.log(p_anchor + 1e-300)
    dv = np.zeros((T_HORIZON, N_STATES))
    for t in range(T_HORIZON):
        if t + RHO < T_HORIZON:
            for x in range(N_STATES):
                marg_t1 = phi[x]["marg_t1_jk"]
                full_t2 = phi[x]["full_t2"]
                u_plus_psi_t1 = u + psi[t + 1]
                contrib_t1 = (marg_t1 * u_plus_psi_t1.T).sum()
                u_plus_psi_t2 = u + psi[t + 2]
                contrib_t2 = np.einsum('abcd,db->', full_t2, u_plus_psi_t2)
                dv[t, x] = ((u[1, x] - u[0, x])
                            + BETA * contrib_t1
                            + BETA**2 * contrib_t2)
        else:
            # last RHO periods: short-horizon fallback via direct EV
            if t == T_HORIZON - 1:
                dv[t, :] = u[1] - u[0]
            else:
                V = np.zeros(N_STATES)
                for s in range(T_HORIZON - 1, t, -1):
                    if s == T_HORIZON - 1:
                        V_t_actions = u
                    else:
                        EV = (F_TRANS * V[None, None, :]).sum(axis=2)
                        V_t_actions = u + BETA * EV
                    m = V_t_actions.max(axis=0, keepdims=True)
                    V = m.squeeze(0) + np.log(np.exp(V_t_actions - m).sum(axis=0))
                EV0 = (F_TRANS * V[None, None, :]).sum(axis=2)
                v_t_actions = u + BETA * EV0
                dv[t, :] = v_t_actions[1] - v_t_actions[0]
    return dv


def bridge_ccp(theta: np.ndarray, p_anchor: np.ndarray) -> np.ndarray:
    dv = bridge_value_diff(theta, p_anchor)
    p1 = 1.0 / (1.0 + np.exp(-dv))
    return np.stack([1.0 - p1, p1], axis=1)


# =============================================================================
# AM 1998 bridge homogeneous estimator (no UH)
# =============================================================================

def neg_log_lik_homogeneous(theta: np.ndarray, data: dict,
                            p_anchor: np.ndarray) -> float:
    """Single-theta MLE under AM 1998 bridge with pooled empirical CCPs.

    This represents the AM 1998 approach when MaCurdy projection has
    no informative observables to condition on -- the CCP anchor is
    a single pooled object and there is no type heterogeneity in
    theta.
    """
    p_pred = bridge_ccp(theta, p_anchor)
    x = data["x"]; d = data["d"]
    ll = 0.0
    for t in range(T_HORIZON):
        log_p = np.log(p_pred[t, d[:, t], x[:, t]] + 1e-300)
        ll += log_p.sum()
    return -ll


def am_bridge_homogeneous(data: dict, theta_init: np.ndarray | None = None,
                          verbose: bool = False) -> dict:
    """AM 1998 bridge with single homogeneous theta (no UH)."""
    rng = np.random.default_rng(42)
    if theta_init is None:
        theta_init = THETA_POOLED + rng.normal(0, 0.1, size=2)
    p_anchor = empirical_ccp_pooled(data)
    t_start = time.time()
    res = minimize(lambda th: neg_log_lik_homogeneous(th, data, p_anchor),
                   theta_init,
                   method="Nelder-Mead",
                   options={"xatol": 1e-4, "fatol": 1e-4, "maxiter": 500})
    elapsed = time.time() - t_start
    if verbose:
        print(f"  [AM-bridge-hom] theta = {res.x}  ({elapsed:.2f}s)")
    return {"theta": res.x, "wall_clock": elapsed, "log_lik": -res.fun}


# =============================================================================
# GFD-EM (K = 2 mixture)
# =============================================================================

def compute_posterior(data: dict, p_by_type: np.ndarray,
                      pi: np.ndarray) -> np.ndarray:
    x = data["x"]; d = data["d"]
    log_pi = np.log(pi + 1e-300)
    log_lik = np.zeros((data["N"], K_TYPES))
    for k in range(K_TYPES):
        for t in range(T_HORIZON):
            log_lik[:, k] += np.log(p_by_type[k, t, d[:, t], x[:, t]] + 1e-300)
    log_post = log_lik + log_pi[None, :]
    m = log_post.max(axis=1, keepdims=True)
    post = np.exp(log_post - m)
    return post / post.sum(axis=1, keepdims=True)


def neg_log_lik_gfd(theta_k: np.ndarray, data: dict,
                    weights_k: np.ndarray,
                    p_anchor_k: np.ndarray) -> float:
    p_pred = bridge_ccp(theta_k, p_anchor_k)
    x = data["x"]; d = data["d"]
    ll = 0.0
    for t in range(T_HORIZON):
        log_p = np.log(p_pred[t, d[:, t], x[:, t]] + 1e-300)
        ll += (weights_k * log_p).sum()
    return -ll


def gfd_em(data: dict, n_iters: int = 25, verbose: bool = False) -> dict:
    """GFD-EM with K=2 mixture and empirical posterior-weighted CCP anchor."""
    rng = np.random.default_rng(42)
    offset = np.array([[+0.5, +0.2], [-0.5, -0.2]])
    theta = THETA_TRUE + offset + rng.normal(0, 0.05, size=THETA_TRUE.shape)
    pi = np.full(K_TYPES, 1.0 / K_TYPES)

    # Initial type-distinct CCPs via bridge with theta_init + pooled anchor
    p_anchor_pooled = empirical_ccp_pooled(data)
    p_anchor = np.stack([p_anchor_pooled] * K_TYPES)
    p_by_type = np.stack([bridge_ccp(theta[k], p_anchor[k])
                          for k in range(K_TYPES)])

    t_start = time.time()
    for m in range(n_iters):
        posterior = compute_posterior(data, p_by_type, pi)
        pi = posterior.mean(axis=0)
        # update type-conditional empirical CCP anchor
        p_anchor = empirical_ccp_by_type(data, posterior)
        for k in range(K_TYPES):
            w_k = posterior[:, k]
            res = minimize(lambda th: neg_log_lik_gfd(th, data, w_k,
                                                       p_anchor[k]),
                           theta[k].copy(), method="Nelder-Mead",
                           options={"xatol": 1e-4, "fatol": 1e-4, "maxiter": 200})
            theta[k] = res.x
        # update p_by_type from new theta
        for k in range(K_TYPES):
            p_by_type[k] = bridge_ccp(theta[k], p_anchor[k])
        if verbose:
            print(f"  [gfd-em] iter {m:>2}: theta = {theta.ravel()}  pi = {pi}")
    elapsed = time.time() - t_start
    perm = match_labels(theta, THETA_TRUE)
    return {
        "theta": theta[perm], "pi": pi[perm],
        "p_by_type": p_by_type[perm],
        "wall_clock": elapsed,
    }


def match_labels(theta_est: np.ndarray, theta_true: np.ndarray) -> np.ndarray:
    if K_TYPES == 2:
        identity = np.array([0, 1]); swap = np.array([1, 0])
        return (identity
                if np.linalg.norm(theta_est - theta_true)
                <= np.linalg.norm(theta_est[swap] - theta_true)
                else swap)
    raise NotImplementedError


# =============================================================================
# Main
# =============================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--N", type=int, default=2000)
    parser.add_argument("--reps", type=int, default=10)
    parser.add_argument("--em_iters", type=int, default=20)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--single_rep", action="store_true")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    print("=" * 78)
    print(f"GFD-EM vs AM 1998 bridge under unobserved heterogeneity")
    print(f"T = {T_HORIZON}, K = {K_TYPES}, rho = {RHO}, N = {args.N}, "
          f"reps = {args.reps}")
    print("=" * 78)
    print(f"\nTrue theta_1 = {THETA_TRUE[0]}  (type 1)")
    print(f"True theta_2 = {THETA_TRUE[1]}  (type 2)")
    print(f"True pi      = {PI_TRUE}")
    print(f"Population mean theta = {THETA_POOLED}")
    print()

    if args.single_rep:
        rng = np.random.default_rng(args.seed)
        data = simulate(args.N, rng)
        print("--- AM 1998 bridge (homogeneous, no UH) ---")
        res_am = am_bridge_homogeneous(data, verbose=True)
        print()
        print("--- GFD-EM (K=2 mixture) ---")
        res_gfd = gfd_em(data, n_iters=args.em_iters, verbose=True)
        print(f"\n  theta_1 = {res_gfd['theta'][0]}  "
              f"theta_2 = {res_gfd['theta'][1]}  pi = {res_gfd['pi']}")
        return

    rng_master = np.random.default_rng(args.seed)
    am_results = []
    gfd_results = []
    for rep in range(args.reps):
        rng = np.random.default_rng(rng_master.integers(0, 2**31))
        data = simulate(args.N, rng)
        am_results.append(am_bridge_homogeneous(data))
        gfd_results.append(gfd_em(data, n_iters=args.em_iters))
        print(f"  rep {rep+1:>3}/{args.reps}  done  "
              f"AM={am_results[-1]['wall_clock']:.2f}s  "
              f"GFD={gfd_results[-1]['wall_clock']:.2f}s")

    print("\n" + "=" * 78)
    print("MC summary")
    print("=" * 78)
    fmt = "{:<46} {:>9} {:>9}"
    print(fmt.format("Estimator", "b bias", "g bias"))
    print(fmt.format("                                              ",
                     "(RMSE)", "(RMSE)"))
    print("-" * 70)

    am_theta = np.array([r["theta"] for r in am_results])      # (R, 2)
    am_bias_t1 = am_theta.mean(axis=0) - THETA_TRUE[0]
    am_rmse_t1 = np.sqrt(((am_theta - THETA_TRUE[0]) ** 2).mean(axis=0))
    am_bias_t2 = am_theta.mean(axis=0) - THETA_TRUE[1]
    am_rmse_t2 = np.sqrt(((am_theta - THETA_TRUE[1]) ** 2).mean(axis=0))
    am_bias_pool = am_theta.mean(axis=0) - THETA_POOLED
    am_rmse_pool = np.sqrt(((am_theta - THETA_POOLED) ** 2).mean(axis=0))

    print(fmt.format("AM-bridge-homogeneous bias vs true theta_1",
                     f"{am_bias_t1[0]:+.3f}", f"{am_bias_t1[1]:+.3f}"))
    print(fmt.format("                          RMSE vs theta_1",
                     f"{am_rmse_t1[0]:.3f}", f"{am_rmse_t1[1]:.3f}"))
    print(fmt.format("AM-bridge-homogeneous bias vs true theta_2",
                     f"{am_bias_t2[0]:+.3f}", f"{am_bias_t2[1]:+.3f}"))
    print(fmt.format("                          RMSE vs theta_2",
                     f"{am_rmse_t2[0]:.3f}", f"{am_rmse_t2[1]:.3f}"))
    print(fmt.format("AM-bridge-homogeneous bias vs population mean",
                     f"{am_bias_pool[0]:+.3f}", f"{am_bias_pool[1]:+.3f}"))
    print(fmt.format("                          RMSE vs mean theta",
                     f"{am_rmse_pool[0]:.3f}", f"{am_rmse_pool[1]:.3f}"))

    print()
    gfd_theta = np.array([r["theta"] for r in gfd_results])      # (R, K, 2)
    gfd_pi = np.array([r["pi"] for r in gfd_results])             # (R, K)
    gfd_bias = gfd_theta.mean(axis=0) - THETA_TRUE
    gfd_rmse = np.sqrt(((gfd_theta - THETA_TRUE) ** 2).mean(axis=0))
    gfd_pi_bias = gfd_pi.mean(axis=0) - PI_TRUE
    gfd_pi_rmse = np.sqrt(((gfd_pi - PI_TRUE) ** 2).mean(axis=0))

    print(fmt.format("GFD-EM bias vs theta_1",
                     f"{gfd_bias[0,0]:+.3f}", f"{gfd_bias[0,1]:+.3f}"))
    print(fmt.format("       RMSE vs theta_1",
                     f"{gfd_rmse[0,0]:.3f}", f"{gfd_rmse[0,1]:.3f}"))
    print(fmt.format("GFD-EM bias vs theta_2",
                     f"{gfd_bias[1,0]:+.3f}", f"{gfd_bias[1,1]:+.3f}"))
    print(fmt.format("       RMSE vs theta_2",
                     f"{gfd_rmse[1,0]:.3f}", f"{gfd_rmse[1,1]:.3f}"))
    print(fmt.format("GFD-EM bias vs pi",
                     f"{gfd_pi_bias[0]:+.3f}", f"{gfd_pi_bias[1]:+.3f}"))
    print(fmt.format("       RMSE vs pi",
                     f"{gfd_pi_rmse[0]:.3f}", f"{gfd_pi_rmse[1]:.3f}"))

    # Save
    import json
    payload = {
        "config": {"T": T_HORIZON, "K": K_TYPES, "rho": RHO,
                   "N": args.N, "reps": args.reps,
                   "em_iters": args.em_iters},
        "true": {"theta_1": THETA_TRUE[0].tolist(),
                 "theta_2": THETA_TRUE[1].tolist(),
                 "pi": PI_TRUE.tolist(),
                 "theta_pop_mean": THETA_POOLED.tolist()},
        "AM_bridge_homogeneous": {
            "theta_mean": am_theta.mean(axis=0).tolist(),
            "bias_vs_theta_1": am_bias_t1.tolist(),
            "rmse_vs_theta_1": am_rmse_t1.tolist(),
            "bias_vs_theta_2": am_bias_t2.tolist(),
            "rmse_vs_theta_2": am_rmse_t2.tolist(),
            "bias_vs_pop_mean": am_bias_pool.tolist(),
            "rmse_vs_pop_mean": am_rmse_pool.tolist(),
        },
        "GFD_EM": {
            "theta_mean": gfd_theta.mean(axis=0).tolist(),
            "pi_mean": gfd_pi.mean(axis=0).tolist(),
            "bias_theta": gfd_bias.tolist(),
            "rmse_theta": gfd_rmse.tolist(),
            "bias_pi": gfd_pi_bias.tolist(),
            "rmse_pi": gfd_pi_rmse.tolist(),
        },
    }
    out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             "..", "data", "gfd_em_am_benchmark_mc.json")
    with open(out_path, "w") as f:
        json.dump(payload, f, indent=2)
    print(f"\nSaved -> {os.path.relpath(out_path)}")


if __name__ == "__main__":
    main()
