"""
Example: Dynamic Entry/Exit Game (3 players)
==============================================
2 actions per player: Exit (0), Enter/Stay (1)
State: market_size x player_statuses
Memory: Nilpotent (Shift), Control: Weak, Topology: Strategic Ripple
Expected: rho=2 (opponents' strategies dilute control)

Tests all 3 players. Uses UnifiedFDSolver (faster than FlowFDSolver).

Usage:
    python example_game.py          # Quick demo (rho=1 only)
    python example_game.py --full   # Full test (rho=1,2)
"""

import numpy as np
import time
import sys, os
import argparse
sys.path.insert(0, os.path.dirname(__file__))
from UnifiedFDSolver import UnifiedFDSolver
from utils import (
    solve_game_equilibrium, compute_ftran_game,
    compute_dpi_dtheta_game, compute_e, my_meshgrid,
)


def build_model():
    n_player = 3
    theta = [
        [1.0, 1.0, 1.0, 1.0],   # Player 0
        [1.0, 1.0, 1.0, 0.9],   # Player 1
        [1.0, 1.0, 1.0, 0.8],   # Player 2
    ]
    discount_factors = [0.9, 0.9, 0.9]

    s_space = np.array([2, 6, 10])          # Market sizes
    a_i_space = np.array([0, 1])            # Exit / Enter
    F_s = np.array([                        # Market transitions
        [0.8, 0.2, 0.0],
        [0.0, 0.6, 0.4],
        [0.0, 0.2, 0.8],
    ])

    state = my_meshgrid([s_space] + [a_i_space] * n_player)
    P_eq, V_eq = solve_game_equilibrium(state, theta, F_s, discount_factors)
    Ftran_all = compute_ftran_game(P_eq, F_s, state, n_player)
    dpi = compute_dpi_dtheta_game(state, n_player, P_eq)

    return n_player, theta, discount_factors, state, P_eq, V_eq, Ftran_all, dpi


def run(full=False):
    n_player, theta, disc, state, P_eq, V_eq, Ftran, dpi = build_model()
    n_states = Ftran[0].shape[1]

    for player in range(n_player):
        F_p = Ftran[player]
        beta = disc[player]

        u_p = np.zeros((2, n_states))
        u_p[1] = dpi[player, 1] @ theta[player]
        u_p[0] = dpi[player, 0] @ theta[player]

        v_p = np.zeros((2, n_states))
        v_p[1] = u_p[1] + beta * F_p[1] @ V_eq[player]
        v_p[0] = u_p[0] + beta * F_p[0] @ V_eq[player]

        e_p = compute_e(P_eq[player])
        if e_p.shape != v_p.shape:
            e_p = e_p.T

        print(f"\nGame Player {player}: S={n_states}, A=2, beta={beta}")
        print(f"  {'rho':>3}  {'case':<28} {'dist':>10} {'payoff_err':>12} {'time':>7}")
        print(f"  {'-'*65}")

        cases = [(s, 0, 1, f"s{s}: Exit vs Enter") for s in [0, 6, 12, 18, 23]]

        # NOTE: rho=2 is slow due to NAC constraint building (O(S^4) complexity)
        rhos = [1, 2] if full else [1]
        
        for rho in rhos:
            if rho == 2:
                print(f"  [rho={rho}] Building solver (this may take 30-60s due to NAC constraints)...")
            else:
                print(f"  [rho={rho}] Building solver...")
            t0 = time.time()
            solver = UnifiedFDSolver(T=F_p, rho=rho, n_states=n_states, n_actions=2)
            init_time = time.time() - t0
            print(f"          Init time: {init_time:.3f}s")
            
            for s0, k, K, desc in cases:
                true_diff = v_p[k, s0] - v_p[K, s0]
                t0 = time.time()
                phi_k, phi_K, dist, ce = solver.solve(s0, k, K)
                solve_time = time.time() - t0
                fd = solver.evaluate_value_difference(phi_k, phi_K, s0, k, K, u_p, e_p, beta)
                print(f"  {rho:>3}  {desc:<28} {dist:>10.2e} {abs(fd - true_diff):>12.2e} {solve_time:>6.3f}s")
            print()
        
        if not full:
            print("  (Skipping rho=2. Use --full flag to enable)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Dynamic Entry/Exit Game Example')
    parser.add_argument('--full', action='store_true', 
                        help='Run full test including rho=2 (slow, may take minutes)')
    args = parser.parse_args()
    run(full=args.full)
