"""
Counterfactual Monte Carlo for the SINGLE-AGENT Entry/Exit model.

Demonstrates Theorem 2 (Bellman-free counterfactual CCPs) cleanly:
this is a Type-D model (action-dependent productivity transitions, no
closed-form Kronecker factorization, no equilibrium feedback). Phi is a
structural object built from f alone; under payoff-only counterfactuals
it stays exact and the bridge identity applies in its strict form.

For each counterfactual structural parameter theta_cf we compute the new
equilibrium CCPs two ways:

  (i) GFD bridge (Theorem 2, strict single-agent):
        p^{(m+1)} = Lambda( v_tilde^{rho-FD}( . ; theta_cf, Phi, p^{(m)} ) )
      with Phi FROZEN at the baseline transition.

 (ii) NFXP gold standard:
        Solve the Bellman fixed point at theta_cf via value-function
        iteration.

State : s = (market_status, productivity, z_shock), |X| = 16
Actions: a in {0=Exit, 1=Enter}
Payoff: u_1(s) = theta_rev * prod - theta_fixed - theta_entry * (1 - market)
        u_0(s) = 0.5 * prod - 0.5   (exit payoff fixed across scenarios)
rho_star = 2 (action-dependent productivity transitions)

Usage:
    python monte_carlo_counterfactual_entry_exit.py
    python monte_carlo_counterfactual_entry_exit.py --quick
"""
from __future__ import annotations

import sys, os, time, argparse, csv
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
from scipy.special import logsumexp

from UnifiedFDSolver import UnifiedFDSolver
from utils import state_transition, my_kron, my_meshgrid

EULER = 0.5772156649
BETA = 0.95
N_ACTIONS = 2


# ============================================================================
# Model: single-agent entry/exit (Type D, rho* = 2)
# ============================================================================

def build_entry_exit_model():
    """Build the entry/exit transition F and the payoff-basis tensor z.

    State decomposition: s = (market, productivity, z)
        market in {0=Out, 1=In}             (2 levels)
        productivity in {0,1,2,3}            (4 Tauchen levels, action-dep.)
        z shock in {0,1}                     (2 levels, exogenous)

    Actions: 0 = Exit/Stay-Out, 1 = Enter/Stay-In
    Productivity transition is ACTION-DEPENDENT (Triple Connector / Type D).

    Payoff parameterization (3 parameters):
        u(s, a=0; theta) = 0.5 * prod - 0.5                  (exit baseline)
        u(s, a=1; theta) = theta[0] * prod                   # revenue
                          - theta[1]                          # fixed op cost
                          - theta[2] * (1 - market)           # entry cost

    Returns (F, z_basis, state_grid)
        F: (n_actions, n_states, n_states)
        z_basis: (n_actions, n_states, n_params)
        state_grid: (n_states, 3) — columns are (market, prod, z)
    """
    # Market status transition (deterministic on action)
    f_x_0 = np.array([[1, 0], [1, 0]])   # Exit -> Out
    f_x_1 = np.array([[0, 1], [0, 1]])   # Enter -> In

    # Productivity (action-dependent Tauchen-discretized AR(1))
    ngrid_o = 4
    f_o_0, o_grid = state_transition(0.0, 0.3, 2.0, ngrid_o,
                                       min_val=0.0, max_val=1.0)
    f_o_1, _ = state_transition(1.0, 0.3, 2.0, ngrid_o,
                                  min_val=0.0, max_val=1.0)

    # Exogenous z shock
    ngrid_z = 2
    f_z, z_grid = state_transition(0.0, 0.9, 1.0, ngrid_z)

    F = np.array([my_kron([f_x_0, f_o_0, f_z]),
                  my_kron([f_x_1, f_o_1, f_z])])
    n_states = F.shape[1]
    state = my_meshgrid([np.array([0, 1]), o_grid, z_grid])

    # Payoff basis z_basis[a, s, k] = partial u(s, a) / partial theta_k
    n_params = 3
    z_basis = np.zeros((N_ACTIONS, n_states, n_params))
    # Action 0 (Exit) has no theta dependence -- z_basis[0] = 0
    # Action 1 (Enter): theta[0]*prod - theta[1] - theta[2]*(1-market)
    z_basis[1, :, 0] = state[:, 1]                # revenue basis
    z_basis[1, :, 1] = -1.0                       # fixed cost basis
    z_basis[1, :, 2] = -(1.0 - state[:, 0])       # entry cost basis

    return F, z_basis, state


def compute_payoff_entry_exit(theta, z_basis, state):
    """Returns u of shape (n_actions, n_states)."""
    n_actions, n_states, _ = z_basis.shape
    u = np.zeros((n_actions, n_states))
    # Exit payoff baseline (NOT counterfactual-dependent)
    u[0] = 0.5 * state[:, 1] - 0.5
    # Enter payoff (linear in theta)
    u[1] = z_basis[1] @ theta
    return u


# True / baseline parameter vector
THETA_BASELINE = np.array([1.0, 1.0, 1.0])   # (revenue, fixed, entry)


# ============================================================================
# NFXP: Bellman re-solve at theta_cf
# ============================================================================

def solve_equilibrium_entry_exit(theta, F, z_basis, state, beta=BETA,
                                    tol=1e-10, maxiter=3000):
    """Standard value iteration. Returns (V, P) with P shape (A, S)."""
    n_states = F.shape[1]
    u = compute_payoff_entry_exit(theta, z_basis, state)
    V = np.zeros(n_states)
    for _ in range(maxiter):
        EV = np.einsum('ask,k->as', F, V)
        vc = u + beta * EV
        Vn = logsumexp(vc, axis=0) + EULER
        if np.max(np.abs(Vn - V)) < tol:
            V = Vn
            break
        V = Vn
    EV = np.einsum('ask,k->as', F, V)
    vc = u + beta * EV
    vm = vc.max(0, keepdims=True)
    ev = np.exp(vc - vm)
    P = ev / ev.sum(0, keepdims=True)
    return V, P


def nfxp_counterfactual(theta_cf, F, z_basis, state):
    t0 = time.time()
    V, P = solve_equilibrium_entry_exit(theta_cf, F, z_basis, state)
    return P, time.time() - t0


# ============================================================================
# GFD bridge: frozen-Phi iteration at theta_cf
# ============================================================================

def build_phi_cache_entry_exit(F, k_analyzed=1, K_ref=0, rho=2,
                                  tol=1e-7, verbose=False):
    """Build the canonical Moore-Penrose flow input
    Δφ = φ_{k_analyzed} − φ_{K_ref} for the entry/exit kernel at every
    initial state, ONCE.

    Returns dphi_coeff of shape (S, A, S):
        dphi_coeff[x0, a, j] = sum_{tau, ji, ki} dphi[x0, ji, ki]
                              * I{j_seq[ji, tau] == j}
                              * I{k_seq[ki, tau] == a}
                              * beta^{tau+1}
    """
    n_actions, n_states, _ = F.shape
    t0 = time.time()
    solver = UnifiedFDSolver(T=F, rho=rho, n_states=n_states,
                              n_actions=n_actions)
    dphi_all = solver.solve_all_states_diff_standard(
        k_analyzed, K_ref, tol=tol)
    j_arr = solver.j_arr
    k_arr = solver.k_arr
    M_j = (j_arr[:, :, None] == np.arange(n_states)[None, None, :]).astype(float)
    M_k = (k_arr[:, :, None] == np.arange(n_actions)[None, None, :]).astype(float)
    beta_pow = BETA ** (np.arange(rho) + 1)
    M_j_w = M_j * beta_pow[None, :, None]
    dphi_coeff = np.einsum('xjk, jtJ, ktA -> xAJ', dphi_all, M_j_w, M_k)
    if verbose:
        print(f"  Phi cache built in {time.time()-t0:.3f}s "
              f"(rho={rho}, S={n_states}, A={n_actions}, "
              f"k_analyzed={k_analyzed}, K_ref={K_ref})")
    return dphi_coeff


def gfd_bridge_counterfactual(theta_cf, F, z_basis, state, dphi_coeff,
                                k_analyzed=1, K_ref=0,
                                tol=1e-8, max_iter=500,
                                P_init=None, verbose=False):
    """Iterate p^{(m+1)} = Lambda(v_tilde^{rho-FD}(theta_cf, Phi, p^{(m)})).

    Phi is frozen (passed in as dphi_coeff). No Bellman solve.
    dphi_coeff was built for the (k_analyzed, K_ref) pair, so the only
    non-zero fd_diff column is k = k_analyzed.

    Returns (P, elapsed, n_iter).
    """
    t0 = time.time()
    n_actions, n_states, _ = F.shape
    u_th = compute_payoff_entry_exit(theta_cf, z_basis, state)  # (A, S)

    if P_init is None:
        P = np.ones((n_actions, n_states)) / n_actions
    else:
        P = P_init.copy()

    for it in range(max_iter):
        log_P = np.log(np.clip(P, 1e-12, 1.0))
        psi = EULER - log_P                          # (A, S)
        u_plus_psi = u_th + psi                       # (A, S)

        # GFD pseudo value-difference: v_tilde(s, k_analyzed) - v_tilde(s, K_ref)
        # = u(s, k_analyzed) - u(s, K_ref)
        #   + sum_{a, j} dphi_coeff[s, a, j] * (u(j, a) + psi(j, a))
        fd_diff_an = (u_th[k_analyzed] - u_th[K_ref]
                       + np.einsum('xaj,aj->x', dphi_coeff, u_plus_psi))  # (S,)

        # Multinomial-logit map (binary case; extend if A > 2)
        fd_diff = np.zeros((n_states, n_actions))
        fd_diff[:, k_analyzed] = fd_diff_an
        # K_ref column stays 0
        vm = fd_diff.max(axis=1, keepdims=True)
        ev = np.exp(fd_diff - vm)
        P_new = (ev / ev.sum(axis=1, keepdims=True)).T   # (A, S)

        diff = np.max(np.abs(P_new - P))
        if verbose and (it % 10 == 0 or it < 5):
            print(f"    iter {it:3d}  max_diff = {diff:.2e}")
        if diff < tol:
            P = P_new
            return P, time.time() - t0, it + 1
        P = P_new

    return P, time.time() - t0, max_iter


# ============================================================================
# Counterfactual scenarios
# ============================================================================

def make_counterfactual_grid():
    """Sweep perturbations on each of the three structural parameters."""
    out = []
    out.append(("baseline", THETA_BASELINE.copy()))
    # Revenue coefficient perturbations
    for delta in [-0.3, -0.1, +0.1, +0.3]:
        th = THETA_BASELINE.copy()
        th[0] = THETA_BASELINE[0] * (1.0 + delta)
        out.append((f"revenue x {1+delta:.2f}", th))
    # Fixed cost perturbations
    for delta in [-0.3, +0.3, +0.5]:
        th = THETA_BASELINE.copy()
        th[1] = THETA_BASELINE[1] * (1.0 + delta)
        out.append((f"fixed   x {1+delta:.2f}", th))
    # Entry cost perturbations
    for delta in [-0.3, +0.3, +0.5]:
        th = THETA_BASELINE.copy()
        th[2] = THETA_BASELINE[2] * (1.0 + delta)
        out.append((f"entry   x {1+delta:.2f}", th))
    return out


# ============================================================================
# MC harness
# ============================================================================

def run_counterfactual_entry_exit(n_reps=3, quick=False, save_path=None,
                                     verbose=True):
    print("=" * 78)
    print("Counterfactual MC: SINGLE-AGENT entry/exit (Type D, rho=2)")
    print("Theorem 2 strict bridge: Phi frozen at baseline transition")
    print("=" * 78)
    print()

    F, z_basis, state = build_entry_exit_model()
    n_states = F.shape[1]
    print(f"Model: |X|={n_states}, A={N_ACTIONS}, rho=2, beta={BETA}")
    print(f"Baseline theta = {THETA_BASELINE}")
    print()

    # Phi precompute (one-time cost)
    print("Building Phi cache (canonical Moore-Penrose flow input)...")
    t0 = time.time()
    dphi_coeff = build_phi_cache_entry_exit(F, k_analyzed=1, K_ref=0, rho=2,
                                              tol=1e-7, verbose=verbose)
    t_phi_setup = time.time() - t0

    grid = make_counterfactual_grid()
    if quick:
        grid = grid[:3]
    K = len(grid)
    print(f"\nCounterfactual sweep: K = {K} scenarios")
    print()

    header = (f"{'scenario':<22} {'NFXP (ms)':>10} {'GFD-bridge (ms)':>17} "
              f"{'iters':>6} {'sup-norm err':>14}")
    print(header)
    print("-" * len(header))

    rows = []
    nfxp_total = 0.0
    gfd_total = 0.0
    err_worst = 0.0

    for label, th_cf in grid:
        # NFXP gold standard (averaged over n_reps for stable timing)
        nfxp_reps = []
        for _ in range(n_reps):
            P_nfxp, t_n = nfxp_counterfactual(th_cf, F, z_basis, state)
            nfxp_reps.append(t_n)
        nfxp_t = float(np.mean(nfxp_reps))
        nfxp_total += nfxp_t

        # GFD bridge (averaged over n_reps; warm-start at baseline init)
        gfd_reps = []
        gfd_iters = []
        for _ in range(n_reps):
            P_gfd, t_g, n_it = gfd_bridge_counterfactual(
                th_cf, F, z_basis, state, dphi_coeff,
                k_analyzed=1, K_ref=0,
                tol=1e-8, max_iter=500,
            )
            gfd_reps.append(t_g)
            gfd_iters.append(n_it)
        gfd_t = float(np.mean(gfd_reps))
        gfd_total += gfd_t

        # Final sup-norm error vs NFXP
        err = float(np.max(np.abs(P_gfd - P_nfxp)))
        err_worst = max(err_worst, err)
        ni = int(np.mean(gfd_iters))

        print(f"{label:<22} {nfxp_t*1000:>8.2f}   {gfd_t*1000:>14.2f}    "
              f"{ni:>4}   {err:>13.4e}")

        rows.append({
            'scenario': label,
            'nfxp_ms': nfxp_t * 1000,
            'gfd_ms': gfd_t * 1000,
            'gfd_iters': ni,
            'sup_norm_err': err,
        })

    gfd_amortized = t_phi_setup + gfd_total
    speedup_per_scenario_avg = (nfxp_total / K) / (gfd_total / K) if gfd_total > 0 else float('nan')
    speedup_sweep = nfxp_total / gfd_amortized if gfd_amortized > 0 else float('nan')

    print("-" * len(header))
    print(f"{'TOTAL':<22} {nfxp_total*1000:>8.2f}   {gfd_total*1000:>14.2f}    "
          f"(+ {t_phi_setup*1000:.1f}ms Phi setup)")
    print(f"{'AMORTIZED GFD':<22} {'':>10} {gfd_amortized*1000:>14.2f} ms")
    print(f"{'speedup per scenario':<22} {'':>10} {speedup_per_scenario_avg:>14.2f}x")
    print(f"{'SPEEDUP SWEEP NFXP/GFD':<22} {'':>10} {speedup_sweep:>14.2f}x")
    print(f"{'WORST sup-norm err':<22} {'':>10} {err_worst:>14.4e}")

    if save_path:
        with open(save_path, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            for r in rows:
                w.writerow(r)
        print(f"\nWrote {save_path}")

    return {
        'rows': rows,
        'nfxp_total_s': nfxp_total,
        'gfd_total_s': gfd_total,
        'phi_setup_s': t_phi_setup,
        'gfd_amortized_s': gfd_amortized,
        'speedup_per_scenario': speedup_per_scenario_avg,
        'speedup_sweep': speedup_sweep,
        'worst_sup_err': err_worst,
        'K_scenarios': K,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--quick', action='store_true',
                        help='Only 3 scenarios')
    parser.add_argument('--out', type=str, default=None,
                        help='CSV output path')
    parser.add_argument('--n-reps', type=int, default=3,
                        help='Reps per scenario for stable timing')
    args = parser.parse_args()
    return run_counterfactual_entry_exit(n_reps=args.n_reps,
                                            quick=args.quick,
                                            save_path=args.out)


if __name__ == "__main__":
    main()
