"""
dynamic_game_uh_synthetic.py
============================

Phase 3 honest feasibility test: GFD-EM mixture estimator for a
dynamic discrete game with *market-level latent unobserved
heterogeneity*.

Honest framing (replaces the earlier "multiplicity-as-UH" pitch which
required MPE multiplicity that smooth-logit symmetric games typically
don't have):

  Different markets in the panel have unobserved type membership
  L_m in {1, ..., K} drawn from a prior pi.  Each type has its own
  structural primitives theta^(ell) -- e.g., different demand
  potential, different competition intensity.  Within each type, the
  smooth-logit dynamic game has a *unique* MPE  p^(ell)_i(d_i | x).
  The econometrician observes (decisions, state) per market but not
  the type.  GFD-EM:
    * E-step:  posterior over market types using mixture log-lik.
    * M-step:  per-type theta^(ell) optimization via the bridge
       identity (or, for this MVP, the inner MPE solve which we'll
       later replace with the bridge).
    * Counterfactual via bridge per type, no Bellman re-solve.

The simpler "single-agent latent UH" case (AM 2011 EM) is well-known
and replicated by our Phase 1b script.  The new contribution targeted
here is the *multi-agent extension* where strategic interactions
need a per-player perceived transition and bridge identity at
rho = 2 (strategic ripple).

Setup
-----
* 2-player entry game, 2 actions, 2-lag incumbency state (4 states).
* K = 2 market types.  Type 1 = high-revenue market, Type 2 =
  low-revenue market.  Same competition intensity and entry cost.
* Each type has its own MPE.
* Posterior over (theta, pi) recovered via mixture EM.

Validation
----------
* pi recovery.
* theta^(ell) recovery per type.
* type-conditional CCPs p^(ell)_i recovery.
* Market-to-type classification accuracy.
"""

from __future__ import annotations

import argparse
import time

import numpy as np
from scipy.optimize import minimize


# =============================================================================
# Setup
# =============================================================================

N_PLAYERS = 2
N_ACTIONS = 2
N_STATES = N_ACTIONS ** N_PLAYERS              # 4 = (y1, y2)
BETA = 0.95

# K = 2 market types with distinct revenue.  Competition penalty and
# entry cost shared across types.  Each type has its own unique MPE
# under smooth-logit best response.
THETA_TRUE = np.array([
    [1.5, 1.5, 0.3],     # type 1: high revenue (more attractive market)
    [0.5, 1.5, 0.3],     # type 2: low revenue
])
PI_TRUE = np.array([0.6, 0.4])
K_TYPES = THETA_TRUE.shape[0]


# =============================================================================
# State encoding (shared with previous synthetic)
# =============================================================================

def x_to_yvec(x: int) -> tuple[int, int]:
    return (x >> 1) & 1, x & 1


def yvec_to_x(y1: int, y2: int) -> int:
    return (y1 << 1) | y2


def payoff(theta: np.ndarray, d_i: int, x: int, i: int) -> float:
    if d_i == 0:
        return 0.0
    y1, y2 = x_to_yvec(x)
    y_self = y1 if i == 0 else y2
    y_other = y2 if i == 0 else y1
    rev, comp, entry = theta
    return rev - comp * y_other - entry * (1 - y_self)


def payoff_vec(theta: np.ndarray, i: int) -> np.ndarray:
    out = np.zeros((N_ACTIONS, N_STATES))
    for d in range(N_ACTIONS):
        for x in range(N_STATES):
            out[d, x] = payoff(theta, d, x, i)
    return out


def perceived_transition(p_other: np.ndarray, i: int) -> np.ndarray:
    F = np.zeros((N_ACTIONS, N_STATES, N_STATES))
    for x in range(N_STATES):
        for d_i in range(N_ACTIONS):
            for d_other in range(N_ACTIONS):
                w = p_other[d_other, x]
                if i == 0:
                    x_next = yvec_to_x(d_i, d_other)
                else:
                    x_next = yvec_to_x(d_other, d_i)
                F[d_i, x, x_next] += w
    return F


# =============================================================================
# MPE per type
# =============================================================================

def best_response_i(theta: np.ndarray, p_other: np.ndarray, i: int,
                    max_iter: int = 800, tol: float = 1e-10) -> np.ndarray:
    F_i = perceived_transition(p_other, i)
    u_i = payoff_vec(theta, i)
    V = np.zeros(N_STATES)
    for _ in range(max_iter):
        v_t = u_i + BETA * (F_i * V[None, None, :]).sum(axis=2)
        m = v_t.max(axis=0)
        V_new = m + np.log(np.exp(v_t - m).sum(axis=0))
        if np.max(np.abs(V_new - V)) < tol:
            V = V_new
            break
        V = V_new
    v_t = u_i + BETA * (F_i * V[None, None, :]).sum(axis=2)
    m = v_t.max(axis=0)
    ev = np.exp(v_t - m)
    return ev / ev.sum(axis=0)


def find_mpe(theta: np.ndarray, p_init: np.ndarray | None = None,
             max_iter: int = 300, tol: float = 1e-7) -> np.ndarray:
    """Best-response iteration to a smooth MPE."""
    if p_init is None:
        p_init = np.full((N_PLAYERS, N_ACTIONS, N_STATES), 0.5)
    p = p_init.copy()
    for _ in range(max_iter):
        p_new = np.zeros_like(p)
        for i in range(N_PLAYERS):
            p_new[i] = best_response_i(theta, p[1 - i], i)
        if np.max(np.abs(p_new - p)) < tol:
            return p_new
        p = p_new
    return p


# =============================================================================
# DGP: each market drawn from one of K types; simulate using type's MPE
# =============================================================================

def simulate_mixture(mpes_by_type: list[np.ndarray], pi: np.ndarray,
                     n_markets: int, T: int, rng) -> dict:
    K = len(mpes_by_type)
    types = rng.choice(K, size=n_markets, p=pi)
    decisions = np.zeros((n_markets, T, N_PLAYERS), dtype=int)
    states = np.zeros((n_markets, T + 1), dtype=int)
    states[:, 0] = rng.integers(0, N_STATES, size=n_markets)
    for m in range(n_markets):
        p_mpe = mpes_by_type[types[m]]
        for t in range(T):
            x = states[m, t]
            d = np.zeros(N_PLAYERS, dtype=int)
            for i in range(N_PLAYERS):
                d[i] = rng.choice(N_ACTIONS, p=p_mpe[i, :, x])
            decisions[m, t] = d
            states[m, t + 1] = yvec_to_x(d[0], d[1])
    return {"decisions": decisions, "states": states, "types": types,
            "n_markets": n_markets, "T": T}


# =============================================================================
# Mixture EM with type-specific theta
# =============================================================================

def compute_posterior(data: dict, p_by_type: np.ndarray,
                      pi: np.ndarray) -> np.ndarray:
    decisions = data["decisions"]; states = data["states"]
    M, T, _ = decisions.shape
    K = p_by_type.shape[0]
    log_pi = np.log(pi + 1e-300)
    log_lik = np.zeros((M, K))
    for k in range(K):
        for t in range(T):
            x_t = states[:, t]
            for i in range(N_PLAYERS):
                d_t = decisions[:, t, i]
                log_lik[:, k] += np.log(p_by_type[k, i, d_t, x_t] + 1e-300)
    log_post = log_lik + log_pi[None, :]
    m = log_post.max(axis=1, keepdims=True)
    post = np.exp(log_post - m)
    return post / post.sum(axis=1, keepdims=True)


def neg_log_lik_per_type(theta_k: np.ndarray, data: dict,
                          weights_k: np.ndarray,
                          warm_start: np.ndarray | None = None
                          ) -> tuple[float, np.ndarray]:
    """Weighted neg log-lik for one type at parameters theta_k.

    Computes the unique MPE under theta_k via best-response iteration
    starting from warm_start, then sums posterior-weighted log-lik.
    Returns (neg_ll, mpe).
    """
    p_mpe = find_mpe(theta_k, p_init=warm_start, max_iter=200)
    ll = 0.0
    decisions = data["decisions"]; states = data["states"]
    M, T, _ = decisions.shape
    for t in range(T):
        x_t = states[:, t]
        for i in range(N_PLAYERS):
            d_t = decisions[:, t, i]
            log_p = np.log(p_mpe[i, d_t, x_t] + 1e-300)
            ll += (weights_k * log_p).sum()
    return -ll, p_mpe


def em_run(data: dict, K: int, theta_init: np.ndarray | None = None,
           n_em_iter: int = 15, verbose: bool = False) -> dict:
    rng = np.random.default_rng(0)
    # Initialise theta with random perturbation from truth.  In a real
    # application we'd use K-means on time-averaged decisions.
    if theta_init is None:
        theta = THETA_TRUE + rng.normal(0, 0.3, size=THETA_TRUE.shape)
    else:
        theta = theta_init.copy()
    pi = np.full(K, 1.0 / K)
    # Initial MPE per type
    p_by_type = np.stack([find_mpe(theta[k]) for k in range(K)])

    ll_traj = []
    t_start = time.time()
    for m_iter in range(n_em_iter):
        # E-step
        posterior = compute_posterior(data, p_by_type, pi)
        pi = posterior.mean(axis=0)
        # M-step per type
        for k in range(K):
            res = minimize(
                lambda th: neg_log_lik_per_type(
                    th, data, posterior[:, k], warm_start=p_by_type[k])[0],
                theta[k].copy(),
                method="Nelder-Mead",
                options={"xatol": 1e-4, "fatol": 1e-4, "maxiter": 150},
            )
            theta[k] = res.x
            # Refresh type k's MPE under new theta
            _, p_new = neg_log_lik_per_type(
                theta[k], data, posterior[:, k], warm_start=p_by_type[k])
            p_by_type[k] = p_new
        # Diagnose log-lik
        log_lik_total = 0.0
        for m in range(data["n_markets"]):
            log_p_each = np.zeros(K)
            for k in range(K):
                ll_k = 0.0
                for t in range(data["T"]):
                    x_t = data["states"][m, t]
                    for i in range(N_PLAYERS):
                        d_it = data["decisions"][m, t, i]
                        ll_k += np.log(p_by_type[k, i, d_it, x_t] + 1e-300)
                log_p_each[k] = np.log(pi[k] + 1e-300) + ll_k
            log_lik_total += np.logaddexp.reduce(log_p_each)
        ll_traj.append(log_lik_total)
        if verbose:
            print(f"  EM iter {m_iter:>2}: "
                  f"theta_1 = {theta[0].round(3)}  "
                  f"theta_2 = {theta[1].round(3)}  "
                  f"pi = {pi.round(3)}  ll = {log_lik_total:.1f}")
    elapsed = time.time() - t_start
    return {"theta": theta, "pi": pi, "p_by_type": p_by_type,
            "posterior": posterior, "ll_traj": ll_traj,
            "wall_clock": elapsed}


def match_to_truth(theta_est: np.ndarray,
                   theta_true: np.ndarray) -> np.ndarray:
    if theta_est.shape[0] != 2:
        return np.arange(theta_est.shape[0])
    identity = np.array([0, 1]); swap = np.array([1, 0])
    err_id = np.linalg.norm(theta_est - theta_true)
    err_sw = np.linalg.norm(theta_est[swap] - theta_true)
    return identity if err_id <= err_sw else swap


# =============================================================================
# Main
# =============================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n_markets", type=int, default=400)
    parser.add_argument("--T", type=int, default=30)
    parser.add_argument("--em_iter", type=int, default=12)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    print("=" * 78)
    print(f"GFD-EM for dynamic game with market-level latent UH (K = 2 types)")
    print(f"  theta_true[0] = {THETA_TRUE[0]}  (high-revenue market)")
    print(f"  theta_true[1] = {THETA_TRUE[1]}  (low-revenue market)")
    print(f"  pi_true = {PI_TRUE}")
    print(f"  beta = {BETA}, n_markets = {args.n_markets}, T = {args.T}")
    print("=" * 78)

    rng = np.random.default_rng(args.seed)

    # Step 1: MPE per market type
    print("\n[1] Computing MPE per market type...")
    mpes_by_type = []
    for k in range(K_TYPES):
        p_mpe = find_mpe(THETA_TRUE[k])
        mpes_by_type.append(p_mpe)
        print(f"    Type {k} MPE: player 0 enter probs = {p_mpe[0, 1, :].round(3)}")
        print(f"               player 1 enter probs = {p_mpe[1, 1, :].round(3)}")

    # Step 2: simulate mixture
    print(f"\n[2] Simulating {args.n_markets} markets, T = {args.T} each, "
          f"pi = {PI_TRUE}")
    data = simulate_mixture(mpes_by_type, PI_TRUE, args.n_markets, args.T, rng)
    type_prevalence = np.bincount(data["types"]) / args.n_markets
    print(f"    DGP type prevalence: {type_prevalence.round(3)}")

    # Step 3: EM
    print(f"\n[3] Mixture EM with K = {K_TYPES} types, "
          f"{args.em_iter} iters")
    res = em_run(data, K_TYPES, n_em_iter=args.em_iter, verbose=args.verbose)

    # Step 4: align labels and report
    perm = match_to_truth(res["theta"], THETA_TRUE)
    theta_est = res["theta"][perm]
    pi_est = res["pi"][perm]
    p_est = res["p_by_type"][perm]
    posterior_aligned = res["posterior"][:, perm]

    print(f"\n[4] Results:")
    print(f"    theta_true[0]  = {THETA_TRUE[0]}")
    print(f"    theta_est[0]   = {theta_est[0].round(3)}")
    print(f"    theta_bias[0]  = {(theta_est[0] - THETA_TRUE[0]).round(3)}")
    print(f"    theta_true[1]  = {THETA_TRUE[1]}")
    print(f"    theta_est[1]   = {theta_est[1].round(3)}")
    print(f"    theta_bias[1]  = {(theta_est[1] - THETA_TRUE[1]).round(3)}")
    print(f"    pi_true        = {PI_TRUE}")
    print(f"    pi_est         = {pi_est.round(3)}")
    print(f"    pi_bias        = {(pi_est - PI_TRUE).round(3)}")

    print(f"\n    CCP RMSE per type per player:")
    p_true_stack = np.stack(mpes_by_type)
    for k in range(K_TYPES):
        for i in range(N_PLAYERS):
            rmse = np.sqrt(((p_est[k, i] - p_true_stack[k, i]) ** 2).mean())
            print(f"      type {k}, player {i}: RMSE = {rmse:.4f}")

    hard_assignment = posterior_aligned.argmax(axis=1)
    accuracy = (hard_assignment == data["types"]).mean()
    print(f"\n    Market->type classification accuracy: {accuracy:.3f}")
    print(f"    Wall-clock: {res['wall_clock']:.1f}s")
    print(f"    Log-lik final: {res['ll_traj'][-1]:.1f}")


if __name__ == "__main__":
    main()
