"""
Example: Dynamic Oligopoly (Ericson-Pakes style, simplified)
==============================================================
2 firms, each with 2 actions: No Invest (0), Invest (1)
State: firm1_productivity x firm2_productivity
Memory: Decay (productivity persists)
Control: Weak (each firm controls own productivity only partially)
Topology: Strategic Ripple (firm 1's state affects firm 2's transition)
Expected: rho=2

Usage:
    python example_oligopoly.py          # Quick demo (rho=1 only)
    python example_oligopoly.py --full   # Full test (rho=1,2)
"""

import numpy as np
import time
import sys, os
import argparse
sys.path.insert(0, os.path.dirname(__file__))
from UnifiedFDSolver import UnifiedFDSolver
from HistoryDependentFDSolver import solve_mdp
from utils import my_kron, my_meshgrid


def build_model():
    beta = 0.95
    n_prod = 4  # Productivity levels per firm
    n_states = n_prod * n_prod  # Joint state space (firm1 x firm2)
    n_actions = 2  # No Invest, Invest (for firm 1)

    prod_grid = np.array([1.0, 2.0, 3.0, 4.0])

    # Firm 1's productivity transition (action-dependent)
    # No invest: productivity decays
    F1_no = np.zeros((n_prod, n_prod))
    for i in range(n_prod):
        if i > 0:
            F1_no[i, i] = 0.5
            F1_no[i, i - 1] = 0.5
        else:
            F1_no[i, i] = 1.0

    # Invest: productivity may increase
    F1_inv = np.zeros((n_prod, n_prod))
    for i in range(n_prod):
        if i < n_prod - 1:
            F1_inv[i, i] = 0.4
            F1_inv[i, i + 1] = 0.6
        else:
            F1_inv[i, i] = 1.0

    # Firm 2's productivity transition (depends on firm 1's state = strategic ripple)
    # Higher firm 1 productivity -> competitive pressure -> firm 2 declines
    F2 = np.zeros((n_prod, n_prod, n_prod))  # F2[firm1_state, firm2_from, firm2_to]
    for w1 in range(n_prod):
        decline_prob = 0.1 * w1 / (n_prod - 1)  # Higher w1 -> more decline
        for w2 in range(n_prod):
            if w2 > 0:
                F2[w1, w2, w2] = 1.0 - decline_prob
                F2[w1, w2, w2 - 1] = decline_prob
            else:
                F2[w1, w2, w2] = 1.0

    # Build full transition F[action, state, state']
    # state = firm1_prod * n_prod + firm2_prod
    F = np.zeros((n_actions, n_states, n_states))

    for a in range(n_actions):
        F1_a = F1_no if a == 0 else F1_inv
        for w1 in range(n_prod):
            for w2 in range(n_prod):
                s = w1 * n_prod + w2
                for w1_next in range(n_prod):
                    for w2_next in range(n_prod):
                        s_next = w1_next * n_prod + w2_next
                        F[a, s, s_next] = F1_a[w1, w1_next] * F2[w1, w2, w2_next]

    # Payoff: profit depends on own productivity minus competitive effect
    state = my_meshgrid([prod_grid, prod_grid])
    u = np.zeros((n_actions, n_states))
    u[0] = 1.5 * state[:, 0] - 0.5 * state[:, 1]  # No invest
    u[1] = 1.5 * state[:, 0] - 0.5 * state[:, 1] - 2.0  # Invest (fixed cost)

    return F, u, beta, n_states, n_actions


def run(full=False):
    F, u, beta, n_states, n_actions = build_model()
    V, v, e = solve_mdp(F, u, beta)

    print(f"Dynamic Oligopoly: S={n_states}, A={n_actions}, beta={beta}")
    print(f"  {'rho':>3}  {'case':<28} {'dist':>10} {'payoff_err':>12} {'time':>7}")
    print(f"  {'-'*65}")

    cases = [
        (0, 0, 1, "s0(1,1): NoInv vs Inv"),
        (5, 0, 1, "s5(2,2): NoInv vs Inv"),
        (10, 0, 1, "s10(3,3): NoInv vs Inv"),
        (15, 0, 1, "s15(4,4): NoInv vs Inv"),
    ]

    rhos = [1, 2] if full else [1]

    for rho in rhos:
        if rho > 1:
            print(f"  [rho={rho}] Building solver (this may take time due to NAC constraints)...")
        else:
            print(f"  [rho={rho}] Building solver...")
        t0 = time.time()
        solver = UnifiedFDSolver(T=F, rho=rho, n_states=n_states, n_actions=n_actions)
        init_time = time.time() - t0
        print(f"          Init time: {init_time:.3f}s")

        for s0, k, K, desc in cases:
            true_diff = v[k, s0] - v[K, s0]
            t0 = time.time()
            phi_k, phi_K, dist, ce = solver.solve(s0, k, K)
            solve_time = time.time() - t0
            fd = solver.evaluate_value_difference(phi_k, phi_K, s0, k, K, u, e, beta)
            print(f"  {rho:>3}  {desc:<28} {dist:>10.2e} {abs(fd - true_diff):>12.2e} {solve_time:>6.3f}s")
        print()

    if not full:
        print("  (Skipping rho=2. Use --full flag to enable)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Dynamic Oligopoly Example')
    parser.add_argument('--full', action='store_true',
                        help='Run full test including rho=2 (slow)')
    args = parser.parse_args()
    run(full=args.full)
