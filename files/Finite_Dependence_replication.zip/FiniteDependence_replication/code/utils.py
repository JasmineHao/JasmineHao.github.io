import numpy as np
from scipy.stats import norm

# Euler Constant
EULER_CONST = 0.5772156649015328606065120900824

def my_meshgrid(list_of_vec):
    """Generates a meshgrid matrix from a list of vectors."""
    tmp = np.meshgrid(*list_of_vec, sparse=False)
    num_vec = len(list_of_vec)
    num_d0 = len(list_of_vec[0])
    meshgrid_matrix = np.zeros([len(tmp[0].flatten()), 0])
    for d_i in range(num_vec):
        meshgrid_vec = np.zeros(0)
        for n_i in range(num_d0):
            meshgrid_vec = np.append(meshgrid_vec, tmp[d_i][:, n_i].flatten())
        meshgrid_matrix = np.column_stack([meshgrid_matrix, meshgrid_vec])
    return meshgrid_matrix

def my_kron(list_of_matrices):
    """Computes the Kronecker product of a list of matrices."""
    Ftran = np.array([1])
    for mat in list_of_matrices:
        Ftran = np.kron(Ftran, mat)
    return Ftran

def generate_block_diagonal(array_list):
    """Generates a block diagonal matrix."""
    num_rows = len(array_list)
    total_columns = sum(len(arr) for arr in array_list)
    result = np.zeros((num_rows, total_columns), dtype=array_list[0].dtype)
    col_start = 0
    for i, arr in enumerate(array_list):
        result[i, col_start:col_start + len(arr)] = arr
        col_start += len(arr)
    return result

def state_transition(gam_0, gam_1, sigma, ngrid, min_val=None, max_val=None):
    """
    Standard Tauchen method for AR(1) discretization.
    y_t = gam_0 + gam_1 * y_{t-1} + N(0, sigma)
    """
    if min_val is None:
        # Default roughly +/- 3 std devs
        unc_std = np.sqrt(sigma**2 / (1 - gam_1**2))
        unc_mean = gam_0 / (1 - gam_1)
        w_half = 0.5 / ngrid
        min_val = norm.ppf(w_half, loc=unc_mean, scale=unc_std)
        max_val = norm.ppf(1 - w_half, loc=unc_mean, scale=unc_std)

    w = (max_val - min_val) / (ngrid - 1)
    grid = np.linspace(min_val, max_val, ngrid)
    trans_matrix = np.zeros((ngrid, ngrid))

    for i in range(ngrid):
        for j in range(ngrid):
            z_upper = (grid[j] + 0.5 * w - gam_0 - gam_1 * grid[i]) / np.sqrt(sigma)
            z_lower = (grid[j] - 0.5 * w - gam_0 - gam_1 * grid[i]) / np.sqrt(sigma)
            
            if j == 0:
                trans_matrix[i, j] = norm.cdf(z_upper)
            elif j == ngrid - 1:
                trans_matrix[i, j] = 1 - norm.cdf(z_lower)
            else:
                trans_matrix[i, j] = norm.cdf(z_upper) - norm.cdf(z_lower)
    
    if ngrid == 1:
        trans_matrix = np.array([[1.0]])
        
    # Ensure row stochasticity
    trans_matrix = trans_matrix / trans_matrix.sum(axis=1, keepdims=True)
    
    return trans_matrix, grid

def logit(t):
    return 1 / (1 + np.exp(-t))



# %%
def compute_dpi_dtheta(state):
    dvp_dtheta = (np.exp(
        state[:, 1]) * np.array([np.ones_like(state[:, 0]), state[:, 2], state[:, 3]])).T
    dfc_dtheta = -np.array([np.ones_like(state[:, 0]), state[:, 4]]).T
    dec_dtheta = - \
        np.array([(1-state[:, 0]), (state[:, 5] * (1-state[:, 0]))]).T
    dpi_dtheta_1 = np.hstack([dvp_dtheta, dfc_dtheta, dec_dtheta])
    dpi_dtheta = np.array([np.zeros_like(dpi_dtheta_1), dpi_dtheta_1])
    return (dpi_dtheta)


def compute_FP(Ftran, P):
    FP = np.zeros_like(Ftran[0])
    for a in range(Ftran.shape[0]):
        FP = FP + np.diag(P[a]) @ Ftran[a]
    return (FP)

# define the bellman operator


def compute_choice_value(V, Ftran, pi, beta):
    v = np.zeros_like(pi)
    for a in range(Ftran.shape[0]):
        v[a] = pi[a] + beta * Ftran[a] @ V
    return (v)


def compute_choice_probability(V, Ftran, pi, beta):
    v = compute_choice_value(V, Ftran, pi, beta)
    # v = v - np.min(v,axis=0)
    tmp = np.exp(v)
    P = tmp / np.sum(tmp, axis=0)
    return (P)


def bellman_operator(V, Ftran, pi, beta):
    euler_constant = 0.5772156649015328606065120900824
    # euler_constant = 0.6
    v = compute_choice_value(V, Ftran, pi, beta)
    tmp = np.exp(v)
    V = euler_constant + np.log(np.sum(tmp, axis=0))
    # V = np.log(np.sum(tmp,axis=0))
    return (V)


def solve_single_agent_equilibrium_V(theta, Ftran, state, beta, V=None):
    n_state = Ftran.shape[2]
    n_action = Ftran.shape[0]
    dpi_dtheta = compute_dpi_dtheta(state)
    pi = dpi_dtheta @ list(theta)
    # compute value function
    if V is None:
        V = np.zeros(n_state)
    diff = 1
    iter = 0
    tol = 1e-16
    max_iter = 1000
    while (diff > tol) & (iter < max_iter):
        V_new = bellman_operator(V, Ftran, pi, beta)
        iter = iter + 1
        diff = np.max(np.abs(V_new - V))
        V = V_new
    return (V)


# solve for the equilibrium
def solve_single_agent_equilibrium(theta, Ftran, state, beta):
    V = solve_single_agent_equilibrium_V(theta, Ftran, state, beta)
    dpi_dtheta = compute_dpi_dtheta(state)
    pi = dpi_dtheta @ list(theta)
    P = compute_choice_probability(V, Ftran, pi, beta)
    return (V, P)
# %%

def compute_e(P):
    euler_constant = 0.5772156649015328606065120900824
    e = euler_constant - np.log(P)
    return (e)

# %%
# ==========================================
# Generic Logit Equilibrium Solver
# ==========================================

def solve_generic_equilibrium(u, F, beta, tol=1e-8, max_iter=2000):
    """
    Generic equilibrium solver for logit models.

    Args:
        u: Utility matrix (n_actions, n_states)
        F: Transition matrix (n_actions, n_states, n_states)
        beta: Discount factor
        tol: Convergence tolerance
        max_iter: Maximum iterations

    Returns:
        V: Ex-ante value function (n_states,)
        P: Choice probabilities (n_actions, n_states)
    """
    from scipy.special import logsumexp

    n_actions, n_states = u.shape
    V = np.zeros(n_states)
    print(f"Solving Equilibrium...")
    for i in range(max_iter):
        V_prev = V.copy()
        EV = np.einsum('ask,k->as', F, V)
        v_choice = u + beta * EV
        V = logsumexp(v_choice, axis=0) + EULER_CONST
        if np.max(np.abs(V - V_prev)) < tol:
            print(f"Converged in {i+1} iterations.")
            break
    EV = np.einsum('ask,k->as', F, V)
    v_choice = u + beta * EV
    v_max = np.max(v_choice, axis=0)
    exp_v = np.exp(v_choice - v_max)
    P = exp_v / np.sum(exp_v, axis=0)
    return V, P

# ==========================================
# Altug-Miller Labor Supply Model Functions
# ==========================================

def state_to_index_altug_miller(l3, l2, l1, n_hours):
    """Convert labor history (l_{t-3}, l_{t-2}, l_{t-1}) to state index."""
    return l3 * n_hours**2 + l2 * n_hours + l1

def index_to_state_altug_miller(idx, n_hours):
    """Convert state index to labor history (l_{t-3}, l_{t-2}, l_{t-1})."""
    i3 = idx // (n_hours**2)
    i2 = (idx % (n_hours**2)) // n_hours
    i1 = idx % n_hours
    return i3, i2, i1

def build_transition_matrices_altug_miller(hours_grid, n_states):
    """
    Build deterministic transition matrices for Altug-Miller model.
    State evolves as: (l_{t-2}, l_{t-1}, a_t)
    """
    n_hours = len(hours_grid)
    F = np.zeros((n_hours, n_states, n_states))
    for idx in range(n_states):
        l3, l2, l1 = index_to_state_altug_miller(idx, n_hours)
        for a in hours_grid:
            next_idx = state_to_index_altug_miller(l2, l1, a, n_hours)
            F[a, idx, next_idx] = 1.0
    return F

def compute_payoff_altug_miller(n_states, n_actions, hours_grid):
    """
    Compute payoff for Altug-Miller labor supply model.

    u(a, s) = wage(human_capital) * hours - cost(hours)
    where human_capital = sum of past labor hours
    """
    n_hours = len(hours_grid)
    u = np.zeros((n_actions, n_states))
    for idx in range(n_states):
        l3, l2, l1 = index_to_state_altug_miller(idx, n_hours)
        human_capital = (l3 + l2 + l1) * 0.1
        for a in range(n_actions):
            wage = 10 + human_capital
            income = wage * (a * 5)
            cost = 1.5 * (a**2)
            u[a, idx] = income - cost
    return u

# ==========================================
# Dynamic Game Functions
# ==========================================

def find_complementary_sublist(lst, sublist):
    """Return elements in lst that are not in sublist."""
    complementary_list = lst.copy()
    for element in sublist:
        if element in complementary_list:
            complementary_list.remove(element)
    return complementary_list

def compute_ftran_game(P, F_s, state, n_player):
    """
    Compute player-specific transition matrices for dynamic games.
    Integrates out opponents' equilibrium strategies.

    Args:
        P: Equilibrium CCPs (n_player, n_states, n_actions)
        F_s: Exogenous state transition (n_states_exog, n_states_exog)
        state: State grid (n_states, n_dims)
        n_player: Number of players

    Returns:
        Ftran: Array (n_player, n_actions_i, n_states, n_states)
    """
    Ftran_list = []
    for i in range(n_player):
        player_ind = list(range(n_player))
        player_ind.pop(i)

        # Base transition: State evolution + identity for actions
        Ftran_ij = my_kron([F_s] + [np.ones((2,2))] * n_player)

        # Integrate out other players' mixed strategies
        for j in player_ind:
            Ftran_ij[:,state[:,j+1]==1] *= P[j,:,1][:,np.newaxis]
            Ftran_ij[:,state[:,j+1]==0] *= P[j,:,0][:,np.newaxis]

        Ftran_i = np.array([Ftran_ij, Ftran_ij])

        # Deterministic transition for own action
        Ftran_i[0, :, state[:,i+1]==1] = 0
        Ftran_i[1, :, state[:,i+1]==0] = 0
        Ftran_list.append(Ftran_i)
    return np.array(Ftran_list)

def compute_dpi_dtheta_game(state, n_player, P):
    """
    Compute basis functions for game payoffs.

    Payoff: u(a,s) = revenue * log(market_size) - competition - fixed_cost - entry_cost

    Returns:
        dpi_dtheta: (n_player, n_actions, n_states, n_params)
    """
    import itertools

    n_state = len(state)
    dpi_dtheta = np.zeros((n_player, 2, n_state, 4))

    for i in range(n_player):
        player_ind = list(range(n_player))
        player_ind.pop(i)

        competition_effect = np.zeros(n_state)
        for j in range(n_player):
            entry_j_ind_list = list(itertools.combinations(player_ind, j))
            p_j_enter = 0
            for entry_j_ind in entry_j_ind_list:
                no_entry_j_ind = find_complementary_sublist(player_ind, entry_j_ind)
                p_j_enter += (P[entry_j_ind,:,1].prod(axis=0) * P[no_entry_j_ind,:,0].prod(axis=0))
            competition_effect += np.log(j+1) * p_j_enter

        # Basis: [Revenue, Competition, Fixed Cost, Scrap Value]
        dpi_dtheta[i,1] = np.array([
            np.log(state[:,0]),
            -competition_effect,
            -np.ones(n_state),
            -(1-state[:,i+1])
        ]).T
    return dpi_dtheta

def solve_game_equilibrium(state, theta, F_s, discount_factors):
    """
    Solve for Stationary Markov Perfect Equilibrium (MPE).

    Args:
        state: State grid (n_states, n_dims)
        theta: List of parameter vectors, one per player
        F_s: Exogenous state transition matrix
        discount_factors: List of discount factors, one per player

    Returns:
        P: Equilibrium CCPs (n_player, n_states, n_actions)
        V: Value functions (n_player, n_states)
    """
    n_player = len(theta)
    n_state = len(state)

    # Initialize guesses
    P = np.ones((n_player, n_state, 2))/2
    V = np.zeros((n_player, n_state))

    iter_count = 0
    dist = 10
    tol = 1e-6
    max_iter = 1000

    print(f"Solving MPE for {n_player} players...")
    while (iter_count < max_iter) and (dist > tol):
        Ftran = compute_ftran_game(P, F_s, state, n_player)
        dpi_dtheta = compute_dpi_dtheta_game(state, n_player, P)

        P_new = np.zeros_like(P)
        V_new = np.zeros_like(V)

        for i in range(n_player):
            v_1i = dpi_dtheta[i,1] @ theta[i] + discount_factors[i] * Ftran[i,1] @ V[i]
            v_0i = dpi_dtheta[i,0] @ theta[i] + discount_factors[i] * Ftran[i,0] @ V[i]

            P_new[i,:,1] = logit(v_1i - v_0i)
            P_new[i,:,0] = 1 - P_new[i,:,1]

            V_new[i] = EULER_CONST + np.log(np.exp(v_1i) + np.exp(v_0i))

        dist = np.max(np.abs(V_new - V))
        iter_count += 1
        V = V_new
        P = P_new
        if iter_count % 100 == 0:
            print(f"  Iter {iter_count}, Dist: {dist:.2e}")

    print(f"Converged in {iter_count} iterations.")
    return P, V

# ==========================================
# Investment Model Functions
# ==========================================

def compute_payoff_investment(state, theta):
    """
    Compute payoff for investment model.

    u(a, s) = revenue * productivity * capital - cost * action - adjustment_cost * action^2

    Args:
        state: State grid (n_states, n_dims) where dims = [capital, productivity, ...]
        theta: Named tuple with (rev_coef, cost_linear, cost_quad)

    Returns:
        u: Payoff matrix (n_actions, n_states)
    """
    n_s = state.shape[0]
    # Assume 3 actions: [Depreciate, Maintain, Invest]
    u = np.zeros((3, n_s))

    k = state[:, 0]  # Capital
    o = state[:, 1]  # Productivity

    # Action 0: Depreciate
    u[0] = theta.rev_coef * o * k - theta.cost_linear * 0 - theta.cost_quad * 0**2
    # Action 1: Maintain
    u[1] = theta.rev_coef * o * k - theta.cost_linear * 1 - theta.cost_quad * 1**2
    # Action 2: Invest
    u[2] = theta.rev_coef * o * k - theta.cost_linear * 2 - theta.cost_quad * 2**2

    return u
