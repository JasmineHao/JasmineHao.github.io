# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Overview

This repository implements **Finite Dependence** (FD) methods for discrete choice dynamic programming models. The core idea is to approximate infinite-horizon value function differences using weighted sums of finite-horizon path probabilities.

## Code Organization

**IMPORTANT**: All function definitions are centralized in two core modules:
- **FDChecker.py**: FD solvers and verification functions
- **utils.py**: Equilibrium solvers, model-specific functions, and utilities

**Example files** (`_example_*.py`) contain ONLY:
- Parameter specifications
- Model setup (using functions from utils)
- Execution code

Never duplicate function definitions. Always import from FDChecker or utils.

## Running Examples

All example files are in `code/` and can be run directly:

```bash
# Renewal models (rho=1)
python3 code/example_engine_replacement.py    # Rust 1987 bus engine
python3 code/example_job_search.py            # Job search with accept/reject

# Nilpotent models (rho=p)
python3 code/example_labor_p1.py              # Female labor, p=1 lag
python3 code/example_altug_miller.py --full   # Altug-Miller, p=3 lags (rho=3)
python3 code/example_education.py --full      # Keane-Wolpin style, p=4 (rho=4)

# Decay + Strong Control (rho=1)
python3 code/example_investment.py            # Capital accumulation (3 actions)
python3 code/example_inventory.py             # Inventory control (3 actions)

# Triple Connector / Strategic Ripple (rho=2)
python3 code/example_entry_exit.py --full     # Entry/exit with endo productivity
python3 code/example_game.py --full           # 3-player entry/exit game (MPE)
python3 code/example_oligopoly.py --full      # 2-firm dynamic oligopoly
```

Use `--full` flag for models with rho>1 to test all rho values (slower).

## Core Architecture

### FDChecker.py - FD Solvers and Verification

**Core FD Solvers:**
- `solve_finite_dependence_with_constraints()`: Full solver using constrained least squares
  - Enforces: Terminal Distribution Matching, Normalization, Non-Anticipativity
- `solve_finite_dependence_subset()`: Sparse solver for restricted state transitions
  - Uses feasibility masking for deterministic/sparse models
- `get_reachable_paths()`: BFS search for reachable state sequences

**Verification Functions:**
- `verify_finite_dependence_transition()`: Verifies terminal distribution matching
- `verify_finite_dependence_payoff()`: Verifies value function approximation (full solver)
- `verify_payoff_sparse()`: Sparse verification for subset solver

**Utilities:**
- `normalize_transitions()`: Ensures transition matrices sum to 1 (prevents probability leakage)
- `get_sequences()`: Generates all action/state sequences for vectorized computation
- `compute_middle_path_probs()`: Pre-computes path probabilities for efficiency

### utils.py - Equilibrium and Model Functions

**Generic Equilibrium Solvers:**
- `solve_generic_equilibrium()`: Generic logit equilibrium solver for single-agent models
- `solve_single_agent_equilibrium()`: Specialized solver with basis functions
- `bellman_operator()`, `compute_choice_probability()`: DP primitives

**Altug-Miller Model Functions:**
- `state_to_index_altug_miller()`, `index_to_state_altug_miller()`: State indexing
- `build_transition_matrices_altug_miller()`: Deterministic labor history transitions
- `compute_payoff_altug_miller()`: Human capital-based payoffs

**Dynamic Game Functions:**
- `solve_game_equilibrium()`: Markov Perfect Equilibrium (MPE) solver
- `compute_ftran_game()`: Player-specific transitions integrating out opponents
- `compute_dpi_dtheta_game()`: Game payoff basis functions
- `find_complementary_sublist()`: Set operation helper

**Investment Model Functions:**
- `compute_payoff_investment()`: Capital-productivity payoffs

**General Utilities:**
- `state_transition()`: Tauchen method for AR(1) discretization
- `my_kron()`: Kronecker product for multi-dimensional transitions
- `my_meshgrid()`: Generate state grids
- `compute_e()`: CCP correction terms

## State Representation

Models use **multi-period state histories** where:
- **State s_t** = (x_t-p+1, ..., x_t-1, x_t) includes p lags
- **k_seqs** = action sequences of length rho
- **j_seqs** = state sequences of length rho
- Flattened indices use row-major order

## Transition Matrix Format

All transition matrices follow shape `(n_actions, n_states, n_states)`:
```python
F_transitions = {
    't': F,      # Current period
    't+1': F,    # Next period (usually same for stationary models)
    't+2': F,    # Period t+2
    # ... up to t+rho
}
```

For stationary models, all time keys point to the same matrix.

## The Phi Weights

The key FD equation approximates value differences as:
```
v(j,k) - v(j,K) ≈ u(j,k) - u(j,K) + Σ phi * P(path) * discounted_payoffs
```

Phi weights have shape `(n_k_seqs, n_j_seqs)` flattened. The solver enforces:
1. **FD Matching**: Terminal distributions must match between actions k and K
2. **Normalization**: For each j_seq, sum over k_seqs equals 1
3. **Non-Anticipativity**: Weights at time t+1 cannot depend on future states (t+2, ..., t+rho)
4. **Sequential Unity** (Optional): For each time point τ and state value j_τ, marginal probabilities sum to the number of j_seqs containing that state

### Sequential Unity Constraint (New)

This optional constraint ensures marginal probability normalization at each time point:

```python
# Enable Sequential Unity Constraint
phi = solve_finite_dependence_with_constraints(
    F_transitions,
    rho=2,
    use_sequential_unity=True  # Optional parameter
)
```

**When to use:**
- Models with complex state transitions
- When additional numerical stability is needed
- When marginal probability interpretation is important

**Constraint definition:** For each τ ∈ {0, ..., ρ-1} and j_τ ∈ {0, ..., S-1}:
```
∑_{j_other, k_all} φ[j_seq with j_τ at position τ, k_seq] = N
```
where N = number of j_seqs containing j_τ at position τ.

See `code/SEQUENTIAL_UNITY_GUIDE.md` for detailed usage and `code/test_sequential_unity.py` for examples.

## Critical Implementation Details

### Non-Anticipativity Constraint (The Time Machine Fix)

The causality constraint ensures that for a given (j1, d1) pair, the marginal probability over future actions (d2, ...) is identical across all possible future states (j2, ...). This prevents "looking into the future" when choosing actions.

Implementation in FDChecker.py:242-270.

### Feasibility Masking (Subset Solver)

When using `solve_finite_dependence_subset()` for models with restricted transitions:
- Only reachable paths are included in the solver
- Normalization constraints use feasibility masks to avoid putting weight on impossible paths
- This prevents probability leakage in payoff verification

Implementation in FDChecker.py:167-179.

### Probability Normalization

Always call `normalize_transitions()` before FD solving to prevent floating-point drift in transition matrices. Even small deviations (1e-6) compound through path products and cause false verification failures.

## Model-Specific Notes

### Altug-Miller Labor Supply (_example_altug_miller.py)
- State: s_t = (l_t-3, l_t-2, l_t-1) with 3 lags of labor hours
- Uses subset solver due to deterministic state transitions
- Requires feasibility masking for correct normalization

### Investment Model (_example_investment.py)
- 3 actions: [Depreciate, Maintain, Invest]
- Endogenous capital transitions depend on actions
- Exogenous productivity shocks discretized via Tauchen method
- State includes multiple lags of exogenous states

### Dynamic Game (_exmaple_game.py)
- Multi-player entry/exit game
- `compute_ftran_game()` integrates out opponents' equilibrium strategies
- FD verification done per-player holding others' CCPs fixed
- Each player's transition matrix is (n_actions_i, n_states, n_states)

## Common Development Patterns

### Adding a New Model

1. **Write model-specific functions in utils.py**:
   - State indexing functions (if needed)
   - Transition matrix construction
   - Payoff computation

2. **Create example file** that:
   - Imports functions from utils and FDChecker
   - Sets parameters
   - Constructs F_transitions and calls `normalize_transitions()`
   - Solves equilibrium using `solve_generic_equilibrium()` or model-specific solver
   - Runs FD verification loop

3. **Choose appropriate solver**:
   - Use `solve_finite_dependence_with_constraints()` for general models
   - Use `solve_finite_dependence_subset()` for deterministic/sparse transitions

**Example template**:
```python
import utils
from FDChecker import (
    solve_finite_dependence_with_constraints,
    normalize_transitions,
    verify_finite_dependence_payoff
)

# Setup
F = utils.build_my_transitions(...)
F_transitions = normalize_transitions({'t': F, 't+1': F})
u = utils.compute_my_payoff(...)
V, P = utils.solve_generic_equilibrium(u, F, beta)

# Verification
for rho in [1, 2]:
    phi = solve_finite_dependence_with_constraints(F_transitions, rho)
    verify_finite_dependence_payoff(F_transitions, u, v, phi, e, rho)
```

### Debugging Verification Failures

Check in order:
1. **Normalization**: Are transitions normalized? Call `normalize_transitions()` first
2. **Payoff scaling**: Large magnitude differences (>1e3) can cause numerical issues
3. **Stationarity**: F_transitions keys must match the actual time structure
4. **Subset solver**: Are all reachable paths included in feasibility mask?
5. **Residual magnitude**: If residual >> error, FD may not hold for this rho

### Function Location Quick Reference

**When you need to...**
- Solve for phi weights → `FDChecker.solve_finite_dependence_with_constraints()` or `.solve_finite_dependence_subset()`
- Verify FD conditions → `FDChecker.verify_finite_dependence_transition()` or `.verify_finite_dependence_payoff()`
- Solve equilibrium → `utils.solve_generic_equilibrium()` or `.solve_game_equilibrium()`
- Build transitions → Model-specific function in utils (e.g., `build_transition_matrices_altug_miller()`)
- Compute payoffs → Model-specific function in utils (e.g., `compute_payoff_investment()`)

## File Organization

- **code/FDChecker.py** - All FD solvers and verification (centralized)
- **code/utils.py** - All model functions and equilibrium solvers (centralized)
- **code/_example_*.py** - Parameter specifications and execution only (no function definitions)
- **code_past/** - Previous versions and exploratory code (not actively maintained)
