# External Data Inputs

This directory is intentionally empty in the code-only release. See
`../DATA_SPEC.md` for the schema of each required file.

Required:
- `battery_cost_bnef.csv`

Optional (only for the disabled `DECOMP_CHARGING=1` toggle; not needed for
any paper figure or table):
- `cs_gs/cs_gs_city_year_fitted.xlsx`
