# Data Specification — Heterogeneous Diffusion Replication

This document describes the data files the pipeline expects. The underlying
microdata (product-market sales, city-year demographics) is not
redistributable; this spec lets a researcher with access to comparable
sources construct the inputs in the schema the code expects.

The pipeline runs end-to-end if the following inputs are placed at the paths
shown below.

---

## Layer 1 — externally provided (you supply)

### `raw_data/battery_cost_bnef.csv`

Annual global battery-pack price, used to fit Wright's-law in the dynamic
simulation and to instrument EV marginal cost.

| column                  | dtype | unit            | example          |
|-------------------------|-------|-----------------|------------------|
| `year`                  | int   | calendar year   | `2013`           |
| `battery_pack_usd_kwh`  | float | USD per kWh     | `684`            |
| `source`                | str   | citation tag    | `BNEF Battery Price Survey` |

Cover 2013–2024. The pipeline only reads the first two columns; `source` is
documentation. Public source: BloombergNEF Battery Price Survey annual
release (or equivalent — IEA Global EV Outlook also reports compatible
numbers).

### `raw_data/cs_gs/cs_gs_city_year_fitted.xlsx` — **optional**

Per-city-year counts and bartik-fitted predictions of charging-station (CS)
and gas-station (GS) installed base.

**This file is not required for the canonical pipeline.** The default
specification does not include a separately identified charging-station
block (see `report/memos/MEMO_2026_04_25_charging_identification.md` for
why the channel cannot be cleanly identified within the BLP framework).
The file is read only when the optional `DECOMP_CHARGING=1` environment
toggle is set on `2_1_static_decomposition.py`; in that mode the residual
$\xi$ is projected onto $\text{ev} \times \log(1 + \mathrm{cs\_count})$.
None of the figures or tables in the current paper depend on this toggle.

If you do want to enable the charging projection, the file's schema is:

| column                              | dtype | meaning |
|-------------------------------------|-------|---------|
| `Geo_Market`                        | str   | city name (CN) matching `df.parquet` |
| `year`                              | int   | calendar year (2015–2024) |
| `gs_count`                          | int   | observed gas-station count |
| `gs_fitted_bartik`                  | float | log gas-station prediction (bartik-shift with leave-one-out base) |
| `gs_fitted_bartik_contemporaryk`    | float | as above with contemporaneous national base |
| `cs_count`                          | int   | observed charging-station count |
| `cs_fitted_bartik`                  | float | log charging-station prediction |
| `cs_fitted_bartik_contemporaryk`    | float | as above with contemporaneous base |

About 800 rows (≈ 80 cities × 10 years). The `cs_count` / `gs_count`
columns are also pre-merged into `df.parquet`, so for the canonical
pipeline this xlsx is redundant.

---

## Layer 2 — preprocessed panel (you build)

The core demand-estimation input is one parquet file. The pipeline reads it
many times; everything else can be derived from it.

### `output/df.parquet`

Product × market × year panel, one row per (Model, Year, Geo_Market). Roughly
**476k rows × 51 columns** in our sample (79 markets × 10 years × ~600 active
models per market on average).

#### Identifiers and labels

| column          | dtype | example      | notes |
|-----------------|-------|--------------|-------|
| `market_ids`    | str   | `2015-上海市`| `YYYY-CityName`, primary key with `Model` |
| `Model`         | str   | `CC`         | product identifier |
| `Year`          | int   | `2015`       | 2015–2024 |
| `Brand`         | str   | `大众`       | brand-level identity (drives Foreign/JV classification) |
| `Manufacturer`  | str   | `一汽-大众`  | parent JV / OEM (drives 7-class firm groups via `code/_brand_groups.py`) |
| `Geo_Market`    | str   | `上海市`     | city in CN; province-residual cells are `"<Province> - Other"` |
| `BodyType`      | str   | `SEDAN`     | one of SEDAN, SUV, MPV, HATCHBACK, WAGON, PICKUP, MICROVAN |
| `FuelType`      | str   | `ICEV`      | one of BEV, PHEV, REEV, HEV, ICEV (EV = BEV ∪ PHEV ∪ REEV) |
| `SizeSegment`   | str   | `MIDSIZE`   | A0 / A / A+ / B / B+ / C / D segment harmonized |

#### Product attributes

| column                | unit             | notes |
|-----------------------|------------------|-------|
| `price`               | 10k yuan (万元)  | MSRP-equivalent transaction price |
| `log_price`           | log 10k yuan     | `log(price)` |
| `log_size`            | log(mm³)         | log of L × W × H |
| `log_ev_range`        | log km           | NEDC/CLTC range; 0 for non-EVs |
| `log_ev_power`        | log kW           | electric motor power; 0 for non-EVs |
| `log_battery_capacity`| log kWh          | 0 for non-EVs |
| `electric_efficiency` | kWh/100km        | 0 for non-EVs |
| `FuelEfficiency`      | L/100km          | 0 for BEV |
| `Displacement`        | liters           | engine displacement; 0 for BEV |
| `log_power`           | log kW           | total engine power (ICE + electric for hybrids) |
| `BodyType_suv`        | 0/1              | SUV indicator |
| `ev`, `gv`            | 0/1              | EV / GV indicators (mutually exclusive) |

#### Market characteristics

| column                | unit                  | notes |
|-----------------------|-----------------------|-------|
| `Population`          | 10k people (万人)     | city-year resident population |
| `GDP`                 | 100M yuan (亿元)      | nominal city GDP |
| `Income_city`         | yuan/year             | per-capita urban disposable income |
| `Income_rural`        | yuan/year             | per-capita rural disposable income |
| `GDP_per_capita`      | log 10k yuan          | log GDP per capita |
| `pop_density`         | log persons/km²       | |
| `edu_years_pc`        | years                 | mean schooling per capita |
| `edu_years_male/female`| years                | by gender |
| `urb_rate`            | 0–1                   | urbanization rate |
| `gs_count`            | count                 | gas stations (from Layer 1) |
| `gs_fitted_bartik`    | log count             | predicted log-GS (from Layer 1) |
| `cs_count`            | count                 | charging stations (from Layer 1) |
| `cs_fitted_bartik`    | log count             | predicted log-CS (from Layer 1) |

#### Shares (BLP inputs)

| column        | unit        | notes |
|---------------|-------------|-------|
| `shares`      | 0–1         | within-market product share |
| `s_0`         | 0–1         | outside-good share in the market |
| `log_shares`  | log         | `log(shares)` |

Outside-good market size convention: `M_market = Population × 10000 / 2.62 / 5`
(2.62 persons/household × 5-year replacement cycle); `shares` are computed as
units sold / M_market. Outside-good captures households that did not purchase
a new vehicle in the year. This is the convention all downstream scripts
assume; if you use a different convention, adjust the M_PER_ROW constant in
`code/9_4_welfare_direct_indirect.py` and the `1.0 - s_jt.sum()` outside-good
construction in `code/1_blp.py`.

#### Subsidies (key for §6 counterfactual)

| column                       | unit          | notes |
|------------------------------|---------------|-------|
| `nat_subsidy_wan`            | 10k yuan      | national NEV cash subsidy at year-of-purchase (per vehicle) |
| `local_subsidy_wan`          | 10k yuan      | provincial / municipal match |
| `total_subsidy_wan`          | 10k yuan      | `nat_subsidy_wan + local_subsidy_wan` |
| `subsidy_share`              | 0–1           | `total_subsidy_wan / price` |
| `purchase_tax_exemption_wan` | 10k yuan      | 10% MSRP × purchase-tax-exemption-active indicator |
| `tradein_voucher_wan`        | 10k yuan      | 2024 trade-in-voucher amount |
| `local_post2022_wan`         | 10k yuan      | post-2022 city-specific extension (residual cash) |
| `ev_dummy`                   | 0/1           | duplicate of `ev`, used by older subsidy-merger code |

These six subsidy columns must be **zero for all GV (non-EV) rows**. For the
"no-subsidy" counterfactual we set every `*_wan` column to zero on EV rows
while leaving GV rows unchanged.

#### Segment fields

| column           | example                  | notes |
|------------------|--------------------------|-------|
| `segment`        | `sedan_gv`               | `<BodyType-lower>_<gv|ev>` |
| `market_segement`| `2015-上海市-sedan_gv`   | `<market_ids>-<segment>`. Typo (`market_segement`) is fixed and used as-is in the code. |

---

## Layer 3 — policy panel (you build)

### `output/policy_panel_merged.csv`

City-year policy indicators used by `2_1_static_decomposition.py` to build the
Subsidy block. About **791 rows × 19+ columns** (79 cities + national row × 10
years).

Key columns (full list in `code/2_1_static_decomposition.py:372`):

| column                     | dtype | meaning |
|----------------------------|-------|---------|
| `Geo_Market`               | str   | city, matches `df.parquet` |
| `Year`                     | int   | 2015–2024 |
| `province_pkulaw`          | str   | province for matching |
| `license_restrict`         | 0/1   | ICE license-plate restriction active |
| `nev_exempt`               | 0/1   | NEV exempt from license auction/lottery |
| `license_nev_advantage`    | 0/1   | NEV plate advantage active (subset of nev_exempt) |
| `ev_license`               | 0/1   | NEV-specific easy-plate program |
| `nat_subsidy_wan`          | 10k yuan | national subsidy schedule (per-vehicle) |
| `total_subsidy_wan`        | 10k yuan | total subsidy (per-vehicle), city-merged |
| `Income_city`              | yuan/yr | per-capita disposable income |
| `income_norm`              | 0–1     | min-max-normalized income across panel |
| `income_inv_normed`        | 0–1     | inverse income (lower-income cities = higher score) |
| `n_policies`, `n_subsidy`, `n_charging`, `n_license` | int | policy counts |
| `count_simple`, `type_weighted`, `magnitude_score` | float | composite policy intensity indices |
| `ev_policy_primary`        | str/cat | primary EV policy tag |

This file is also used by the year-by-year decomposition loop
(`PIPELINE_STAGE=decomp_byyear`).

---

## Layer 4 — what the pipeline produces (you do not supply)

The remaining files in `output/` are produced by running `code/run_pipeline.sh`
from the inputs above:

- `output/blp_essentials_v12/blp_essentials.npz` — BLP δ, Σ, agent draws (from `1_blp.py`)
- `output/national_mc.parquet` — sticker-space marginal costs (from `1_2_mc_estimation.py`)
- `output/mc_decomposed.parquet` — MC decomposed into observable/unobservable components
- `output/decomp_s4_final/coalition_results.csv` — 64-coalition static decomposition
- `output/decomp_s4_final_byyear_YYYY/coalition_results.csv` — year-by-year sweep
- `output/dynamic_sim_v33*.csv` — dynamic forward-sim outputs (regimes × scenarios)
- `output/check_static_*.csv` — equilibrium-roundtrip diagnostics

A seed bundle of these intermediates is available in the full replication
package (`replication_package.tar.gz`) so the figures and tables can be
regenerated without rerunning the multi-hour BLP and dynamic-sim stages. With
this code-only release, you can rerun the full pipeline from Layers 1–3.

---

## Required Python packages

See `requirements.txt`. Tested on Python 3.10–3.13:

```
numpy>=1.24
pandas>=2.0
pyarrow>=10
scipy>=1.10
matplotlib>=3.7
joblib>=1.3
linearmodels>=5.3
statsmodels>=0.14
openpyxl>=3.1
```

---

## Quick-start with your own data

1. Place your panel at `output/df.parquet` matching the schema above.
2. Place battery-cost CSV at `raw_data/battery_cost_bnef.csv`.
3. Build the policy panel as `output/policy_panel_merged.csv`.
4. (Optional — only if running the disabled `DECOMP_CHARGING=1` toggle:
   place `raw_data/cs_gs/cs_gs_city_year_fitted.xlsx`.)
5. Run:
   ```bash
   pip install -r requirements.txt
   bash code/run_pipeline.sh                       # full pipeline from scratch
   ```
   Or run just the figures stage if you already have a seed bundle of
   intermediates:
   ```bash
   PIPELINE_STAGE=figures bash code/run_pipeline.sh
   ```

If your panel uses different geographic granularity or a different outside-good
size convention, edit the constants flagged in `code/1_blp.py` and
`code/9_4_welfare_direct_indirect.py` before running.
