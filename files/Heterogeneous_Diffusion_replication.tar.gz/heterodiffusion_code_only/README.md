# Heterogeneous Diffusion — Replication Code (Code-Only Release)

This package contains the **complete pipeline code** for the paper. The
underlying microdata (product-level sales, city-year demographics) is
licensed or otherwise not redistributable. To run the pipeline, you supply
your own panel matching the schema documented in
[`DATA_SPEC.md`](DATA_SPEC.md).

A separate full-data bundle (with the seeded `output/` intermediates that
let you regenerate every figure and table without rerunning the multi-hour
BLP and dynamic-sim stages) can be made available on request, subject to the
data provider's terms.

Directory layout:

```
heterodiffusion_code/
├── README.md          # this file
├── DATA_SPEC.md       # schemas for every required input file
├── MANIFEST.md        # complete file manifest
├── requirements.txt   # Python dependencies
├── code/              # Pipeline scripts
│   ├── extra/         # Alternative / appendix figure scripts
│   └── run_pipeline.sh
├── raw_data/          # (empty) Place battery_cost_bnef.csv + cs_gs/ here
├── output/            # (empty) Place df.parquet + policy_panel_merged.csv here;
│                      #         pipeline writes all intermediates here
└── report/memos/      # Pipeline writes tables (.tex) and figures (.png/.pdf) here
```

## Goal

Replicate **every table and chart referenced in `draft.tex`**. Core scripts live
in `code/`; extra scripts (additional diagnostics, dated variants,
appendix-style figures) are in `code/extra/` and can be run as alternatives.

## What is reproduced

Running the full pipeline regenerates:

1. BLP demand estimates (`output/blp_essentials_v12/`)
2. Marginal-cost backout and decomposition (`national_mc.parquet`, `mc_decomposed.parquet`, `mc_true_v33_sticker.parquet`)
3. Static equilibrium validation (`check_static_*.csv`)
4. Pooled 2015→2024 Shapley decomposition (`output/decomp_s4_final/`)
5. Year-by-year Shapley decompositions (`output/decomp_s4_final_byyear_YYYY/`)
6. Dynamic forward simulation (`dynamic_sim_v33*.csv`)
7. Dynamic equilibrium check (`check_dynamic_equilibrium.csv`)
8. All paper tables (`report/memos/tab_*.tex`)
9. All paper figures (`report/memos/fig_*.png` / `.pdf`)

## Required inputs (you supply)

The code-only release ships with empty `raw_data/` and `output/` directories.
Place the following files at the paths shown before running the pipeline:

| File | Source / how to build | Schema |
|------|-----------------------|--------|
| `output/df.parquet` | Build from your product × market × year vehicle-registration panel. | See [DATA_SPEC.md §Layer 2](DATA_SPEC.md) |
| `output/policy_panel_merged.csv` | Build from central + provincial NEV subsidy and license-plate notices. | See [DATA_SPEC.md §Layer 3](DATA_SPEC.md) |
| `raw_data/battery_cost_bnef.csv` | BloombergNEF Battery Price Survey (annual; IEA Global EV Outlook is a compatible substitute). | See [DATA_SPEC.md §Layer 1](DATA_SPEC.md) |

**Optional** (not required for any paper figure or table; only used if you
toggle the disabled `DECOMP_CHARGING=1` charging projection):
`raw_data/cs_gs/cs_gs_city_year_fitted.xlsx`. The same `cs_count` /
`gs_count` columns are already pre-merged into `df.parquet`, so for the
canonical pipeline this file is redundant.

The pipeline then generates everything else (BLP demand estimates, MC backout,
Shapley decompositions, dynamic-sim outputs, all paper figures and tables). See
[DATA_SPEC.md §Layer 4](DATA_SPEC.md) for the full list of produced
intermediates.

### Fast national-MC regeneration

`1_blp.py` is the most expensive stage. If you only need to refresh `national_mc.parquet` after a subsidy or df update, use the much faster standalone backout:

```bash
python3 code/_regen_mc_v33_sticker.py
python3 code/_rebuild_mc_decomposed.py
```

This regenerates `national_mc.parquet` and `mc_decomposed.parquet` from the saved BLP essentials without re-estimating demand.

## Requirements

- Python 3.10+
- `numpy`, `pandas`, `scipy`, `joblib`, `matplotlib`
- `linearmodels`, `statsmodels`
- `pyarrow`, `openpyxl`

Install with:

```bash
pip install -r requirements.txt
```

## Running the pipeline

### Full pipeline

```bash
cd heterodiffusion_code
bash code/run_pipeline.sh
```

### Individual stages

```bash
PIPELINE_STAGE=demand       bash code/run_pipeline.sh   # 1_blp.py
PIPELINE_STAGE=mc           bash code/run_pipeline.sh   # 1_2_mc_estimation.py
PIPELINE_STAGE=check_static bash code/run_pipeline.sh   # 2_0_check_static.py
PIPELINE_STAGE=decomp_main  bash code/run_pipeline.sh   # pooled decomposition
PIPELINE_STAGE=decomp_byyear bash code/run_pipeline.sh  # year-by-year sweep
PIPELINE_STAGE=dynamic_sim  bash code/run_pipeline.sh   # 3_1_dynamic_decomposition.py
PIPELINE_STAGE=check_dynamic bash code/run_pipeline.sh  # 3_0_check_dynamic.py
PIPELINE_STAGE=tables       bash code/run_pipeline.sh   # 9_0 / 9_1 / 9_2 tables
PIPELINE_STAGE=figures      bash code/run_pipeline.sh   # all core paper figures
```

### Extra / alternative figures

```bash
bash code/extra/run_extra_figures.sh
```

This runs the scripts in `code/extra/` (price distribution, MC distribution, dated Shapley variants, sequential ordering, Shapley comparison, etc.). These are **not** referenced in the main paper but are kept as alternatives.

## Paper figure scripts → Overleaf figure mapping

| Overleaf figure | Generated by |
|-----------------|--------------|
| `fig_subsidy_magnitude_2026_06_12.png` | `code/9_2_subsidy_magnitude_fig.py` |
| `fig_ev_progress_ev.png` / `gv.png` | `code/9_4_ev_progress_fig.py` |
| `fig_delta_distribution_ev.png` / `gv.png` | `code/9_8_delta_distribution_fig.py` |
| `fig_xi_distribution_ev.png` / `gv.png` | `code/9_15_xi_distribution_fig.py` |
| `fig_elasticity_elas.png` / `lerner.png` | `code/9_3_elasticity_markup_fig.py` |
| `fig_mc_distribution.png` | `code/9_11_mc_distribution_fig.py` |
| `fig_mc_unobs_distribution.png` | `code/9_12_mc_unobs_distribution_fig.py` |
| `fig_shapley_waterfall_2024_2026_06_15.png` | `code/9_9_shapley_waterfall_fig.py` |
| `fig_seq_waterfall_A.png` / `_B.png` | `code/9_16_sequential_ordering_fig.py` |
| `fig_order_sensitivity_seqA.png` / `seqB.png` / `shapley.png` | `code/9_19_order_sensitivity_fig.py` |
| `fig_shapley_cumulative_share.png` / `qty.png` | `code/9_18_shapley_cumulative_combined_fig.py` |
| `fig_shapley_by_tier.png` | `code/9_32_tier_shapley.py` |
| `fig_ev_range_trajectory.png` | `code/9_20_ev_range_trajectory_fig.py` |
| `fig_dynamic_quantity_path.png` / `channels.png` | `code/9_6_dynamic_quantity_fig.py` |
| `fig_subsidy_equity_share.png` / `benefit.png` | `code/9_5_subsidy_decomp_fig.py` |
| `fig_diffusion_lag.png` | `code/9_30_diffusion_lag.py` |

## Paper table scripts → Overleaf table mapping

| Overleaf table | Generated by |
|----------------|--------------|
| `tab:summary_statistics` | `code/9_0_summary_statistics.py` → `report/memos/tab_summary_statistics.tex` |
| `tab:demand_estimation`, `tab:supply_estimation` | `code/9_2_estimation_tables.py` |
| `tab:endpoints` | `code/2_0_check_static.py` → `output/check_static_endpoints.csv` |
| `tab:shapley` (main 6-block, 2015–2024) | `output/decomp_s4_final/shapley_decomposition.csv` |
| `tab:shapley_robustness` (order sensitivity) | `output/decomp_s4_final/shapley_robustness.csv` |
| `tab:shapley_by_tier` (Quality/Variety/... by city tier) | `code/9_32_tier_shapley.py` |
| `tab:dynamic_sim` (subsidy-removal by regime) | `output/dynamic_sim_v33_aggregated.csv` |
| `tab:channels` (CS direct vs indirect) | `code/9_4_welfare_direct_indirect.py` |
| `tab:retention` (firm-group EV survival) | `code/9_3_firm_group_survival.py` |
| `tab:passthrough` (subsidy pass-through to CS by tier) | `code/9_4_welfare_direct_indirect.py` |
| `tab:lag` (cross-tier diffusion lag) | `code/9_30_diffusion_lag.py` |
| `tab:iv_diagnostics` (per-IV-group F-stats) | `code/9_31_iv_diagnostics.py` |
| `tab:tier_definitions`, `tab:firm_group_definitions` | Hand-written in `draft.tex` appendix |

### Figure-style convention

All paper figures follow two conventions (enforced across the scripts above):

1. **Axis labels and value annotations use `%`**, not `pp`. No `+` sign.
2. **Subfigure panels carry no embedded matplotlib title.** Panel titles are typeset via the LaTeX `\caption{}` inside each `\begin{subfigure}` block.

If you modify a figure script, audit `set_title` / `\,pp` and remove them before regenerating.

## Notes & known issues

- Run all scripts from the `replication/` directory.
- `1_blp.py` is the most expensive stage. If it appears to hang in the MC-backout step, force sequential execution:
  ```bash
  DIY_N_JOBS=1 bash code/run_pipeline.sh
  ```
- `national_mc.parquet` is now generated in **sticker space**: the firm's choice variable is the gross/sticker price (`df["price"]`), and the FOC uses the exact chain rule `∂s/∂sticker = ∂s/∂log(p_net) / p_net` with `p_net = exp(log_price)`. This makes the supply roundtrip in `2_0_check_static.py` pass exactly.
- `mc_decomposed.parquet` is rebuilt from the sticker-space `national_mc.parquet`; the subsidy block in static decomposition now only affects demand-side net prices, not marginal cost.
- `_regen_mc_v33_sticker.py` provides a fast path to regenerate `national_mc.parquet` without rerunning `1_blp.py`.
- `3_1_dynamic_decomposition.py` may emit non-convergence warnings for thin early-year markets; it falls back to observed prices.
- Several figure scripts hard-code a Dropbox/Overleaf copy path. These copies will fail silently if that path does not exist; the local `report/memos/` outputs are always produced.

## File manifest

See `MANIFEST.md` for a complete list of included scripts, inputs, and expected outputs.
