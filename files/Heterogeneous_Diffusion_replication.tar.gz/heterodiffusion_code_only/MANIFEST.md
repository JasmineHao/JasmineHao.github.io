# Replication Package Manifest

## Core code (`code/`)

| File | Role |
|------|------|
| `run_pipeline.sh` | Master orchestration script |
| `_decomp_year_sweep.sh` | Helper for year-by-year decomposition |
| `1_blp.py` | BLP demand estimation (S4 / v12 log-price spec) |
| `1_2_mc_estimation.py` | MC estimation wrapper |
| `_rebuild_subsidy.py` | Rebuilds `df.parquet.total_subsidy_wan` |
| `_regen_mc_v33_sticker.py` | Backs out sticker-space MC (v33 convention) |
| `_regen_mc_v33_sticker.py` | Fast regeneration of `national_mc.parquet` from saved BLP essentials |
| `_rebuild_mc_decomposed.py` | Rebuilds `mc_decomposed.parquet` |
| `2_0_check_static.py` | Static equilibrium validation |
| `2_1_static_decomposition.py` | 64-coalition Shapley decomposition |
| `3_1_dynamic_decomposition.py` | Dynamic forward simulation |
| `3_0_check_dynamic.py` | Dynamic equilibrium validation |
| `9_0_summary_statistics.py` | Summary statistics table |
| `9_1_heterogeneity.py` | Heterogeneity tables + `fig_heterogeneity.png` |
| `9_2_estimation_tables.py` | Demand & supply estimation tables |
| `9_2_subsidy_magnitude_fig.py` | `fig_subsidy_magnitude*` |
| `9_4_ev_progress_fig.py` | `fig_ev_progress*` |
| `9_8_delta_distribution_fig.py` | `fig_delta_distribution*` |
| `9_15_xi_distribution_fig.py` | `fig_xi_distribution*` |
| `9_3_elasticity_markup_fig.py` | `fig_elasticity_elas`, `fig_elasticity_lerner` |
| `9_19_order_sensitivity_fig.py` | `fig_order_sensitivity*` |
| `9_9_shapley_waterfall_fig.py` | `fig_shapley_waterfall_2024_2026_06_15` |
| `9_18_shapley_cumulative_combined_fig.py` | `fig_shapley_cumulative_share`, `fig_shapley_cumulative_qty` |
| `9_6_dynamic_quantity_fig.py` | `fig_dynamic_quantity_path`, `fig_dynamic_quantity_channels` |
| `9_5_subsidy_decomp_fig.py` | `fig_subsidy_equity_share`, `fig_subsidy_equity_benefit` |
| `9_20_ev_range_trajectory_fig.py` | `fig_ev_range_trajectory` |
| `_brand_groups.py` | Manufacturer → firm-group helper |
| `_plot_style.py` | Shared plotting style helper |

## Extra / alternative code (`code/extra/`)

| File | Role |
|------|------|
| `run_extra_figures.sh` | Runs all extra figure scripts |
| `9_7_heterogeneity_fig.py` | `fig_price_distribution*` |
| `9_10_shapley_cumulative_fig.py` | Dated cumulative-share variant |
| `9_11_mc_distribution_fig.py` | `fig_mc_distribution*` |
| `9_12_mc_unobs_distribution_fig.py` | `fig_mc_unobs_distribution*` |
| `9_13_shapley_waterfall_qty_fig.py` | Quantity waterfall variant |
| `9_14_shapley_cumulative_qty_fig.py` | Dated cumulative-qty variant |
| `9_16_sequential_ordering_fig.py` | `fig_seq_waterfall_A/B` |
| `9_17_shapley_comparison_fig.py` | `fig_shapley_comparison` |

## Input / seed data (`output/` and `raw_data/`)

| File | Purpose |
|------|---------|
| `output/df.parquet` | Product-market panel |
| `output/policy_panel_merged.csv` | City-year policy panel |
| `output/blp_essentials_v12/blp_essentials.npz` | BLP parameters and agent draws |
| `output/diy_blp_v12.csv`, `ols_logit_v12.csv`, `iv_logit_v12.csv` | BLP/Logit estimates |
| `output/national_mc.parquet` | National-FOC sticker-space MC backout (mc_true) |
| `output/diy_mc_ols_v12.csv`, `diy_mc_iv_v12.csv`, `diy_mc_ols_ev_v12.csv`, `diy_mc_ols_gv_v12.csv` | MC regression coefficients |
| `output/mc_learning_results.csv` | Wright's Law parameters |
| `output/diy_mc_v12.csv` | Per-product-market MC / elasticity / markup |
| `output/mc_decomposed.parquet` | MC decomposition |
| `output/mc_true_v33_sticker.parquet` | Sticker-space MC backout |
| `output/decomp_s4_final/` | Pooled Shapley decomposition |
| `output/decomp_s4_final_byyear_YYYY/` | Year-by-year decompositions |
| `output/dynamic_sim_v33_aggregated.csv` | Dynamic simulation aggregates |
| `raw_data/battery_cost_bnef.csv` | BNEF battery cost |
| `raw_data/cs_gs/cs_gs_city_year_fitted.xlsx` | Charging/gas-station data |

## Outputs produced

After running the pipeline, `output/` and `report/memos/` will contain the regenerated BLP/MC/decomposition/dynamic-simulation results, plus all `.tex` tables and `.png`/`.pdf` figures.
