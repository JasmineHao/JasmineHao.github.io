"""
9_5_subsidy_decomp_fig.py
==========================
Core narrative:
  Historical (2015–2022): high-income cities captured 57.5 % of EV subsidies;
  low-income cities' EV adoption share was rising toward 30 %+ just as the
  national subsidy hit zero (2023).  A restored 2015-level subsidy in 2024
  would nearly equalize the distribution — and be worth more per yuan of car
  price for lower-income buyers.

Panel A: EV adoption share by city income tier (2015–2024)
         with national subsidy level on right axis
Panel B: Historical subsidy benefit share vs. counterfactual (2024 + 2015 subsidy)
         by city income tier; annotated with effective subsidy rate
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = ["Arial Unicode MS", "DejaVu Sans"]
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT  = f"{ROOT}/report/memos"
OVERLEAF = "/Users/jasminehao/Dropbox/Apps/Overleaf/heterogenous_diffusion/figures"
os.makedirs(OUT, exist_ok=True)

YEARS = list(range(2015, 2025))

# ── Load & prepare ─────────────────────────────────────────────────────────────
df = pd.read_parquet(f"{ROOT}/output/df.parquet")
ev = df[df["ev_dummy"] == 1].copy()
ev["sales_proxy"] = ev["shares"] * ev["Population"]
ev["nat_benefit"]  = ev["nat_subsidy_wan"] * ev["sales_proxy"]
ev["city"] = ev["market_segement"].str.split("-").str[1]

city_base = (ev[ev["Year"] == 2020]
             .drop_duplicates("city")[["city", "GDP_per_capita"]])
q33, q67 = city_base["GDP_per_capita"].quantile([0.33, 0.67])
city_base["income_tier"] = pd.cut(
    city_base["GDP_per_capita"],
    bins=[0, q33, q67, 1e9],
    labels=["Low-Income\nCities", "Mid-Income\nCities", "High-Income\nCities"])
ev = ev.merge(city_base[["city", "income_tier"]], on="city", how="left")

TIERS  = ["Low-Income\nCities", "Mid-Income\nCities", "High-Income\nCities"]
COLORS = {
    "Low-Income\nCities":  "#4dac26",
    "Mid-Income\nCities":  "#f4a261",
    "High-Income\nCities": "#d6604d",
}

# ── Panel A data ──────────────────────────────────────────────────────────────
sales = (ev.groupby(["Year", "income_tier"], observed=True)["sales_proxy"]
           .sum().unstack().fillna(0).reindex(columns=TIERS).reindex(YEARS).fillna(0))
sales_pct = sales.div(sales.sum(axis=1), axis=0) * 100

nat_sub = (ev.drop_duplicates(["Brand", "Model", "FuelType", "Year"])
             .groupby("Year")["nat_subsidy_wan"].mean()
             .reindex(YEARS, fill_value=0))

# ── Panel B data ──────────────────────────────────────────────────────────────
ben = (ev.groupby(["Year", "income_tier"], observed=True)["nat_benefit"]
         .sum().unstack().fillna(0).reindex(columns=TIERS))
hist_ben = ben.loc[2015:2022].sum()
hist_pct = hist_ben / hist_ben.sum() * 100

NAT2015 = 3.724
ev24 = ev[ev["Year"] == 2024].copy()
ev24["cf_benefit"] = NAT2015 * ev24["sales_proxy"]
cf_abs = (ev24.groupby("income_tier", observed=True)["cf_benefit"]
               .sum().reindex(TIERS, fill_value=0))
cf_pct  = cf_abs / cf_abs.sum() * 100

avg_price_24 = (ev24.groupby("income_tier", observed=True)
                .apply(lambda g: np.average(g["price"],
                                            weights=g["sales_proxy"].clip(lower=1e-12)),
                       include_groups=False)
                .reindex(TIERS))
eff_rate = NAT2015 / avg_price_24 * 100


# ── Panel A: EV adoption trajectory + subsidy overlay ─────────────────────────
def draw_panel_A(ax):
    ax1r = ax.twinx()

    bottom = np.zeros(len(YEARS))
    for tier in TIERS:
        vals = sales_pct[tier].values
        ax.fill_between(YEARS, bottom, bottom + vals,
                        color=COLORS[tier], alpha=0.72, linewidth=0)
        ax.plot(YEARS, bottom + vals,
                color=COLORS[tier], lw=0.5, alpha=0.5)
        bottom = bottom + vals

    ax1r.plot(YEARS, nat_sub.values, color="#222222", lw=2.4,
              marker="o", ms=5, ls="-", zorder=6,
              label="Nat. subsidy\n(1000 CNY/vehicle)")
    ax1r.fill_between(YEARS, 0, nat_sub.values,
                       color="#222222", alpha=0.08, zorder=3)
    ax1r.set_ylim(0, 6.5)
    ax1r.set_ylabel("National Subsidy (10k CNY / vehicle)", fontsize=9.5, color="#333")
    ax1r.tick_params(axis="y", colors="#333", labelsize=8.5)

    ax1r.annotate("Subsidy\nends 2023",
                  xy=(2023, 0.05), xytext=(2021.5, 2.4),
                  fontsize=7.5, color="#222", ha="center",
                  arrowprops=dict(arrowstyle="->", color="#777", lw=0.9))

    ax.axvline(2023, color="#555", lw=1.2, ls="--", alpha=0.5, zorder=5)

    for yr in [2015, 2024]:
        bottom_acc = 0
        for tier in TIERS:
            v = sales_pct.loc[yr, tier]
            if v >= 9:
                mid_y = bottom_acc + v / 2
                ax.text(yr, mid_y, f"{v:.0f}%",
                        ha="center", va="center",
                        fontsize=8.5, color="white", fontweight="bold",
                        zorder=7)
            bottom_acc += v

    ax.set_xlim(2015, 2024)
    ax.margins(x=0)
    ax.set_xticks(YEARS)
    ax.set_xticklabels([str(y) for y in YEARS], fontsize=8, rotation=30, ha="right")
    ax.set_ylim(0, 100)
    ax.set_ylabel("Share of National EV Sales (%)", fontsize=10)
    ax.spines[["top"]].set_visible(False)
    ax.tick_params(labelsize=9)

    legend_patches = [mpatches.Patch(fc=COLORS[t], alpha=0.75, label=t.replace("\n", " "))
                      for t in TIERS]
    legend_patches.append(Line2D([0], [0], color="#222", lw=2, marker="o", ms=4.5,
                                  label="Nat. subsidy (right axis)"))
    ax.legend(handles=legend_patches, fontsize=8, frameon=False,
               loc="upper right", title="City Income Tier", title_fontsize=8)


# ── Panel B: Benefit share historical vs counterfactual ───────────────────────
def draw_panel_B(ax):
    x = np.arange(len(TIERS))
    w = 0.32

    bars_h = ax.bar(x - w/2, hist_pct.values, width=w,
                     color=[COLORS[t] for t in TIERS],
                     alpha=0.45, linewidth=0.8,
                     edgecolor=[COLORS[t] for t in TIERS])
    bars_c = ax.bar(x + w/2, cf_pct.values, width=w,
                     color=[COLORS[t] for t in TIERS],
                     alpha=0.92, linewidth=0)

    for bar, v in zip(bars_h, hist_pct.values):
        ax.text(bar.get_x() + bar.get_width()/2, v + 0.8,
                f"{v:.1f}%", ha="center", va="bottom", fontsize=8.5, color="#555")

    for bar, v, rate in zip(bars_c, cf_pct.values, eff_rate.values):
        ax.text(bar.get_x() + bar.get_width()/2, v + 0.8,
                f"{v:.1f}%", ha="center", va="bottom", fontsize=8.5,
                color="#222", fontweight="bold")
        ax.text(bar.get_x() + bar.get_width()/2, v + 4.2,
                f"({rate:.0f}% of price)", ha="center", va="bottom",
                fontsize=7.0, color="#555", style="italic")

    ax.set_xticks(x)
    ax.set_xticklabels([t.replace("\n", " ") for t in TIERS], fontsize=9.5)
    ax.set_ylim(0, 80)
    ax.set_yticks([0, 20, 40, 60])
    ax.set_ylabel("Share of Total Subsidy Benefit (%)", fontsize=10)
    ax.spines[["top", "right"]].set_visible(False)
    ax.tick_params(labelsize=9)

    h_patch = mpatches.Patch(fc="gray", alpha=0.45, ec="gray", lw=0.8,
                              label="Historical avg. (2015--2022)")
    c_patch = mpatches.Patch(fc="gray", alpha=0.92, ec="none",
                              label="Counterfactual: 2024 + 2015 subsidy")
    ax.legend(handles=[h_patch, c_patch], fontsize=8.5, frameon=False, loc="upper left")


# ── Combined figure ────────────────────────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(13, 4.2),
                         gridspec_kw={"wspace": 0.40})
draw_panel_A(axes[0])
draw_panel_B(axes[1])

for ext in ("png", "pdf"):
    fp = f"{OUT}/fig_subsidy_equity.{ext}"
    fig.savefig(fp, bbox_inches="tight", dpi=200 if ext == "png" else 72)
    print(f"Saved -> {fp}")
plt.close(fig)

# ── Individual panel saves ─────────────────────────────────────────────────────
fig_a, ax_a = plt.subplots(figsize=(7.5, 4.5), constrained_layout=True)
draw_panel_A(ax_a)
for ext in ("png", "pdf"):
    fp = f"{OUT}/fig_subsidy_equity_share.{ext}"
    fig_a.savefig(fp, bbox_inches="tight", dpi=200 if ext == "png" else 72)
    print(f"Saved -> {fp}")
fig_a.savefig(f"{OVERLEAF}/fig_subsidy_equity_share.png", dpi=200, bbox_inches="tight")
plt.close(fig_a)

fig_b, ax_b = plt.subplots(figsize=(5.5, 4.5), constrained_layout=True)
draw_panel_B(ax_b)
for ext in ("png", "pdf"):
    fp = f"{OUT}/fig_subsidy_equity_benefit.{ext}"
    fig_b.savefig(fp, bbox_inches="tight", dpi=200 if ext == "png" else 72)
    print(f"Saved -> {fp}")
fig_b.savefig(f"{OVERLEAF}/fig_subsidy_equity_benefit.png", dpi=200, bbox_inches="tight")
plt.close(fig_b)
