#!/usr/bin/env bash
# =============================================================================
# Extra / alternative figures not referenced in the main paper (draft.tex)
# =============================================================================
# These scripts produce additional diagnostics, dated variants, and appendix-
# style figures. They are kept as alternatives and are not part of the core
# replication pipeline.
#
# Usage:
#   bash code/extra/run_extra_figures.sh
# =============================================================================
set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
CODE="$SCRIPT_DIR"
ROOT="$( cd "$SCRIPT_DIR/../.." && pwd )"
cd "$ROOT"

python3 "$CODE/9_7_heterogeneity_fig.py"          # fig_price_distribution*
python3 "$CODE/9_10_shapley_cumulative_fig.py"    # dated cumulative share variant
python3 "$CODE/9_11_mc_distribution_fig.py"       # fig_mc_distribution*
python3 "$CODE/9_12_mc_unobs_distribution_fig.py" # fig_mc_unobs_distribution*
python3 "$CODE/9_13_shapley_waterfall_qty_fig.py" # quantity waterfall variant
python3 "$CODE/9_14_shapley_cumulative_qty_fig.py"  # dated cumulative qty variant
python3 "$CODE/9_16_sequential_ordering_fig.py"   # fig_seq_waterfall_A/B
python3 "$CODE/9_17_shapley_comparison_fig.py"    # fig_shapley_comparison

echo "✓ Extra figures complete"
