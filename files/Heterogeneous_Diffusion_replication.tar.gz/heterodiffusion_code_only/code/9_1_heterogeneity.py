"""
_heterogeneity_analysis.py
==========================

Heterogeneity analysis of the subsidy-removal counterfactual at 2024.
Computes three breakdowns directly from BLP essentials + df + mc_v33,
mirroring the canonical sim's iter-0 (no FOC iteration, additive subsidy):

  1. Firm survival: per firm-group, EV product count, total EV Q, total
     profit, and the actual-vs-no-subsidy survival rate.
  2. Geographic: per-city EV qty and EV share under both scenarios.
  3. Consumer welfare: per-city ΔCS = CS_no_sub − CS_actual, computed
     from the BLP agent-integral inclusive value.

Outputs:
  output/tab_firm_survival_no_sub.csv
  output/tab_geo_heterogeneity.csv
  output/tab_consumer_welfare.csv
  output/fig_heterogeneity.png
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "output")
NS = 25
M_PER_ROW = 21220.0
YEAR_TARGET = 2024

ess = np.load(f"{OUT}/blp_essentials_v12/blp_essentials.npz", allow_pickle=True)
PI_P = float(ess["pi_price"])
SIGMA_EV = float(ess["sigma_diag"][1])
beta_labels = list(ess["beta_labels"].astype(str))
# Path D canonical: log-price spec. β_log_price enters α_i = β + π·inc_inv.
BETA_PRICE = float(ess["beta"][beta_labels.index("log_price")])
delta_loaded = ess["delta"]
nu_attrs = ess["nu_attrs_v12"]
inc_inv = ess["income_inv_normed_v12"]
markets_blp = ess["markets_v12"].astype(str)

df = pd.read_parquet(f"{ROOT}/output/df.parquet")
df["log_power_gv"] = (1.0 - df["ev_dummy"]) * df["log_power"]

def _singleton_filter(d):
    out = d.copy()
    vs = [v for v in ["log_size", "Displacement", "electric_efficiency",
                      "FuelEfficiency", "log_ev_range"] if v in out.columns]
    grp = out.groupby("market_segement", sort=False)
    n = grp[vs[0]].transform("size")
    for v in vs:
        s = grp[v].transform("sum")
        out[f"{v}_iv_diff"] = np.abs(out[v] - np.where(n > 1, (s - out[v]) / (n - 1), np.nan))
    return out.dropna(subset=[f"{v}_iv_diff" for v in vs]).reset_index(drop=True)

df = _singleton_filter(df)
assert len(df) == len(delta_loaded)
# Path D log-price spec: subtract β × log_price (not β × level-price).
delta_NET = delta_loaded - BETA_PRICE * df["log_price"].values

# Subsidy + sticker (additive)
df["sticker"] = df["price"] + df["total_subsidy_wan"].fillna(0)
df["subsidy_amt"] = df["total_subsidy_wan"].fillna(0)

# mc (per-row, canonical)
mc_v33 = pd.read_parquet(f"{OUT}/mc_true_v33_sticker.parquet")
df["mc_v33"] = mc_v33.sort_values("row_idx")["mc_true_v33"].values

mkt_to_blpidx = {m: list(markets_blp).index(m) for m in df["market_ids"].unique() if m in markets_blp}
agent_w = np.full(NS, 1.0 / NS)

# Firm-group mapping (4-tier industry classification)
FIRM_GROUPS = {
    # BYD
    "比亚迪汽车": "BYD",
    # Tesla
    "特斯拉": "Tesla", "特斯拉(上海)": "Tesla",
    # New Forces (post-2014 EV-only startups)
    "蔚来汽车": "NewForces", "小鹏汽车": "NewForces", "理想汽车": "NewForces",
    "威马汽车": "NewForces", "哪吒汽车": "NewForces", "零跑汽车": "NewForces",
    "极氪汽车": "NewForces", "高合汽车": "NewForces", "小米汽车": "NewForces",
    "智己汽车": "NewForces", "岚图汽车": "NewForces", "极石汽车": "NewForces",
    "极狐汽车": "NewForces", "腾势": "NewForces", "AITO问界": "NewForces",
    "智界汽车": "NewForces", "享界汽车": "NewForces",
    # Foreign / JV (will pick up via prefix)
}
def firm_group(manu):
    if manu in FIRM_GROUPS:
        return FIRM_GROUPS[manu]
    if any(x in manu for x in ["大众", "丰田", "本田", "日产", "宝马", "奔驰",
                                 "奥迪", "现代", "起亚", "通用", "福特", "马自达",
                                 "斯巴鲁", "三菱", "雷诺", "标致", "雪铁龙",
                                 "保时捷", "沃尔沃", "凯迪拉克", "雪佛兰", "别克",
                                 "捷豹", "路虎", "MINI", "讴歌", "雷克萨斯",
                                 "英菲尼迪", "克莱斯勒", "Jeep", "林肯", "斯柯达",
                                 "西雅特", "兰博基尼", "宾利", "玛莎拉蒂", "阿尔法",
                                 "菲亚特"]):
        return "ForeignJV"
    return "TradOEM"

df["firm_group"] = df["Manufacturer"].map(firm_group)

# Print firm-group composition
print("=" * 70)
print("Firm-group composition (2024 EV products)")
print("=" * 70)
prods24 = df[(df["Year"] == YEAR_TARGET) & (df["ev_dummy"] == 1)].drop_duplicates(["Model", "FuelType"])
print(prods24.groupby("firm_group").size().sort_values(ascending=False).to_string())
print(f"  Total 2024 EV products: {len(prods24)}")

# =============================================================================
# Compute per-market iter-0 shares for actual and no_subsidy scenarios at 2024.
# =============================================================================
df24 = df[df["Year"] == YEAR_TARGET].reset_index(drop=False).rename(columns={"index": "orig_idx"})

def shares_iter0(df_m, sub_scale):
    bidx = mkt_to_blpidx.get(df_m["market_ids"].iloc[0])
    if bidx is None:
        return None, None, None
    inc_i = inc_inv[bidx]
    nu_i = nu_attrs[bidx, :, 0]
    rows = df_m["orig_idx"].values
    delta_m = delta_NET[rows]
    sticker = df_m["sticker"].values
    subsidy = df_m["subsidy_amt"].values * sub_scale
    net = np.maximum(sticker - subsidy, 1e-3)
    ev_d = df_m["ev_dummy"].values.astype(float)
    alpha_i = BETA_PRICE + PI_P * inc_i
    # Path D log-price utility. At sub_scale=1.0 net == df["price"] so we use
    # df["log_price"] directly (BLP X1 convention, ~23% rows ≠ log(net));
    # at sub_scale=0.0 net = sticker, so use log(net).
    if abs(sub_scale - 1.0) < 1e-9 and "log_price" in df_m.columns:
        log_net = df_m["log_price"].values
    else:
        log_net = np.log(net)
    u = (delta_m[:, None] + alpha_i[None, :] * log_net[:, None]
         + SIGMA_EV * np.outer(ev_d, nu_i))
    u_max = np.maximum(0.0, u.max(axis=0, keepdims=True))
    e = np.exp(u - u_max)
    e0 = np.exp(-u_max[0])
    denom = e0 + e.sum(axis=0)
    s_ij = e / denom[None, :]
    s_j = s_ij @ agent_w
    # Consumer surplus per agent: CS_i = log(denom_i) / |α_i|  in 10k yuan
    # (E[max u] under EV1 errors = log(denom) − γ; γ cancels in ΔCS)
    log_denom_i = np.log(np.maximum(denom, 1e-300)) + u_max.squeeze()
    cs_i = log_denom_i / np.maximum(np.abs(alpha_i), 1e-6)  # per agent, in 10k yuan
    cs_market = float(cs_i @ agent_w)  # mean across agents, in 10k yuan
    return s_j, sticker, cs_market

results = []
for m_id, df_m in df24.groupby("market_ids"):
    if m_id not in mkt_to_blpidx:
        continue
    s_actual, P_actual, cs_actual = shares_iter0(df_m, sub_scale=1.0)
    s_no_sub, P_no_sub, cs_no_sub = shares_iter0(df_m, sub_scale=0.0)
    if s_actual is None:
        continue
    pop = df_m["Population"].iloc[0]
    M_c = pop * M_PER_ROW
    ev_d = df_m["ev_dummy"].values
    firm_g = df_m["firm_group"].values
    models = df_m["Model"].values
    fueltypes = df_m["FuelType"].values
    for j in range(len(df_m)):
        results.append({
            "market_ids": m_id,
            "Population": pop,
            "M_c": M_c,
            "Model": models[j],
            "FuelType": fueltypes[j],
            "ev_dummy": int(ev_d[j]),
            "firm_group": firm_g[j],
            "s_actual": s_actual[j],
            "s_no_sub": s_no_sub[j],
            "q_actual": s_actual[j] * M_c,
            "q_no_sub": s_no_sub[j] * M_c,
            "cs_actual_market": cs_actual,
            "cs_no_sub_market": cs_no_sub,
            "log_inc_inv_mean": float(inc_inv[mkt_to_blpidx[m_id]].mean()),
        })

prod_mkt = pd.DataFrame(results)
print(f"\nComputed per-(market, product) outcomes: {len(prod_mkt):,} rows")
print(f"  Total 2024 EV quantity at actual: {prod_mkt.loc[prod_mkt['ev_dummy']==1, 'q_actual'].sum()/1e6:.2f} M cars")
print(f"  Total 2024 EV quantity at no-sub: {prod_mkt.loc[prod_mkt['ev_dummy']==1, 'q_no_sub'].sum()/1e6:.2f} M cars")

# =============================================================================
# 1. Firm survival
# =============================================================================
print("\n" + "=" * 70)
print("(1) Firm survival under no-subsidy")
print("=" * 70)
ev = prod_mkt[prod_mkt["ev_dummy"] == 1]
firm_summary = ev.groupby("firm_group").agg(
    n_products=("Model", lambda x: x.nunique()),
    q_actual_M=("q_actual", lambda x: x.sum() / 1e6),
    q_no_sub_M=("q_no_sub", lambda x: x.sum() / 1e6),
).reset_index()
firm_summary["retention_pct"] = (firm_summary["q_no_sub_M"] / firm_summary["q_actual_M"]) * 100
firm_summary["loss_M"] = firm_summary["q_actual_M"] - firm_summary["q_no_sub_M"]
firm_summary = firm_summary.sort_values("q_actual_M", ascending=False)
print(firm_summary.round(2).to_string(index=False))
firm_summary.to_csv(f"{OUT}/tab_firm_survival_no_sub.csv", index=False)
print(f"\nSaved → {OUT}/tab_firm_survival_no_sub.csv")

# =============================================================================
# 2. Geographic heterogeneity
# =============================================================================
print("\n" + "=" * 70)
print("(2) Geographic heterogeneity")
print("=" * 70)
def _tier_from_market(m):
    cities_t1 = {"北京市", "上海市", "广州市", "深圳市"}
    cities_nt1 = {"成都市", "杭州市", "武汉市", "重庆市", "南京市", "天津市",
                   "苏州市", "西安市", "长沙市", "沈阳市", "青岛市", "郑州市",
                   "大连市", "东莞市", "宁波市"}
    city = m.split("-", 1)[1] if "-" in m else m
    if city in cities_t1:
        return "T1"
    if city in cities_nt1:
        return "NT1"
    if "Other" in city:
        return "Rest"
    return "T2"

# Per-market aggregates
geo = prod_mkt.groupby("market_ids").apply(lambda g: pd.Series({
    "Population": g["Population"].iloc[0],
    "q_total_actual_M": g["q_actual"].sum() / 1e6,
    "q_total_no_sub_M": g["q_no_sub"].sum() / 1e6,
    "ev_q_actual_M": g.loc[g["ev_dummy"]==1, "q_actual"].sum() / 1e6,
    "ev_q_no_sub_M": g.loc[g["ev_dummy"]==1, "q_no_sub"].sum() / 1e6,
    "cs_actual_per_cap": g["cs_actual_market"].iloc[0],
    "cs_no_sub_per_cap": g["cs_no_sub_market"].iloc[0],
})).reset_index()
geo["city_tier"] = geo["market_ids"].apply(_tier_from_market)
geo["ev_share_actual"] = geo["ev_q_actual_M"] / geo["q_total_actual_M"] * 100
geo["ev_share_no_sub"] = geo["ev_q_no_sub_M"] / geo["q_total_no_sub_M"] * 100
geo["ev_q_drop_pct"] = (geo["ev_q_no_sub_M"] / geo["ev_q_actual_M"] - 1) * 100
geo["delta_cs_per_cap"] = geo["cs_no_sub_per_cap"] - geo["cs_actual_per_cap"]  # negative if subsidy helps

# By tier
tier_summary = geo.groupby("city_tier").agg(
    n_cities=("market_ids", "count"),
    pop_M=("Population", lambda x: x.sum() / 1e2),  # 10k → M
    ev_q_actual_M=("ev_q_actual_M", "sum"),
    ev_q_no_sub_M=("ev_q_no_sub_M", "sum"),
    ev_share_actual=("ev_share_actual", "mean"),
    ev_share_no_sub=("ev_share_no_sub", "mean"),
    delta_cs_per_cap=("delta_cs_per_cap", "mean"),
).round(2).reset_index()
tier_summary["ev_q_drop_pct"] = (tier_summary["ev_q_no_sub_M"] / tier_summary["ev_q_actual_M"] - 1) * 100
tier_summary = tier_summary.reindex(columns=["city_tier", "n_cities", "pop_M",
    "ev_q_actual_M", "ev_q_no_sub_M", "ev_q_drop_pct",
    "ev_share_actual", "ev_share_no_sub", "delta_cs_per_cap"])
print("By city tier:")
print(tier_summary.round(2).to_string(index=False))
geo.to_csv(f"{OUT}/tab_geo_heterogeneity.csv", index=False)
tier_summary.to_csv(f"{OUT}/tab_geo_heterogeneity_by_tier.csv", index=False)

# Top / bottom 10 cities by EV qty drop
geo_sorted = geo.sort_values("ev_q_drop_pct")
print("\nTop 10 cities most-exposed (largest EV qty % drop under no-sub):")
print(geo_sorted[["market_ids", "city_tier", "ev_q_actual_M", "ev_q_no_sub_M", "ev_q_drop_pct", "delta_cs_per_cap"]].head(10).round(2).to_string(index=False))
print("\nTop 10 cities least-exposed (smallest EV qty drop):")
print(geo_sorted[["market_ids", "city_tier", "ev_q_actual_M", "ev_q_no_sub_M", "ev_q_drop_pct", "delta_cs_per_cap"]].tail(10).round(2).to_string(index=False))

# =============================================================================
# 3. Consumer welfare summary
# =============================================================================
print("\n" + "=" * 70)
print("(3) Consumer welfare (ΔCS = CS_no_sub − CS_actual, 10k yuan/agent)")
print("=" * 70)
# Units: cs_per_cap is in 10k yuan per BLP-agent. Each market has M_c =
#   Population_万 × M_PER_ROW agents. Total market CS (bn yuan) =
#   pop_万 × M_PER_ROW × cs_per_cap × (1e4 yuan/万) / (1e9 yuan/bn) =
#   pop_万 × M_PER_ROW × cs_per_cap × 1e-5.
_SCALE_TO_BN = M_PER_ROW * 1e-5  # 0.2122
geo["cs_actual_bn"] = geo["Population"] * geo["cs_actual_per_cap"] * _SCALE_TO_BN
geo["cs_no_sub_bn"] = geo["Population"] * geo["cs_no_sub_per_cap"] * _SCALE_TO_BN
geo["delta_cs_bn"] = geo["cs_no_sub_bn"] - geo["cs_actual_bn"]

total_cs_actual = geo["cs_actual_bn"].sum()
total_cs_no_sub = geo["cs_no_sub_bn"].sum()
delta_total = total_cs_no_sub - total_cs_actual
n_agents_total = (geo["Population"] * M_PER_ROW).sum()
per_cap_loss_yuan = -delta_total * 1e9 / n_agents_total
print(f"  National CS at actual:  {total_cs_actual:.1f} bn yuan/yr")
print(f"  National CS at no-sub:  {total_cs_no_sub:.1f} bn yuan/yr")
print(f"  Δ (loss from no-sub):   {delta_total:.1f} bn yuan/yr "
      f"({delta_total/total_cs_actual*100:+.1f}%)")
print(f"  Per-agent mean ΔCS:     {-delta_total*1e4/n_agents_total*1e4:.0f} yuan/yr loss "
      f"(negative ΔCS = subsidy raises welfare)")

# By tier
welf_tier = geo.groupby("city_tier").apply(lambda g: pd.Series({
    "n_cities": len(g),
    "pop_M": g["Population"].sum() / 100,  # 万人 → M
    "cs_actual_bn": g["cs_actual_bn"].sum(),
    "cs_no_sub_bn": g["cs_no_sub_bn"].sum(),
    "delta_bn": g["delta_cs_bn"].sum(),
})).reset_index()
welf_tier["per_cap_loss_yuan"] = -welf_tier["delta_bn"] * 1e9 / (welf_tier["pop_M"] * 1e6)
welf_tier["pct_loss"] = welf_tier["delta_bn"] / welf_tier["cs_actual_bn"] * 100
print("\nCS by city tier:")
print(welf_tier[["city_tier", "n_cities", "pop_M",
                  "cs_actual_bn", "cs_no_sub_bn", "delta_bn",
                  "per_cap_loss_yuan", "pct_loss"]].round(2).to_string(index=False))
welf_tier.to_csv(f"{OUT}/tab_consumer_welfare.csv", index=False)

# =============================================================================
# 4. Figure
# =============================================================================
fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))

ax = axes[0]
fs = firm_summary.head(8)
y = np.arange(len(fs))
ax.barh(y, fs["q_actual_M"], color="#1f77b4", label="Actual (with subsidy)")
ax.barh(y, fs["q_no_sub_M"], color="#d62728", label="No subsidy")
ax.set_yticks(y); ax.set_yticklabels(fs["firm_group"])
ax.set_xlabel("2024 EV quantity (M cars)")
ax.set_title("Firm survival under no-subsidy")
ax.legend(fontsize=8); ax.invert_yaxis()

ax = axes[1]
geo_plot = geo.sort_values("ev_q_actual_M", ascending=False).head(15)
y = np.arange(len(geo_plot))
ax.barh(y, geo_plot["ev_q_actual_M"], color="#1f77b4", label="Actual")
ax.barh(y, geo_plot["ev_q_no_sub_M"], color="#d62728", label="No subsidy")
ax.set_yticks(y); ax.set_yticklabels([m.replace("2024-", "") for m in geo_plot["market_ids"]])
ax.set_xlabel("2024 EV quantity (M cars)")
ax.set_title("Top 15 cities: EV adoption with vs. without subsidy")
ax.legend(fontsize=8); ax.invert_yaxis()

ax = axes[2]
ax.scatter(geo["log_inc_inv_mean"] if "log_inc_inv_mean" in geo.columns else np.arange(len(geo)),
            -geo["delta_cs_per_cap"], alpha=0.6,
            s=np.sqrt(geo["Population"]) * 0.5)
ax.set_xlabel("city income (BLP inc_inv normed, lower = richer)")
ax.set_ylabel("ΔCS per agent (10k yuan, positive = subsidy helps)")
ax.axhline(0, color="k", lw=0.5)
ax.set_title("Subsidy welfare impact by city income")

plt.tight_layout()
plt.savefig(f"{OUT}/fig_heterogeneity.png", dpi=150)
plt.close()
print(f"\nSaved → {OUT}/fig_heterogeneity.png")

print("\nDone.")
