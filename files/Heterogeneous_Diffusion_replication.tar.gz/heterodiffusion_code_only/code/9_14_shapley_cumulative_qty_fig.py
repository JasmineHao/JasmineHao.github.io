"""
9_14_shapley_cumulative_qty_fig.py
====================================
Stacked-area cumulative Shapley decomposition in EV QUANTITY (millions of
vehicles), 2015->2024.

For each year Y, the contribution of block B (in millions of EVs) is:
    phi_qty_B_Y = phi_share_B_Y * total_real_auto_sales_Y

where total_real_auto_sales_Y = sum(shares * Population) * M_PER_ROW (millions)
comes from df.parquet for year Y.

This gives "given the total auto market in year Y, how many EVs did each factor
produce?"

Reads:  output/decomp_s4_final_byyear_{YR}/shapley_decomposition.csv
        output/df.parquet
Writes: report/memos/fig_shapley_cumulative_qty_2026_06_15.png/.pdf
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = ["Arial Unicode MS", "DejaVu Sans"]
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT  = f"{ROOT}/report/memos"
os.makedirs(OUT, exist_ok=True)

YEARS  = list(range(2016, 2025))
BLOCKS = ["A_attrs", "Entry_qty", "Battery", "xi", "Subsidy", "Income"]
LABELS = {
    "A_attrs":   r"$A_\mathrm{attrs}$",
    "Entry_qty": r"Entry$_\mathrm{qty}$",
    "Battery":   "Battery (Wright)",
    "xi":        r"$\xi$ demand",
    "Subsidy":   "Subsidy",
    "Income":    "Income",
}
COLORS = {
    "A_attrs":   "#1f77b4",
    "Entry_qty": "#ff7f0e",
    "Battery":   "#2ca02c",
    "xi":        "#9467bd",
    "Subsidy":   "#d62728",
    "Income":    "#8c564b",
}

M_PER_ROW = 21220

# ── Total real auto sales per year (model units x M_PER_ROW = millions) ───────
df_raw = pd.read_parquet(f"{ROOT}/output/df.parquet")
df_raw["sales"] = df_raw["shares"] * df_raw["Population"]
total_sales_yr = (df_raw.groupby("Year")["sales"].sum() * M_PER_ROW / 1e6).to_dict()

# ── Read Shapley per year and convert to quantity ──────────────────────────────
rows = []
for yr in YEARS:
    csv = f"{ROOT}/output/decomp_s4_final_byyear_{yr}/shapley_decomposition.csv"
    if not os.path.exists(csv):
        print(f"missing: {csv}"); continue
    df_sh = pd.read_csv(csv)
    df_sh = df_sh[~df_sh["block"].isin(["BASELINE", "FINAL"])]
    M_yr = total_sales_yr.get(yr, total_sales_yr[2024])
    rec = {"year": yr, "M_yr": M_yr}
    for b in BLOCKS:
        v_share = df_sh[df_sh["block"] == b]["shapley_ev_share"]
        phi_share = float(v_share.values[0]) if len(v_share) else 0.0
        rec[b] = phi_share * M_yr   # millions of EVs
    rec["sum_signed"] = float(df_sh["shapley_ev_share"].sum()) * M_yr
    rows.append(rec)

df = pd.DataFrame(rows).set_index("year")
_zero = {b: 0.0 for b in BLOCKS}
_zero["sum_signed"] = 0.0
_zero["M_yr"] = total_sales_yr.get(2015, total_sales_yr[2015])
df = pd.concat([pd.DataFrame([_zero], index=[2015]), df]).sort_index()

# ── Observed EV quantity per year (millions) ───────────────────────────────────
df_raw["ev"] = df_raw["FuelType"].isin(["BEV", "PHEV", "REEV"]).astype(int)

def obs_ev_qty(yr):
    s = df_raw[df_raw["Year"] == yr]
    return float((s["ev"] * s["sales"]).sum()) * M_PER_ROW / 1e6

obs_ev_qty_2015 = obs_ev_qty(2015)
yrs_full  = [2015] + YEARS
obs_delta_qty = np.array([obs_ev_qty(y) - obs_ev_qty_2015 for y in yrs_full])

# ── Build stacked bands ────────────────────────────────────────────────────────
yrs   = np.array(yrs_full)
N     = len(yrs)
pos_top = np.zeros(N)
neg_bot = np.zeros(N)
pos_bands = []
neg_bands = []

for b in BLOCKS:
    v = df[b].values
    pos_v = np.where(v > 0, v, 0.0)
    neg_v = np.where(v < 0, v, 0.0)
    if pos_v.any():
        pos_bands.append((b, pos_top.copy(), pos_top + pos_v))
        pos_top = pos_top + pos_v
    if neg_v.any():
        neg_bands.append((b, neg_bot.copy(), neg_bot + neg_v))
        neg_bot = neg_bot + neg_v

# ── Draw ──────────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(12, 5.8))

for b, lo, hi in pos_bands:
    ax.fill_between(yrs, lo, hi, color=COLORS[b], alpha=0.82, linewidth=0,
                    label=LABELS[b])
for b, lo_base, hi_base in neg_bands:
    ax.fill_between(yrs, lo_base, hi_base, color=COLORS[b], alpha=0.82,
                    linewidth=0, hatch="///")

ax.plot(yrs, obs_delta_qty, color="black", lw=2.6, marker="o", ms=5.5,
        markerfacecolor="white", markeredgewidth=1.8, zorder=6,
        label="Observed $\\Delta$ EV quantity")
ax.plot(yrs, df["sum_signed"].values, color="gray", lw=1.3,
        linestyle="--", marker="d", ms=4.5, zorder=5,
        label="$\\Sigma_b\\,\\phi_b$ (model closure)")

ax.axhline(0, color="black", linewidth=0.6)
ax.set_xlim(2015, 2024)
ax.set_xticks(yrs_full)
ax.set_xticklabels([str(y) for y in yrs_full], fontsize=8.5, rotation=30, ha="right")
ax.set_ylabel("Cumulative contribution to $\\Delta$ EV quantity vs 2015 (millions)", fontsize=10)
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"{x:+.1f}M"))
ax.spines[["top", "right"]].set_visible(False)
ax.grid(axis="y", lw=0.5, alpha=0.3, color="gray")
ax.tick_params(labelsize=8.5)

handles = []
for b in BLOCKS:
    v_2024 = df.loc[2024, b]
    pat = mpatches.Patch(fc=COLORS[b], alpha=0.82,
                         hatch=("///" if v_2024 < 0 else ""),
                         label=LABELS[b])
    handles.append(pat)
handles.append(Line2D([0], [0], color="black", lw=2.2, marker="o", ms=5,
                       markerfacecolor="white", markeredgewidth=1.6,
                       label="Observed $\\Delta$ EV qty"))
handles.append(Line2D([0], [0], color="gray", lw=1.3, linestyle="--",
                       marker="d", ms=4, label="$\\Sigma_b\\,\\phi_b$"))
ax.legend(handles=handles, fontsize=8.5, frameon=True, loc="upper left",
          ncol=2, handlelength=1.5, labelspacing=0.4, borderpad=0.7)

plt.tight_layout()
out_png = f"{OUT}/fig_shapley_cumulative_qty_2026_06_15.png"
out_pdf = f"{OUT}/fig_shapley_cumulative_qty_2026_06_15.pdf"
fig.savefig(out_png, dpi=200, bbox_inches="tight")
fig.savefig(out_pdf, bbox_inches="tight")
print(f"Saved -> {out_png}")
print(f"Saved -> {out_pdf}")
