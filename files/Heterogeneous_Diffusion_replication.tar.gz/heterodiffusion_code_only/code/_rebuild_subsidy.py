"""
_rebuild_subsidy.py
===================

Audit fix per 2026-06-10: the prior `total_subsidy_wan` in df.parquet
was a regression-fit approximation (subsidy ≈ a(t) + b(t) × price) that
materially overstated 2024 EV policy support — including non-zero values
for 2023-2024 even though the national NEV cash subsidy program ended
Dec 31, 2022.

This script rebuilds `total_subsidy_wan` per-product using:
  (1) the real official NATIONAL NEV cash subsidy schedule (MOF/MIIT
      publications 2015-2022) with range-tier discrimination per year,
  (2) purchase tax exemption (10% of sticker, 2014-2025),
  (3) local match factor (declining 1.0 → 0 over 2015-2019, then 0).

Per-product subsidy is determined by:
  - Year
  - FuelType (BEV / PHEV / REEV / HEV / ICEV)
  - Range tier (from log_ev_range)
  - Sticker price (for purchase tax component)

A backup of the existing df.parquet is saved to df_old_subsidy_approx.parquet.
"""
import os
import numpy as np
import pandas as pd

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DF_PATH = f"{ROOT}/output/df.parquet"
BACKUP_PATH = f"{ROOT}/output/df_old_subsidy_approx.parquet"

# =============================================================================
# 1. OFFICIAL NATIONAL NEV CASH SUBSIDY SCHEDULE
# =============================================================================
# Source: MOF + MIIT joint notices, annual NEV subsidy adjustments.
# Format: (year, fuel_type, range_low_km, range_high_km) → subsidy 万元/car.
# Range tiers reflect actual policy tier breakpoints in each year.

NAT_SCHEDULE = {
    # 2015: MOF/MIIT 2015-2020 NEV plan
    (2015, "BEV", 0, 150):   0.00,
    (2015, "BEV", 150, 250): 4.50,
    (2015, "BEV", 250, 9999): 5.40,
    (2015, "PHEV", 0, 9999):  3.15,
    (2015, "REEV", 0, 9999):  3.15,
    (2015, "HEV", 0, 9999):   0.00,

    # 2016: -10% adjustment
    (2016, "BEV", 0, 100):    0.00,
    (2016, "BEV", 100, 150):  2.50,
    (2016, "BEV", 150, 250):  4.50,
    (2016, "BEV", 250, 9999): 5.50,
    (2016, "PHEV", 0, 9999):  3.00,
    (2016, "REEV", 0, 9999):  3.00,
    (2016, "HEV", 0, 9999):   0.00,

    # 2017: -20% adjustment
    (2017, "BEV", 0, 100):    0.00,
    (2017, "BEV", 100, 150):  2.00,
    (2017, "BEV", 150, 250):  3.60,
    (2017, "BEV", 250, 9999): 4.40,
    (2017, "PHEV", 0, 9999):  2.40,
    (2017, "REEV", 0, 9999):  2.40,
    (2017, "HEV", 0, 9999):   0.00,

    # 2018: New tier system with battery density adjustment (we ignore density)
    (2018, "BEV", 0, 150):    0.00,
    (2018, "BEV", 150, 200):  1.50,
    (2018, "BEV", 200, 250):  2.40,
    (2018, "BEV", 250, 300):  3.40,
    (2018, "BEV", 300, 400):  4.50,
    (2018, "BEV", 400, 9999): 5.00,
    (2018, "PHEV", 0, 9999):  2.20,
    (2018, "REEV", 0, 9999):  2.20,
    (2018, "HEV", 0, 9999):   0.00,

    # 2019: significant cut (only ≥250km supported)
    (2019, "BEV", 0, 250):    0.00,
    (2019, "BEV", 250, 400):  1.80,
    (2019, "BEV", 400, 9999): 2.50,
    (2019, "PHEV", 0, 9999):  1.00,
    (2019, "REEV", 0, 9999):  1.00,
    (2019, "HEV", 0, 9999):   0.00,

    # 2020: -10% from 2019
    (2020, "BEV", 0, 300):    0.00,
    (2020, "BEV", 300, 400):  1.62,
    (2020, "BEV", 400, 9999): 2.25,
    (2020, "PHEV", 0, 9999):  0.85,
    (2020, "REEV", 0, 9999):  0.85,
    (2020, "HEV", 0, 9999):   0.00,

    # 2021: -20% from 2020
    (2021, "BEV", 0, 300):    0.00,
    (2021, "BEV", 300, 400):  1.30,
    (2021, "BEV", 400, 9999): 1.80,
    (2021, "PHEV", 0, 9999):  0.68,
    (2021, "REEV", 0, 9999):  0.68,
    (2021, "HEV", 0, 9999):   0.00,

    # 2022: -30% from 2021
    (2022, "BEV", 0, 300):    0.00,
    (2022, "BEV", 300, 400):  0.91,
    (2022, "BEV", 400, 9999): 1.26,
    (2022, "PHEV", 0, 9999):  0.48,
    (2022, "REEV", 0, 9999):  0.48,
    (2022, "HEV", 0, 9999):   0.00,

    # 2023, 2024: National cash subsidy ended Dec 31, 2022.
    # (Some local cash + 以旧换新 still apply but are city/program-specific.
    # Modeled as 0 cash here; tax exemption is added separately below.)
    (2023, "BEV", 0, 9999):   0.00,
    (2023, "PHEV", 0, 9999):  0.00,
    (2023, "REEV", 0, 9999):  0.00,
    (2023, "HEV", 0, 9999):   0.00,

    (2024, "BEV", 0, 9999):   0.00,
    (2024, "PHEV", 0, 9999):  0.00,
    (2024, "REEV", 0, 9999):  0.00,
    (2024, "HEV", 0, 9999):   0.00,
}


def lookup_national_subsidy(year, fuel_type, range_km):
    """Return national cash subsidy in 万元 for (year, fuel_type, range_km)."""
    if fuel_type == "ICEV":
        return 0.0
    for (yr, ft, r_lo, r_hi), sub in NAT_SCHEDULE.items():
        if yr == year and ft == fuel_type and r_lo <= range_km < r_hi:
            return sub
    return 0.0


# =============================================================================
# 2. LOCAL MATCH FACTOR
# =============================================================================
# Source: PKULaw policy archive. Declining over 2015-2019, zero thereafter.
# Applied uniformly across cities (cities with no match are absorbed into a
# weighted average).

LOCAL_MATCH = {
    2015: 1.00, 2016: 1.00, 2017: 0.50, 2018: 0.50,
    2019: 0.00, 2020: 0.00, 2021: 0.00, 2022: 0.00,
    2023: 0.00, 2024: 0.00,
}

# =============================================================================
# 3. PURCHASE TAX EXEMPTION
# =============================================================================
# All NEVs exempt from 10% purchase tax (2014-2025 program). For each EV row:
#   tax_exemption_wan = 0.10 × sticker_price_wan
# Stated 10% rate is exact; in practice tax base differs slightly from sticker
# but for our policy-incidence purposes the 10% × sticker is the right approx.

PURCHASE_TAX_RATE = 0.10
TAX_EXEMPT_YEARS = set(range(2014, 2026))


def compute_subsidy(row):
    """Return total subsidy in 10k yuan for this (product × market × year) row."""
    year = int(row["Year"])
    ft = row["FuelType"]
    if ft == "ICEV":
        return 0.0
    # National cash subsidy by range tier
    log_r = float(row["log_ev_range"])
    range_km = float(np.exp(log_r)) if log_r > 0 else 0.0
    nat_sub = lookup_national_subsidy(year, ft, range_km)
    # Local match
    local_match = LOCAL_MATCH.get(year, 0.0)
    cash_total = nat_sub * (1.0 + local_match)
    # Purchase tax exemption (only for NEVs in covered years)
    if year in TAX_EXEMPT_YEARS:
        # Sticker = observed net price + cash subsidy
        sticker = float(row["price"]) + cash_total
        tax_exempt = PURCHASE_TAX_RATE * sticker
    else:
        tax_exempt = 0.0
    return cash_total + tax_exempt


# =============================================================================
# 4. APPLY TO df.parquet
# =============================================================================
print("=" * 70)
print("Rebuilding total_subsidy_wan from official policy schedule")
print("=" * 70)

df = pd.read_parquet(DF_PATH)
print(f"Loaded df.parquet: {len(df):,} rows")

print(f"\nBacking up old df.parquet → {os.path.basename(BACKUP_PATH)}")
df.to_parquet(BACKUP_PATH, index=False)

# Save old values for comparison
old_sub = df["total_subsidy_wan"].copy()

# Vectorized computation using numpy arrays for speed
print("Computing new subsidy per row...")
years = df["Year"].values.astype(int)
fuels = df["FuelType"].values
log_ranges = df["log_ev_range"].values
prices = df["price"].values

# Cache schedule lookups
nat_sub_arr = np.zeros(len(df))
for i in range(len(df)):
    if fuels[i] == "ICEV":
        continue
    range_km = float(np.exp(log_ranges[i])) if log_ranges[i] > 0 else 0.0
    nat_sub_arr[i] = lookup_national_subsidy(years[i], fuels[i], range_km)

local_match_arr = np.array([LOCAL_MATCH.get(y, 0.0) for y in years])
cash_total = nat_sub_arr * (1.0 + local_match_arr)

# Sticker = price (net) + cash subsidy
stickers = prices + cash_total
tax_exempt_arr = np.where(
    np.isin(years, list(TAX_EXEMPT_YEARS)) & (fuels != "ICEV"),
    PURCHASE_TAX_RATE * stickers,
    0.0
)
new_sub = cash_total + tax_exempt_arr
df["total_subsidy_wan"] = new_sub
df["nat_subsidy_wan"] = nat_sub_arr  # Update this too for consistency

# Sanity report by year × fuel
print("\nNew per-(Year, FuelType) median subsidy (10k yuan):")
print(df.groupby(["Year", "FuelType"])["total_subsidy_wan"]
        .median().unstack().round(2).to_string())

print("\nNew cumulative subsidy (cash + tax exemption) by year:")
M_PER_ROW = 21220.0
df["_Q"] = df["shares"] * df["Population"] * M_PER_ROW
df["_subsidy_paid"] = df["total_subsidy_wan"] * df["_Q"]
ann = df.groupby("Year").agg(
    cash_yi=("total_subsidy_wan", lambda x: ((x - df.loc[x.index, "_Q"] * 0) * 0).sum()),  # placeholder
).reset_index()
# Simpler: just sum subsidy × Q
for yr in sorted(df["Year"].unique()):
    sub = df[df["Year"] == yr]
    ev_mask = sub["FuelType"].isin(["BEV", "PHEV", "REEV"])
    total_yi = sub.loc[ev_mask, "_subsidy_paid"].sum() / 10000
    ev_q_M = sub.loc[ev_mask, "_Q"].sum() / 1e6
    med_per_car = sub.loc[ev_mask, "total_subsidy_wan"].median()
    print(f"  {int(yr)}: EV q = {ev_q_M:.2f} M  median sub = {med_per_car:.2f} 10k yuan  total = {total_yi:.0f} bn yuan")

total_cum = df["_subsidy_paid"].sum() / 10000
print(f"\n  CUMULATIVE 2015-2024: {total_cum:,.0f} bn yuan ({total_cum/10000:.2f} trillion)")

# Reality check
print("\n=== Validation vs official totals ===")
print("  Official cash NEV subsidy 2015-2022: ~1500-2000 bn yuan (MOF)")
print("  Official tax exemption 2014-2024:    ~7000-10000 bn yuan (CAAM)")
print(f"  Combined target range:               ~9000-12000 bn yuan")
print(f"  Our rebuilt total:                   {total_cum:,.0f} bn yuan")
in_range = 9000 <= total_cum <= 12000
print(f"  Status: {'IN RANGE ✓' if in_range else 'OUT OF RANGE'}")

# Drop helper cols and save
df = df.drop(columns=["_Q", "_subsidy_paid"])
df.to_parquet(DF_PATH, index=False)
print(f"\nSaved → {DF_PATH}  ({len(df):,} rows)")

# Diff report
print("\n=== Before vs After: per-car BEV subsidy by year ===")
new_med_by_yr_bev = (df[df["FuelType"] == "BEV"]
                     .groupby("Year")["total_subsidy_wan"].median())
print(f"  {'Year':>5} {'OLD (approx)':>12} {'NEW (schedule)':>14} {'Δ':>7}")
for yr in sorted(new_med_by_yr_bev.index):
    old_med = old_sub[(df["Year"] == yr) & (df["FuelType"] == "BEV")].median()
    new_med = new_med_by_yr_bev[yr]
    print(f"  {int(yr):>5} {old_med:>12.2f} {new_med:>14.2f} {new_med - old_med:>+7.2f}")
