"""
9_4_ev_progress_fig.py
======================
Panel A: EV attribute index 2015→2024 — Range, Battery, Power, Vehicle Size
Panel B: GV attribute index 2015→2024 — Engine Power, Vehicle Size, Fuel Consumption
Panel C: EV unobserved demand ξ by year (within-year-demeaned BLP delta)
         Scatter colored + shaped by firm group; best-selling product per year labeled
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = ["Arial Unicode MS", "DejaVu Sans"]
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from matplotlib.lines import Line2D

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT  = f"{ROOT}/report/memos"
os.makedirs(OUT, exist_ok=True)

YEARS = list(range(2015, 2025))
XLIM  = (2015 - 0.45, 2024 + 0.45)

# ── Load data ─────────────────────────────────────────────────────────────────
df_raw  = pd.read_parquet(f"{ROOT}/output/df.parquet")
brand_fg = (pd.read_csv(f"{ROOT}/output/diy_mc_v12.csv")[["Brand", "firm_group"]]
            .drop_duplicates("Brand").set_index("Brand")["firm_group"])

# ── Singleton filter (must match 1_blp.py to align rows with saved delta) ────
def singleton_filter(d):
    out = d.copy()
    vars_ = [v for v in ["log_size", "Displacement", "electric_efficiency",
                          "FuelEfficiency", "log_ev_range"] if v in out.columns]
    grp = out.groupby("market_segement", sort=False)
    n = grp[vars_[0]].transform("size")
    for v in vars_:
        s = grp[v].transform("sum")
        out[f"{v}_iv_diff"] = np.abs(
            out[v] - np.where(n > 1, (s - out[v]) / (n - 1), np.nan))
    return out.dropna(subset=[f"{v}_iv_diff" for v in vars_]).reset_index(drop=True)

df_full = singleton_filter(df_raw)

# ── Attach BLP delta; compute within-year-demeaned ξ ─────────────────────────
ess = np.load(f"{ROOT}/output/blp_essentials_v12/blp_essentials.npz",
              allow_pickle=True)
assert len(ess["delta"]) == len(df_full)
df_full["delta"]      = ess["delta"]
df_full["firm_group"] = df_full["Brand"].map(brand_fg).fillna("Other")

df_ev = df_full[df_full["ev_dummy"] == 1].copy()
yr_mean = df_ev.groupby("Year")["delta"].transform("mean")
df_ev["xi"] = df_ev["delta"] - yr_mean

# National product-level average (share-weighted across cities)
xi_nat = (
    df_ev.groupby(["Brand", "Model", "firm_group", "FuelType", "Year"])
    .apply(lambda g: pd.Series({
        "xi":          np.average(g["xi"],    weights=g["shares"].clip(lower=1e-10)),
        "price":       np.average(g["price"], weights=g["shares"].clip(lower=1e-10)),
        "sales_proxy": (g["shares"] * g["Population"]).sum(),
    }), include_groups=False)
    .reset_index()
)
xi_nat  = xi_nat[xi_nat["Year"].isin(YEARS)].copy()
xi_med  = xi_nat.groupby("Year")["xi"].median()

# ── Attribute index computation ───────────────────────────────────────────────
def exp_median(s):
    v = np.exp(s.replace(0, np.nan).dropna())
    return v.median() if len(v) else np.nan

def raw_median(s):
    v = s.replace(0, np.nan).dropna()
    return v.median() if len(v) else np.nan

def inv_median(s):
    v = s.replace(0, np.nan).dropna()
    return (1.0 / v).median() if len(v) else np.nan

def attr_index(prod_df, col, transform="exp"):
    fn = {"exp": exp_median, "raw": raw_median, "inv": inv_median}[transform]
    rows = [{"Year": yr, "med": fn(prod_df.loc[prod_df["Year"] == yr, col])}
            for yr in YEARS]
    s = pd.DataFrame(rows).set_index("Year")
    return s / s.loc[2015, "med"]          # normalize 2015 = 1

prod_ev = (df_raw[df_raw["ev_dummy"] == 1]
           .drop_duplicates(["Model", "FuelType", "Year"])
           .loc[lambda x: x["Year"].isin(YEARS)])
prod_gv = (df_raw[df_raw["ev_dummy"] == 0]
           .drop_duplicates(["Model", "FuelType", "Year"])
           .loc[lambda x: x["Year"].isin(YEARS)])

EV_ATTRS = {                           # col → (label, color, marker, transform)
    "log_ev_range":         ("Electric Range",   "#2166ac", "o", "exp"),
    "log_battery_capacity": ("Battery Capacity", "#4dac26", "s", "exp"),
    "log_ev_power":         ("Max Power",        "#d6604d", "^", "exp"),
    "log_size":             ("Vehicle Size",     "#7b6cb0", "D", "exp"),
}
GV_ATTRS = {
    # Colors/markers match EV_ATTRS for analogous attributes (power, size)
    "log_power":      ("Engine Power",      "#d6604d", "^", "exp"),   # matches EV Max Power
    "log_size":       ("Vehicle Size",      "#7b6cb0", "D", "exp"),   # matches EV Vehicle Size
    "Displacement":   ("Displacement (L)",  "#f4a261", "s", "raw"),
    "FuelEfficiency": ("Fuel Efficiency (↑ = better)", "#888888", "v", "inv"),
}

ev_idx = {col: attr_index(prod_ev, col, tr) for col, (_, _, _, tr) in EV_ATTRS.items()}
gv_idx = {col: attr_index(prod_gv, col, tr) for col, (_, _, _, tr) in GV_ATTRS.items()}

# ── Style ─────────────────────────────────────────────────────────────────────
FIRM_COLORS = {
    "Tesla":            "#e63946",
    "New Forces":       "#457b9d",
    "Foreign/JV":       "#6a994e",
    "Trad. OEM":        "#f4a261",
    "Private National": "#9b72cf",
    "BYD":              "#1d3557",
    "Other":            "#aaaaaa",
}
FIRM_MARKERS = {
    "Tesla":            "D",
    "New Forces":       "^",
    "Foreign/JV":       "s",
    "Trad. OEM":        "o",
    "Private National": "v",
    "BYD":              "P",
    "Other":            "x",
}
BRAND_ENG = {
    "特斯拉": "Tesla",   "比亚迪": "BYD",     "腾势":  "Denza",
    "仰望":  "Yangwang", "方程豹": "FCB",      "蔚来":  "NIO",
    "小鹏":  "Xpeng",    "理想":  "Li Auto",  "零跑":  "Leapmotor",
    "哪吒":  "Neta",     "路特斯": "Lotus",   "极氪":  "Zeekr",
    "智己":  "IM",       "岚图":  "Voyah",    "阿维塔": "Avatr",
    "埃安":  "Aion",     "极星":  "Polestar", "红旗":  "Hongqi",
    "高合":  "HiPhi",    "鸿蒙智行": "Aito",  "赛力斯": "Seres",
    "小米":  "Xiaomi",   "SMART": "Smart",    "MG":   "MG",
    "ARCFOX": "Arcfox",  "极越":  "Jiyue",
    "知豆":  "Zhidou",   "野马":  "Yeema",
    "日产":  "Nissan",   "坦克":  "Tank",
    "北京":  "BAIC",     "五菱":  "Wuling",
}
MODEL_ENG = {
    "知豆D1": "D1",       "E6": "E6",           "野马T70": "T70",
    "轩逸":   "Sylphy",   "MODEL3": "Model 3",  "MODELY": "Model Y",
    "QM5":    "QM5",      "坦克500": "Tank 500",
    "秦":     "Qin",      "唐": "Tang",          "宋": "Song",
    "北汽EC3": "EC3",     "北京U5": "U5",        "宏光MINI": "Hongguang Mini",
}

# ── Draw ──────────────────────────────────────────────────────────────────────
fig, (ax_ev, ax_gv) = plt.subplots(1, 2, figsize=(12, 4.0),
                                    sharey=True,
                                    gridspec_kw={"wspace": 0.06})

def draw_attr(ax, idx_dict, attrs_meta, legend_loc="upper left"):
    for col, (label, color, mk, _) in attrs_meta.items():
        s = idx_dict[col]
        ax.plot(s.index.tolist(), s["med"],
                color=color, lw=2.0, marker=mk, ms=5, label=label, zorder=4)
        val = s.loc[2024, "med"]
        ax.annotate(f"×{val:.2f}", xy=(2024, val),
                    xytext=(4, 0), textcoords="offset points",
                    fontsize=7, color=color, va="center")
    ax.axhline(1.0, color="gray", lw=0.8, ls="--", alpha=0.5)
    ax.set_xlim(*XLIM)
    ax.set_xticks(YEARS)
    ax.set_xticklabels([str(y) for y in YEARS], fontsize=8, rotation=30, ha="right")
    ax.legend(fontsize=8.5, frameon=True, loc=legend_loc,
              handlelength=1.5, labelspacing=0.4, borderpad=0.7)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", lw=0.5, alpha=0.3, color="gray")
    ax.tick_params(labelsize=8)

draw_attr(ax_ev, ev_idx, EV_ATTRS, legend_loc="upper left")
draw_attr(ax_gv, gv_idx, GV_ATTRS, legend_loc="upper right")

ax_ev.set_ylabel("Index (2015 = 1)", fontsize=9.5)
ax_gv.set_ylabel("")

out_png = f"{OUT}/fig_ev_progress.png"
out_pdf = f"{OUT}/fig_ev_progress.pdf"
fig.savefig(out_png, bbox_inches="tight", dpi=200)
fig.savefig(out_pdf, bbox_inches="tight")
print(f"Saved → {out_png}")
print(f"Saved → {out_pdf}")

# ── Save individual panels ─────────────────────────────────────────────────────
for tag, idx_dict, attrs_meta in [("ev", ev_idx, EV_ATTRS), ("gv", gv_idx, GV_ATTRS)]:
    fig_p, ax_p = plt.subplots(1, 1, figsize=(6.5, 4.0))
    draw_attr(ax_p, idx_dict, attrs_meta, legend_loc="upper left")
    ax_p.set_ylabel("Index (2015 = 1)", fontsize=9.5)
    fig_p.tight_layout(pad=0.6)
    for ext in ("png", "pdf"):
        fp = f"{OUT}/fig_ev_progress_{tag}.{ext}"
        fig_p.savefig(fp, dpi=200 if ext=="png" else 72, bbox_inches="tight")
        print(f"Saved → {fp}")
    plt.close(fig_p)
