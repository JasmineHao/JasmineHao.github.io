#!/bin/bash
# Year-by-year Shapley decomposition (2016..2024 vs 2015 baseline) under the
# 2026-06-12 finalized S4 spec (log_size dropped, 5-col battery IVs, SS_FE,
# log_price-consistent δ_net). 9 years × 64 coalitions ≈ 80 min total.
set -e
cd "$(dirname "$0")/.."

for YR in 2016 2017 2018 2019 2020 2021 2022 2023 2024; do
    OUTDIR="output/decomp_s4_final_byyear_${YR}"
    if [ -f "$OUTDIR/shapley_decomposition.csv" ]; then
        echo "[SKIP] ${YR} already done"
        continue
    fi
    echo "=== Year ${YR} ==="
    DECOMP_BLOCKS_SPEC=6_cross DECOMP_PRICE_FORM=log DECOMP_MODE=shapley \
        DECOMP_YEAR_END=${YR} \
        BLP_INPUT_DIR=output/blp_essentials_v12 \
        DECOMP_OUTPUT_DIR=${OUTDIR} \
        PYTHONUNBUFFERED=1 python3 -u code/2_decomposition.py \
        > /tmp/decomp_s4_final_${YR}.txt 2>&1
    echo "  done: $(tail -1 /tmp/decomp_s4_final_${YR}.txt | head -c 100)"
done
echo "ALL YEARS DONE"
