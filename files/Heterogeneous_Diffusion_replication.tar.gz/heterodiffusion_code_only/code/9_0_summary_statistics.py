"""
9_summary_statistics.py
========================

Generate Panels A/B/C summary statistics in LaTeX (booktabs) format,
matching the attributes ACTUALLY used in our demand BLP, supply MC OLS,
and city-level macro covariates.

Panel A: product × year × city observations (used in demand BLP).
Panel B: model × year observations (used in supply-side MC OLS).
Panel C: year × city city-level covariates + market-structure counts.

Variables included (one row each):

  Product attributes (Panels A/B):
    - Sales (cars)                        from shares × M
    - MSRP (10k RMB)                      sticker = price + total_subsidy
    - Net price (10k RMB)                 consumer-paid = `price` column
    - Vehicle size (L×W×H, m³)            exp(log_size) / 1e9
    - Horsepower                          exp(log_power_gv)
    - L/100km                             GV-only, from FuelEfficiency
    - kWh/100km                           EV-only, from electric_efficiency
    - Driving range (km)                  EV-only, exp(log_ev_range)
    - Battery capacity (kWh)              EV-only, exp(log_battery_capacity)
    - National cash subsidy (10k RMB)     EV-only, nat_subsidy_wan
    - Local cash subsidy (10k RMB)        EV-only, local_subsidy_wan
    - Purchase-tax exemption (10k RMB)    EV-only, purchase_tax_exemption_wan

  City-level macro (Panel C, year × city):
    - Income per capita (10k RMB)         Income_city / 10000
    - GDP per capita (10k RMB)            GDP_per_capita (already 10k RMB)
    - Population density                  pop_density (10k pers / km²)
    - Urbanization rate                   urb_rate
    - # gas stations                      gs_count
    - # charging stations                 cs_count
    - # firms                             unique Manufacturer
    - # GV models                         ICEV + HEV
    - # BEV models
    - # PHEV models
    - # REEV models

Output:
  - report/memos/tab_summary_statistics.tex  (3 stacked tables)
  - Console: same numbers for sanity check.
"""
import os
import numpy as np
import pandas as pd

# =============================================================================
# Paths
# =============================================================================
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DF_PATH = f"{ROOT}/output/df.parquet"
OUT_TEX = f"{ROOT}/report/memos/tab_summary_statistics.tex"

# =============================================================================
# Load and classify
# =============================================================================
print("=" * 70)
print("Summary statistics — Panels A / B / C")
print("=" * 70)

df = pd.read_parquet(DF_PATH)
df = df.copy()
print(f"Loaded df.parquet: {len(df):,} rows, "
      f"years {df.Year.min()}-{df.Year.max()}, "
      f"{df.Geo_Market.nunique()} cities")

EV_FUELS = ["BEV", "PHEV", "REEV"]
GV_FUELS = ["ICEV", "HEV"]
df["is_ev"] = df["FuelType"].isin(EV_FUELS)
df["is_gv"] = df["FuelType"].isin(GV_FUELS)

# Derived attributes (level form for the table)
df["M"] = df["Population"].astype(float) * 10000.0 / 2.62 / 5.0
df["sales"]            = df["shares"].astype(float) * df["M"]
df["msrp_wan"]         = df["price"].astype(float) + df["total_subsidy_wan"].fillna(0)
df["net_price_wan"]    = df["price"].astype(float)
df["horsepower"]       = np.where(df["log_power"] > 0, np.exp(df["log_power"]), np.nan)
df["size_m3"]          = np.where(df["log_size"] > 0,
                                   np.exp(df["log_size"]) / 1e9, np.nan)
df["range_km"]         = np.where(df["log_ev_range"] > 0,
                                   np.exp(df["log_ev_range"]), np.nan)
df["battery_cap_kwh"]  = np.where(df["log_battery_capacity"] > 0,
                                   np.exp(df["log_battery_capacity"]), np.nan)

# Fuel-type specific consumption: keep two separate columns so they show on
# distinct rows in the table (different units, not comparable).
df["L_per_100km"]   = np.where(df["is_gv"], df["FuelEfficiency"], np.nan)
df["kWh_per_100km"] = np.where(df["is_ev"], df["electric_efficiency"], np.nan)

# EV-only attributes: mask GVs to NaN so panel A doesn't report misleading
# 0 values (which would inflate the GV mean toward 0 for EV-specific vars).
df.loc[~df["is_ev"], ["range_km", "battery_cap_kwh",
                       "nat_subsidy_wan", "local_subsidy_wan",
                       "purchase_tax_exemption_wan"]] = np.nan


# =============================================================================
# Helpers
# =============================================================================
def stat_block(subset, varlist):
    """Return list of (label, N, mean, std) for each variable in varlist on subset."""
    rows = []
    for label, col in varlist:
        if col is None:
            rows.append((label, None, None, None))
            continue
        s = subset[col].dropna()
        if len(s) == 0:
            rows.append((label, 0, None, None))
        else:
            rows.append((label, len(s), float(s.mean()), float(s.std())))
    return rows


def fmt(v, fmt_str):
    if v is None:
        return "---"
    return f"{v:{fmt_str}}"


def fmt_num(N):
    if N is None:
        return "---"
    return f"{N:,}"


def latex_row_panAB(g, e, fmt_mean="{:,.2f}", fmt_n="{:,}"):
    label = g[0]
    cells_g = ["---"] * 3
    cells_e = ["---"] * 3
    if g[1] is not None and g[2] is not None and g[1] > 0:
        cells_g[0] = fmt_n.format(int(g[1]))
        cells_g[1] = fmt_mean.format(g[2])
        cells_g[2] = fmt_mean.format(g[3])
    if e[1] is not None and e[2] is not None and e[1] > 0:
        cells_e[0] = fmt_n.format(int(e[1]))
        cells_e[1] = fmt_mean.format(e[2])
        cells_e[2] = fmt_mean.format(e[3])
    return f"{label} & " + " & ".join(cells_g + cells_e) + " \\\\"


def latex_row_panC(label, N, mean, sd, mn, mx):
    return (f"{label} & {N:,} & {mean:,.2f} & {sd:,.2f} & "
            f"{mn:,.2f} & {mx:,.2f} \\\\")


# =============================================================================
# Panel A — product × year × city  (used in demand BLP)
# =============================================================================
print("\n" + "=" * 70)
print("Panel A — product × year × city (demand BLP)")
print("=" * 70)

gv_panA = df[df["is_gv"]]
ev_panA = df[df["is_ev"]]
print(f"GV obs: {len(gv_panA):,} | EV obs: {len(ev_panA):,}")

varlist_panA = [
    ("Sales (cars)",                       "sales"),
    ("MSRP (10k RMB)",                     "msrp_wan"),
    ("Net price (10k RMB)",                "net_price_wan"),
    ("Vehicle size ($\\mathrm{m}^3$)",     "size_m3"),
    ("Horsepower",                         "horsepower"),
    ("L/100km",                            "L_per_100km"),
    ("kWh/100km",                          "kWh_per_100km"),
    ("Driving range (km)",                 "range_km"),
    ("Battery capacity (kWh)",             "battery_cap_kwh"),
    ("National cash subsidy (10k RMB)",    "nat_subsidy_wan"),
    ("Local cash subsidy (10k RMB)",       "local_subsidy_wan"),
    ("Purchase-tax exemption (10k RMB)",   "purchase_tax_exemption_wan"),
]

gv_rows = stat_block(gv_panA, varlist_panA)
ev_rows = stat_block(ev_panA, varlist_panA)


# =============================================================================
# Panel B — model × year (supply-side MC OLS)
# =============================================================================
print("\n" + "=" * 70)
print("Panel B — model × year (supply MC OLS)")
print("=" * 70)

agg_dict = {
    "sales":             ("sales", "sum"),
    "msrp_wan":          ("msrp_wan", "mean"),
    "net_price_wan":     ("net_price_wan", "mean"),
    "size_m3":           ("size_m3", "mean"),
    "horsepower":        ("horsepower", "mean"),
    "L_per_100km":       ("L_per_100km", "mean"),
    "kWh_per_100km":     ("kWh_per_100km", "mean"),
    "range_km":          ("range_km", "mean"),
    "battery_cap_kwh":   ("battery_cap_kwh", "mean"),
    "is_ev":             ("is_ev", "first"),
    "is_gv":             ("is_gv", "first"),
}
panB = (df.groupby(["Model", "FuelType", "Year"], as_index=False)
          .agg(**agg_dict))

gv_panB = panB[panB["is_gv"]]
ev_panB = panB[panB["is_ev"]]
print(f"GV obs: {len(gv_panB):,} model-years | EV obs: {len(ev_panB):,} model-years")

varlist_panB = [
    ("Sales (cars, national)",          "sales"),
    ("MSRP (10k RMB)",                  "msrp_wan"),
    ("Net price (10k RMB)",             "net_price_wan"),
    ("Vehicle size ($\\mathrm{m}^3$)",  "size_m3"),
    ("Horsepower",                      "horsepower"),
    ("L/100km",                         "L_per_100km"),
    ("kWh/100km",                       "kWh_per_100km"),
    ("Driving range (km)",              "range_km"),
    ("Battery capacity (kWh)",          "battery_cap_kwh"),
]
gv_rowsB = stat_block(gv_panB, varlist_panB)
ev_rowsB = stat_block(ev_panB, varlist_panB)


# =============================================================================
# Panel C — year × city: macro covariates + market structure
# =============================================================================
print("\n" + "=" * 70)
print("Panel C — year × city (city-level macro + counts)")
print("=" * 70)

city_year = df.drop_duplicates(["Geo_Market", "Year"]).copy()
city_year["income_pc_wan"] = city_year["Income_city"] / 10000.0  # to 10k RMB

# Merge policy panel for ev_license / is_pilot / ev_policy_primary / oil_price.
# These enter BLP X1 via ev_x_license, ev_x_pilot, ev_x_policy_str, oil_price
# but are stored in policy_panel_merged.csv, not df.parquet.
_POLICY_PATH = f"{ROOT}/output/policy_panel_merged.csv"
if os.path.exists(_POLICY_PATH):
    pp = pd.read_csv(_POLICY_PATH)
    _pp_keep = [c for c in ["Geo_Market", "Year", "ev_license", "is_pilot",
                            "ev_policy_primary", "oil_price"] if c in pp.columns]
    city_year = city_year.merge(pp[_pp_keep], on=["Geo_Market", "Year"], how="left")
    for c in ["ev_license", "is_pilot", "ev_policy_primary"]:
        if c in city_year.columns:
            city_year[c] = city_year[c].fillna(0)
    if "oil_price" in city_year.columns:
        city_year["oil_price"] = city_year["oil_price"].fillna(city_year["oil_price"].mean())
    print(f"  Merged policy panel: {_pp_keep[2:]}")
else:
    print(f"  ⚠ policy_panel_merged.csv not found — policy vars skipped from Panel C")

# Per (Year, Geo_Market) counts derived from full df
def count_by(panel, mask, col="Model"):
    return panel[mask].groupby(["Year", "Geo_Market"])[col].nunique()

cm = (df.groupby(["Year", "Geo_Market"])
        .agg(n_firms=("Manufacturer", "nunique")).reset_index())
for label, mask in [("n_gv",   df["is_gv"]),
                    ("n_bev",  df["FuelType"] == "BEV"),
                    ("n_phev", df["FuelType"] == "PHEV"),
                    ("n_reev", df["FuelType"] == "REEV")]:
    cm = cm.merge(count_by(df, mask).rename(label).reset_index(),
                  on=["Year", "Geo_Market"], how="left")
cm = cm.fillna(0)

# Merge in city macro
city_year_full = city_year.merge(cm, on=["Year", "Geo_Market"], how="left")

panC_vars = [
    ("Income per capita (10k RMB)",        "income_pc_wan"),
    ("GDP per capita (10k RMB)",           "GDP_per_capita"),
    ("Population density (10k/km$^2$)",    "pop_density"),
    ("Urbanization rate",                  "urb_rate"),
    ("EV license priority (dummy)",        "ev_license"),
    ("Pilot city (dummy)",                 "is_pilot"),
    ("EV policy strength",                 "ev_policy_primary"),
    ("Oil price (year-level)",             "oil_price"),
    ("\\# of firms",                       "n_firms"),
    ("\\# of GV models",                   "n_gv"),
    ("\\# of BEV models",                  "n_bev"),
    ("\\# of PHEV models",                 "n_phev"),
    ("\\# of REEV models",                 "n_reev"),
]

panC_rows = []
for label, col in panC_vars:
    s = city_year_full[col].dropna()
    if len(s) > 0:
        panC_rows.append((label, len(s), float(s.mean()), float(s.std()),
                          float(s.min()), float(s.max())))
    else:
        panC_rows.append((label, 0, None, None, None, None))


# =============================================================================
# Console summary
# =============================================================================
print("\n──────────────────────  Panel A  ──────────────────────")
print(f"{'Variable':40s} {'GV N':>10s} {'GV mean':>10s} {'GV std':>10s} "
      f"{'EV N':>10s} {'EV mean':>10s} {'EV std':>10s}")
for g, e in zip(gv_rows, ev_rows):
    print(f"{g[0]:40s} {fmt_num(g[1]):>10s} {fmt(g[2], '10.2f')} {fmt(g[3], '10.2f')} "
          f"{fmt_num(e[1]):>10s} {fmt(e[2], '10.2f')} {fmt(e[3], '10.2f')}")

print("\n──────────────────────  Panel B  ──────────────────────")
print(f"{'Variable':40s} {'GV N':>10s} {'GV mean':>12s} {'GV std':>12s} "
      f"{'EV N':>10s} {'EV mean':>12s} {'EV std':>12s}")
for g, e in zip(gv_rowsB, ev_rowsB):
    print(f"{g[0]:40s} {fmt_num(g[1]):>10s} {fmt(g[2], '12.2f')} {fmt(g[3], '12.2f')} "
          f"{fmt_num(e[1]):>10s} {fmt(e[2], '12.2f')} {fmt(e[3], '12.2f')}")

print("\n──────────────────────  Panel C  ──────────────────────")
print(f"{'Variable':40s} {'N':>6s} {'Mean':>10s} {'SD':>10s} {'Min':>10s} {'Max':>10s}")
for label, N, mean, sd, mn, mx in panC_rows:
    label_plain = label.replace("\\#", "#").replace("\\mathrm{", "").replace("}", "").replace("$","")
    if mean is None:
        print(f"{label_plain:40s} {N:>6d} {'---':>10s} {'---':>10s} {'---':>10s} {'---':>10s}")
    else:
        print(f"{label_plain:40s} {N:>6d} {mean:>10.2f} {sd:>10.2f} "
              f"{mn:>10.2f} {mx:>10.2f}")


# =============================================================================
# LaTeX output
# =============================================================================
YEAR_MIN, YEAR_MAX = int(df.Year.min()), int(df.Year.max())
N_CITIES = df.Geo_Market.nunique()

tex_lines = []
tex_lines.append(r"% Auto-generated by code/9_summary_statistics.py — do not edit by hand.")
tex_lines.append(r"% Source: output/df.parquet")
tex_lines.append("")

# --- Panel A + B in one table ---
tex_lines.append(r"\begin{table}[htbp]")
tex_lines.append(r"\centering")
tex_lines.append(r"\caption{Summary Statistics}")
tex_lines.append(r"\label{tab:summary_statistics}")
tex_lines.append(r"\small")
tex_lines.append(r"\begin{tabular}{lrrrrrr}")
tex_lines.append(r"\toprule")
tex_lines.append(r" & \multicolumn{3}{c}{GVs} & \multicolumn{3}{c}{EVs} \\")
tex_lines.append(r" \cmidrule(lr){2-4} \cmidrule(lr){5-7}")
tex_lines.append(r" & \# of Obs. & Mean & Std. Dev. & \# of Obs. & Mean & Std. Dev. \\")
tex_lines.append(r"\midrule")
tex_lines.append(r"\multicolumn{7}{l}{\textbf{Panel A: Product--year--city observations for demand-side analysis}} \\[0.5em]")
for g, e in zip(gv_rows, ev_rows):
    tex_lines.append(latex_row_panAB(g, e))
tex_lines.append(r"\midrule")
tex_lines.append(r"\multicolumn{7}{l}{\textbf{Panel B: Model--year observations for supply-side analysis}} \\[0.5em]")
for g, e in zip(gv_rowsB, ev_rowsB):
    tex_lines.append(latex_row_panAB(g, e))
tex_lines.append(r"\bottomrule")
tex_lines.append(r"\end{tabular}")

tex_lines.append(r"")
tex_lines.append(r"\vspace{0.5em}")
tex_lines.append(r"\begin{flushleft}")
tex_lines.append(r"\footnotesize")
tex_lines.append(
    rf"\textbf{{Notes:}} Panel A reports product$\times$year$\times$city observations used in "
    rf"the BLP demand estimation ({YEAR_MIN}--{YEAR_MAX}, {N_CITIES} cities). Panel B aggregates "
    rf"to the model$\times$year level used in the marginal-cost OLS. ``GVs'' includes "
    rf"ICE and HEV; ``EVs'' includes BEV, PHEV, and REEV. Vehicle size is exterior "
    rf"length$\times$width$\times$height in $\mathrm{{m}}^3$. ``L/100km'' is GV fuel economy; "
    rf"``kWh/100km'' is EV electricity consumption (not directly comparable). Subsidy rows "
    rf"split the cash schedule (national + local) from the 10\% purchase-tax exemption "
    rf"(active for NEVs 2014--2025). Driving range and battery capacity are reported "
    rf"for EVs only.")
tex_lines.append(r"\end{flushleft}")
tex_lines.append(r"\end{table}")

# --- Panel C ---
tex_lines.append(r"")
tex_lines.append(r"\vspace{2em}")
tex_lines.append(r"")
tex_lines.append(r"\begin{table}[htbp]")
tex_lines.append(r"\centering")
tex_lines.append(r"\small")
tex_lines.append(r"\caption{Panel C — City-Level Covariates and Market Structure}")
tex_lines.append(r"\label{tab:summary_statistics_C}")
tex_lines.append(r"\begin{tabular}{lrrrrr}")
tex_lines.append(r"\toprule")
tex_lines.append(r"\textbf{Panel C} & \# of Obs. & Mean & Std. Dev. & Min & Max \\")
tex_lines.append(r"\midrule")
for label, N, mean, sd, mn, mx in panC_rows:
    if mean is None:
        tex_lines.append(f"{label} & {N:,} & --- & --- & --- & --- \\\\")
    else:
        tex_lines.append(latex_row_panC(label, N, mean, sd, mn, mx))
tex_lines.append(r"\bottomrule")
tex_lines.append(r"\end{tabular}")

tex_lines.append(r"")
tex_lines.append(r"\vspace{0.5em}")
tex_lines.append(r"\begin{flushleft}")
tex_lines.append(r"\footnotesize")
tex_lines.append(
    rf"\textbf{{Notes:}} Panel C reports the year$\times$city level covariates and market-structure "
    rf"counts used in the demand BLP and the Shapley decomposition, across the {N_CITIES} cities "
    rf"during {YEAR_MIN}--{YEAR_MAX} ($N = $ year$\times$city cells). Population density is in "
    rf"10\,000 persons per $\mathrm{{km}}^2$. ``EV license priority'' is a city$\times$year dummy "
    rf"= 1 if the city grants priority/free EV license plates (binding in Beijing, Shanghai, "
    rf"Tianjin, Hangzhou, Guangzhou, Shenzhen). ``Pilot city'' is the central-government NEV "
    rf"pilot-city dummy. ``EV policy strength'' is the PKULaw-coded composite of city-level NEV "
    rf"support policies. ``Oil price'' is the annual Brent crude (USD/bbl) entered uniformly across "
    rf"cities. ``\# of firms'' counts unique Manufacturer codes selling at least one model in that "
    rf"city$\times$year cell.")
tex_lines.append(r"\end{flushleft}")
tex_lines.append(r"\end{table}")

os.makedirs(os.path.dirname(OUT_TEX), exist_ok=True)
with open(OUT_TEX, "w") as f:
    f.write("\n".join(tex_lines) + "\n")

print(f"\nSaved LaTeX → {OUT_TEX}")
print(f"   ({len(tex_lines)} lines)")
