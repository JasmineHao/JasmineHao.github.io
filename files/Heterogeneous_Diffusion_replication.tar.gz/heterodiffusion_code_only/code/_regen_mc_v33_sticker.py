"""
_regen_mc_v33_sticker.py
========================

Regenerate output/mc_true_v33_sticker.parquet from scratch using current
df.parquet (new subsidy) and current BLP essentials. This file is a pipeline
gap discovered 2026-06-10: it was generated once on 2026-05-16 by an
unidentified script and never refreshed; subsequent changes to subsidy data
left it stale, causing 3_dynamic_simulation.py to use mc_v33 inconsistent
with the current df.

Formula (v33 sticker-space convention):
    sticker_jc = price_jc + subsidy_jc
    Markup in sticker space from multi-product Bertrand FOC at observed
    shares: markup_sticker = −(Φ_sticker · own_mask)⁻¹ · s_obs
    where Φ_sticker[j,k] = ∂s_j/∂sticker_k, evaluated at the converged BLP δ
    and BLP α, σ_EV, π_p.

    mc_v33 = sticker − markup_sticker
"""
import os
import time
import numpy as np
import pandas as pd
from joblib import Parallel, delayed

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
NS = 25
N_JOBS = -1

print("=" * 70)
print("Regenerate mc_true_v33_sticker.parquet from current df + BLP essentials")
print("=" * 70)

# Load BLP essentials
ess = np.load(f"{PROJECT_ROOT}/output/blp_essentials_v12/blp_essentials.npz",
              allow_pickle=True)
PI_P = float(ess["pi_price"])
SIGMA_EV = float(ess["sigma_diag"][1])
beta = ess["beta"]
beta_labels = ess["beta_labels"].astype(str)
BETA_PRICE = float(beta[list(beta_labels).index("log_price")])  # Path D log-price
nu_attrs = ess["nu_attrs_v12"]
inc_inv = ess["income_inv_normed_v12"]
markets_blp = ess["markets_v12"].astype(str)
print(f"\nLoaded BLP: σ_ev={SIGMA_EV:.4f}, π_price={PI_P:.4f}, β_price={BETA_PRICE:.4f}")
print(f"  markets in BLP: {len(markets_blp)}")

# Load df.parquet with new subsidy
df = pd.read_parquet(f"{PROJECT_ROOT}/output/df.parquet")

def _singleton_filter(d):
    """Replicate the BLP singleton filter so row alignment with delta_blp holds."""
    out = d.copy()
    vars_ = ["log_size", "Displacement", "electric_efficiency",
             "FuelEfficiency", "log_ev_range"]
    vars_ = [v for v in vars_ if v in out.columns]
    grp = out.groupby("market_segement", sort=False)
    n = grp[vars_[0]].transform("size")
    for v in vars_:
        s = grp[v].transform("sum")
        out[f"{v}_iv_diff"] = np.abs(out[v] - np.where(n > 1, (s - out[v]) / (n - 1), np.nan))
    return out.dropna(subset=[f"{v}_iv_diff" for v in vars_]).reset_index(drop=True)

df = _singleton_filter(df)

# Compute RC-consistent δ via BLP contraction mapping.
# The saved ess["delta"] is in a different row ordering than df; recomputing
# guarantees alignment and that s(δ_RC; θ) = s_obs exactly, so the Bertrand FOC
# at observed shares is consistent with the simulation's fixed point.
print("Computing RC-contraction δ (BLP inner loop)...", flush=True)
_t_rc0 = time.time()
_mkt_to_bidx_rc = {m: i for i, m in enumerate(markets_blp)}
_aw_rc = np.full(NS, 1.0 / NS)
delta_blp = np.zeros(len(df))
for _m_id, _df_m in df.groupby("market_ids"):
    _ridx = _df_m.index.values
    _sobs = _df_m["shares"].values
    _s0   = float(_df_m["s_0"].iloc[0])
    _lp   = np.log(np.maximum(_df_m["price"].values, 1e-6))
    _evd  = _df_m["ev_dummy"].values.astype(float)
    _d    = np.log(np.maximum(_sobs, 1e-300)) - np.log(max(_s0, 1e-300))
    if _m_id in _mkt_to_bidx_rc:
        _t  = _mkt_to_bidx_rc[_m_id]
        _ii = inc_inv[_t]; _ni = nu_attrs[_t, :, 0]
        _ls = np.log(np.maximum(_sobs, 1e-300))
        for _ in range(500):
            _u  = (_d[:, None] + PI_P * _ii[None, :] * _lp[:, None]
                   + SIGMA_EV * np.outer(_evd, _ni))
            _um = np.maximum(0.0, _u.max(axis=0, keepdims=True))
            _eu = np.exp(_u - _um)
            _ss = (_eu / (np.exp(-_um.squeeze()) + _eu.sum(axis=0))[None, :]) @ _aw_rc
            _dn = _d + _ls - np.log(np.maximum(_ss, 1e-300))
            if np.max(np.abs(_dn - _d)) < 1e-10: _d = _dn; break
            _d  = _dn
    delta_blp[_ridx] = _d
print(f"  RC-contraction done in {time.time()-_t_rc0:.1f}s "
      f"(mean δ={delta_blp.mean():.3f})")

# Build per-row observed sticker = price + total_subsidy_wan
df["sticker"] = df["price"] + df["total_subsidy_wan"].fillna(0)
print(f"\nObserved sticker built: median = {df['sticker'].median():.2f} 10k yuan")
print(f"  2024 BEV median sticker: {df[(df['Year']==2024) & (df['FuelType']=='BEV')]['sticker'].median():.2f}")

# Q-weighted national sticker — matches 3_1_dynamic_decomposition.py's sticker_national.
# Critical: the simulation's solve_market iterates P = sticker_national, so the
# Bertrand FOC in the mc backout must also use sticker_national as the "sticker"
# variable. This ensures P = sticker_national is the EXACT fixed point (at scale=1).
df["_w"] = df["Population"] * df["shares"]
_snum = (df["sticker"] * df["_w"]).groupby([df["Model"], df["FuelType"], df["Year"]]).sum()
_sden = df["_w"].groupby([df["Model"], df["FuelType"], df["Year"]]).sum()
_snat_map = (_snum / _sden.replace(0, np.nan)).fillna(df["sticker"].median()).to_dict()
df["sticker_national"] = df.apply(
    lambda r: _snat_map.get((r["Model"], r["FuelType"], r["Year"]), r["sticker"]), axis=1)
print(f"  sticker_national median: {df['sticker_national'].median():.2f} "
      f"(city sticker median: {df['sticker'].median():.2f})")

# Per-market grouping — preserve original row indices for delta_blp alignment.
# delta_blp is in the original (pre-sort) order; sorting df would misalign them.
df["_orig_idx"] = np.arange(len(df), dtype=np.int64)  # row index in delta_blp
df = df.sort_values("market_ids").reset_index(drop=True)
markets = df["market_ids"].unique()
T = len(markets)
m_idx = df["market_ids"].map({m: i for i, m in enumerate(markets)}).values
mkt_starts = np.searchsorted(m_idx, np.arange(T))
mkt_ends = np.append(mkt_starts[1:], len(df))
mkt_to_blpidx = {m: list(markets_blp).index(m) for m in markets if m in markets_blp}
agent_w = np.full(NS, 1.0 / NS)

# Per-market sticker-space markup FOC at observed shares.
# In sticker space the consumer net price is sticker × (1 − subsidy_ratio),
# where subsidy_ratio_j = subsidy_j / sticker_j. The chain rule for the
# Jacobian of shares wrt sticker is:
#   ∂s_j / ∂sticker_k = ∂s_j / ∂net_k × ∂net_k / ∂sticker_k
#                     = ∂s_j / ∂net_k × (1 − subsidy_ratio_k)
# The BLP-side Jacobian ∂s_j/∂net_k uses heterogeneous α_i = β_price + π_p × inc_inv_i.

def solve_market(t):
    s_i, e_i = mkt_starts[t], mkt_ends[t]
    J = e_i - s_i
    df_m = df.iloc[s_i:e_i]
    m_id = df_m["market_ids"].iloc[0]
    if m_id not in mkt_to_blpidx:
        return t, np.full(J, np.nan), np.full(J, np.nan), np.full(J, np.nan)
    bidx = mkt_to_blpidx[m_id]
    inc_i = inc_inv[bidx]
    nu_i = nu_attrs[bidx, :, 0]
    orig_idxs = df.iloc[s_i:e_i]["_orig_idx"].values   # original row positions in delta_blp
    delta_t = delta_blp[orig_idxs]
    # National sticker (Bertrand FOC variable, matches simulation's P iterate)
    sticker = df_m["sticker_national"].values
    # City-specific observed net price (for BLP utility — gives BLP-fitted shares)
    net_obs = df_m["price"].values
    ev_dummy = df_m["ev_dummy"].values.astype(float)
    mf = df_m["Manufacturer"].astype("category").cat.codes.values
    own_mask = (mf[:, None] == mf[None, :]).astype(float)
    # v12 BLP log-price utility at observed net prices → BLP-fitted shares
    log_net_obs = np.log(np.maximum(net_obs, 1e-6))
    delta_NET_t = delta_t - BETA_PRICE * log_net_obs   # strip β × log(p_obs) from δ
    alpha_i = BETA_PRICE + PI_P * inc_i
    mu_price = np.outer(log_net_obs, alpha_i)
    mu_attr = SIGMA_EV * np.outer(ev_dummy, nu_i)
    u = delta_NET_t[:, None] + mu_price + mu_attr
    u_max = np.maximum(0.0, u.max(axis=0, keepdims=True))
    e_u = np.exp(u - u_max)
    denom = np.exp(-u_max[0]) + e_u.sum(axis=0)
    s_ij = e_u / denom[None, :]
    s_j = s_ij @ agent_w
    # Jacobian wrt log(net): ∂s_j/∂log(net_k) = α_i × s_ij × (δ_jk − s_ik)
    w_alpha = agent_w * alpha_i
    A_mat = (s_ij * w_alpha[None, :]) @ s_ij.T
    diag_j = s_ij @ w_alpha
    Jac_lognet = np.diag(diag_j) - A_mat
    # Chain rule: firm sets national sticker, consumer pays net = sticker × exp(lsf).
    # ∂log(net)/∂sticker_national = 1/sticker_national → ∂s/∂sticker = Jac_lognet / sticker.
    # Using sticker_national (not city sticker) ensures consistency with solve_market,
    # where P = sticker_national is the exact Bertrand fixed point at scale=1.
    Jac_sticker = Jac_lognet / sticker[None, :]
    Phi = Jac_sticker.T * own_mask + 1e-9 * np.eye(J)
    try:
        m_imp = np.linalg.solve(Phi, -s_j)
        # Safety clip: Lerner ∈ [0, 0.80]. Same clip in solve_market keeps fixed point exact.
        m_imp = np.clip(m_imp, 0.0, 0.8 * sticker)
    except np.linalg.LinAlgError:
        m_imp = 0.2 * sticker
    mc_v33 = sticker - m_imp
    return t, sticker, m_imp, mc_v33

print(f"\nSolving Bertrand-Nash markup per market (T={T})...")
t0 = time.time()
results = Parallel(n_jobs=N_JOBS, batch_size=20)(
    delayed(solve_market)(t) for t in range(T))
print(f"  done in {time.time()-t0:.1f}s")

# Assemble output dataframe
sticker_arr = np.empty(len(df)); sticker_arr[:] = np.nan
markup_arr = np.empty(len(df)); markup_arr[:] = np.nan
mc_v33_arr = np.empty(len(df)); mc_v33_arr[:] = np.nan
for t, st, mk, mc in results:
    s, e = mkt_starts[t], mkt_ends[t]
    sticker_arr[s:e] = st
    markup_arr[s:e] = mk
    mc_v33_arr[s:e] = mc

out = pd.DataFrame({
    "market_ids":         df["market_ids"].values,
    "Model":              df["Model"].values,
    "Year":               df["Year"].values,
    "FuelType":           df["FuelType"].values,
    "BodyType":           df["BodyType"].values,
    "sticker_national":   sticker_arr,
    "markup_sticker_v33": markup_arr,
    "mc_true_v33":        mc_v33_arr,
    "row_idx":            df["_orig_idx"].astype(np.int64).values,
})
n_nan = np.isnan(mc_v33_arr).sum()
print(f"\n  rows: {len(out):,}, mc_v33 NaN: {n_nan}")
print(f"  mc_v33 median (all):       {np.nanmedian(mc_v33_arr):.3f}")
print(f"  mc_v33 median 2024 BEV:    {np.nanmedian(mc_v33_arr[(df['Year']==2024) & (df['FuelType']=='BEV')]):.3f}")
print(f"  mc_v33 median 2018 BEV:    {np.nanmedian(mc_v33_arr[(df['Year']==2018) & (df['FuelType']=='BEV')]):.3f}")

out.to_parquet(f"{PROJECT_ROOT}/output/mc_true_v33_sticker.parquet", index=False)
print(f"\nSaved → output/mc_true_v33_sticker.parquet  (regenerated 2026-06-10)")
