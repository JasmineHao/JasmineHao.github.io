"""
9_17_shapley_comparison_fig.py
================================
Three-panel comparison: two sequential decompositions + Shapley.
Shows why ordering matters and why Shapley averaging is necessary.

Left:   Sequential A — Entry_qty added first
Middle: Sequential B — Entry_qty added last
Right:  Shapley value decomposition

Output: report/memos/fig_shapley_comparison.pdf/.png
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = ["Arial Unicode MS", "DejaVu Sans"]
import matplotlib.pyplot as plt

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT  = f"{ROOT}/report/memos"
os.makedirs(OUT, exist_ok=True)

COLORS = {
    "A_attrs":   "#1f77b4",
    "Entry_qty": "#ff7f0e",
    "Battery":   "#2ca02c",
    "xi":        "#9467bd",
    "Subsidy":   "#d62728",
    "Income":    "#8c564b",
}
LABELS = {
    "A_attrs":   r"$A_\mathrm{attrs}$",
    "Entry_qty": r"Entry$_\mathrm{qty}$",
    "Battery":   "Battery",
    "xi":        r"$\xi$",
    "Subsidy":   "Subsidy",
    "Income":    "Income",
}

# ── Load data ─────────────────────────────────────────────────────────────────
df = pd.read_csv(f"{ROOT}/output/decomp_s4_final_byyear_2024/coalition_results.csv")
df["cset"] = df["coalition"].str.strip("{}").apply(
    lambda x: frozenset(x.split(",")) if x.strip() else frozenset())

ALL_BLOCKS = ["A_attrs", "Battery", "Subsidy", "Entry_qty", "xi", "Income"]

def ev_share(blocks):
    mask = df["cset"] == frozenset(blocks)
    return float(df.loc[mask, "ev_share"].iloc[0])

baseline = ev_share([])
final    = ev_share(ALL_BLOCKS)

def seq_decomp(ordering):
    prev, result = [], {}
    for blk in ordering:
        curr = prev + [blk]
        result[blk] = ev_share(curr) - ev_share(prev)
        prev = curr
    return result

SEQ_A   = ["Entry_qty", "A_attrs", "Battery", "Subsidy", "xi", "Income"]
SEQ_B   = ["A_attrs",   "Battery", "Subsidy", "xi",     "Income", "Entry_qty"]
phi_A   = seq_decomp(SEQ_A)
phi_B   = seq_decomp(SEQ_B)

# Shapley from shapley_decomposition.csv
sh_csv  = pd.read_csv(f"{ROOT}/output/decomp_s4_final_byyear_2024/shapley_decomposition.csv")
phi_sh  = {r["block"]: r["shapley_ev_share"]
           for _, r in sh_csv.iterrows()
           if r["block"] not in ("BASELINE", "FINAL")}
# Shapley sorted: positive large-first, then negative most-negative-first
sh_pos  = sorted([b for b in ALL_BLOCKS if phi_sh[b] >= 0], key=lambda b: -phi_sh[b])
sh_neg  = sorted([b for b in ALL_BLOCKS if phi_sh[b] <  0], key=lambda b:  phi_sh[b])
SEQ_SH  = sh_pos + sh_neg

# ── Panel drawing function ────────────────────────────────────────────────────
def draw_waterfall(ax, phi, ordering, panel_label, panel_title=None):
    x_labels = ["'15"] + [LABELS[b] for b in ordering] + ["'24"]
    N = len(x_labels)   # baseline + 6 blocks + final = 8
    xs = np.arange(N)

    run = 0.0
    bots, hts, cols, hats = [0.0], [0.0], ["none"], [""]

    for b in ordering:
        v = phi[b]
        if v >= 0:
            bots.append(run); hts.append(v)
        else:
            bots.append(run + v); hts.append(-v)
        cols.append(COLORS[b])
        hats.append("" if v >= 0 else "///")
        run += v

    bots.append(0.0); hts.append(run)
    cols.append("#555"); hats.append("")

    W = 0.72
    for i, (bot, h, c, hat) in enumerate(zip(bots, hts, cols, hats)):
        if i == 0 or i == N - 1:
            ec, lw = "#333", 0.9
        else:
            ec, lw = "none", 0
        ax.bar(i, h, bottom=bot, color=c, edgecolor=ec, linewidth=lw,
               hatch=hat, alpha=0.88, width=W)

    # Value labels on bars
    run2 = 0.0
    for i, b in enumerate(ordering, start=1):
        v   = phi[b]
        bot = bots[i]
        h   = hts[i]
        yc  = bot + h / 2      # centre of bar
        # only label if bar is tall enough
        if abs(v) * 100 > 1.5:
            ax.text(i, yc, f"{v*100:+.0f}",
                    ha="center", va="center", fontsize=7.5,
                    color="white" if abs(v) * 100 > 6 else "black",
                    weight="bold")
        run2 += v

    # Baseline label
    ax.text(0, baseline + 0.003, f"{baseline*100:.1f}%",
            ha="center", va="bottom", fontsize=7, color="#333")
    # Final label
    ax.text(N - 1, run + 0.003, f"{run*100:.1f}%",
            ha="center", va="bottom", fontsize=11, weight="bold")

    # Connector lines
    run3 = 0.0
    for i, b in enumerate(ordering, start=1):
        ax.plot([i - 1 + W/2, i - W/2], [run3, run3],
                color="#aaa", lw=0.7, ls=":")
        run3 += phi[b]
    ax.plot([N - 2 + W/2, N - 1 - W/2], [run3, run3],
            color="#aaa", lw=0.7, ls=":")

    ax.axhline(0, color="black", lw=0.6)
    ax.set_xticks(xs)
    ax.set_xticklabels(x_labels, fontsize=11)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"{x*100:.0f}%"))
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", lw=0.4, alpha=0.3, color="gray")
    ax.tick_params(labelsize=11)
    # Flush x-axis: no extra whitespace left/right
    ax.set_xlim(-W/2 - 0.04, N - 1 + W/2 + 0.04)

    # Panel label (A / B / C) top-left
    ax.text(0.03, 0.98, panel_label, transform=ax.transAxes,
            fontsize=14, fontweight="bold", va="top", ha="left")


# ── Layout ────────────────────────────────────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(16, 5.0),
                         sharey=True,
                         constrained_layout=True,
                         gridspec_kw={"wspace": 0.05})

draw_waterfall(axes[0], phi_A, SEQ_A,
               "(A)", r"Sequential: Entry$_{qty}$ ordered first")
draw_waterfall(axes[1], phi_B, SEQ_B,
               "(B)", r"Sequential: Entry$_{qty}$ ordered last")
draw_waterfall(axes[2], phi_sh, SEQ_SH,
               "(C)", "Shapley value (average over all orderings)")

# Shared y-axis label on leftmost panel only
axes[0].set_ylabel("EV-share contribution vs 2015 (%)", fontsize=12)

# ── Align y-limits ────────────────────────────────────────────────────────────
_ylo = min(ax.get_ylim()[0] for ax in axes)
_yhi = max(ax.get_ylim()[1] for ax in axes)
for ax in axes:
    ax.set_ylim(_ylo, _yhi)

for ext in ("png", "pdf"):
    fp = f"{OUT}/fig_shapley_comparison.{ext}"
    fig.savefig(fp, dpi=200 if ext == "png" else 72, bbox_inches="tight")
    print(f"Saved → {fp}")
