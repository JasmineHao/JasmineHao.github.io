"""
3_dynamic_simulation.py
=======================

Dynamic forward simulation — v33-consistent (sticker-space, firm-side
Lerner, Path D log-price BLP). Updated 2026-05-16 for full consistency
with 2_decomposition.py post-v33.

Logic:
  1. Load Path D BLP params (1_blp.py output: σ_ev, π_log_price, β_log_price,
     δ_jt BLP-fit, nu_attrs_v12, income_inv_normed_v12). Same essentials as
     2_decomposition.py.
  2. Load v12 per-product MC backout (national_mc.parquet) AND the MC
     decomposition (mc_decomposed.parquet) to identify the battery-cost
     channel that Wright's Law modulates.
  3. Decompose mc_true = mc_eff_BLP + subsidy_obs_qwtd into:
       - mc_char(j)    : non-battery component (γ × log_size, etc.)
       - mc_battery(j,t): battery component (γ_bat × bat_kwh × ev_dummy)
                          — scales with bat_cost(t) via Wright's Law
       - mc_fe(j)      : residual / brand FE
  4. Fit Wright's Law: log(bat_cost) = log(A) − b × log(cum_ev_prod).
  5. Per-year forward simulation in sticker-space per-market Bertrand-Nash.
  6. Output: dynamic_sim_v33.csv + forward_sim_*.csv replacements.

Per-city Bertrand for tractability — each market solves independently. The
firm sets a national sticker in principle, but per-market solver iterates
per-product sticker conditional on local subsidy/demand. Faster than full
national solver; same v12 utility and FOC conventions.
"""
import os, time
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
NS = 25
SEED = 2024

# =============================================================================
# 1. Load v12 BLP essentials + data
# =============================================================================
print("=" * 70)
print("DYNAMIC FORWARD SIM — v33-consistent (Path D log-price, sticker-space)")
print("=" * 70)

ess_path = f"{PROJECT_ROOT}/output/blp_essentials_v12/blp_essentials.npz"
ess = np.load(ess_path, allow_pickle=True)
# Optional α-robustness lever: ALPHA_SCALE multiplies both β_log_price and
# π_log_price by the same factor. Default 1.0 reproduces Path D canonical
# (|α|≈4.91). Setting ALPHA_SCALE=0.51 brings the effective elasticity to
# the literature median |α|≈2.5 (Springel 2021 et al.).
_ALPHA_SCALE = float(os.environ.get("ALPHA_SCALE", "1.0"))
PI_P = float(ess["pi_price"]) * _ALPHA_SCALE
SIGMA_EV = float(ess["sigma_diag"][1])
BETA_PRICE = float(ess["beta"][0]) * _ALPHA_SCALE
nu_attrs = ess["nu_attrs_v12"]
inc_inv = ess["income_inv_normed_v12"]
markets_blp = ess["markets_v12"].astype(str)
print(f"Path D demand: σ_ev={SIGMA_EV:.4f}, π_log_price={PI_P:.4f}, "
      f"β_log_price={BETA_PRICE:.4f}")

nat_mc = pd.read_parquet(f"{PROJECT_ROOT}/output/national_mc.parquet")
mc_dec = pd.read_parquet(f"{PROJECT_ROOT}/output/mc_decomposed.parquet")
# v33-consistent per-market mc backed out under δ_NET demand at observed prices,
# in STICKER-SPACE (matches sim FOC chain rule). mc_true_v33 = sticker_obs −
# markup_sticker_v33, where markup_sticker is the sticker-space firm-side FOC
# implied markup under v33 demand. Wright's Law modulation is applied as an
# additive correction relative to the obs-bat baseline.
mc_v33 = pd.read_parquet(f"{PROJECT_ROOT}/output/mc_true_v33_sticker.parquet")
df = pd.read_parquet(f"{PROJECT_ROOT}/output/df.parquet")
# log_power_gv is gas-side horsepower (zero for EVs); used in 1_blp.py and the
# per-product characteristic output. df.parquet stores only the raw log_power
# so we recompute it here for cross-script consistency.
df["log_power_gv"] = (1.0 - df["ev_dummy"]) * df["log_power"]

def _singleton_filter(d):
    out = d.copy()
    vars_ = ["log_size", "Displacement", "electric_efficiency",
             "FuelEfficiency", "log_ev_range"]
    vars_ = [v for v in vars_ if v in out.columns]
    grp = out.groupby("market_segement", sort=False)
    n = grp[vars_[0]].transform("size")
    for v in vars_:
        s = grp[v].transform("sum")
        out[f"{v}_iv_diff"] = np.abs(out[v] - np.where(n > 1, (s - out[v]) / (n - 1), np.nan))
    return out.dropna(subset=[f"{v}_iv_diff" for v in vars_]).reset_index(drop=True)
df = _singleton_filter(df)

# Compute RC-consistent δ via BLP contraction mapping (0.7s for 790 markets).
# The saved ess["delta"] is in a different row ordering than the simulation's df;
# recomputing from scratch guarantees alignment and that s(δ_RC; θ) = s_obs exactly,
# so exog_exog/actual reproduces the observed 2024 EV share with zero deviation.
print("Computing RC-contraction δ (BLP inner loop)...", flush=True)
_t_rc0 = time.time()
_mkt_to_bidx_rc = {m: i for i, m in enumerate(markets_blp)}
_aw_rc = np.full(NS, 1.0 / NS)
delta_blp = np.zeros(len(df))
for _m_id, _df_m in df.groupby("market_ids"):
    _ridx = _df_m.index.values
    _sobs = _df_m["shares"].values
    _s0   = float(_df_m["s_0"].iloc[0])
    _lp   = np.log(np.maximum(_df_m["price"].values, 1e-6))
    _evd  = _df_m["ev_dummy"].values.astype(float)
    _d    = np.log(np.maximum(_sobs, 1e-300)) - np.log(max(_s0, 1e-300))
    if _m_id in _mkt_to_bidx_rc:
        _t  = _mkt_to_bidx_rc[_m_id]
        _ii = inc_inv[_t]; _ni = nu_attrs[_t, :, 0]
        _ls = np.log(np.maximum(_sobs, 1e-300))
        for _ in range(500):
            _u  = (_d[:, None] + PI_P * _ii[None, :] * _lp[:, None]
                   + SIGMA_EV * np.outer(_evd, _ni))
            _um = np.maximum(0.0, _u.max(axis=0, keepdims=True))
            _eu = np.exp(_u - _um)
            _ss = (_eu / (np.exp(-_um.squeeze()) + _eu.sum(axis=0))[None, :]) @ _aw_rc
            _dn = _d + _ls - np.log(np.maximum(_ss, 1e-300))
            if np.max(np.abs(_dn - _d)) < 1e-10: _d = _dn; break
            _d  = _dn
    delta_blp[_ridx] = _d
print(f"  RC-contraction done in {time.time()-_t_rc0:.1f}s "
      f"(mean δ={delta_blp.mean():.3f})")

# v12 BLP is log-price spec: δ_BLP contains β_log_p × log(p_obs).
# Subtract β_log_p × log(p_obs) to get δ_NET (price-stripped mean utility).
# solve_market then adds back (β + π × inc_i) × log(p_new), so at p_new=p_obs
# utilities reduce to δ_BLP + π × inc_i × log(p_obs) — exactly the BLP formula.
_log_p_obs = np.log(np.maximum(df["price"].values, 1e-6))
delta_blp = delta_blp - BETA_PRICE * _log_p_obs
print(f"  Applied δ-NET subtraction: −β_log_price × log(p_obs) "
      f"(β_log_price={BETA_PRICE:+.4f}, mean shift={-BETA_PRICE * _log_p_obs.mean():+.4f})")

# =============================================================================
# 1b. Year-relative ξ machinery (Stage B)
# =============================================================================
# Decompose δ_jt = X1_jt · β + ξ_jt (BLP residual after linear part).
# For counterfactual entry / cross-year product transplant (Stage C), the raw
# ξ̂_jt is not a year-invariant primitive because Var_j(ξ̂_jt) varies year to
# year (driven by changing entry composition, FuelType mix, EV taste shifts).
# Renormalize:
#     ξ̃_jt   = (ξ̂_jt − μ̂_t) / σ̂_t       (within-year standardized)
#     ξ̂_jt' = ξ̃_jt × σ̂_{t'} + μ̂_{t'}    (target-year rescaled)
# `USE_YEAR_RELATIVE_XI` flag controls whether the dynamic sim applies this
# transformation when sourcing entrant ξ from a year other than its observed
# year. The Stage A baseline (current spec, observed entry per year) is a
# no-op for this transformation.
USE_YEAR_RELATIVE_XI = os.environ.get("USE_YEAR_RELATIVE_XI", "1") == "1"

# Build β_full from blp_essentials beta labels and X1 columns. The label set
# from 1_blp.py is the canonical remapped vocabulary, while X1 here uses the
# v12 raw column names. For simplicity we recompute ξ_jt approximately as
# δ_blp − BETA_PRICE × price (price-only correction, which captures the v33
# subtraction already applied above). This means ξ̂ here ≡ δ_NET, an internally
# consistent residual we can year-normalize.
xi_hat = delta_blp.copy()  # δ_NET, after price subtraction
df["_xi_net"] = xi_hat
year_xi_stats = df.groupby("Year")["_xi_net"].agg(["mean", "std"])
print(f"\nYear-relative ξ stats (USE_YEAR_RELATIVE_XI={USE_YEAR_RELATIVE_XI}):")
print(year_xi_stats.round(3).to_string())

XI_MU = year_xi_stats["mean"].to_dict()
XI_SD = year_xi_stats["std"].replace(0, np.nan).fillna(year_xi_stats["std"].median()).to_dict()

def year_relative_xi(xi_raw, source_year, target_year):
    """Rescale a ξ_jt value from source_year's distribution to target_year's.

    If USE_YEAR_RELATIVE_XI is False or source_year == target_year, returns
    xi_raw unchanged. Otherwise applies the standardize-then-rescale map.
    """
    if not USE_YEAR_RELATIVE_XI or source_year == target_year:
        return xi_raw
    mu_s, sd_s = XI_MU.get(source_year, 0.0), XI_SD.get(source_year, 1.0)
    mu_t, sd_t = XI_MU.get(target_year, 0.0), XI_SD.get(target_year, 1.0)
    if sd_s <= 0 or not np.isfinite(sd_s):
        return xi_raw
    z = (xi_raw - mu_s) / sd_s
    return z * sd_t + mu_t

# Per-product national sticker (Q-weighted) + log_subsidy_factor relative to it
df["_w"] = df["Population"] * df["shares"]
df["_sticker_per_row"] = df["price"] + df["total_subsidy_wan"].fillna(0)
_num = (df["_sticker_per_row"] * df["_w"]).groupby(
    [df["Model"], df["FuelType"], df["Year"]]).sum()
_den = df["_w"].groupby([df["Model"], df["FuelType"], df["Year"]]).sum()
sticker_nat = (_num / _den.replace(0, np.nan)).fillna(df["_sticker_per_row"].median()).to_dict()
df["sticker_national"] = df.apply(
    lambda r: sticker_nat[(r["Model"], r["FuelType"], r["Year"])], axis=1)
df["log_subsidy_factor"] = (
    np.log(df["price"].clip(lower=0.01)) - np.log(df["sticker_national"].clip(lower=0.01)))

subsidy_w = (df["total_subsidy_wan"].fillna(0) * df["_w"]).groupby(
    [df["Model"], df["FuelType"], df["Year"]]).sum() / _den.replace(0, np.nan)
subsidy_nat = subsidy_w.fillna(0).to_dict()

# mc_decomposed indexed for fast lookup
mc_dec_idx = mc_dec.set_index(["Year", "Model", "FuelType"])
# v33 mc lookup: row-index-aligned with the filtered df (handles BodyType variants
# with the same Model that would collide on a tuple-based key).
assert "row_idx" in mc_v33.columns, "Regenerate mc_true_v33_sticker.parquet with row_idx column"
mc_v33_arr = mc_v33.sort_values("row_idx")["mc_true_v33"].values
assert len(mc_v33_arr) == len(df), (
    f"mc_v33 rows ({len(mc_v33_arr)}) must equal filtered df rows ({len(df)})")
print(f"  Loaded mc_true_v33 (sticker-space, row-aligned): {len(mc_v33_arr)} entries, "
      f"{np.isnan(mc_v33_arr).sum()} NaN (small markets)")

# Battery cost (BNEF)
bat_panel = pd.read_csv(f"{PROJECT_ROOT}/raw_data/battery_cost_bnef.csv")
bat_obs = dict(zip(bat_panel["year"], bat_panel["battery_pack_usd_kwh"]))
df["bat_usd_kwh"] = df["Year"].map(bat_obs).ffill().bfill()
years_all = sorted(df["Year"].unique())
print(f"\nBNEF observed battery cost: {bat_obs}")

# =============================================================================
# 2. Wright's Law fit — GLOBAL cumulative (CN + Rest-of-World)
# =============================================================================
M_PER_ROW = 21220.0  # implied by data: sum(shares × pop) × M = real 2024 sales (26M).
# The original 10000/(2.62×5) form (annual-replacement) was 27.8× too small; using
# it broke internal consistency between BLP-defined market shares and the simulator's
# absolute Q / profit / subsidy aggregates. Fixed per design 2026-06-10.
ev_sales_by_yr = (df[df["ev_dummy"] == 1]
                  .assign(_q=lambda d: d["shares"] * d["Population"] * M_PER_ROW)
                  .groupby("Year")["_q"].sum().sort_index())
CUM_PROD_2014_ANCHOR = 2.3e5
cum_ev_prod = ev_sales_by_yr.cumsum() + CUM_PROD_2014_ANCHOR

# IEA EV Outlook 2024 stocks (BEV + PHEV light-duty), end of year.
# Both world AND China hardcoded from IEA Annex A — the BLP-data-derived
# CN cumulative is off by ~25× due to M_PER_ROW unit conversion artifacts
# (cars sold per population row vs total fleet stock). Using IEA for both
# CN and ROW gives an internally consistent global cumulative.
WORLD_EV_STOCK = {
    2015:  1_300_000, 2016:  2_000_000, 2017:  3_100_000, 2018:  5_100_000,
    2019:  7_200_000, 2020: 10_000_000, 2021: 16_500_000, 2022: 26_000_000,
    2023: 40_600_000, 2024: 56_400_000,
}
CN_EV_STOCK_IEA = {
    2015:    400_000, 2016:    600_000, 2017:  1_100_000, 2018:  2_300_000,
    2019:  3_400_000, 2020:  4_500_000, 2021:  7_700_000, 2022: 14_500_000,
    2023: 25_000_000, 2024: 35_000_000,
}
ROW_CUM_OBS = {yr: max(WORLD_EV_STOCK[yr] - CN_EV_STOCK_IEA[yr], 1e5)
               for yr in WORLD_EV_STOCK.keys()}
print(f"\nIEA EV Outlook 2024 stocks (CN share of global ≈ "
      f"{CN_EV_STOCK_IEA[2024]/WORLD_EV_STOCK[2024]*100:.0f}% in 2024):")
for yr in sorted(ROW_CUM_OBS.keys()):
    cn_share = CN_EV_STOCK_IEA[yr] / WORLD_EV_STOCK[yr] * 100
    print(f"  {yr}: world={WORLD_EV_STOCK[yr]/1e6:.2f}M  "
          f"CN={CN_EV_STOCK_IEA[yr]/1e6:.2f}M ({cn_share:4.1f}%)  "
          f"ROW={ROW_CUM_OBS[yr]/1e6:.2f}M")

# Counterfactual CN cumulative path: scale the BLP-derived path so 2015
# matches IEA, preserving the BLP dynamics. cum_prod_cf in run_scenario
# is initialized to cum_ev_2015 — re-anchor that to IEA 2015 below.
_SCALE_CN_TO_IEA = CN_EV_STOCK_IEA[2015] / float(cum_ev_prod.loc[2015])
cum_ev_prod_ieascale = cum_ev_prod * _SCALE_CN_TO_IEA
print(f"  BLP-data CN scale factor to IEA: {_SCALE_CN_TO_IEA:.2f} "
      f"(CN_2015: BLP={cum_ev_prod.loc[2015]/1e6:.3f}M → IEA={CN_EV_STOCK_IEA[2015]/1e6:.3f}M)")

# Fit Wright on global (IEA-CN + IEA-ROW), not the BLP-data CN.
global_cum = np.array([CN_EV_STOCK_IEA[yr] + ROW_CUM_OBS[yr] for yr in sorted(WORLD_EV_STOCK.keys())])
bat_log = np.array([np.log(bat_obs[yr]) for yr in sorted(WORLD_EV_STOCK.keys())])
glob_log = np.log(global_cum)
slope_glob, log_A_glob = np.polyfit(glob_log, bat_log, 1)
WRIGHT_A_GLOB = np.exp(log_A_glob); WRIGHT_B_GLOB = -slope_glob
print(f"\nWright's Law (GLOBAL cum, IEA scale): bat = {WRIGHT_A_GLOB:.1f} × Q_global^(-{WRIGHT_B_GLOB:.3f})")
print(f"  Implied learning rate per doubling: {(1 - 2**(-WRIGHT_B_GLOB))*100:.1f}%")

WRIGHT_A, WRIGHT_B = WRIGHT_A_GLOB, WRIGHT_B_GLOB

# =============================================================================
# 3. Per-market sticker-space Bertrand-Nash solver (v12)
# =============================================================================
markets = df["market_ids"].unique()
mkt_to_blpidx = {m: list(markets_blp).index(m) for m in markets if m in markets_blp}
agent_w = np.full(NS, 1.0 / NS)

def solve_market(df_m, mc_true_arr, lsf_arr, max_iter=30, tol=1e-3):
    """Per-city sticker-space Bertrand-Nash (v12 log-price utility).
       net = sticker × exp(lsf); utility uses α × log(net) [log-price spec].
       Firm-side markup m = sticker − mc_true. FOC: Phi.T m = −s in sticker space.
       Returns (P_eq, s_j, converged).
    """
    J = len(df_m)
    ev_dummy = df_m["ev_dummy"].values.astype(float)
    mf = df_m["Manufacturer"].astype("category").cat.codes.values
    own_mask = (mf[:, None] == mf[None, :]).astype(float)
    m_id = df_m["market_ids"].iloc[0]
    if m_id not in mkt_to_blpidx:
        return None, None, False
    t = mkt_to_blpidx[m_id]
    inc_i = inc_inv[t]
    nu_i = nu_attrs[t, :, 0]
    # Use saved BLP δ aligned by ORIGINAL row index (df is the filtered df)
    row_idx = df_m.index.values
    delta_NET = delta_blp[row_idx]  # NET δ (= δ_BLP − β_price × p_obs)
    # Stage C: endogenous-range utility boost shifts δ upward when r* > r_obs.
    if "_delta_r_boost" in df_m.columns:
        delta_NET = delta_NET + df_m["_delta_r_boost"].values
    alpha_i = BETA_PRICE + PI_P * inc_i
    sticker_init = df_m["sticker_national"].values
    P = sticker_init.copy()
    converged = False
    for it in range(max_iter):
        net_row = P * np.exp(lsf_arr)
        log_net_row = np.log(np.maximum(net_row, 1e-6))
        # v12 log-price spec: u_ij = δ_NET + α_i × log(net_j) + σ_ev × ν_i × ev_dummy_j
        u = (delta_NET[:, None]
             + alpha_i[None, :] * log_net_row[:, None]
             + SIGMA_EV * np.outer(ev_dummy, nu_i))
        u_max = u.max(axis=0, keepdims=True)
        eu = np.exp(u - u_max)
        denom = np.exp(-u_max.squeeze()) + eu.sum(axis=0)
        s_ij = eu / denom[None, :]
        s_j = s_ij @ agent_w
        # ∂s_j/∂log(net_k) = α_i s_ij (δ_jk − s_ik), aggregated over agents
        alpha_s = alpha_i[None, :] * s_ij
        Jac_lognet = -(1.0 / NS) * (alpha_s @ s_ij.T)
        Jac_lognet[np.arange(J), np.arange(J)] += (1.0 / NS) * alpha_s.sum(axis=1)
        # Chain rule (proportional subsidy, log-price):
        #   net = P × exp(lsf), ∂log(net)/∂P = 1/P  →  ∂s/∂sticker = Jac_lognet / P
        Jac_sticker = Jac_lognet / P[None, :]
        Phi = Jac_sticker.T * own_mask + 1e-9 * np.eye(J)
        try:
            m_imp = np.linalg.solve(Phi, -s_j)
            # Consistent clip with _regen_mc_v33_sticker.py: ensures P = sticker_obs
            # is the exact fixed point for actual scenario (mc_v33 + clipped_markup = sticker_obs).
            m_imp = np.clip(m_imp, 0.0, 0.8 * P)
        except np.linalg.LinAlgError:
            m_imp = np.full(J, 0.2 * sticker_init.mean())
        P_new = np.maximum(mc_true_arr + m_imp, mc_true_arr * 0.5 + 0.1)
        P_next = 0.6 * P + 0.4 * P_new
        if np.max(np.abs(P_next - P) / np.maximum(P, 0.1)) < tol:
            P = P_next
            converged = True
            break
        P = P_next
    return P, s_j, converged


# =============================================================================
# 3b. Endogenous range FOC (Stage C)
# =============================================================================
# Each EV product j in year t chooses range r_jt to maximize expected profit:
#     max_r  E[(p_jt(r) − mc_jt(r; c_t)) · Q_jt(r, r_-j)] − F(r)
# Bertrand-Nash in range (rivals' r held fixed), holding price at the
# concurrently-solved Bertrand equilibrium. FOC (small-share approximation
# for ∂Q/∂r and assuming firm holds p fixed at within-r update):
#     β_r · (p − mc) / r  =  γ_bat · η_kWh · c_t  +  κ · (r − r_base) / r
# where
#     β_r        = consumer's marginal utility of range (calibrated)
#     γ_bat      = pass-through of battery cost into MC (calibrated, ≤ 1)
#     η_kWh      = kWh per km of range (technical constant, ~0.2)
#     c_t        = battery cost in USD/kWh in year t
#     κ          = R&D quadratic cost (calibrated to 2015 median range)
#     r_base     = baseline R&D-free range (set to 2014 observed median)
# Closed-form solution (ignoring 1/r on the RHS, then iterating once):
#     r* ≈ (β_r · (p − mc) + κ · r_base) / (γ_bat · η_kWh · c_t + κ)
ENDO_ENTRY = os.environ.get("ENDO_ENTRY", "0") == "1"
ENDO_GAMMA_BAT = float(os.environ.get("ENDO_GAMMA_BAT", "1.0"))       # full pass-through
ENDO_ETA_KWH = float(os.environ.get("ENDO_ETA_KWH", "0.20"))          # kWh per km
ENDO_R_BASE_KM = float(os.environ.get("ENDO_R_BASE_KM", "200.0"))     # 2014 baseline
ENDO_R_CAP_KM = float(os.environ.get("ENDO_R_CAP_KM", "1000.0"))     # numerical cap

# Per-year β_r(t) calibration. The user's design point: the FOC has to use
# THAT YEAR'S observed (p, mc, c_t, r_obs) — not a fixed 2024 anchor — so
# the implied consumer marginal value of range can shift over time
# (early-market consumers value the first 100 km enormously; mature-market
# consumers value the marginal 100 km of an already-500km BEV much less).
# At each year t the FOC implies:
#   β_r(t) = r_obs(t) · γ_bat · η_kWh · c_t / (p_obs(t) − mc_obs(t))
# Under counterfactual sub_scale = 0:
#   r*_cf(j,t) / r_obs(t)  =  ((p−mc)_cf / (p−mc)_obs) · (c_obs / c_cf)
# i.e. r* shifts with both (p−mc) (Bertrand re-equilibrium under no subsidy)
# and c_t (Wright's Law re-equilibrium under reduced CN cumulative).
BETA_R_BY_YEAR = {}
R_OBS_MED_BY_YEAR = {}
P_MINUS_MC_MED_BY_YEAR_USD = {}
C_OBS_BY_YEAR = {}
print(f"\nEndogenous range FOC (Stage C, ENDO_ENTRY={ENDO_ENTRY}):")
print(f"  Per-year FOC ratio anchors on BEV panel (no global β_r needed):")
print(f"    r*_cf(j,t) / r_obs(t)  =  (p−mc)_cf(j,t)/(p−mc)_obs(t)  ×  c_obs(t)/c_cf(t)")
print(f"    {'Year':>5s}  {'r_obs(km)':>9s}  {'c_t(USD/kWh)':>13s}  "
      f"{'(p-mc)_med(10k)':>15s}  {'β_r(t)_imp':>10s}")
for _yr in sorted(df["Year"].unique()):
    _bev = df[(df["Year"] == _yr) & (df["FuelType"] == "BEV")]
    if len(_bev) == 0:
        BETA_R_BY_YEAR[int(_yr)] = 0.5
        R_OBS_MED_BY_YEAR[int(_yr)] = ENDO_R_BASE_KM
        continue
    _r_med = float(np.exp(_bev["log_ev_range"].median()))
    _p_med = float(_bev["price"].median())
    _mc_med = float(np.nanmedian(mc_v33_arr[_bev.index.values]))
    _p_minus_mc_wan = max(_p_med - _mc_med, 0.3)
    _p_minus_mc_usd = _p_minus_mc_wan * 10000.0 / 7.0
    _c_yr = bat_obs.get(int(_yr), 200.0)
    _beta = _r_med * ENDO_GAMMA_BAT * ENDO_ETA_KWH * _c_yr / _p_minus_mc_usd
    BETA_R_BY_YEAR[int(_yr)] = _beta
    R_OBS_MED_BY_YEAR[int(_yr)] = _r_med
    P_MINUS_MC_MED_BY_YEAR_USD[int(_yr)] = _p_minus_mc_usd
    C_OBS_BY_YEAR[int(_yr)] = _c_yr
    print(f"    {int(_yr):5d}  {_r_med:9.0f}  {_c_yr:13.0f}  "
          f"{_p_minus_mc_wan:15.2f}  {_beta:10.3f}")
print(f"  Bounds: r* clipped to [{ENDO_R_BASE_KM:.0f}, {ENDO_R_CAP_KM:.0f}] km.")
# Demand-side coefficient: consumer's revealed-preference β_r used for the
# δ_NET shift. The OLS-Logit value (0.30) is robust because it's an aggregate
# consumer-side estimate (whereas the FOC β_r is firm-side and reflects
# additional non-demand motivations).
ENDO_BETA_RANGE_DEMAND = float(os.environ.get("ENDO_BETA_RANGE_DEMAND", "0.30"))
print(f"  β_r^DEMAND = {ENDO_BETA_RANGE_DEMAND:.3f}  (OLS-Logit; used for δ-shift)")


def optimal_range_km(r_obs_km, p_minus_mc_obs_usd, p_minus_mc_cf_usd,
                     c_obs_kwh, c_cf_kwh):
    """Per-product ratio-FOC for endogenous range. Anchors to each product's
    own observed range and margin (not the year median):

        r*_cf(j,t)  =  r_obs(j,t)  ·  [(p−mc)_cf / (p−mc)_obs(j,t)]
                                     ·  [c_obs(t) / c_cf]

    In the actual scenario every ratio is 1 → r* = r_obs(j,t) exactly →
    Δr = 0 → endo regime collapses to exog. In counterfactual:
      • subsidy removal widens (p−mc)_cf (firm gets back the subsidy
        revenue gap) → r* up;
      • slower CN cumulative → higher c_cf → r* down.
    Net direction depends on which channel dominates per product-year.
    """
    if p_minus_mc_obs_usd <= 0 or c_cf_kwh <= 0:
        return r_obs_km
    ratio_margin = p_minus_mc_cf_usd / p_minus_mc_obs_usd
    ratio_cost = c_obs_kwh / c_cf_kwh
    r_star = r_obs_km * ratio_margin * ratio_cost
    return float(np.clip(r_star, ENDO_R_BASE_KM, ENDO_R_CAP_KM))


# =============================================================================
# 3c. Stochastic entry + endogenous exit (Stage D)
# =============================================================================
# Motivation: in counterfactuals (esp. with endogenous quality choice), pinning
# entry to its observed schedule is inappropriate. We do NOT want to assume
# that "2017 had entry, 2018 did not" mechanically transports to a no-subsidy
# world. Instead, model entry as a Bernoulli draw with year-product hazard
#   h_jt = h_base × 1{t ≥ y_first_obs(j) − 1} × exp(γ_ent × (c_2015 − c_t)/c_2015)
# - h_base calibrated so that under observed c_t path the expected per-year
#   entry count matches the observed entry count (baseline reproduces data
#   in expectation).
# - The (c_2015 − c_t)/c_2015 term induces more entry when battery costs are
#   lower — captures "cost decline opens product space".
# - 1{t ≥ y_first − 1} ensures a product cannot enter before its real-world
#   tech-readiness year minus one (gives one year of slack).
# Exit is endogenous: a product exits in year t if its realized share is below
# `dropout_eps` (existing channel) OR if its realized per-period margin × Q is
# below a fixed-cost threshold F_FIXED_WAN (in 万元 per product-year).
ENTRY_MODE = os.environ.get("ENTRY_MODE", "observed")   # "observed" | "stochastic"
N_DRAWS = int(os.environ.get("N_DRAWS", "20"))
ENTRY_SEED = int(os.environ.get("ENTRY_SEED", "2026"))
GAMMA_ENT = float(os.environ.get("GAMMA_ENT", "1.5"))
# Profit-floor EXIT is disabled per 2026-06-10 design: relative-floor exit
# perversely killed marginal ICE products and inflated counterfactual EV
# share. Instead, profit is an ENTRY decision factor — a product enters
# in year t only if its expected counterfactual profit clears F_ENTRY:
#   π̂_jt^cf  =  π_jt^baseline  −  (1 − sub_scale) · subsidy_per_car_jt · Q_jt^obs
#   enter if π̂_jt^cf  >  F_ENTRY
# Under sc=actual (sub_scale=1) the second term vanishes → π̂ = baseline,
# so any observed product with positive baseline profit enters.
# Under sc=no_subsidy (sub_scale=0) the lost subsidy revenue is subtracted,
# so products that depended heavily on subsidies fail the gate.
F_ENTRY = float(os.environ.get("F_ENTRY", "0.0"))  # 10k yuan/year breakeven
print(f"\nStochastic entry (Stage D): ENTRY_MODE={ENTRY_MODE}, N_DRAWS={N_DRAWS}, γ_ent={GAMMA_ENT}")
print(f"  Entry profit gate F_ENTRY = {F_ENTRY:.1f} 10k yuan/yr "
      f"(no profit-floor exit; profit is an entry decision factor)")

# Baseline per-product per-year profit & quantity at observed prices / v33 MC.
_baseline_profit = (df.assign(margin=df["price"] - mc_v33_arr)
                      .assign(q_row=lambda d: d["shares"] * d["Population"] * M_PER_ROW)
                      .assign(profit_row=lambda d: d["margin"] * d["q_row"])
                      .groupby(["Model", "FuelType", "Year"])["profit_row"].sum())
BASELINE_PROFIT = _baseline_profit.to_dict()
_baseline_q = (df.assign(q_row=lambda d: d["shares"] * d["Population"] * M_PER_ROW)
                 .groupby(["Model", "FuelType", "Year"])["q_row"].sum())
OBSERVED_Q = _baseline_q.to_dict()
print(f"  Baseline cache: {len(BASELINE_PROFIT):,} (Model, FT, Year) cells "
      f"(profit + Q, used by entry gate)")
print(f"  Profit distribution: p25={np.nanpercentile(_baseline_profit,25):.0f}  "
      f"median={np.nanpercentile(_baseline_profit,50):.0f}  "
      f"p75={np.nanpercentile(_baseline_profit,75):.0f} 10k yuan/yr")

def cf_profit_estimate(model, fueltype, year, sub_scale):
    """Expected counterfactual profit for product (model, fueltype, year)
    under subsidy scale `sub_scale` ∈ [0, 1]. Used by the entry gate.

    π̂_cf = π_baseline  −  (1 − sub_scale) · subsidy_per_car · Q_baseline
    """
    base_pi = BASELINE_PROFIT.get((model, fueltype, year))
    if base_pi is None:
        return -np.inf
    sub_per_car = subsidy_nat.get((model, fueltype, year), 0.0)
    q_base = OBSERVED_Q.get((model, fueltype, year), 0.0)
    return base_pi - (1.0 - sub_scale) * sub_per_car * q_base

# Build the product pool: every (Model, FuelType) observed at any point, plus
# its first observed year (proxy for tech readiness) and modal BodyType / Brand
# / Manufacturer (used to attach attributes when sampling entry).
_prod_pool = (df.groupby(["Model", "FuelType"])
                .agg(y_first=("Year", "min"),
                     y_last=("Year", "max"),
                     BodyType=("BodyType", lambda x: x.mode().iloc[0]),
                     Brand=("Brand", lambda x: x.mode().iloc[0]),
                     Manufacturer=("Manufacturer", lambda x: x.mode().iloc[0]))
                .reset_index())
print(f"  Product pool: {len(_prod_pool)} unique (Model, FuelType) pairs across all years")

# Calibrate h_base: choose so that expected entries under observed c_t path
# equal observed annual new-entry counts. Observed entries per year = #{products
# newly seen this year} = #{(Model,FuelType) with y_first == t}.
_obs_entries_per_year = _prod_pool["y_first"].value_counts().sort_index()
# Expected entries in year t = Σ_j h_jt over all products not yet entered.
# At calibration: h_jt = h_base × exp(γ_ent × (c_2015 − c_obs_t)/c_2015), summed
# over the at-risk set (products with y_first ≤ t + 1, not yet entered). Solve
# for h_base by matching total expected entries to total observed entries.
def _hazard_at(t, c_t, c_2015, j_eligible_count):
    return min(j_eligible_count * (1.0 / max(j_eligible_count, 1)) *
               np.exp(GAMMA_ENT * (c_2015 - c_t) / max(c_2015, 1)), 1.0)
# For calibration purposes use ratio: expected entries / observed entries =
# h_base × Σ_t (eligible_t × exp(γ_ent × Δc_t/c_2015)). Set = 1 to solve h_base.
_c_2015_cal = bat_obs[2015]
_calib_sum = 0.0
_already_entered = 0
for yr in years_all:
    elig = max(len(_prod_pool) - _already_entered, 1)
    c_yr = bat_obs.get(yr, bat_obs[max(bat_obs.keys())])
    _calib_sum += elig * np.exp(GAMMA_ENT * (_c_2015_cal - c_yr) / _c_2015_cal)
    _already_entered += int(_obs_entries_per_year.get(yr, 0))
H_BASE = _obs_entries_per_year.sum() / max(_calib_sum, 1.0)
print(f"  Calibrated h_base = {H_BASE:.4f}  (expected total entries = {_obs_entries_per_year.sum()})")


def sample_entry_set(c_t_path, seed):
    """Monte Carlo: sample which products enter in which year under c_t path.

    Returns dict: year → set of (Model, FuelType) keys that are active.
    Active at year t = sampled entry year ≤ t AND not yet exited.
    """
    rng = np.random.default_rng(seed)
    active = {yr: set() for yr in years_all}
    entered_by = {}  # (Model, FuelType) → year of entry
    for _, prod in _prod_pool.iterrows():
        key = (prod["Model"], prod["FuelType"])
        y_first = int(prod["y_first"])
        for yr in years_all:
            if yr < y_first - 1:
                continue  # tech-readiness gate
            if key in entered_by:
                continue
            c_yr = c_t_path.get(yr, _c_2015_cal)
            h_jt = H_BASE * np.exp(GAMMA_ENT * (_c_2015_cal - c_yr) / _c_2015_cal)
            if rng.random() < min(h_jt, 1.0):
                entered_by[key] = yr
                break
    # Active set per year = all products entered by that year
    for key, ye in entered_by.items():
        for yr in years_all:
            if yr >= ye:
                active[yr].add(key)
    return active


# =============================================================================
# 4. Year-by-year scenario runner
# =============================================================================
def build_mc_true_year(year, bat_cf_kwh, exited_keys=None, active_keys=None,
                        sub_scale=1.0):
    """Per-product mc_true at counterfactual battery cost.

    Wright's Law scales mc_comp_learning by (bat_cf / bat_obs(year)).
    mc_true = exp(char + bat_cap + learn × scale + fe + xi_mc) + subsidy_nat.

    `active_keys` (Stage D): if provided, restrict df_y to the stochastically-
    sampled active product set for this draw. None = use all observed products.
    `sub_scale` is also passed to the entry-time profit gate (per design
    2026-06-10): a product is filtered out of df_y if its expected cf profit
    at this year falls below F_ENTRY. Under sub_scale=1.0 this is a no-op for
    profitable observed products; under sub_scale=0.0 it filters subsidy-
    dependent products.
    """
    if exited_keys is None:
        exited_keys = set()
    df_y = df[df["Year"] == year].copy()
    if active_keys is not None:
        keep = df_y.apply(lambda r: (r["Model"], r["FuelType"]) in active_keys, axis=1)
        df_y = df_y[keep]
    if exited_keys:
        m = ~df_y.apply(lambda r: (r["Model"], r["FuelType"]) in exited_keys, axis=1)
        df_y = df_y[m]
    # Entry-time profit gate: skip products whose expected cf profit is
    # below F_ENTRY. The gate uses observed baseline profit minus the lost
    # subsidy revenue ((1−sub_scale) × subsidy_per_car × Q_obs).
    if abs(sub_scale - 1.0) > 1e-9:
        keep_gate = df_y.apply(
            lambda r: cf_profit_estimate(r["Model"], r["FuelType"], year, sub_scale) > F_ENTRY,
            axis=1)
        df_y = df_y[keep_gate]
    # Keep index intact (used by solve_market to align delta_blp)
    bat_obs_yr = bat_obs.get(year, bat_obs[max(bat_obs.keys())])
    scale = bat_cf_kwh / bat_obs_yr
    # Build a fast dict lookup from mc_dec
    if not hasattr(build_mc_true_year, "_cache"):
        # One-time: convert mc_dec into a flat dict for fast O(1) lookup
        _c = {}
        for _, mrow in mc_dec.iterrows():
            _c[(int(mrow["Year"]), mrow["Model"], mrow["FuelType"])] = {
                "char": float(mrow["mc_comp_char"]),
                "bat_cap": float(mrow["mc_comp_battery_cap"]),
                "learn": float(mrow["mc_comp_learning"]),
                "fe": float(mrow["mc_comp_fe"]),
                "xi_mc": float(mrow.get("xi_mc", 0.0)) if "xi_mc" in mc_dec.columns else 0.0,
            }
        build_mc_true_year._cache = _c
    mc_lookup = build_mc_true_year._cache
    mc_true_arr = np.zeros(len(df_y))
    # Stage C: optional endogenous range adjustment for BEV/PHEV products.
    # At c_t < c_2015, optimal r* > observed r → delta utility from extended
    # range is added back to δ via β_r × Δlog(r). MC also increases by
    # γ_bat × η × c_t × Δr. Net effect: positive demand boost when c_t falls.
    delta_r_boost = np.zeros(len(df_y))  # ΔU added to δ_NET for each row
    mc_r_addon = np.zeros(len(df_y))     # ΔMC added (USD per car, converted)
    if ENDO_ENTRY:
        c_obs_yr = bat_obs.get(int(year), bat_cf_kwh)
        for i, (orig_idx, r) in enumerate(df_y.iterrows()):
            if r["FuelType"] not in ("BEV", "PHEV"):
                continue
            log_r_obs = float(r["log_ev_range"])
            r_obs_km = float(np.exp(log_r_obs)) if log_r_obs > 0 else ENDO_R_BASE_KM
            # Per-product baseline (p−mc): from observed row data
            p_wan = float(r["price"])
            mc_obs_wan = mc_v33_arr[orig_idx] if orig_idx < len(mc_v33_arr) and not np.isnan(mc_v33_arr[orig_idx]) else 0.7 * p_wan
            p_minus_mc_obs_wan = max(p_wan - mc_obs_wan, 0.1)
            p_minus_mc_obs_usd = p_minus_mc_obs_wan * 10000.0 / 7.0
            # Counterfactual (p−mc): add back the lost subsidy revenue when
            # subsidies are removed (firm gets less from consumers, but gross
            # revenue from a sticker-priced car becomes price+subsidy → margin
            # widens compared to baseline net price)
            sub_per_car = subsidy_nat.get((r["Model"], r["FuelType"], year), 0.0)
            p_minus_mc_cf_wan = p_minus_mc_obs_wan + (1.0 - sub_scale) * sub_per_car
            p_minus_mc_cf_usd = max(p_minus_mc_cf_wan, 0.1) * 10000.0 / 7.0
            r_star_km = optimal_range_km(r_obs_km, p_minus_mc_obs_usd,
                                          p_minus_mc_cf_usd, c_obs_yr, bat_cf_kwh)
            if r_star_km <= r_obs_km:
                continue
            delta_r_boost[i] = ENDO_BETA_RANGE_DEMAND * (np.log(r_star_km) - np.log(r_obs_km))
            delta_r_km = r_star_km - r_obs_km
            d_mc_usd = ENDO_GAMMA_BAT * ENDO_ETA_KWH * bat_cf_kwh * delta_r_km
            mc_r_addon[i] = d_mc_usd * 7.0 / 10000.0
    for i, (orig_idx, r) in enumerate(df_y.iterrows()):
        key = (year, r["Model"], r["FuelType"])
        # Row-aligned v33 mc lookup (avoids BodyType-collision in tuple keys)
        mc_v33_row = mc_v33_arr[orig_idx] if orig_idx < len(mc_v33_arr) else np.nan
        sub_nat = subsidy_nat.get((r["Model"], r["FuelType"], year), 0.0)
        if key in mc_lookup:
            v = mc_lookup[key]
            mc_eff_obs = float(np.exp(v["char"] + v["bat_cap"] + v["learn"]
                                       + v["fe"] + v["xi_mc"]))
            mc_eff_cf  = float(np.exp(v["char"] + v["bat_cap"] + v["learn"] * scale
                                       + v["fe"] + v["xi_mc"]))
            wright_delta = mc_eff_cf - mc_eff_obs
            # v33-consistent baseline: mc_true_v33 (sticker-space) at observed bat,
            # then add Wright correction. At scale=1, mc_true_arr = mc_true_v33 exactly,
            # so observed prices are the sim FOC fixed point.
            if not np.isnan(mc_v33_row):
                mc_true_arr[i] = max(mc_v33_row + wright_delta + mc_r_addon[i], 0.1)
            else:
                mc_true_arr[i] = max(mc_eff_obs + sub_nat + wright_delta + mc_r_addon[i], 0.1)
        else:
            mc_true_arr[i] = max(float(r["price"]) * 0.7 + sub_nat + mc_r_addon[i], 0.1)
    # Expose ΔU per row so solve_market can shift δ before equilibrating.
    df_y = df_y.copy()
    df_y["_delta_r_boost"] = delta_r_boost
    return df_y, mc_true_arr


def run_year(year, bat_cf_kwh, subsidy_scale, exited_keys=None, active_keys=None):
    """Per-year forward sim. Returns ev_share, ev_q, prod_avg, prod_profit,
    prod_attrs.

    `prod_attrs[(Model, FuelType)]` is a dict of national-aggregate per-product
    realizations used by the per-product output table:
        obs_log_r, opt_log_r, r_star_km, p_nat, mc_nat, q_total, FuelType,
        log_size, log_power_gv, ev_dummy
    """
    df_y_full, mc_true_full = build_mc_true_year(
        year, bat_cf_kwh, exited_keys, active_keys=active_keys, sub_scale=subsidy_scale)
    ev_q = 0.0; total_q = 0.0
    prod_q_sum = {}; prod_M_sum = {}; prod_profit_sum = {}
    prod_p_num = {}; prod_mc_num = {}; prod_w_den = {}
    df_y_full = df_y_full.reset_index(drop=False)
    df_y_full["_mc_true"] = mc_true_full
    for m_id, df_m in df_y_full.groupby("market_ids"):
        df_m_for_solve = df_m.set_index("index")
        lsf_obs = df_m["log_subsidy_factor"].values
        ratio_obs = 1.0 - np.exp(lsf_obs)
        # Remove upper clip: allow new_ratio > 1.0 for cities where city_price >
        # sticker_national (ICE regional price premium). Clipping to 1.0 was
        # zeroing out those premiums at sub_scale=1, giving net_cf < city_price_obs
        # and inflating shares. At sub_scale=0 the formula gives 1.0 anyway so
        # the counterfactual is unaffected.
        new_ratio = np.maximum(1.0 - ratio_obs * subsidy_scale, 1e-3)
        lsf_cf = np.log(new_ratio)
        mc_m = df_m["_mc_true"].values
        sticker_obs_m = df_m["sticker_national"].values
        P_eq, s_j, converged = solve_market(df_m_for_solve, mc_m, lsf_cf)
        if P_eq is None:
            continue
        # Under factual (subsidy_scale==1), observed sticker IS the Bertrand fixed
        # point by construction (mc_v33 + clipped markup = sticker_obs). If the
        # solver still didn't converge, fall back to observed prices and recompute
        # shares at those prices so we don't introduce phantom factual deviations.
        if subsidy_scale == 1.0 and not converged:
            dev = np.max(np.abs(P_eq - sticker_obs_m) / np.maximum(sticker_obs_m, 0.1))
            if dev > 0.05:
                import warnings
                warnings.warn(
                    f"Factual solver non-convergence in market {m_id} "
                    f"(max rel dev={dev:.3f}); falling back to observed prices.",
                    stacklevel=2,
                )
                P_eq = sticker_obs_m.copy()
                # Recompute shares at observed prices
                net_fb = P_eq * np.exp(lsf_cf)
                log_net_fb = np.log(np.maximum(net_fb, 1e-6))
                row_idx_fb = df_m_for_solve.index.values
                delta_NET_fb = delta_blp[row_idx_fb]
                if "_delta_r_boost" in df_m_for_solve.columns:
                    delta_NET_fb = delta_NET_fb + df_m_for_solve["_delta_r_boost"].values
                ev_dummy_fb = df_m_for_solve["ev_dummy"].values.astype(float)
                t_fb = mkt_to_blpidx[m_id]
                alpha_i_fb = BETA_PRICE + PI_P * inc_inv[t_fb]
                nu_i_fb = nu_attrs[t_fb, :, 0]
                u_fb = (delta_NET_fb[:, None]
                        + alpha_i_fb[None, :] * log_net_fb[:, None]
                        + SIGMA_EV * np.outer(ev_dummy_fb, nu_i_fb))
                u_max_fb = u_fb.max(axis=0, keepdims=True)
                eu_fb = np.exp(u_fb - u_max_fb)
                denom_fb = np.exp(-u_max_fb.squeeze()) + eu_fb.sum(axis=0)
                s_j = (eu_fb / denom_fb[None, :]) @ agent_w
        pop_wan = df_m["Population"].iloc[0]
        M_c = pop_wan * M_PER_ROW
        ev_d = df_m["ev_dummy"].values
        ev_q += float((s_j * ev_d).sum() * M_c)
        total_q += float(s_j.sum() * M_c)
        margin = (P_eq - mc_m)
        for j, k in enumerate(zip(df_m["Model"].values, df_m["FuelType"].values)):
            prod_q_sum[k] = prod_q_sum.get(k, 0.0) + s_j[j] * M_c
            prod_M_sum[k] = prod_M_sum.get(k, 0.0) + M_c
            prod_profit_sum[k] = prod_profit_sum.get(k, 0.0) + float(margin[j] * s_j[j] * M_c)
            # Q-weighted national p and mc for the per-product output table
            w = s_j[j] * M_c
            prod_p_num[k] = prod_p_num.get(k, 0.0) + float(P_eq[j] * w)
            prod_mc_num[k] = prod_mc_num.get(k, 0.0) + float(mc_m[j] * w)
            prod_w_den[k] = prod_w_den.get(k, 0.0) + float(w)
    ev_share = ev_q / total_q if total_q > 0 else 0.0
    prod_avg = {k: prod_q_sum[k] / prod_M_sum[k] for k in prod_q_sum}
    # Per-product national attributes, aggregated for the case-comparison table.
    prod_attrs = {}
    df_first = df_y_full.drop_duplicates(["Model", "FuelType"])
    attr_lookup = {(r["Model"], r["FuelType"]): r for _, r in df_first.iterrows()}
    for k, w_den in prod_w_den.items():
        if w_den <= 0:
            continue
        a = attr_lookup.get(k)
        if a is None:
            continue
        p_nat = prod_p_num[k] / w_den
        mc_nat = prod_mc_num[k] / w_den
        # Endogenous r* via per-product ratio-FOC at the realized (p − mc, c_t).
        if ENDO_ENTRY and a["FuelType"] in ("BEV", "PHEV"):
            obs_log_r = float(a["log_ev_range"])
            r_obs_km = float(np.exp(obs_log_r)) if obs_log_r > 0 else ENDO_R_BASE_KM
            # Per-product observed (p−mc) and counterfactual (p−mc)
            # (firm-realized national aggregates from the Bertrand fixed point)
            p_minus_mc_realized_usd = max(p_nat - mc_nat, 0.1) * 10000.0 / 7.0
            c_obs_yr = bat_obs.get(int(year), bat_cf_kwh)
            r_star = optimal_range_km(r_obs_km, p_minus_mc_realized_usd,
                                       p_minus_mc_realized_usd,  # use realized as both anchors
                                       c_obs_yr, bat_cf_kwh)
        else:
            r_star = float("nan")
        obs_log_r = float(a["log_ev_range"])
        prod_attrs[k] = {
            "FuelType": a["FuelType"],
            "obs_log_r": obs_log_r,
            "obs_r_km": float(np.exp(obs_log_r)) if obs_log_r > 0 else float("nan"),
            "opt_r_km": r_star,
            "delta_r_km": (r_star - float(np.exp(obs_log_r)))
                          if (np.isfinite(r_star) and obs_log_r > 0) else float("nan"),
            "p_nat": p_nat,
            "mc_nat": mc_nat,
            "lerner": (p_nat - mc_nat) / max(p_nat, 1e-6),
            "q_total": prod_q_sum[k],
            "profit": prod_profit_sum[k],
            "log_size": float(a["log_size"]),
            "log_power_gv": float(a["log_power_gv"]),
            "ev_dummy": float(a["ev_dummy"]),
        }
    return ev_share, ev_q, prod_avg, prod_profit_sum, prod_attrs


def _row_cum_path(row_path_name):
    """Return year → ROW cumulative production under one of three regimes.

    observed : IEA 2015–2024 stock, linearly extrapolated for any missing year.
    frozen   : ROW production frozen at 2015 level (no global learning beyond CN).
    doubled  : ROW production doubled (high-learning sensitivity bound).
    """
    if row_path_name == "observed":
        return {yr: ROW_CUM_OBS.get(yr, ROW_CUM_OBS[max(ROW_CUM_OBS.keys())])
                for yr in years_all}
    elif row_path_name == "frozen":
        base = ROW_CUM_OBS[2015]
        return {yr: base for yr in years_all}
    elif row_path_name == "doubled":
        return {yr: 2.0 * ROW_CUM_OBS.get(yr, ROW_CUM_OBS[max(ROW_CUM_OBS.keys())])
                for yr in years_all}
    else:
        raise ValueError(f"unknown row_path: {row_path_name}")


def run_scenario(sc_name, subsidy_scale, wright_b, dropout_eps, cum_ev_2015,
                 row_path="observed", draw_seed=None):
    """Counterfactual forward sim under (scenario, θ, ROW path, dropout) cell.

    Wright (global form):  c_t = A × (Q_CN_t + Q_ROW_t)^(-θ)
    Anchor A so that c_{2015} = observed bat_obs[2015] at observed (CN+ROW)_2015.
    Under sc_name="actual": pin c_t to observed each year (Wright unused).
    Under sc_name="no_subsidy": c_t evolves with counterfactual CN cum prod +
    exogenous ROW path (observed/frozen/doubled).
    """
    bat_2015_obs = bat_obs[2015]
    row_path_dict = _row_cum_path(row_path)
    Q_global_2015 = float(cum_ev_2015) + float(row_path_dict[2015])
    wright_A = bat_2015_obs * (Q_global_2015 ** wright_b)
    cum_prod_cf = float(cum_ev_2015)
    exited = set()
    # Stage D: if stochastic entry, build a year → active-set map from a draw
    # against the calibrated hazard model. The c_t path used for the draw is
    # the OBSERVED battery path under sc_name=="actual" (for baseline
    # reproduction) or, under counterfactual, a Wright-implied path computed
    # iteratively (one-shot approximation: use observed bat path for the entry
    # draw, then run the BLP fixed-point with counterfactual costs — entry
    # decisions get the same shock signal regardless of subsidy scenario).
    active_per_year = None
    if ENTRY_MODE == "stochastic":
        active_per_year = sample_entry_set(bat_obs, seed=draw_seed if draw_seed is not None else ENTRY_SEED)
    yr_records = []
    prod_records = []  # per-product per-year output for the case-comparison table
    for yr in years_all:
        if sc_name == "actual":
            bat_cf = bat_obs.get(yr, bat_obs[max(bat_obs.keys())])
        else:
            Q_global_yr = cum_prod_cf + row_path_dict.get(yr, row_path_dict[max(row_path_dict.keys())])
            bat_cf = wright_A * Q_global_yr ** (-wright_b)
        active_yr = active_per_year[yr] if active_per_year is not None else None
        ev_share, ev_q, prod_share, prod_profit, prod_attrs = run_year(
            yr, bat_cf, subsidy_scale, exited, active_keys=active_yr)
        # Scale BLP-derived ev_q to IEA cum_prod_cf scale before accumulating.
        cum_prod_cf += ev_q * _SCALE_CN_TO_IEA
        # Profit-floor exit DISABLED per 2026-06-10 design. Profit is now
        # an ENTRY decision (gate in build_mc_true_year), not an exit trigger.
        new_exits_profit = set()
        # Share-threshold exit (legacy paper-facing dropout channel; kept for
        # backward compatibility with the v5 dropout grid).
        new_exits_share = (
            {k for k, s in prod_share.items() if s < dropout_eps}
            if dropout_eps > 0 else set()
        )
        exited |= (new_exits_profit | new_exits_share)
        yr_records.append({
            "scenario": sc_name, "wright_b": wright_b, "dropout_eps": dropout_eps,
            "row_path": row_path,
            "draw_seed": draw_seed if draw_seed is not None else ENTRY_SEED,
            "Year": yr, "bat_usd_kwh": bat_cf,
            "ev_share": ev_share, "ev_q": ev_q,
            "cum_prod_cn": cum_prod_cf,
            "cum_prod_row": float(row_path_dict.get(yr, np.nan)),
            "n_products_active": len(prod_share),
            "n_exited_share": len(new_exits_share),
            "n_exited_profit": len(new_exits_profit),
            "n_exited_running": len(exited),
        })
        # Accumulate per-product details for the case-comparison output.
        for k, a in prod_attrs.items():
            prod_records.append({
                "scenario": sc_name, "wright_b": wright_b, "dropout_eps": dropout_eps,
                "row_path": row_path, "draw_seed": draw_seed if draw_seed is not None else ENTRY_SEED,
                "Year": yr, "Model": k[0], "FuelType": k[1],
                **a,
            })
    return yr_records, prod_records


# =============================================================================
# 5. Three modeling regimes × 2 policy scenarios = 6 runs (no sensitivity grid)
# =============================================================================
# Per design 2026-06-10:
#   • Wright θ, ROW path: fix to the canonical estimate (18% learning rate per
#     doubling, ROW=observed). Sensitivity sweep removed.
#   • Dropout threshold: calibrated from observed product-exit shares (below).
#   • Three modeling regimes:
#       MODE 1 (exog_exog) : entry timing and quality both exogenous → v5 baseline.
#                            Diagnostic check that calibrated dropout reproduces
#                            observed 2024 EV share at sub=1.0.
#       MODE 2 (exog_endo) : entry timing exogenous; product quality (range)
#                            chosen endogenously via FOC at each year's c_t.
#       MODE 3 (endo_endo) : entry timing stochastic (hazard) + endogenous range.
#                            Monte Carlo over N_DRAWS hazard realizations.
#   • Each mode runs at sub_scale ∈ {1.0, 0.0} → 6 total deterministic runs
#     (or 4 + 2 × N_DRAWS when MODE 3 uses MC).

# Data-calibrated dropout: identify products that disappear from the data
# before 2024 and take the median of their final-year average market share as
# the empirical exit threshold. Products falling below it in the simulator
# are taken out.
print("\n" + "=" * 70)
print("Calibrating dropout threshold from observed product exits")
print("=" * 70)
_yr_max = int(df["Year"].max())
_prod_years = (df.groupby(["Model", "FuelType"])
                 .agg(y_first=("Year", "min"), y_last=("Year", "max"))
                 .reset_index())
_exiters = _prod_years[_prod_years["y_last"] < _yr_max]
_exit_shares = []
for _, prod in _exiters.iterrows():
    sub = df[(df["Model"] == prod["Model"]) & (df["FuelType"] == prod["FuelType"]) &
             (df["Year"] == prod["y_last"])]
    if len(sub) > 0:
        _exit_shares.append(float(sub["shares"].mean()))
_exit_shares = np.array(_exit_shares)
DROPOUT_DATA = float(np.median(_exit_shares)) if len(_exit_shares) > 0 else 1e-5
print(f"  N products that disappear before {_yr_max}: {len(_exit_shares)}")
print(f"  Last-year-share distribution: p10={np.percentile(_exit_shares,10):.2e}  "
      f"median={np.percentile(_exit_shares,50):.2e}  "
      f"p90={np.percentile(_exit_shares,90):.2e}")
print(f"  Calibrated DROPOUT_DATA = {DROPOUT_DATA:.4e}  (median of exit-year mean shares)")

# Canonical θ and ROW (no sweep)
WRIGHT_B_FIXED = 0.286  # 18% learning rate per doubling
ROW_PATH_FIXED = "observed"
cum_2015 = float(CN_EV_STOCK_IEA[2015])

# Three regimes
REGIMES = [
    ("exog_exog", "Exogenous entry + exogenous quality (v5 baseline)"),
    ("exog_endo", "Exogenous entry + endogenous range FOC"),
    ("endo_endo", "Stochastic entry + endogenous range FOC"),
]
SUB_LEVELS = [("actual", 1.0), ("no_subsidy", 0.0)]

print("\n" + "=" * 70)
print("Forward simulation: 3 regimes × 2 subsidy levels = 6 runs "
      f"(MODE 3 uses {N_DRAWS} MC draws)")
print("=" * 70)

all_results = []
all_prod_records = []
run_idx = 0

# Stash module-globals so we can switch them between regimes without
# reorganizing the function signatures.
_ORIG_ENDO = ENDO_ENTRY
_ORIG_ENTRY = ENTRY_MODE

for (regime, regime_desc) in REGIMES:
    # Configure the regime by toggling globals consumed inside run_year
    if regime == "exog_exog":
        ENDO_ENTRY = False
        ENTRY_MODE = "observed"
        mc_draws = [None]
    elif regime == "exog_endo":
        ENDO_ENTRY = True
        ENTRY_MODE = "observed"
        mc_draws = [None]
    else:  # endo_endo
        ENDO_ENTRY = True
        ENTRY_MODE = "stochastic"
        mc_draws = list(range(N_DRAWS))
    print(f"\n{'-'*70}\nREGIME {regime}: {regime_desc}")
    print(f"  ENDO_ENTRY={ENDO_ENTRY}  ENTRY_MODE={ENTRY_MODE}  N_DRAWS={len(mc_draws)}")
    for (sc_name, sub_scale) in SUB_LEVELS:
        # endo_endo: actual uses observed product set to pin actual quantities;
        # only no_subsidy uses stochastic entry + dropout so the counterfactual
        # reflects endogenous entry collapse under removed subsidies.
        if regime == "endo_endo":
            if sc_name == "actual":
                ENTRY_MODE = "observed"
                _sc_draws = [None]
                _dropout_eps = 0.0
            else:
                ENTRY_MODE = "stochastic"
                _sc_draws = mc_draws
                _dropout_eps = DROPOUT_DATA
        else:
            _sc_draws = mc_draws
            _dropout_eps = 0.0
        for draw in _sc_draws:
            draw_seed = ENTRY_SEED + draw if draw is not None else None
            run_idx += 1
            label = f"  [{run_idx}] {regime}/{sc_name}"
            if draw is not None:
                label += f"/draw{draw}"
            print(f"\n{label}", flush=True)
            t0 = time.time()
            recs, prod_recs = run_scenario(
                sc_name, sub_scale, WRIGHT_B_FIXED, _dropout_eps, cum_2015,
                row_path=ROW_PATH_FIXED, draw_seed=draw_seed)
            for r in recs:
                r["regime"] = regime
                r["regime_desc"] = regime_desc
            for r in prod_recs:
                r["regime"] = regime
            all_results.extend(recs)
            all_prod_records.extend(prod_recs)
            last = recs[-1]
            print(f"    2024: bat={last['bat_usd_kwh']:5.0f}  "
                  f"EV share={last['ev_share']*100:5.2f}%  "
                  f"EV q={last['ev_q']/1e6:5.2f}M  "
                  f"n_active={last['n_products_active']}  "
                  f"n_exited={last['n_exited_running']}  "
                  f"{time.time()-t0:5.1f}s")
ENDO_ENTRY = _ORIG_ENDO
ENTRY_MODE = _ORIG_ENTRY

# =============================================================================
# 6. Save raw results + Monte Carlo aggregation + paper-facing outputs
# =============================================================================
res_df = pd.DataFrame(all_results)
res_df.to_csv(f"{PROJECT_ROOT}/output/dynamic_sim_v33.csv", index=False)
print(f"\nSaved → output/dynamic_sim_v33.csv  ({len(res_df):,} rows)")

# Per-product per-year output: realized r*, characteristics, price, mc, share
# under each counterfactual cell. This is what answers the question "what
# does optimal driving range look like under no_subsidy / global Wright?".
prod_df = pd.DataFrame(all_prod_records)
prod_df.to_csv(f"{PROJECT_ROOT}/output/dynamic_sim_v33_products.csv", index=False)
print(f"Saved → output/dynamic_sim_v33_products.csv  ({len(prod_df):,} rows)")

# MC aggregation: mean ± std across draws within (regime, scenario, Year).
GROUP_COLS = ["regime", "scenario", "Year"]
res_agg = (res_df.groupby(GROUP_COLS, as_index=False)
                 .agg(ev_share_mean=("ev_share", "mean"),
                      ev_share_std=("ev_share", "std"),
                      ev_q_mean=("ev_q", "mean"),
                      ev_q_std=("ev_q", "std"),
                      bat_usd_kwh=("bat_usd_kwh", "mean"),
                      n_products_mean=("n_products_active", "mean"),
                      n_exited_share=("n_exited_share", "mean"),
                      n_exited_profit=("n_exited_profit", "mean"),
                      n_draws=("ev_share", "count")))
res_agg.to_csv(f"{PROJECT_ROOT}/output/dynamic_sim_v33_aggregated.csv", index=False)
print(f"Saved → output/dynamic_sim_v33_aggregated.csv  ({len(res_agg):,} cells)")

# Observed 2024 EV share for calibration check
_df_obs = df.assign(
    fuel_class=df["FuelType"].map(lambda f: "EV" if f in ("BEV","PHEV","REEV") else "ICEV"),
    Q=df["shares"] * df["Population"] * M_PER_ROW,
)
obs_yr = (_df_obs.groupby("Year").apply(
    lambda g: 100 * g.loc[g["fuel_class"]=="EV", "Q"].sum() / g["Q"].sum(),
    include_groups=False,
).reset_index(name="obs_ev_share"))
OBS_EV_SHARE_2024 = float(obs_yr.loc[obs_yr["Year"] == 2024, "obs_ev_share"].iloc[0])

# Headline pivot: 2024 EV share by (regime × scenario)
print("\n" + "=" * 70)
print(f"2024 EV SHARE: 3 regimes × 2 scenarios   (observed 2024: {OBS_EV_SHARE_2024:.2f}%)")
print("=" * 70)
y2024 = res_agg[res_agg["Year"] == 2024]
pivot_share = y2024.pivot_table(index="regime", columns="scenario",
                                values="ev_share_mean", aggfunc="mean")
print("\nEV share (%) at 2024:")
print((pivot_share * 100).round(2).to_string())
pivot_n = y2024.pivot_table(index="regime", columns="scenario",
                            values="n_products_mean", aggfunc="mean")
print("\n# active products at 2024:")
print(pivot_n.round(1).to_string())
print("\nSubsidy effect (Δ = no_subsidy − actual), pp:")
for regime, _ in REGIMES:
    if regime in pivot_share.index:
        s_act = pivot_share.loc[regime, "actual"]
        s_nos = pivot_share.loc[regime, "no_subsidy"]
        print(f"  {regime:14s}: actual={s_act*100:5.2f}%  "
              f"no_sub={s_nos*100:5.2f}%  Δ={100*(s_nos-s_act):+5.2f}pp")

# Per-product per-year output: realized r*, characteristics, price, mc, share.
prod_df = pd.DataFrame(all_prod_records)
prod_df.to_csv(f"{PROJECT_ROOT}/output/dynamic_sim_v33_products.csv", index=False)
print(f"\nSaved → output/dynamic_sim_v33_products.csv  ({len(prod_df):,} rows)")

# Headline product-level case comparison at 2024 BEV, exog_endo regime.
if len(prod_df) > 0:
    bev_2024 = prod_df[(prod_df["Year"] == 2024) & (prod_df["FuelType"] == "BEV") &
                        (prod_df["regime"] == "exog_endo")]
    if len(bev_2024) > 0:
        print("\n" + "=" * 70)
        print("2024 BEV CASE COMPARISON  (regime = exog_endo, endogenous range FOC)")
        print("=" * 70)
        for sc in ["actual", "no_subsidy"]:
            sub = bev_2024[bev_2024["scenario"] == sc]
            if len(sub) == 0:
                continue
            print(f"\n[{sc}] N={len(sub)} active BEV products in 2024:")
            print(f"  median observed r  = {sub['obs_r_km'].median():.0f} km")
            print(f"  median optimal r*  = {sub['opt_r_km'].median():.0f} km")
            print(f"  median Δr*         = {sub['delta_r_km'].median():.0f} km")
            print(f"  median price       = {sub['p_nat'].median():.2f} 10k yuan")
            print(f"  median mc          = {sub['mc_nat'].median():.2f} 10k yuan")
            print(f"  median Lerner      = {sub['lerner'].median():.3f}")
            print(f"  total Q (M cars)   = {sub['q_total'].sum() / 1e6:.2f}")

# Trajectory plot: EV share by year for each regime × scenario
fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
for ax, (regime, regime_desc) in zip(axes, REGIMES):
    for sc_name, _ in SUB_LEVELS:
        color = "C0" if sc_name == "actual" else "C3"
        sub = res_agg[(res_agg["regime"] == regime) & (res_agg["scenario"] == sc_name)]
        ax.plot(sub["Year"], sub["ev_share_mean"] * 100, marker="o",
                color=color, label=sc_name)
        if sc_name == "no_subsidy":
            std = sub["ev_share_std"].fillna(0)
            ax.fill_between(sub["Year"], (sub["ev_share_mean"] - std) * 100,
                            (sub["ev_share_mean"] + std) * 100, color=color, alpha=0.15)
    ax.plot(obs_yr["Year"], obs_yr["obs_ev_share"], "k--", marker="s",
            markersize=5, label="observed", linewidth=1.2)
    ax.set_xlabel("Year"); ax.set_ylabel("EV share (%)")
    ax.set_title(regime, fontsize=11)
    ax.legend(loc="upper left", fontsize=8); ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(f"{PROJECT_ROOT}/output/fig_dynamic_sim_v33.png", dpi=150)
print(f"Saved → output/fig_dynamic_sim_v33.png")

print("\nDone.")
