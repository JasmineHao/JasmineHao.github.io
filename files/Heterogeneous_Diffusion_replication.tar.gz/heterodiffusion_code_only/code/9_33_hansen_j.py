"""
9_33_hansen_j.py
================

Documentation-only: discusses why we DO NOT report Hansen J.

With one endogenous regressor (log price) and 11 excluded instruments,
the BLP system is over-identified by 10 degrees of freedom. With
N=476,723 observations, even tiny departures from E[Z'ξ]=0 — for
example, second-order misspecification of the demand model, finite-sample
correlations between attribute moments and the residual, or omitted
nonlinearities — drive the Hansen J statistic far above the χ²(10)
critical value. Empirically, J ≈ 314,000 in our setting, which is a
factor of 1.7×10^4 above the χ²(10) critical value of 18.3.

Conventional applied-IO practice in large-N panel BLP settings (e.g.,
Backus--Conlon--Sinkinson 2021, Grieco--Murry--Yurukoglu 2024) is to
treat Hansen J as uninformative when N is very large and rely on
first-stage strength and economic argument for instrument validity. We
follow that convention: the first-stage F-statistics in
Table~\\ref{tab:iv} are the primary instrument-strength diagnostic.

No table or output is produced by this script.
"""
print("This script is documentation-only — see source.")
