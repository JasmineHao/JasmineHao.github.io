"""
9_9_shapley_waterfall_fig.py
============================
Waterfall chart for the 2015 → 2024 Shapley decomposition.
Reads:  output/decomp_s4_final_byyear_2024/shapley_decomposition.csv
Writes: report/memos/fig_shapley_waterfall_2024_2026_06_15.png/.pdf
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = ["Arial Unicode MS", "DejaVu Sans"]
import matplotlib.pyplot as plt

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT  = f"{ROOT}/report/memos"
os.makedirs(OUT, exist_ok=True)

BLOCKS = ["A_attrs", "Entry_qty", "Battery", "xi", "Subsidy", "Income"]
# Paper-facing names matching the six table terms.
LABELS = {
    "A_attrs":   "Quality",
    "Entry_qty": "Variety",
    "Battery":   "Battery",
    "xi":        "Residual",
    "Subsidy":   "Subsidy",
    "Income":    "Market",
}
COLORS = {
    "A_attrs":   "#1f77b4",
    "Entry_qty": "#ff7f0e",
    "Battery":   "#2ca02c",
    "xi":        "#9467bd",
    "Subsidy":   "#d62728",
    "Income":    "#8c564b",
}

csv_all  = pd.read_csv(f"{ROOT}/output/decomp_s4_final_byyear_2024/shapley_decomposition.csv")
sh       = csv_all[~csv_all["block"].isin(["BASELINE", "FINAL"])]
phi      = {b: float(sh[sh["block"] == b]["shapley_ev_share"].values[0]) for b in BLOCKS}

# Use the model's own BASELINE and FINAL so Σφ = obs_delta exactly
lev_base  = float(csv_all[csv_all["block"] == "BASELINE"]["level_ev_share"].values[0])
lev_final = float(csv_all[csv_all["block"] == "FINAL"]["level_ev_share"].values[0])
obs_delta = lev_final - lev_base   # = Σφ by construction

# Sort: positive blocks largest-first, then negative blocks most-negative-first
blocks_pos = sorted([b for b in BLOCKS if phi[b] > 0], key=lambda b: -phi[b])
blocks_neg = sorted([b for b in BLOCKS if phi[b] < 0], key=lambda b:  phi[b])
ordered    = blocks_pos + blocks_neg

x_labels = ["2015\nbaseline"] + [LABELS[b] for b in ordered] + ["2024\n(model)"]
N  = len(x_labels)
xs = np.arange(N)

running     = 0.0
bar_bottoms = []
bar_heights = []
bar_colors  = []
bar_hatches = []

# Baseline placeholder bar
bar_bottoms.append(0.0); bar_heights.append(0.0)
bar_colors.append("white"); bar_hatches.append("")

for b in ordered:
    v = phi[b]
    if v >= 0:
        bar_bottoms.append(running)
        bar_heights.append(v)
    else:
        bar_bottoms.append(running + v)
        bar_heights.append(-v)
    bar_colors.append(COLORS[b])
    bar_hatches.append("" if v >= 0 else "///")
    running += v

# Final bar (total Σϕ from 0)
bar_bottoms.append(0.0)
bar_heights.append(running)
bar_colors.append("#444444")
bar_hatches.append("")

fig, ax = plt.subplots(figsize=(11, 5.8))

for i, (bot, h, c, hat) in enumerate(
        zip(bar_bottoms, bar_heights, bar_colors, bar_hatches)):
    ec = "black" if i in (0, N - 1) else "none"
    lw = 0.9 if i in (0, N - 1) else 0
    ax.bar(i, h, bottom=bot, color=c, edgecolor=ec, linewidth=lw,
           hatch=hat, alpha=0.85, width=0.68)

    # Value labels — % units, no plus sign
    if i == 0:
        ax.text(i, 0.006, f"2015 = {lev_base*100:.2f}%",
                ha="center", va="bottom", fontsize=10, color="#333")
    elif i == N - 1:
        ax.text(i, running + 0.006,
                f"{running*100:.1f}%\n(2024 = {lev_final*100:.2f}%)",
                ha="center", va="bottom", fontsize=12, weight="bold")
    else:
        v = phi[ordered[i - 1]]
        ypos = bot + h + 0.005 if v >= 0 else bot - 0.005
        va   = "bottom"        if v >= 0 else "top"
        ax.text(i, ypos, f"{v*100:.1f}%",
                ha="center", va=va, fontsize=12)

# Reference line at the closed endpoint (= Σφ = FINAL − BASELINE)
ax.axhline(obs_delta, color="black", linestyle="--", linewidth=1.4,
           label=f"$\\Delta$ EV share 2015$\\to$2024 = {obs_delta*100:.2f}%")

# Waterfall connector lines
run = 0.0
for i, b in enumerate(ordered, start=1):
    ax.plot([i - 1 + 0.34, i - 0.34], [run, run],
            color="gray", linewidth=0.7, linestyle=":")
    run += phi[b]
ax.plot([N - 2 + 0.34, N - 1 - 0.34], [run, run],
        color="gray", linewidth=0.7, linestyle=":")

ax.axhline(0, color="black", linewidth=0.6)
ax.set_xticks(xs)
ax.set_xticklabels(x_labels, fontsize=12)
ax.set_ylabel(r"EV-share change vs 2015 (%)", fontsize=12)
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"{x*100:.0f}%"))
ax.spines[["top", "right"]].set_visible(False)
ax.grid(axis="y", lw=0.5, alpha=0.3, color="gray")
ax.tick_params(labelsize=11)
ax.legend(loc="upper left", fontsize=11, frameon=True)

ax.text(0.99, 0.03,
        "Solid fill = positive contribution\nHatching = negative drag",
        transform=ax.transAxes, ha="right", va="bottom", fontsize=10,
        bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#ccc", lw=0.5))

plt.tight_layout()
out_png = f"{OUT}/fig_shapley_waterfall_2024_2026_06_15.png"
out_pdf = f"{OUT}/fig_shapley_waterfall_2024_2026_06_15.pdf"
fig.savefig(out_png, dpi=200, bbox_inches="tight")
fig.savefig(out_pdf, bbox_inches="tight")
print(f"Saved → {out_png}")
print(f"Saved → {out_pdf}")
