"""
_plot_style.py
===============
Shared matplotlib style for the "Heterogeneous Diffusion" paper figures.

Clean, QJE/AER-style formatting mimicking Grieco, Murry & Yurukoglu (2023
QJE) on US automobile market power: muted colour palette, serif font,
minimal spines, tight captions, consistent bar heights.

Usage:
    from _plot_style import (apply_style, BLOCK_COLORS, BLOCK_SHORT,
                             BLOCK_LABELS, clean_ax)
    apply_style()
    ...
    clean_ax(ax)
"""
from __future__ import annotations
import matplotlib as mpl


def apply_style() -> None:
    """Apply global rcParams."""
    mpl.rcParams.update({
        "font.family":       "serif",
        "font.serif":        ["Times New Roman", "Times", "DejaVu Serif"],
        "mathtext.fontset":  "stix",
        "font.size":         10,
        "axes.titlesize":    11,
        "axes.labelsize":    10,
        "axes.titleweight":  "normal",
        "axes.labelweight":  "normal",
        "axes.linewidth":    0.8,
        "axes.edgecolor":    "#333333",
        "axes.titlepad":     8,
        "xtick.labelsize":   9,
        "ytick.labelsize":   9,
        "legend.fontsize":   9,
        "legend.frameon":    False,
        "figure.dpi":        120,
        "savefig.dpi":       300,
        "savefig.bbox":      "tight",
        "savefig.facecolor": "white",
        "axes.facecolor":    "white",
        "figure.facecolor":  "white",
        "axes.spines.top":   False,
        "axes.spines.right": False,
        "axes.grid":         True,
        "axes.axisbelow":    True,
        "grid.color":        "#DDDDDD",
        "grid.linewidth":    0.6,
        "grid.linestyle":    "-",
    })


# Block colour palette — muted Tableau-10 inspired, with the two
# emphasis blocks (Subsidy and Entry_set/Entry_demand) taking the three
# most saturated hues. Colours are grouped by block family so a reader
# can infer the broad category from the hue: blues/greens for supply-side
# product channels, lavender/tan for macro/policy, red for the Subsidy
# emphasis block, navy/teal for the two Entry blocks, mustard/grey for
# the residual EV-time and BrandShock blocks.
BLOCK_COLORS = {
    "A_nonbat":              "#6B93C0",   # muted steel-blue      (supply: non-battery)
    "A_bat":                 "#7FB069",   # muted green           (supply: battery)
    "D_env":                 "#9E8FB2",   # muted lavender        (demand env: macro+policy)
    "Subsidy":               "#B23A48",   # brick red (emphasis)  (policy: subsidy)
    "Entry_set":             "#1F4E79",   # deep navy (emphasis)  (entry: product set)
    "Entry_demand":          "#2E8A8A",   # deep teal (emphasis)  (entry: demand env)
    "Consumer_Composition":  "#2E8A8A",   # alias of Entry_demand
    "EV_trend":              "#8C8C8C",   # neutral grey          (residual: ev_time + xi)
    "Brand_trajectory":      "#D9B96E",   # mustard               (national brand drift)
    "Local_Competition":     "#C76E6E",   # warm rust             (geographic stronghold)
    "Brand_cost_trajectory": "#5BA199",   # muted teal-green      (firm cost productivity)
    # Legacy 9-block aliases kept for backward compatibility.
    "D_macro":      "#9E8FB2",
    "Policy":       "#C3A38A",
    "EV_time":      "#D9B96E",
    "BrandShock":   "#8C8C8C",
    "Entry":        "#1F4E79",
}

# Short labels (for axis tick labels — keep them concise)
BLOCK_SHORT = {
    "A_nonbat":              r"$A_\mathrm{nonbat}$",
    "A_bat":                 r"$A_\mathrm{bat}$",
    "D_env":                 r"$D_\mathrm{env}$",
    "Subsidy":               "Subsidy",
    "Entry_set":             r"Entry$_\mathrm{set}$",
    "Entry_demand":          r"Entry$_\mathrm{demand}$",
    "Consumer_Composition":  r"Cons.$_\mathrm{comp}$",
    "EV_trend":              "EV trend",
    "Brand_trajectory":      r"Brand$_\mathrm{traj}$",
    "Local_Competition":     r"Local$_\mathrm{comp}$",
    "Brand_cost_trajectory": r"Brand$_\mathrm{cost}$",
    "Entry":                 "Entry",
    # legacy 9-block aliases
    "D_macro":      r"$D_\mathrm{macro}$",
    "Policy":       "Policy",
    "EV_time":      "EV time",
    "BrandShock":   "BrandShock",
}

# Long labels (for legends or standalone figures)
BLOCK_LABELS = {
    "A_nonbat":              "Non-battery attributes",
    "A_bat":                 "Battery learning",
    "D_env":                 "Demand env. (macro + policy)",
    "Subsidy":               "Direct purchase subsidy",
    "Entry_set":             "Product entry (set only)",
    "Entry_demand":          "City demand growth",
    "Consumer_Composition":  "City demand growth (pop + income)",
    "EV_trend":              "EV unobserved trend residual",
    "Brand_trajectory":      "Brand × Year ξ_blp (national brand drift)",
    "Local_Competition":     "Brand × City × Year ξ_blp (geographic stronghold)",
    "Brand_cost_trajectory": "Brand × Year ξ_mc (firm cost productivity)",
    "Entry":                 "Product entry",
    # legacy 9-block aliases
    "D_macro":      "Demand-environment macros",
    "Policy":       "Non-subsidy policy",
    "EV_time":      "Year-specific EV taste",
    "BrandShock":   "Residual brand drift",
}

# Canonical order for the 10-block decomposition (May 2026):
# supply attributes → cost productivity → demand env → subsidy → unobserved trends → entry.
BLOCK_ORDER = ["A_nonbat", "A_bat", "Brand_cost_trajectory",
               "D_env", "Subsidy",
               "EV_trend", "Brand_trajectory", "Local_Competition",
               "Entry_set", "Consumer_Composition"]

# Tier / firm / segment palette (qualitative, for non-block dimensions)
TIER_COLORS = {
    "Tier 1":     "#1F4E79",
    "New Tier 1": "#5A8DB0",
    "Tier 2":     "#9BB8D0",
    "Rest":       "#B23A48",
}


def clean_ax(ax, *, keep_left: bool = True, keep_bottom: bool = True) -> None:
    """Strip top/right spines; thin remaining spines; subtle x grid only."""
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    if not keep_left:
        ax.spines["left"].set_visible(False)
    if not keep_bottom:
        ax.spines["bottom"].set_visible(False)
    ax.tick_params(axis="both", which="both", length=3, width=0.6,
                   color="#333333", direction="out")
    ax.grid(axis="x", color="#E5E5E5", linewidth=0.6, linestyle="-")
    ax.grid(axis="y", visible=False)
    ax.set_axisbelow(True)
