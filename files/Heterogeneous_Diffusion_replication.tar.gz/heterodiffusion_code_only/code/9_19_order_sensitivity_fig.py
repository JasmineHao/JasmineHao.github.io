r"""
9_19_order_sensitivity_fig.py
==============================
Three-panel year-by-year cumulative stacked area:
  (A) Sequential: Entry_qty ordered first
  (B) Sequential: Entry_qty ordered last
  (C) Shapley value (average over all orderings)

For each year Y, the sequential contribution of block b is computed from
coalition_results.csv for year Y vs 2015 baseline, under the given ordering.
The Shapley panel reads from shapley_decomposition.csv.

Output: report/memos/fig_order_sensitivity.pdf/.png
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = ["Arial Unicode MS", "DejaVu Sans"]
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT  = f"{ROOT}/report/memos"
os.makedirs(OUT, exist_ok=True)

YEARS  = list(range(2016, 2025))
BLOCKS = ["A_attrs", "Entry_qty", "Battery", "xi", "Subsidy", "Income"]

SEQ_A = ["Entry_qty", "A_attrs", "Battery", "Subsidy", "xi", "Income"]
SEQ_B = ["A_attrs",   "Battery", "Subsidy", "xi",     "Income", "Entry_qty"]

LABELS = {
    "A_attrs":   r"$A_\mathrm{attrs}$",
    "Entry_qty": r"Entry$_\mathrm{qty}$",
    "Battery":   "Battery (Wright)",
    "xi":        r"$\xi$ demand",
    "Subsidy":   "Subsidy",
    "Income":    "Income",
}
COLORS = {
    "A_attrs":   "#1f77b4",
    "Entry_qty": "#ff7f0e",
    "Battery":   "#2ca02c",
    "xi":        "#9467bd",
    "Subsidy":   "#d62728",
    "Income":    "#8c564b",
}

# ── Sequential decomposition for year yr under a given ordering ───────────────
def seq_decomp_yr(yr, ordering):
    csv = f"{ROOT}/output/decomp_s4_final_byyear_{yr}/coalition_results.csv"
    df_c = pd.read_csv(csv)
    df_c["cset"] = df_c["coalition"].str.strip("{}").apply(
        lambda x: frozenset(x.split(",")) if x.strip() else frozenset())

    def ev_s(blocks):
        mask = df_c["cset"] == frozenset(blocks)
        return float(df_c.loc[mask, "ev_share"].iloc[0])

    prev, result = [], {}
    for b in ordering:
        curr = prev + [b]
        result[b] = ev_s(curr) - ev_s(prev)
        prev = curr
    result["_total"] = ev_s(ALL := list(ordering)) - ev_s([])
    return result

# ── Build per-scenario DataFrames ─────────────────────────────────────────────
yrs_full = [2015] + YEARS

def build_df(ordering=None, use_shapley=False):
    rows = []
    for yr in YEARS:
        if use_shapley:
            csv_sh = f"{ROOT}/output/decomp_s4_final_byyear_{yr}/shapley_decomposition.csv"
            df_sh  = pd.read_csv(csv_sh)
            df_sh  = df_sh[~df_sh["block"].isin(["BASELINE", "FINAL"])]
            rec    = {"year": yr}
            for b in BLOCKS:
                v = df_sh[df_sh["block"] == b]["shapley_ev_share"]
                rec[b] = float(v.values[0]) if len(v) else 0.0
            rec["_total"] = float(df_sh["shapley_ev_share"].sum())
        else:
            phi = seq_decomp_yr(yr, ordering)
            rec = {"year": yr}
            for b in BLOCKS:
                rec[b] = phi.get(b, 0.0)
            rec["_total"] = phi["_total"]
        rows.append(rec)

    df = pd.DataFrame(rows).set_index("year")
    _zero = {b: 0.0 for b in BLOCKS}
    _zero["_total"] = 0.0
    return pd.concat([pd.DataFrame([_zero], index=[2015]), df]).sort_index()

df_A  = build_df(ordering=SEQ_A)
df_B  = build_df(ordering=SEQ_B)
df_SH = build_df(use_shapley=True)

# ── Observed Delta EV share ────────────────────────────────────────────────────
df_raw = pd.read_parquet(f"{ROOT}/output/df.parquet")
df_raw["ev"] = df_raw["FuelType"].isin(["BEV", "PHEV", "REEV"]).astype(int)

def obs_share(yr):
    s = df_raw[df_raw["Year"] == yr]
    M = s["Population"] * 10000 / 2.62 / 5
    return float((s["shares"] * M * s["ev"]).sum() / (s["shares"] * M).sum())

obs_2015  = obs_share(2015)
obs_delta = np.array([obs_share(y) - obs_2015 for y in yrs_full])
yrs       = np.array(yrs_full)

# ── Stacked band builder ───────────────────────────────────────────────────────
def make_bands(df):
    pos_top = np.zeros(len(yrs))
    neg_bot = np.zeros(len(yrs))
    pos_b, neg_b = [], []
    for b in BLOCKS:
        v     = df[b].values
        pos_v = np.where(v > 0, v, 0.0)
        neg_v = np.where(v < 0, v, 0.0)
        if pos_v.any():
            pos_b.append((b, pos_top.copy(), pos_top + pos_v))
            pos_top = pos_top + pos_v
        if neg_v.any():
            neg_b.append((b, neg_bot.copy(), neg_bot + neg_v))
            neg_bot = neg_bot + neg_v
    return pos_b, neg_b

# ── Draw one panel ─────────────────────────────────────────────────────────────
def draw_panel(ax, df, title, panel_letter="", show_legend=False, show_ylabel=False):
    pos_bands, neg_bands = make_bands(df)

    for b, lo, hi in pos_bands:
        ax.fill_between(yrs, lo, hi, color=COLORS[b], alpha=0.82, linewidth=0)
    for b, lo, hi in neg_bands:
        ax.fill_between(yrs, lo, hi, color=COLORS[b], alpha=0.82,
                        linewidth=0, hatch="///")

    ax.plot(yrs, obs_delta, color="black", lw=2.4, marker="o", ms=5.5,
            markerfacecolor="white", markeredgewidth=1.8, zorder=6)
    ax.plot(yrs, df["_total"].values, color="gray", lw=1.3,
            linestyle="--", marker="d", ms=4.5, zorder=5)

    ax.axhline(0, color="black", linewidth=0.6)
    ax.set_xlim(2015, 2024)
    ax.set_xticks(yrs_full)
    ax.set_xticklabels([str(y) for y in yrs_full],
                       fontsize=11, rotation=35, ha="right")
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"{x*100:.0f}%"))
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", lw=0.5, alpha=0.3, color="gray")
    ax.tick_params(labelsize=11)

    if show_ylabel:
        ax.set_ylabel(r"Cumulative contribution to $\Delta$ EV share vs 2015 (%)",
                      fontsize=12)

    # Panel letter (only if provided)
    if panel_letter:
        ax.text(0.03, 0.98, f"({panel_letter})", transform=ax.transAxes,
                fontsize=12, fontweight="bold", va="top", ha="left")

    if show_legend:
        handles = []
        for b in BLOCKS:
            neg = df.loc[2024, b] < 0
            handles.append(mpatches.Patch(
                fc=COLORS[b], alpha=0.82, hatch="///" if neg else "",
                label=LABELS[b]))
        handles.append(Line2D([0], [0], color="black", lw=2.2, marker="o", ms=5,
                               markerfacecolor="white", markeredgewidth=1.6,
                               label="Observed $\\Delta$ share"))
        handles.append(Line2D([0], [0], color="gray", lw=1.2, linestyle="--",
                               marker="d", ms=4, label="$\\Sigma_b\\,\\phi_b$"))
        ax.legend(handles=handles, fontsize=9.5, frameon=True, loc="upper left",
                  ncol=1, handlelength=1.5, labelspacing=0.45, borderpad=0.7)

# ── Layout ─────────────────────────────────────────────────────────────────────
fig, (ax_A, ax_B, ax_SH) = plt.subplots(
    1, 3, figsize=(18, 5.2),
    constrained_layout=True,
    gridspec_kw={"wspace": 0.08})

draw_panel(ax_A,  df_A,  r"(A) Sequential: Entry$_{qty}$ first",
           "A", show_legend=True, show_ylabel=True)
draw_panel(ax_B,  df_B,  r"(B) Sequential: Entry$_{qty}$ last",
           "B", show_legend=False, show_ylabel=False)
draw_panel(ax_SH, df_SH, "(C) Shapley value (avg over all orderings)",
           "C", show_legend=False, show_ylabel=False)

# Align y-axis across all three panels
_ylo = min(ax.get_ylim()[0] for ax in (ax_A, ax_B, ax_SH))
_yhi = max(ax.get_ylim()[1] for ax in (ax_A, ax_B, ax_SH))
for ax in (ax_A, ax_B, ax_SH):
    ax.set_ylim(_ylo, _yhi)

for ext in ("png", "pdf"):
    fp = f"{OUT}/fig_order_sensitivity.{ext}"
    fig.savefig(fp, dpi=200 if ext == "png" else 72, bbox_inches="tight")
    print(f"Saved -> {fp}")

# ── Save individual panels ─────────────────────────────────────────────────────
_indiv_specs = [
    ("seqA",    df_A,  True,  True),
    ("seqB",    df_B,  False, False),
    ("shapley", df_SH, False, False),
]
for tag, df_p, show_leg, show_yl in _indiv_specs:
    fig_p, ax_p = plt.subplots(1, 1, figsize=(6.5, 5.0), constrained_layout=True)
    draw_panel(ax_p, df_p, "", panel_letter="",
               show_legend=show_leg, show_ylabel=show_yl)
    for ext in ("png", "pdf"):
        fp = f"{OUT}/fig_order_sensitivity_{tag}.{ext}"
        fig_p.savefig(fp, dpi=200 if ext == "png" else 72, bbox_inches="tight")
        print(f"Saved -> {fp}")
    plt.close(fig_p)
