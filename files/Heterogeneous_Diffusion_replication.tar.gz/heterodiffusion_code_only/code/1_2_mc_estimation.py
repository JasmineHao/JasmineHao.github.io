"""
1_2_mc_estimation.py
====================

Stage 1-2: Marginal cost estimation.  Runs after 1_1_blp.py.

Steps (in sequence):
  A. Rebuild total_subsidy_wan in df.parquet from the official NEV schedule.
  B. Back out mc_true_v33_sticker.parquet  (sticker-space Bertrand FOC).
  C. Rebuild mc_decomposed.parquet         (char / battery / FE decomposition
                                            used by Wright's Law in Stage 3-1).

Outputs written to output/:
    df.parquet                   (subsidy column refreshed)
    mc_true_v33_sticker.parquet
    mc_decomposed.parquet

Run:
    python3 code/1_2_mc_estimation.py
"""
import subprocess, sys, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CODE = os.path.join(ROOT, "code")


def run(script, label):
    print(f"\n{'─'*70}")
    print(f"  {label}")
    print(f"{'─'*70}")
    subprocess.run([sys.executable, os.path.join(CODE, script)], check=True)


print("=" * 70)
print("MC ESTIMATION  (Stage 1-2)")
print("=" * 70)

run("_rebuild_subsidy.py",       "A. Rebuild subsidy schedule in df.parquet")
run("_regen_mc_v33_sticker.py",  "B. Back out mc_true_v33_sticker.parquet")
run("_rebuild_mc_decomposed.py", "C. Rebuild mc_decomposed.parquet")

print("\n" + "=" * 70)
print("Stage 1-2 complete.")
print("=" * 70)
