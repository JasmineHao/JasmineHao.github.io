"""
9_6_dynamic_quantity_fig.py
============================
Decompose the subsidy counterfactual on EV QUANTITY (not penetration rate).

Panel A: EV quantity trajectory — actual vs no_subsidy (canonical endo_endo)
         Key annotation: 2024 no_subsidy ≈ 2021 actual → 3-year delay

Panel B: 2024 EV quantity by regime × scenario
         Shows how dynamic channels (learning, entry/exit) amplify the loss
         in the no_subsidy counterfactual
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = ["Arial Unicode MS", "DejaVu Sans"]
import matplotlib.pyplot as plt

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT  = f"{ROOT}/report/memos"
OVERLEAF = "/Users/jasminehao/Dropbox/Apps/Overleaf/heterogenous_diffusion/figures"
os.makedirs(OUT, exist_ok=True)

agg = pd.read_csv(f"{ROOT}/output/dynamic_sim_v33_aggregated.csv")

REGIME_LABELS = {
    "endo_endo": "Full Dynamic\n(+ entry/exit + learning)",
    "exog_endo": "+ Learning only\n(fixed products)",
    "exog_exog": "Static\n(fixed products, fixed costs)",
}
REGIME_ORDER  = ["exog_exog", "exog_endo", "endo_endo"]
REGIME_COLORS = {
    "endo_endo": "#2166ac",
    "exog_endo": "#4dac26",
    "exog_exog": "#d6604d",
}

YEARS = list(range(2015, 2025))

def get(regime, scenario, col="ev_q_mean"):
    sub = agg[(agg["regime"] == regime) & (agg["scenario"] == scenario)]
    return sub.set_index("Year")[col].reindex(YEARS, fill_value=0)

def getstd(regime, scenario):
    return get(regime, scenario, col="ev_q_std")


# ── Panel A: quantity trajectory ───────────────────────────────────────────────
def draw_panel_A(ax):
    q_act = get("endo_endo", "actual") / 1e6
    s_act = getstd("endo_endo", "actual") / 1e6
    ax.plot(YEARS, q_act, color="#1a1a1a", lw=2.5, marker="o", ms=4.5,
            label="Actual (with subsidies)", zorder=5)
    ax.fill_between(YEARS, q_act - s_act, q_act + s_act,
                    color="#1a1a1a", alpha=0.10, zorder=3)

    q_nos = get("endo_endo", "no_subsidy") / 1e6
    s_nos = getstd("endo_endo", "no_subsidy") / 1e6
    ax.plot(YEARS, q_nos, color="#d6604d", lw=2.5, marker="o", ms=4.5,
            ls="--", label="No-subsidy counterfactual", zorder=5)
    ax.fill_between(YEARS, q_nos - s_nos, q_nos + s_nos,
                    color="#d6604d", alpha=0.10, zorder=3)

    ax.fill_between(YEARS, q_nos, q_act, color="#2166ac", alpha=0.08, zorder=2,
                    label="Subsidy effect")

    ax.annotate("",
                xy=(2021, float(q_act.loc[2021])),
                xytext=(2024, float(q_nos.loc[2024])),
                arrowprops=dict(arrowstyle="<->", color="#555", lw=1.2))
    ax.text(2022.6, (float(q_act.loc[2021]) + float(q_nos.loc[2024])) / 2 + 0.05,
            "~3-year\ndelay",
            fontsize=8, color="#555", ha="center", va="bottom",
            bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="#ccc", lw=0.6, alpha=0.9))

    ax.text(2024.1, float(q_act.loc[2024]) + 0.05,
            f"{float(q_act.loc[2024]):.1f}M", fontsize=8, color="#1a1a1a", va="bottom")
    ax.text(2024.1, float(q_nos.loc[2024]) - 0.05,
            f"{float(q_nos.loc[2024]):.1f}M", fontsize=8, color="#d6604d", va="top")

    ax.set_xlim(2015, 2024)
    ax.margins(x=0)
    ax.set_xticks(YEARS)
    ax.set_xticklabels([str(y) for y in YEARS], fontsize=8.5, rotation=30, ha="right")
    ax.set_ylim(bottom=0)
    ax.set_ylabel("EV Quantity Sold (millions)", fontsize=10)
    ax.legend(fontsize=8.5, frameon=False, loc="upper left")
    ax.spines[["top", "right"]].set_visible(False)
    ax.tick_params(labelsize=8.5)
    ax.grid(axis="y", lw=0.5, alpha=0.3, color="gray")


# ── Panel B: 2024 no-subsidy by regime ────────────────────────────────────────
def draw_panel_B(ax):
    yr = 2024
    actual_q = float(get("endo_endo", "actual").loc[yr]) / 1e6
    vals_nos  = {r: float(get(r, "no_subsidy").loc[yr]) / 1e6 for r in REGIME_ORDER}

    x = np.arange(len(REGIME_ORDER))
    w = 0.45

    bars_nos = ax.bar(x, [vals_nos[r] for r in REGIME_ORDER], width=w,
                      color=[REGIME_COLORS[r] for r in REGIME_ORDER],
                      alpha=0.80, linewidth=0)

    ax.axhline(actual_q, color="#1a1a1a", lw=2.0, ls="-", zorder=5)
    ax.text(len(REGIME_ORDER) - 0.5 - w/2 - 0.08, actual_q + 0.15,
            f"Actual: {actual_q:.1f}M", fontsize=8.5, color="#1a1a1a",
            ha="right", va="bottom", fontweight="bold")

    y_xx = vals_nos["exog_exog"]
    y_xe = vals_nos["exog_endo"]
    y_ee = vals_nos["endo_endo"]

    ax.annotate("", xy=(x[1], y_xe + 0.05), xytext=(x[0], y_xx - 0.05),
                arrowprops=dict(arrowstyle="->", color="#555", lw=1.3))
    ax.text((x[0] + x[1]) / 2 - 0.05, (y_xx + y_xe) / 2 + 0.15,
            f"−{y_xx - y_xe:.2f}M\n(learning)", fontsize=7.5, color="#444",
            ha="center", va="bottom")

    ax.annotate("", xy=(x[2], y_ee + 0.05), xytext=(x[1], y_xe - 0.05),
                arrowprops=dict(arrowstyle="->", color="#555", lw=1.3))
    ax.text((x[1] + x[2]) / 2 - 0.05, (y_xe + y_ee) / 2 + 0.15,
            f"−{y_xe - y_ee:.2f}M\n(entry/exit)", fontsize=7.5, color="#444",
            ha="center", va="bottom")

    for bar, v in zip(bars_nos, [vals_nos[r] for r in REGIME_ORDER]):
        ax.text(bar.get_x() + bar.get_width()/2, v + 0.08,
                f"{v:.1f}M", ha="center", va="bottom", fontsize=8.5, fontweight="bold")

    ax.set_xticks(x)
    ax.set_xticklabels([REGIME_LABELS[r] for r in REGIME_ORDER], fontsize=7.8)
    ax.set_ylim(0, actual_q * 1.35)
    ax.set_ylabel("EV Quantity in 2024 (millions)", fontsize=10)
    ax.spines[["top", "right"]].set_visible(False)
    ax.tick_params(labelsize=8.5)
    ax.grid(axis="y", lw=0.5, alpha=0.3, color="gray")


# ── Combined figure ────────────────────────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(13, 4.5),
                         gridspec_kw={"wspace": 0.38, "width_ratios": [1.5, 1]})
draw_panel_A(axes[0])
draw_panel_B(axes[1])

for ext in ("png", "pdf"):
    fp = f"{OUT}/fig_dynamic_quantity.{ext}"
    fig.savefig(fp, bbox_inches="tight", dpi=200 if ext == "png" else 72)
    print(f"Saved -> {fp}")
plt.close(fig)

# ── Individual panel saves ─────────────────────────────────────────────────────
fig_a, ax_a = plt.subplots(figsize=(7.5, 4.5), constrained_layout=True)
draw_panel_A(ax_a)
for ext in ("png", "pdf"):
    fp = f"{OUT}/fig_dynamic_quantity_path.{ext}"
    fig_a.savefig(fp, bbox_inches="tight", dpi=200 if ext == "png" else 72)
    print(f"Saved -> {fp}")
fig_a.savefig(f"{OVERLEAF}/fig_dynamic_quantity_path.png", dpi=200, bbox_inches="tight")
plt.close(fig_a)

fig_b, ax_b = plt.subplots(figsize=(5.5, 4.5), constrained_layout=True)
draw_panel_B(ax_b)
for ext in ("png", "pdf"):
    fp = f"{OUT}/fig_dynamic_quantity_channels.{ext}"
    fig_b.savefig(fp, bbox_inches="tight", dpi=200 if ext == "png" else 72)
    print(f"Saved -> {fp}")
fig_b.savefig(f"{OVERLEAF}/fig_dynamic_quantity_channels.png", dpi=200, bbox_inches="tight")
plt.close(fig_b)
