r"""
9_18_shapley_cumulative_combined_fig.py
========================================
Side-by-side cumulative Shapley decomposition:
  Left:  EV market share (pp vs 2015)
  Right: EV quantity (millions of vehicles vs 2015)

Designed as one full-page-width figure so the legend is readable
when included at \linewidth in the paper.

Output: report/memos/fig_shapley_cumulative_combined.pdf/.png
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = ["Arial Unicode MS", "DejaVu Sans"]
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT  = f"{ROOT}/report/memos"
os.makedirs(OUT, exist_ok=True)

YEARS  = list(range(2016, 2025))
BLOCKS = ["A_attrs", "Entry_qty", "Battery", "xi", "Subsidy", "Income"]
LABELS = {
    "A_attrs":   r"$A_\mathrm{attrs}$",
    "Entry_qty": r"Entry$_\mathrm{qty}$",
    "Battery":   "Battery (Wright)",
    "xi":        r"$\xi$ demand",
    "Subsidy":   "Subsidy",
    "Income":    "Income",
}
COLORS = {
    "A_attrs":   "#1f77b4",
    "Entry_qty": "#ff7f0e",
    "Battery":   "#2ca02c",
    "xi":        "#9467bd",
    "Subsidy":   "#d62728",
    "Income":    "#8c564b",
}

M_PER_ROW = 21220

# ── Raw data ──────────────────────────────────────────────────────────────────
df_raw = pd.read_parquet(f"{ROOT}/output/df.parquet")
df_raw["sales"] = df_raw["shares"] * df_raw["Population"]
df_raw["ev"]    = df_raw["FuelType"].isin(["BEV", "PHEV", "REEV"]).astype(int)
total_sales_yr  = (df_raw.groupby("Year")["sales"].sum() * M_PER_ROW / 1e6).to_dict()

# ── Read Shapley per year ──────────────────────────────────────────────────────
yrs_full = [2015] + YEARS
rows = []
for yr in YEARS:
    csv = f"{ROOT}/output/decomp_s4_final_byyear_{yr}/shapley_decomposition.csv"
    if not os.path.exists(csv):
        print(f"missing: {csv}"); continue
    df_sh = pd.read_csv(csv)
    df_sh = df_sh[~df_sh["block"].isin(["BASELINE", "FINAL"])]
    M_yr  = total_sales_yr.get(yr, total_sales_yr[2024])
    rec   = {"year": yr, "M_yr": M_yr}
    for b in BLOCKS:
        v = df_sh[df_sh["block"] == b]["shapley_ev_share"]
        phi = float(v.values[0]) if len(v) else 0.0
        rec[b]           = phi        # share contribution
        rec[b + "_qty"]  = phi * M_yr # qty contribution (millions)
    rec["sum_share"] = float(df_sh["shapley_ev_share"].sum())
    rec["sum_qty"]   = rec["sum_share"] * M_yr
    rows.append(rec)

df = pd.DataFrame(rows).set_index("year")
_zero = {b: 0.0 for b in BLOCKS}
for b in BLOCKS:
    _zero[b + "_qty"] = 0.0
_zero.update({"sum_share": 0.0, "sum_qty": 0.0,
              "M_yr": total_sales_yr.get(2015, total_sales_yr[2015])})
df = pd.concat([pd.DataFrame([_zero], index=[2015]), df]).sort_index()

# ── Observed trajectories ─────────────────────────────────────────────────────
def obs_share(yr):
    s = df_raw[df_raw["Year"] == yr]
    M = s["Population"] * 10000 / 2.62 / 5
    return float((s["shares"] * M * s["ev"]).sum() / (s["shares"] * M).sum())

def obs_ev_qty(yr):
    s = df_raw[df_raw["Year"] == yr]
    return float((s["ev"] * s["sales"]).sum()) * M_PER_ROW / 1e6

obs_2015      = obs_share(2015)
obs_qty_2015  = obs_ev_qty(2015)
obs_d_share   = np.array([obs_share(y)   - obs_2015     for y in yrs_full])
obs_d_qty     = np.array([obs_ev_qty(y)  - obs_qty_2015 for y in yrs_full])

yrs = np.array(yrs_full)

# ── Build stacked bands for one data column ───────────────────────────────────
def make_bands(col_suffix=""):
    pos_top = np.zeros(len(yrs))
    neg_bot = np.zeros(len(yrs))
    pos_b, neg_b = [], []
    for b in BLOCKS:
        key = b + col_suffix
        v     = df[key].values
        pos_v = np.where(v > 0, v, 0.0)
        neg_v = np.where(v < 0, v, 0.0)
        if pos_v.any():
            pos_b.append((b, pos_top.copy(), pos_top + pos_v))
            pos_top = pos_top + pos_v
        if neg_v.any():
            neg_b.append((b, neg_bot.copy(), neg_bot + neg_v))
            neg_bot = neg_bot + neg_v
    return pos_b, neg_b

pos_share, neg_share = make_bands("")
pos_qty,   neg_qty   = make_bands("_qty")

# ── Legend handles (shared across both panels) ─────────────────────────────────
def make_legend_handles(col_suffix=""):
    handles = []
    for b in BLOCKS:
        key = b + col_suffix
        neg = df.loc[2024, key] < 0
        handles.append(mpatches.Patch(
            fc=COLORS[b], alpha=0.82, hatch="///" if neg else "",
            label=LABELS[b]))
    handles.append(Line2D([0], [0], color="black", lw=2.4, marker="o", ms=6,
                          markerfacecolor="white", markeredgewidth=1.8,
                          label="Observed $\\Delta$"))
    handles.append(Line2D([0], [0], color="gray", lw=1.4, linestyle="--",
                          marker="d", ms=5, label="$\\Sigma_b\\,\\phi_b$"))
    return handles

# ── Draw ──────────────────────────────────────────────────────────────────────
fig, (ax_s, ax_q) = plt.subplots(
    1, 2, figsize=(15, 5.5),
    constrained_layout=True,
    gridspec_kw={"wspace": 0.12})

def draw_panel(ax, pos_bands, neg_bands, obs_delta, sum_col,
               ylabel, fmt_fn, label_obs, panel_tag, panel_letter=""):
    for b, lo, hi in pos_bands:
        ax.fill_between(yrs, lo, hi, color=COLORS[b], alpha=0.82, linewidth=0)
    for b, lo, hi in neg_bands:
        ax.fill_between(yrs, lo, hi, color=COLORS[b], alpha=0.82,
                        linewidth=0, hatch="///")

    ax.plot(yrs, obs_delta, color="black", lw=2.5, marker="o", ms=6,
            markerfacecolor="white", markeredgewidth=1.8, zorder=6)
    ax.plot(yrs, df[sum_col].values, color="gray", lw=1.4,
            linestyle="--", marker="d", ms=5, zorder=5)

    ax.axhline(0, color="black", linewidth=0.6)
    ax.set_xlim(2015, 2024)
    ax.set_xticks(yrs_full)
    ax.set_xticklabels([str(y) for y in yrs_full],
                       fontsize=10, rotation=35, ha="right")
    ax.set_ylabel(ylabel, fontsize=11)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(fmt_fn))
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", lw=0.5, alpha=0.3, color="gray")
    ax.tick_params(labelsize=10)

    # Legend
    handles = make_legend_handles("" if panel_tag == "share" else "_qty")
    ax.legend(handles=handles, fontsize=10, frameon=True, loc="upper left",
              ncol=1, handlelength=1.6, labelspacing=0.55, borderpad=0.8,
              handletextpad=0.6)

    # Panel label (only if provided)
    if panel_letter:
        ax.text(0.03, 0.98, panel_letter,
                transform=ax.transAxes, fontsize=13, fontweight="bold",
                va="top", ha="left")

draw_panel(
    ax_s, pos_share, neg_share, obs_d_share, "sum_share",
    r"Cumulative contribution to $\Delta$ EV share vs 2015 (%)",
    lambda x, _: f"{x*100:.0f}%",
    "Observed $\\Delta$ share", "share", panel_letter="(A)")

draw_panel(
    ax_q, pos_qty, neg_qty, obs_d_qty, "sum_qty",
    r"Cumulative contribution to $\Delta$ EV quantity vs 2015 (million vehicles)",
    lambda x, _: f"{x:+.1f}M",
    "Observed $\\Delta$ qty", "qty", panel_letter="(B)")

for ext in ("png", "pdf"):
    fp = f"{OUT}/fig_shapley_cumulative_combined.{ext}"
    fig.savefig(fp, dpi=200 if ext == "png" else 72, bbox_inches="tight")
    print(f"Saved → {fp}")

# ── Save individual panels ─────────────────────────────────────────────────────
_panel_specs = [
    ("share", pos_share, neg_share, obs_d_share, "sum_share",
     r"Cumulative contribution to $\Delta$ EV share vs 2015 (%)",
     lambda x, _: f"{x*100:.0f}%", "Observed $\\Delta$ share"),
    ("qty",   pos_qty,   neg_qty,   obs_d_qty,   "sum_qty",
     r"Cumulative contribution to $\Delta$ EV quantity vs 2015 (million vehicles)",
     lambda x, _: f"{x:+.1f}M",     "Observed $\\Delta$ qty"),
]
for tag, pb, nb, od, sc, yl, ff, lo in _panel_specs:
    fig_p, ax_p = plt.subplots(1, 1, figsize=(7.5, 5.5), constrained_layout=True)
    draw_panel(ax_p, pb, nb, od, sc, yl, ff, lo, tag, panel_letter="")
    for ext in ("png", "pdf"):
        fp = f"{OUT}/fig_shapley_cumulative_{tag}.{ext}"
        fig_p.savefig(fp, dpi=200 if ext == "png" else 72, bbox_inches="tight")
        print(f"Saved → {fp}")
    plt.close(fig_p)
