"""
9_15_xi_distribution_fig.py
============================
Distribution of demand-side BLP residual (xi_jt = delta_j - delta_FE_j)
for EV and GV products, 2015-2024.

xi_jt is the year-specific deviation of each product's mean utility from its
long-run (all-year) sales-weighted mean.  It captures whether a product had
unusually high or low unobserved appeal in a given year, after netting out
the permanent product quality level.

Line = sales-weighted mean; inner band = IQR (p25-p75); outer = p10-p90.
Notable products annotated per year.

Output: report/memos/fig_xi_distribution.pdf
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = ["Arial Unicode MS", "DejaVu Sans"]
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT  = f"{ROOT}/report/memos"
os.makedirs(OUT, exist_ok=True)

YEARS = list(range(2015, 2025))
XLIM  = (2014.85, 2024.15)

# ── Load raw data & apply singleton filter (must match 1_blp.py) ──────────────
df_raw = pd.read_parquet(f"{ROOT}/output/df.parquet")
df_raw["sales"] = df_raw["shares"] * df_raw["Population"]

def singleton_filter(d):
    out = d.copy()
    vars_ = [v for v in ["log_size", "Displacement", "electric_efficiency",
                          "FuelEfficiency", "log_ev_range"] if v in out.columns]
    grp = out.groupby("market_segement", sort=False)
    n = grp[vars_[0]].transform("size")
    for v in vars_:
        s = grp[v].transform("sum")
        out[f"{v}_iv_diff"] = np.abs(
            out[v] - np.where(n > 1, (s - out[v]) / (n - 1), np.nan))
    return out.dropna(subset=[f"{v}_iv_diff" for v in vars_]).reset_index(drop=True)

df_full = singleton_filter(df_raw)

# ── Attach BLP delta ───────────────────────────────────────────────────────────
ess = np.load(f"{ROOT}/output/blp_essentials_v12/blp_essentials.npz",
              allow_pickle=True)
assert len(ess["delta"]) == len(df_full), \
    f"delta length {len(ess['delta'])} != df_full {len(df_full)}"
df_full["delta"] = ess["delta"]

# ── Product FE: sales-weighted mean delta across all years per (Model, FuelType)
prod_fe = (
    df_full.groupby(["Model", "FuelType"])
    .apply(lambda g: np.average(g["delta"], weights=g["sales"].clip(lower=1e-10)),
           include_groups=False)
    .rename("delta_fe")
    .reset_index()
)
df_full = df_full.merge(prod_fe, on=["Model", "FuelType"], how="left")
df_full["xi"] = df_full["delta"] - df_full["delta_fe"]

# ── Aggregate to national product level ────────────────────────────────────────
def nat_prod(mask):
    sub = df_full[mask]
    grp = sub.groupby(["Brand", "Model", "FuelType", "Year"])
    return grp.apply(
        lambda g: pd.Series({
            "xi":    np.average(g["xi"],    weights=g["sales"].clip(lower=1e-10)),
            "sales": g["sales"].sum(),
        }), include_groups=False
    ).reset_index()

ev_prod = nat_prod(df_full["ev_dummy"] == 1)
gv_prod = nat_prod(df_full["ev_dummy"] == 0)

# ── Sales-weighted quantiles per year ─────────────────────────────────────────
def wq(vals, weights, q):
    order = np.argsort(vals)
    v_s   = vals[order]
    w_s   = weights[order]
    cdf   = np.cumsum(w_s) / w_s.sum()
    return float(np.interp(q, cdf, v_s))

def year_stats(prod_df):
    rows = []
    for yr in YEARS:
        s = prod_df[prod_df["Year"] == yr]
        if s.empty:
            rows.append({"Year": yr}); continue
        v = s["xi"].values
        w = s["sales"].clip(lower=1e-10).values
        rows.append({
            "Year": yr,
            "p10":  wq(v, w, 0.10),
            "p25":  wq(v, w, 0.25),
            "mean": float(np.average(v, weights=w)),
            "p75":  wq(v, w, 0.75),
            "p90":  wq(v, w, 0.90),
        })
    return pd.DataFrame(rows).set_index("Year")

ev_stats = year_stats(ev_prod)
gv_stats = year_stats(gv_prod)

# ── Brand / model translations ─────────────────────────────────────────────────
BRAND = {
    "比亚迪": "BYD",    "特斯拉": "Tesla",   "五菱":  "Wuling",
    "北京":  "BAIC",    "埃安":  "Aion",     "欧拉":  "Ora",
    "奇瑞":  "Chery",   "蔚来":  "NIO",      "小鹏":  "Xpeng",
    "理想":  "Li Auto", "零跑":  "Leapmotor","哪吒":  "Neta",
    "极氪":  "Zeekr",   "小米":  "Xiaomi",   "智己":  "IM",
    "岚图":  "Voyah",   "红旗":  "Hongqi",   "鸿蒙智行": "Aito",
    "知豆":  "Zhidou",  "众泰":  "Zotye",    "江淮":  "JAC",
    "吉利":  "Geely",   "长安":  "Changan",  "广汽":  "GAC",
    "哈弗":  "Haval",   "长城":  "GWM",      "大众":  "VW",
    "日产":  "Nissan",  "丰田":  "Toyota",   "本田":  "Honda",
    "宝马":  "BMW",     "奔驰":  "Benz",     "奥迪":  "Audi",
    "别克":  "Buick",   "荣威":  "Roewe",    "宝骏":  "Baojun",
    "上汽":  "SAIC",    "雪佛兰": "Chevy",   "现代":  "Hyundai",
}
MODEL = {
    "MODEL3": "Model 3", "MODELY": "Model Y", "MODELX": "Model X",
    "MODELS": "Model S",
    "秦":   "Qin",    "唐":   "Tang",   "宋":  "Song",  "汉": "Han",
    "元":   "Yuan",   "海豚": "Dolphin","海鸥": "Seagull",
    "宋PLUS":"Song+", "宋Pro":"Song Pro",
    "宏光MINI": "Mini EV", "五菱宏光": "Wuling HG",
    "知豆D1": "D1",   "知豆D2": "D2",
    "北汽EC3":"EC3",  "北汽EV": "EV",   "北京U5": "U5",
    "AIONS": "Aion S","欧拉黑猫": "Black Cat",
    "小蚂蚁": "Ant",  "帝豪":  "Emgrand",
    "ES6": "ES6", "ET5": "ET5", "SU7": "SU7",
    "轩逸":  "Sylphy","朗逸":  "Lavida","哈弗H6": "H6",
    "速腾":  "Sagitar","帕萨特": "Passat","卡罗拉": "Corolla",
    "宝来":  "Bora",  "捷达":  "Jetta", "迈腾":  "Magotan",
}

def eng(brand, model):
    return f"{BRAND.get(brand, brand)} {MODEL.get(model, model)}"

# ── Annotation: highest and lowest xi in top-20 by sales ──────────────────────
def pick_labels(prod_df, n_top=20):
    out = {}
    for yr in YEARS:
        s = prod_df[prod_df["Year"] == yr]
        if s.empty:
            out[yr] = []; continue
        top20 = s.nlargest(n_top, "sales")
        picks = []
        r = top20.nlargest(1, "xi").iloc[0]
        picks.append({"name": eng(r["Brand"], r["Model"]), "xi": r["xi"]})
        r2 = top20.nsmallest(1, "xi").iloc[0]
        nm2 = eng(r2["Brand"], r2["Model"])
        if nm2 != picks[0]["name"]:
            picks.append({"name": nm2, "xi": r2["xi"]})
        out[yr] = picks
    return out

ev_labels = pick_labels(ev_prod)
gv_labels = pick_labels(gv_prod)

# ── Draw ──────────────────────────────────────────────────────────────────────
EV_C = "#2166ac"
GV_C = "#d6604d"

fig, (ax_ev, ax_gv) = plt.subplots(1, 2, figsize=(14, 3.8),
                                    gridspec_kw={"wspace": 0.32})

def draw_panel(ax, stats, labels, color):
    yrs = [y for y in YEARS if y in stats.index and pd.notna(stats.loc[y, "mean"])]

    ax.fill_between(yrs,
                    [stats.loc[y, "p10"] for y in yrs],
                    [stats.loc[y, "p90"] for y in yrs],
                    color=color, alpha=0.10, linewidth=0, zorder=1)
    ax.fill_between(yrs,
                    [stats.loc[y, "p25"] for y in yrs],
                    [stats.loc[y, "p75"] for y in yrs],
                    color=color, alpha=0.28, linewidth=0, zorder=2)
    means = [stats.loc[y, "mean"] for y in yrs]
    ax.plot(yrs, means, color=color, lw=2.4, marker="o", ms=4.5, zorder=4)

    rng = np.random.default_rng(3)
    for yr, picks in labels.items():
        if not picks or yr not in stats.index:
            continue
        for i, p in enumerate(picks):
            xval  = p["xi"]
            above = (xval >= stats.loc[yr, "mean"])
            if i == 1:
                above = not above
            dy = 18 if above else -18
            va = "bottom" if above else "top"
            dx = int(rng.integers(-5, 6))
            ax.scatter(yr, xval, s=28, color=color, zorder=6,
                       edgecolors="white", linewidths=0.7)
            ax.annotate(p["name"],
                        xy=(yr, xval),
                        xytext=(dx, dy), textcoords="offset points",
                        fontsize=5.5, ha="center", va=va, zorder=7,
                        bbox=dict(boxstyle="round,pad=0.22", fc="white",
                                  ec="#bbb", lw=0.5, alpha=0.93),
                        arrowprops=dict(arrowstyle="-", color="#ccc", lw=0.6))

    mean_line = Line2D([0],[0], color=color, lw=2.2, marker="o", ms=4,
                       label="Sales-wtd. mean")
    inner = mpatches.Patch(fc=color, alpha=0.28, label="IQR (p25--p75)")
    outer = mpatches.Patch(fc=color, alpha=0.10, label="p10--p90")
    ax.legend(handles=[mean_line, inner, outer],
              fontsize=8, frameon=True, loc="lower right",
              handlelength=1.4, labelspacing=0.35, borderpad=0.7)
    ax.axhline(0, color="black", lw=0.6)
    ax.set_xlim(*XLIM)
    ax.set_xticks(YEARS)
    ax.set_xticklabels([str(y) for y in YEARS], fontsize=8, rotation=30, ha="right")
    ax.set_ylabel(r"Demand residual $\xi_{jt}$ (BLP mean utility units)", fontsize=10)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", lw=0.5, alpha=0.3, color="gray")
    ax.tick_params(labelsize=8.5)

draw_panel(ax_ev, ev_stats, ev_labels, EV_C)
draw_panel(ax_gv, gv_stats, gv_labels, GV_C)

_ylo = min(ax_ev.get_ylim()[0], ax_gv.get_ylim()[0])
_yhi = max(ax_ev.get_ylim()[1], ax_gv.get_ylim()[1])
ax_ev.set_ylim(_ylo, _yhi)
ax_gv.set_ylim(_ylo, _yhi)

ax_ev.text(0.97, 0.97, "EV", transform=ax_ev.transAxes,
           fontsize=11, fontweight="bold", va="top", ha="right", color=EV_C)
ax_gv.text(0.97, 0.97, "GV", transform=ax_gv.transAxes,
           fontsize=11, fontweight="bold", va="top", ha="right", color=GV_C)

out_png = f"{OUT}/fig_xi_distribution.png"
out_pdf = f"{OUT}/fig_xi_distribution.pdf"
fig.savefig(out_png, bbox_inches="tight", dpi=200)
fig.savefig(out_pdf, bbox_inches="tight")
print(f"Saved -> {out_png}")
print(f"Saved -> {out_pdf}")

# ── Save individual panels (no EV/GV label baked in) ──────────────────────────
for panel_tag, stats, labels, color in [
    ("ev", ev_stats, ev_labels, EV_C),
    ("gv", gv_stats, gv_labels, GV_C),
]:
    fig_p, ax_p = plt.subplots(1, 1, figsize=(7, 3.8))
    draw_panel(ax_p, stats, labels, color)
    _ylo_p, _yhi_p = ax_p.get_ylim()   # draw_panel already sets ylim from data
    fig_p.tight_layout(pad=0.6)
    for ext in ("png", "pdf"):
        fp = f"{OUT}/fig_xi_distribution_{panel_tag}.{ext}"
        fig_p.savefig(fp, dpi=200 if ext=="png" else 72, bbox_inches="tight")
        print(f"Saved -> {fp}")
    plt.close(fig_p)
