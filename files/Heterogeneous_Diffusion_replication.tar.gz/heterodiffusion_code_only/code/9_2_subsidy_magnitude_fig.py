"""
9_2_subsidy_magnitude_fig.py
============================
Panel A: National cash subsidy per BEV vehicle (10k CNY) by year
Panel B: Total subsidy decomposition for BEV purchasers — national cash,
         local match, and purchase-tax exemption — stacked by year

Reads:  output/df.parquet
Writes: report/memos/fig_subsidy_magnitude.png
        report/memos/fig_subsidy_magnitude.pdf
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = ["Arial Unicode MS", "DejaVu Sans"]
import matplotlib.pyplot as plt

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT  = f"{ROOT}/report/memos"
os.makedirs(OUT, exist_ok=True)

YEARS = list(range(2015, 2025))

# ── Load data ─────────────────────────────────────────────────────────────────
df = pd.read_parquet(f"{ROOT}/output/df.parquet")
ev = df[df["ev_dummy"] == 1].copy()

# Product-level deduplicated (one row per unique product × year)
prod_ev = ev.drop_duplicates(["Brand", "Model", "FuelType", "Year"])

def prod_mean(col):
    return (prod_ev.groupby("Year")[col]
            .mean().reindex(YEARS, fill_value=0))

nat_sub  = prod_mean("nat_subsidy_wan")
loc_sub  = prod_mean("local_subsidy_wan")
tax_sub  = prod_mean("purchase_tax_exemption_wan")

# ── Colors ────────────────────────────────────────────────────────────────────
C_NAT  = "#2166ac"
C_LOC  = "#74add1"
C_TAX  = "#f4a261"

fig, axes = plt.subplots(1, 2, figsize=(12, 4.2),
                          gridspec_kw={"wspace": 0.38})

# ════════════════════════════════════════════════════════════════════
# PANEL A — national cash subsidy per vehicle
# ════════════════════════════════════════════════════════════════════
ax = axes[0]
ax.bar(YEARS, nat_sub.values, color=C_NAT, alpha=0.85, linewidth=0)

# Annotate each non-zero bar
for yr, v in zip(YEARS, nat_sub.values):
    if v > 0.05:
        ax.text(yr, v + 0.05, f"{v:.2f}", ha="center", va="bottom",
                fontsize=7.5, color=C_NAT)

ax.set_xticks(YEARS)
ax.set_xticklabels([str(y) for y in YEARS], rotation=30, ha="right", fontsize=8)
ax.set_ylabel("National Cash Subsidy (10k CNY / vehicle)", fontsize=9.5)
ax.set_ylim(0, nat_sub.max() * 1.25)
ax.spines[["top", "right"]].set_visible(False)
ax.grid(axis="y", lw=0.5, alpha=0.3, color="gray")
ax.tick_params(labelsize=8.5)

# Annotation: subsidy ends
end_yr = [y for y, v in zip(YEARS, nat_sub.values) if v > 0][-1]
ax.annotate("Cash subsidy\nphased out",
            xy=(end_yr + 0.5, 0.1), xytext=(end_yr - 1.5, nat_sub.max() * 0.5),
            fontsize=7.5, color="#444", ha="center",
            arrowprops=dict(arrowstyle="->", color="#888", lw=0.9))

# ════════════════════════════════════════════════════════════════════
# PANEL B — stacked total subsidy (nat + local + tax exemption)
# ════════════════════════════════════════════════════════════════════
ax = axes[1]

xpos = np.arange(len(YEARS))
w    = 0.65

b1 = ax.bar(xpos, nat_sub.values, width=w, color=C_NAT, alpha=0.85,
            linewidth=0, label="National cash subsidy")
b2 = ax.bar(xpos, loc_sub.values, width=w, bottom=nat_sub.values,
            color=C_LOC, alpha=0.85, linewidth=0, label="Local match")
b3 = ax.bar(xpos, tax_sub.values, width=w,
            bottom=nat_sub.values + loc_sub.values,
            color=C_TAX, alpha=0.85, linewidth=0, label="Purchase-tax exemption")

total = nat_sub.values + loc_sub.values + tax_sub.values
for xi, tot in zip(xpos, total):
    if tot > 0.1:
        ax.text(xi, tot + 0.06, f"{tot:.2f}", ha="center", va="bottom",
                fontsize=7, color="#333")

ax.set_xticks(xpos)
ax.set_xticklabels([str(y) for y in YEARS], rotation=30, ha="right", fontsize=8)
ax.set_ylabel("Total Subsidy Benefit (10k CNY / vehicle)", fontsize=9.5)
ax.set_ylim(0, total.max() * 1.25)
ax.spines[["top", "right"]].set_visible(False)
ax.grid(axis="y", lw=0.5, alpha=0.3, color="gray")
ax.tick_params(labelsize=8.5)
ax.legend(fontsize=8, frameon=False, loc="upper right")

out_png = f"{OUT}/fig_subsidy_magnitude.png"
out_pdf = f"{OUT}/fig_subsidy_magnitude.pdf"
fig.savefig(out_png, bbox_inches="tight", dpi=200)
fig.savefig(out_pdf, bbox_inches="tight")
print(f"Saved → {out_png}")
print(f"Saved → {out_pdf}")
