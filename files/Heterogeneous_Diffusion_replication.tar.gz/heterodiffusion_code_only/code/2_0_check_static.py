"""
2_0_check_static.py
===================

Stage 2-0: Static equilibrium check.  Runs after 1_2_mc_estimation.py,
before 2_1_static_decomposition.py.

Three checks:

(A) Demand roundtrip at 2015 and 2024.
    With BLP-inverted δ and observed prices, does the BLP share function
    reproduce observed within-market shares?  (Tests δ correctness.)

(B) Supply roundtrip at 2015 and 2024.
    Does Bertrand-Nash FOC at observed (p_obs, mc_obs) give back mc_obs?
    (Tests supply-side consistency.)

(C) Shapley endpoint check (all-off / all-on).
    Reads coalition_results.csv from the latest decomp output and reports
    the factored EV share and factored mean EV price at:
      all-off  = coalition {}               ≈ 2015 data
      all-on   = coalition {all 6 blocks}   ≈ 2024 model prediction

PASS criterion per year/direction:
    demand: EV-share gap |pred − obs| ≤ 0.5 pp  AND  max per-row |Δs| ≤ 0.01
    supply: max log|mc_foc − mc_nat| ≤ 0.01

Saves output/check_static_equilibrium.csv.
"""
import os, sys, glob
import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

print("=" * 78)
print("STATIC EQUILIBRIUM CHECK  (Stage 2-0)")
print("=" * 78)

# ── Load BLP essentials ───────────────────────────────────────────────────────
ess = np.load("output/blp_essentials_v12/blp_essentials.npz", allow_pickle=True)
delta_stored  = ess["delta"]
sigma_ev      = float(ess["sigma_diag"][1])
pi_price      = float(ess["pi_price"])
beta          = ess["beta"]
beta_labels   = list(ess["beta_labels"].astype(str))
nu_attrs      = ess["nu_attrs_v12"]
income_inv    = ess["income_inv_normed_v12"]
markets       = ess["markets_v12"]
NS            = nu_attrs.shape[1]
beta_log_p    = float(beta[beta_labels.index("log_price")])

print(f"θ̂: σ_ev={sigma_ev:.4f}  π={pi_price:.4f}  β_log_p={beta_log_p:.4f}  NS={NS}")

# ── Load data ─────────────────────────────────────────────────────────────────
vs = ["log_size", "Displacement", "electric_efficiency",
      "FuelEfficiency", "log_ev_range"]
df = pd.read_parquet("output/df.parquet")
grp = df.groupby("market_segement", sort=False)
n_  = grp[vs[0]].transform("size")
for v in vs:
    s = grp[v].transform("sum")
    df[f"{v}_iv"] = np.abs(df[v] - np.where(n_ > 1, (s - df[v]) / (n_ - 1), np.nan))
df = df.dropna(subset=[f"{v}_iv" for v in vs]).reset_index(drop=True)
assert len(df) == len(delta_stored), f"row mismatch: df={len(df)} δ={len(delta_stored)}"
df["delta_blp"] = delta_stored
df["ev"]        = df["FuelType"].isin(["BEV", "PHEV", "REEV"]).astype(int)
df["mkt"]       = df["Year"].astype(str) + "-" + df["Geo_Market"].astype(str)
df["M_c"]       = df["Population"] * 10000 / 2.62 / 5
mt              = {m: i for i, m in enumerate(markets.astype(str))}
df["mkt_idx"]   = df["mkt"].map(mt).astype(int)

nat_mc = pd.read_parquet("output/national_mc.parquet")
nat_mc_lookup = {(r["Year"], r["Model"], r["FuelType"]): r["mc_national"]
                 for _, r in nat_mc.iterrows()}

# ── Share functions ───────────────────────────────────────────────────────────
def shares_at_p(delta_loc, log_p_loc, ev_loc, mi):
    nu  = nu_attrs[mi, :, 0]
    inc = income_inv[mi, :]
    u   = (delta_loc[:, None]
           + (pi_price * inc)[None, :] * log_p_loc[:, None]
           + sigma_ev * nu[None, :] * ev_loc[:, None])
    u_max = np.maximum(0.0, u.max(axis=0, keepdims=True))
    eu    = np.exp(u - u_max)
    e0    = np.exp(-u_max[0])
    return (eu / (e0 + eu.sum(axis=0))[None, :]).mean(axis=1)


def shares_jac_at_p(delta_loc, log_p_loc, ev_loc, mi):
    nu        = nu_attrs[mi, :, 0]
    inc       = income_inv[mi, :]
    alpha_jac = beta_log_p + pi_price * inc
    u         = (delta_loc[:, None]
                 + (pi_price * inc)[None, :] * log_p_loc[:, None]
                 + sigma_ev * nu[None, :] * ev_loc[:, None])
    u_max = np.maximum(0.0, u.max(axis=0, keepdims=True))
    eu    = np.exp(u - u_max)
    e0    = np.exp(-u_max[0])
    denom = e0 + eu.sum(axis=0)
    s_ij  = eu / denom[None, :]
    s_j   = s_ij.mean(axis=1)
    alpha_s = alpha_jac[None, :] * s_ij
    Jac = -(alpha_s @ s_ij.T) / NS
    np.fill_diagonal(Jac, Jac.diagonal() + alpha_s.sum(axis=1) / NS)
    return s_j, Jac


# ── (A) Demand roundtrip ──────────────────────────────────────────────────────
print("\n" + "─" * 78)
print("(A) DEMAND ROUNDTRIP  — BLP-inverted δ at p_obs → reproduces obs shares?")
print("─" * 78)

rows_A = []
for yr in (2015, 2024):
    dfy = df[df["Year"] == yr].reset_index(drop=True).copy()
    sp  = np.zeros(len(dfy))
    for mi, gdf in dfy.groupby("mkt_idx"):
        idx = gdf.index.values
        sp[idx] = shares_at_p(gdf["delta_blp"].values,
                               gdf["log_price"].values,
                               gdf["ev"].values.astype(float), int(mi))
    dfy["sp"] = sp
    w        = dfy["M_c"]
    obs_ev   = (dfy["shares"] * w * dfy["ev"]).sum() / (dfy["shares"] * w).sum()
    pred_ev  = (dfy["sp"]     * w * dfy["ev"]).sum() / (dfy["sp"]     * w).sum()
    max_row  = (dfy["sp"] - dfy["shares"]).abs().max()
    gap_pp   = (pred_ev - obs_ev) * 100
    passed   = (abs(gap_pp) <= 0.5) and (max_row <= 0.01)
    print(f"  {yr}: obs EV={obs_ev*100:6.2f}%  pred EV={pred_ev*100:6.2f}%  "
          f"gap={gap_pp:+5.2f}pp  per-row max|Δs|={max_row:.4f}  "
          f"{'PASS' if passed else 'FAIL'}")
    rows_A.append(dict(check="demand_roundtrip", year=yr,
                       obs_ev_share=obs_ev, pred_ev_share=pred_ev,
                       gap_pp=gap_pp, max_row_delta=max_row,
                       passed=passed))


# ── (B) Supply roundtrip ──────────────────────────────────────────────────────
print("\n" + "─" * 78)
print("(B) SUPPLY ROUNDTRIP  — Bertrand FOC at p_obs round-trips to mc_obs?")
print("─" * 78)

firm_lookup = {(r["Model"], r["FuelType"]): r["firm_id"] for _, r in nat_mc.iterrows()}
all_firms   = sorted({v for v in firm_lookup.values() if pd.notna(v)})
firm_id_int = {f: i for i, f in enumerate(all_firms)}

rows_B = []
for yr in (2015, 2024):
    dfy  = df[df["Year"] == yr].copy()
    grpb = dfy.groupby(["Model", "FuelType"], sort=False)
    prod_keys = list(grpb.groups.keys())
    J         = len(prod_keys)
    prod_idx  = {k: i for i, k in enumerate(prod_keys)}
    ev_flag   = np.zeros(J)
    firm_arr  = np.zeros(J, dtype=int)
    mc_arr    = np.full(J, np.nan)
    for (m, f), g in grpb:
        i = prod_idx[(m, f)]
        ev_flag[i]  = 1.0 if f in ("BEV", "PHEV", "REEV") else 0.0
        firm_arr[i] = firm_id_int.get(firm_lookup.get((m, f), None), 0)
        mc_arr[i]   = nat_mc_lookup.get((yr, m, f), np.nan)
    Q_nat  = np.zeros(J)
    Omega  = np.zeros((J, J))
    P_num  = np.zeros(J)
    for mi, gdf in dfy.groupby("mkt_idx"):
        loc_idx = np.array([prod_idx[(m, f)]
                            for m, f in zip(gdf["Model"], gdf["FuelType"])])
        log_p   = gdf["log_price"].values
        p_lvl   = np.exp(log_p)
        ev_loc  = gdf["ev"].values.astype(float)
        M_c     = float(gdf["M_c"].iloc[0])
        s_loc, Jac_loc = shares_jac_at_p(gdf["delta_blp"].values,
                                          log_p, ev_loc, int(mi))
        np.add.at(Q_nat, loc_idx, M_c * s_loc)
        np.add.at(P_num, loc_idx, M_c * s_loc * p_lvl)
        Omega[np.ix_(loc_idx, loc_idx)] += M_c * Jac_loc
    P_lvl     = P_num / np.maximum(Q_nat, 1e-12)
    same_firm = (firm_arr[:, None] == firm_arr[None, :]).astype(float)
    Omega_own = Omega * same_firm + 1e-6 * np.eye(J)
    markup    = np.linalg.solve(Omega_own.T, -(P_lvl * Q_nat))
    mc_foc    = P_lvl - markup
    valid     = ~np.isnan(mc_arr) & (mc_arr > 0) & (mc_foc > 0)
    log_diff  = np.abs(np.log(mc_foc[valid]) - np.log(mc_arr[valid]))
    passed    = log_diff.max() < 0.01
    # NOTE: The canonical sim backs out mc_true_v33_sticker under a sticker-space
    # Bertrand FOC (see _regen_mc_v33_sticker.py).  national_mc.parquet uses the
    # log-price FOC convention from 1_blp.py.  A small gap here is expected
    # and reflects sticker-space vs consumer-net-space FOC framings.
    print(f"  {yr}: J={J}  valid={valid.sum()}  "
          f"log|mc_foc−mc_nat| mean={log_diff.mean():.4f} max={log_diff.max():.4f}  "
          f"{'PASS' if passed else 'NOTE: sticker-FOC vs log-price-FOC mismatch (expected)'}")
    rows_B.append(dict(check="supply_roundtrip", year=yr,
                       n_products=J, n_valid=int(valid.sum()),
                       log_mc_diff_mean=log_diff.mean(),
                       log_mc_diff_max=log_diff.max(),
                       passed=passed))


# ── (C) Shapley endpoint check (all-off / all-on) ────────────────────────────
print("\n" + "─" * 78)
print("(C) SHAPLEY ENDPOINTS  — factored EV share & price at all-off / all-on")
print("─" * 78)

rows_C = []
for yr in (2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024):
    cdir = f"output/decomp_s4_final_byyear_{yr}"
    csv  = os.path.join(cdir, "coalition_results.csv")
    if not os.path.exists(csv):
        print(f"  {yr}: MISSING  ({cdir})")
        continue
    cr = pd.read_csv(csv)
    # Identify all-off ({}) and all-on (set with all 6 blocks)
    def _n_blocks(c):
        inner = c.strip().strip("{}")
        return 0 if inner == "" else len(inner.split(","))

    all_off_row = cr[cr["coalition"] == "{}"]
    all_on_row  = cr[cr["coalition"].apply(_n_blocks) == 6]
    obs_yr = df[df["Year"] == yr]
    w      = obs_yr["M_c"]
    obs_ev = (obs_yr["shares"] * w * obs_yr["ev"]).sum() / (obs_yr["shares"] * w).sum()
    obs_price_ev = (obs_yr.loc[obs_yr["ev"] == 1, "price"] * w[obs_yr["ev"] == 1]).sum() \
                   / w[obs_yr["ev"] == 1].sum() if "price" in obs_yr.columns else np.nan
    for label, row_df in [("all_off", all_off_row), ("all_on", all_on_row)]:
        if len(row_df) == 0:
            print(f"  {yr} {label}: coalition row not found")
            continue
        row = row_df.iloc[0]
        ev_sh = float(row["ev_share"])
        price = float(row.get("mean_price_ev", row.get("mean_price", np.nan)))
        print(f"  {yr} {label:<8s}: factored EV share={ev_sh*100:6.2f}%  "
              f"factored EV price={price:.3f} 万元  "
              f"(obs EV share={obs_ev*100:.2f}%)")
        rows_C.append(dict(year=yr, endpoint=label,
                           factored_ev_share=ev_sh, factored_ev_price=price,
                           obs_ev_share=obs_ev,
                           gap_pp=(ev_sh - obs_ev) * 100))


# ── Save summary ──────────────────────────────────────────────────────────────
out_A = pd.DataFrame(rows_A)
out_B = pd.DataFrame(rows_B)
out_C = pd.DataFrame(rows_C)

out_A.to_csv("output/check_static_demand.csv",   index=False)
out_B.to_csv("output/check_static_supply.csv",   index=False)
out_C.to_csv("output/check_static_endpoints.csv", index=False)

print("\n" + "═" * 78)
n_pass_A = out_A["passed"].sum()
n_pass_B = out_B["passed"].sum()
print(f"Summary:  Demand roundtrip  {n_pass_A}/{len(out_A)} PASS")
print(f"          Supply roundtrip  {n_pass_B}/{len(out_B)} PASS")
print("Saved: output/check_static_demand.csv")
print("       output/check_static_supply.csv")
print("       output/check_static_endpoints.csv")
print("=" * 78)

# Factual must converge: demand and supply roundtrips must all pass.
if n_pass_A < len(out_A) or n_pass_B < len(out_B):
    print("\nERROR: Factual equilibrium check FAILED — pipeline aborted.")
    sys.exit(1)
