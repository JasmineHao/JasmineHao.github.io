"""
9_30_diffusion_lag.py
=====================

Cross-tier EV diffusion timing chart. Plots the EV share by city tier
(T1 / NT1 / T2 / Rest) from 2015 to 2024, and annotates the year each
tier first crosses 10%, 25%, and 40% EV share to expose the diffusion
lag heterogeneity that the title of the paper claims.

Sources:
  output/df.parquet   — product × city × year shares + Population

Output:
  report/memos/fig_diffusion_lag.pdf / .png
  report/memos/tab_diffusion_lag.tex
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT_FIG_PDF = f"{ROOT}/report/memos/fig_diffusion_lag.pdf"
OUT_FIG_PNG = f"{ROOT}/report/memos/fig_diffusion_lag.png"
OUT_TEX     = f"{ROOT}/report/memos/tab_diffusion_lag.tex"

# Also drop the figure into Overleaf/figures
OVERLEAF_FIG = "/Users/jasminehao/Library/CloudStorage/Dropbox/Apps/Overleaf/heterogenous_diffusion/figures/fig_diffusion_lag.png"


def _tier_from_market(m):
    cities_t1  = {"北京市", "上海市", "广州市", "深圳市"}
    cities_nt1 = {"成都市", "杭州市", "武汉市", "重庆市", "南京市", "天津市",
                  "苏州市", "西安市", "长沙市", "沈阳市", "青岛市", "郑州市",
                  "大连市", "东莞市", "宁波市"}
    city = m.split("-", 1)[1] if "-" in m else m
    if city in cities_t1:  return "T1"
    if city in cities_nt1: return "NT1"
    if "Other" in city:    return "Rest"
    return "T2"


# Load
df = pd.read_parquet(f"{ROOT}/output/df.parquet")
df["tier"] = df["Geo_Market"].apply(_tier_from_market)
df["is_ev"] = df["FuelType"].isin(["BEV", "PHEV", "REEV"]).astype(int)
df["M"]    = df["Population"] * 10000.0 / 2.62 / 5.0
df["q"]    = df["shares"] * df["M"]

# Per (tier, year): EV share = Σ EV q / Σ total q (annual)
def tier_share(g):
    return pd.Series({
        "ev_q":    g.loc[g.is_ev == 1, "q"].sum(),
        "total_q": g["q"].sum(),
    })

panel = (df.groupby(["tier", "Year"])
            .apply(tier_share, include_groups=False)
            .reset_index())
panel["ev_share"] = panel["ev_q"] / panel["total_q"]
print("EV share by tier × year:")
print(panel.pivot(index="Year", columns="tier", values="ev_share").round(4).to_string())

# Find first-crossing years for thresholds
THRESHOLDS = [0.05, 0.10, 0.25, 0.40]
TIER_ORDER = ["T1", "NT1", "T2", "Rest"]
crossings = {}
for tier in TIER_ORDER:
    sub = panel[panel.tier == tier].sort_values("Year")
    crossings[tier] = {}
    for thr in THRESHOLDS:
        match = sub[sub["ev_share"] >= thr]
        crossings[tier][thr] = int(match["Year"].iloc[0]) if len(match) > 0 else None

print("\nFirst-crossing year by tier × threshold:")
for tier in TIER_ORDER:
    cells = []
    for thr in THRESHOLDS:
        y = crossings[tier][thr]
        cells.append(f"{int(thr*100):>2d}%: {str(y) if y is not None else '--':>4s}")
    print(f"  {tier:>5s}: " + " | ".join(cells))

# Compute lag relative to T1
print("\nLag (years) relative to T1 first-crossing:")
for thr in THRESHOLDS:
    t1_yr = crossings["T1"][thr]
    if t1_yr is None:
        continue
    lags = []
    for tier in TIER_ORDER:
        if tier == "T1": continue
        y = crossings[tier][thr]
        lags.append((tier, (y - t1_yr) if y is not None else None))
    print(f"  {int(thr*100):>2d}%: " + " | ".join(
        f"{t}: {l}y" if l is not None else f"{t}: never"
        for t, l in lags))


# ---------------------------------------------------------------------------
# Plot
# ---------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(8, 5))
COLORS = {"T1": "#1f77b4", "NT1": "#ff7f0e", "T2": "#2ca02c", "Rest": "#d62728"}
LABELS = {"T1": "Tier 1 (4 cities)", "NT1": "New Tier 1 (15 cities)",
          "T2": "Tier 2 (33 cities)", "Rest": "Rest of China (27 cells)"}

for tier in TIER_ORDER:
    sub = panel[panel.tier == tier].sort_values("Year")
    ax.plot(sub["Year"], sub["ev_share"] * 100,
            color=COLORS[tier], lw=2.5, marker="o", markersize=5,
            label=LABELS[tier])

# Reference thresholds + crossing annotations
for thr in [0.10, 0.25]:
    ax.axhline(thr * 100, color="gray", lw=0.8, alpha=0.4, ls="--")
    ax.text(2015.1, thr * 100 + 0.5, f"{int(thr*100)}\\%",
            fontsize=10, color="gray")

# Lag annotation arrow for the 10% threshold
t1_10 = crossings["T1"][0.10]
rest_10 = crossings["Rest"][0.10]
if t1_10 and rest_10:
    lag_text = f"{rest_10 - t1_10}-year lag at 10\\% EV share"
    ax.annotate("", xy=(rest_10, 10), xytext=(t1_10, 10),
                arrowprops=dict(arrowstyle="<->", color="dimgray", lw=1.3))
    ax.text((t1_10 + rest_10) / 2, 12.5, lag_text,
            ha="center", fontsize=11, color="dimgray", style="italic")

ax.set_xlabel("Year", fontsize=12)
ax.set_ylabel("EV share (\\% of new-vehicle sales)", fontsize=12)
ax.set_xlim(2014.5, 2024.5)
ax.set_ylim(-1, 60)
ax.tick_params(labelsize=11)
ax.legend(loc="upper left", fontsize=11, frameon=True)
ax.grid(True, axis="y", alpha=0.25)
plt.tight_layout()

os.makedirs(os.path.dirname(OUT_FIG_PDF), exist_ok=True)
plt.savefig(OUT_FIG_PDF, dpi=160, bbox_inches="tight")
plt.savefig(OUT_FIG_PNG, dpi=160, bbox_inches="tight")
if os.path.exists(os.path.dirname(OVERLEAF_FIG)):
    plt.savefig(OVERLEAF_FIG, dpi=160, bbox_inches="tight")
    print(f"\nAlso saved → {OVERLEAF_FIG}")
print(f"\nSaved → {OUT_FIG_PDF}")
print(f"Saved → {OUT_FIG_PNG}")


# ---------------------------------------------------------------------------
# LaTeX crossings table
# ---------------------------------------------------------------------------
lines = []
lines.append(r"% Auto-generated by code/9_30_diffusion_lag.py")
lines.append(r"\begin{table}[!ht]")
lines.append(r"\centering")
lines.append(r"\small")
lines.append(r"\caption{Year each tier first crosses an EV-share threshold}")
lines.append(r"\label{tab:lag}")
lines.append(r"\begin{tabular}{lrrrr}")
lines.append(r"\toprule")
lines.append(r"City tier & 5\% threshold & 10\% threshold & 25\% threshold & 40\% threshold \\")
lines.append(r"\midrule")
for tier in TIER_ORDER:
    cells = []
    for thr in THRESHOLDS:
        y = crossings[tier][thr]
        cells.append(f"{y}" if y is not None else "---")
    lines.append(f"{tier if tier!='Rest' else 'Rest of China'} & " + " & ".join(cells) + " \\\\")
lines.append(r"\midrule")
# Lag relative to T1 at 10%
lag_row = ["\\emph{Lag vs.\\ Tier 1}"]
for thr in THRESHOLDS:
    t1 = crossings["T1"][thr]
    if t1 is None:
        lag_row.append("---")
        continue
    rest = crossings["Rest"][thr]
    if rest is None:
        lag_row.append(f"$>${2024 - t1}\\,yr")
    else:
        lag_row.append(f"{rest - t1}\\,yr (Rest)")
lines.append(" & ".join(lag_row) + " \\\\")
lines.append(r"\bottomrule")
lines.append(r"\end{tabular}")
lines.append(r"")
lines.append(r"\begin{flushleft}")
lines.append(r"\footnotesize")
lines.append(
    r"\textit{Notes:} The table reports the first calendar year in which each "
    r"city tier's Q-weighted EV share (BEV $+$ PHEV $+$ REEV as a fraction of "
    r"all new-vehicle sales in the tier) reaches each threshold. T1 = "
    r"\{Beijing, Shanghai, Guangzhou, Shenzhen\}; NT1 = 15 new first-tier "
    r"cities (Chengdu, Hangzhou, Wuhan, Chongqing, Nanjing, Tianjin, Suzhou, "
    r"Xi'an, Changsha, Shenyang, Qingdao, Zhengzhou, Dalian, Dongguan, "
    r"Ningbo); T2 = 33 second-tier cities in the panel; Rest of China = the "
    r"27 small-city residual cells. The bottom row reports the diffusion lag "
    r"of the Rest tier relative to Tier 1.")
lines.append(r"\end{flushleft}")
lines.append(r"\end{table}")

with open(OUT_TEX, "w") as f:
    f.write("\n".join(lines) + "\n")
print(f"Saved → {OUT_TEX}")
