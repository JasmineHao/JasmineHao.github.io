"""
9_20_ev_range_trajectory_fig.py
=================================
Appendix figure: per-product BEV driving-range trajectories 2015-2024.

Each thin gray line traces one BEV model's range over the years it was sold,
showing that upgrades are product-specific (flexible) rather than uniform.
Median and IQR band are overlaid to capture the aggregate upward trend.

Output: report/memos/fig_ev_range_trajectory.pdf/.png
        Overleaf: figures/fig_ev_range_trajectory.png
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = ["Arial Unicode MS", "DejaVu Sans"]
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT  = f"{ROOT}/report/memos"
os.makedirs(OUT, exist_ok=True)

# ── Load & filter to BEV ──────────────────────────────────────────────────────
df = pd.read_parquet(f"{ROOT}/output/df.parquet")
ev = df[df["FuelType"] == "BEV"].copy()
ev["range_km"] = np.exp(ev["log_ev_range"])

# National average: one (Brand, Model, Year) obs
ev_nat = (ev.groupby(["Brand", "Model", "Year"])["range_km"]
            .mean().reset_index())

# Keep models that appear in ≥ 2 years
counts = ev_nat.groupby(["Brand", "Model"])["Year"].nunique()
multi  = counts[counts >= 2].reset_index()[["Brand", "Model"]]
ev_nat = ev_nat.merge(multi, on=["Brand", "Model"])

# ── Aggregate percentiles by year ─────────────────────────────────────────────
years = list(range(2015, 2025))
agg = (ev_nat.groupby("Year")["range_km"]
             .quantile([0.25, 0.50, 0.75])
             .unstack(level=1)
             .rename(columns={0.25: "q25", 0.50: "med", 0.75: "q75"}))
agg = agg.reindex(years)

# ── Highlighted models ────────────────────────────────────────────────────────
HIGHLIGHTS = [
    ("比亚迪",  "秦",       "#e6550d", "BYD Qin",       "left"),
    ("比亚迪",  "宋",       "#756bb1", "BYD Song",      "left"),
    ("比亚迪",  "汉",       "#31a354", "BYD Han",       "right"),
    ("特斯拉",  "MODEL3",   "#2166ac", "Tesla Model 3", "right"),
    ("吉利",    "熊猫",     "#e7298a", "Geely Panda",   "right"),
]

# ── Draw ──────────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(9, 5.5), constrained_layout=True)

# Background spaghetti: all models in light gray
for (brand, model), grp in ev_nat.groupby(["Brand", "Model"]):
    sub = grp.sort_values("Year")
    skip = any((brand == hb and model == hm) for hb, hm, *_ in HIGHLIGHTS)
    if not skip:
        ax.plot(sub["Year"], sub["range_km"],
                color="#aaaaaa", lw=0.8, alpha=0.35, zorder=1)

# IQR band
ax.fill_between(agg.index, agg["q25"], agg["q75"],
                color="#888888", alpha=0.15, linewidth=0, zorder=2,
                label="IQR (25th–75th pct.)")

# Median line
ax.plot(agg.index, agg["med"], color="black", lw=2.4,
        marker="o", ms=5.5, markerfacecolor="white",
        markeredgewidth=1.8, zorder=4, label="Median")

# Highlighted models
for brand, model, color, eng_name, side in HIGHLIGHTS:
    sub = ev_nat[(ev_nat["Brand"] == brand) & (ev_nat["Model"] == model)].sort_values("Year")
    if sub.empty:
        continue
    ax.plot(sub["Year"], sub["range_km"],
            color=color, lw=1.8, marker="s", ms=4.5,
            alpha=0.92, zorder=5, label=eng_name)
    # End-of-line label
    last = sub.iloc[-1]
    xoff = 0.15 if side == "right" else -0.15
    ha   = "left" if side == "right" else "right"
    ax.text(last["Year"] + xoff, last["range_km"],
            eng_name, color=color, fontsize=7.5,
            va="center", ha=ha, zorder=6)

# Annotation: total model count in 2024
n_2024 = ev_nat[ev_nat["Year"] == 2024]["Model"].nunique()
ax.text(0.98, 0.04, f"N = {n_2024} BEV models\nin 2024",
        transform=ax.transAxes, fontsize=8.5, ha="right", va="bottom",
        color="#555555")

ax.set_xlim(2014.6, 2025.5)
ax.set_xticks(years)
ax.set_xticklabels([str(y) for y in years], fontsize=9.5)
ax.set_ylim(0, 950)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{int(x)} km"))
ax.set_ylabel("Driving range (km)", fontsize=11)
ax.spines[["top", "right"]].set_visible(False)
ax.grid(axis="y", lw=0.5, alpha=0.3, color="gray")
ax.tick_params(labelsize=9.5)

# Legend — only for aggregate lines, not highlighted models (those are labeled)
handles = [
    plt.Line2D([0], [0], color="black", lw=2.2, marker="o", ms=5,
               markerfacecolor="white", markeredgewidth=1.6, label="Median"),
    plt.Rectangle((0, 0), 1, 1, fc="#888888", alpha=0.25, label="IQR (25–75th pct.)"),
    plt.Line2D([0], [0], color="#aaaaaa", lw=1.2, alpha=0.6, label="Individual model"),
]
ax.legend(handles=handles, fontsize=9, frameon=True, loc="upper left",
          handlelength=1.6, labelspacing=0.5, borderpad=0.8)

for ext in ("png", "pdf"):
    fp = f"{OUT}/fig_ev_range_trajectory.{ext}"
    fig.savefig(fp, dpi=200 if ext == "png" else 72, bbox_inches="tight")
    print(f"Saved -> {fp}")

# Copy to Overleaf
overleaf = "/Users/jasminehao/Dropbox/Apps/Overleaf/heterogenous_diffusion/figures/fig_ev_range_trajectory.png"
fig.savefig(overleaf, dpi=200, bbox_inches="tight")
print(f"Saved -> {overleaf}")
