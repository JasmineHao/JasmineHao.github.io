"""
Self-contained DIY BLP for the canonical-lite spec.

What it does:
- Reads df.parquet (output of 02_logit_estimation.py)
- Builds X1, X2, Z, agent draws (ν, income_inv_normed)
- Runs BLP inversion (contraction with SQUAREM acceleration)
- Solves GMM over (σ_size, σ_power_gv, σ_range, π_price)
- Custom objective via `gmm_obj_fn` — swap in alternative weighting / penalties

Canonical-lite spec:
  X1 (linear) = log_size + log_power_gv + log_ev_range + ev_range_x_density
              + FuelType FE + BodyType FE + Year FE (no Brand FE for tractability)
  X2 (RC)     = log_price, log_size, log_power_gv, log_ev_range
              σ_price = 0 (fixed)
              σ_log_size, σ_log_power_gv, σ_log_ev_range free
              π_price × income_inv_normed (interaction on log_price)
  Z          = X1[non-price] + BLP differentiation IVs for log_price

Usage:
  python _diy_blp.py                 # default obj: 2-step GMM with W=(Z'Z)^-1
  DIY_OBJ=ridge python _diy_blp.py   # with ridge penalty on σ
"""
import os, sys, time
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from joblib import Parallel, delayed

N_JOBS = int(os.environ.get("DIY_N_JOBS", "-1"))  # -1 = all cores

# =============================================================================
# Constants (match 03_blp_income_ev.py)
# =============================================================================
NS               = 25
SEED             = 2024
SIGMA_LOG_INCOME = 0.307
CONTRACTION_TOL  = 1e-12
CONTRACTION_MAX  = 2000
PROJECT_ROOT     = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# =============================================================================
# 1. Load data + build matrices
# =============================================================================
print("=" * 70)
print("DIY BLP — canonical-lite")
print("=" * 70)

df = pd.read_parquet(f"{PROJECT_ROOT}/output/df.parquet")
print(f"Loaded {len(df):,} rows × {df.shape[1]} cols, "
      f"{df['market_ids'].nunique()} markets")

# Construct gv-side power (=log_power × gv_dummy)
df["log_power_gv"] = (1.0 - df["ev_dummy"]) * df["log_power"]
df["ev_range_x_density"] = df["log_ev_range"] * np.log1p(df["pop_density"]).fillna(0)

# Merge policy panel (subsidies, license advantage, pilot status) on Geo_Market × Year
pp = pd.read_csv(f"{PROJECT_ROOT}/output/policy_panel_merged.csv")
keep_pp = ["Geo_Market", "Year", "ev_license", "is_pilot", "admin_rank",
           "ev_policy_primary", "oil_price"]
df = df.merge(pp[keep_pp], on=["Geo_Market", "Year"], how="left")
df["ev_license"]      = df["ev_license"].fillna(0)
df["is_pilot"]        = df["is_pilot"].fillna(0)
df["admin_rank"]      = df["admin_rank"].fillna(0)
df["ev_policy_primary"] = df["ev_policy_primary"].fillna(0)
df["oil_price"]       = df["oil_price"].fillna(df["oil_price"].mean())
# EV-interacted policy variables (these enter X1 as EV-side utility shifters)
df["ev_x_license"]     = df["ev_dummy"] * df["ev_license"]
df["ev_x_pilot"]       = df["ev_dummy"] * df["is_pilot"]
df["ev_x_policy_str"]  = df["ev_dummy"] * df["ev_policy_primary"]
# 2026-06-12 Path D: add EV × observable city-characteristic interactions to
# X1. With these in, the EV-taste heterogeneity is identified by observable
# city characteristics (higher-income cities like EVs more, etc.) instead of
# by the unobserved σ_ev random coefficient — so σ_ev RC is dropped from X2
# and the BLP estimation stops needing a θ-pin.
df["GDP_per_capita_filled"] = df["GDP_per_capita"].fillna(df["GDP_per_capita"].median())
df["log_pop_density_filled"] = np.log1p(df["pop_density"].fillna(0))
df["urb_rate_filled"] = df["urb_rate"].fillna(df["urb_rate"].median())
df["log_income_city_filled"] = np.log(df["Income_city"].clip(lower=1))
df["ev_x_log_income"]   = df["ev_dummy"] * df["log_income_city_filled"]
df["ev_x_GDPpc"]        = df["ev_dummy"] * df["GDP_per_capita_filled"]
df["ev_x_log_pop_dens"] = df["ev_dummy"] * df["log_pop_density_filled"]
df["ev_x_urb_rate"]     = df["ev_dummy"] * df["urb_rate_filled"]
# Subsidy NOT in X1 — enters mechanically via net_price = sticker - subsidy.
# Adding ev_x_subsidy broke α identification in v11 (collinear with price).
df["log_pop_density"]  = np.log1p(df["pop_density"].fillna(0))
df["GDP_per_capita"]   = df["GDP_per_capita"].fillna(df["GDP_per_capita"].median())
df["urb_rate"]         = df["urb_rate"].fillna(df["urb_rate"].median())
print(f"Policy + macro variables (NO subsidy): "
      f"ev_x_license mean={df['ev_x_license'].mean():.3f}, "
      f"oil_price mean={df['oil_price'].mean():.3f}, "
      f"log_pop_density mean={df['log_pop_density'].mean():.3f}")

# Drop rows missing critical fields
need = ["log_price", "log_size", "log_power_gv", "log_ev_range",
        "shares", "s_0", "market_ids", "Income_city", "FuelType",
        "BodyType", "Year"]
df = df.dropna(subset=need).reset_index(drop=True)

# Sort by (market, product_idx) for fast per-market slicing
df = df.sort_values("market_ids").reset_index(drop=True)
markets = df["market_ids"].unique()
T = len(markets)
mkt_idx = {m: i for i, m in enumerate(markets)}
df["_m_idx"] = df["market_ids"].map(mkt_idx)

# Group ranges (start, end) per market for fast slicing
m_idx_arr = df["_m_idx"].values
mkt_starts = np.searchsorted(m_idx_arr, np.arange(T))
mkt_ends = np.append(mkt_starts[1:], len(df))
print(f"Markets: T={T}, avg J per market = {len(df)/T:.1f}")

# X1: linear characteristics + FE
fuel_d = pd.get_dummies(df["FuelType"], prefix="FT", drop_first=True).astype(float)
body_d = pd.get_dummies(df["BodyType"], prefix="BT", drop_first=True).astype(float)
year_d = pd.get_dummies(df["Year"], prefix="YR", drop_first=True).astype(float)
# 2026-06-12: SizeSegment FE added (MINI, SUBCOMPACT, COMPACT, MIDSIZE, LARGE,
# 跑车). With it, log_size β captures within-segment variation only; broad
# size-class preferences (e.g. consumers prefer MIDSIZE over MINI) go into the
# SS FE. Expected effect: β_log_size moves toward 0 or positive, and the
# A_attrs Shapley reflects a cleaner attribute-upgrading channel.
ss_d = pd.get_dummies(df["SizeSegment"], prefix="SS", drop_first=True).astype(float)

# Firm group (BYD, Foreign/JV, Trad. OEM, New Forces, Private National, Other)
sys.path.insert(0, f"{PROJECT_ROOT}/code")
from _brand_groups import assign_firm_group
df = assign_firm_group(df, src_col="Manufacturer", out_col="firm_group")
print(f"Firm groups: {df['firm_group'].value_counts().to_dict()}")
fg_d = pd.get_dummies(df["firm_group"], prefix="FG", drop_first=True).astype(float)

# EV × Year interactions DROPPED (2026-06-12 spec fix). With both year FE and
# log_ev_range in X1, EV × Year is collinear with log_ev_range — long-range EVs
# only became common in recent years, so EV × Y_2022/2023/2024 absorbs the
# range effect and forces β_log_ev_range to a wrong (negative) sign. Dropping
# EV × Year lets log_ev_range carry the EV-time-range joint variation and gives
# β_log_ev_range > 0 (consumers prefer longer range). The "EV got popular over
# time" effect now goes into ξ — interpretable as unobserved demand shock that
# evolves with the EV trend.
ev_yr_cols = []
ev_yr_arr = np.zeros((len(df), 0))
print(f"EV × Year interactions: DROPPED (2026-06-12 spec fix; range sign was wrong with them in)")

# log_size DROPPED 2026-06-12. log_size is +0.62 to +0.76 correlated with
# log_price, and its partial coefficient comes out negative (β≈-0.7) — not a
# credible direct utility channel, just a price-collinear residual. Earlier
# attempt to drop it broke β_log_price (flipped to +7.9), but that was an IV
# weakness, not a sign log_size should stay; we beef up Z_bat below to identify
# β_log_price independently. SizeSegment FE (added above) carries the size-class
# preference channel.
x1_attr = df[["log_power_gv", "log_ev_range", "ev_range_x_density"]].values
x1_fe   = np.column_stack([fuel_d.values, body_d.values, ss_d.values, year_d.values,
                            fg_d.values, ev_yr_arr])

# Price enters utility in log form (Path D canonical spec).
price_col = df["log_price"].values
price_name = "log_price"
print(f"[PRICE] LOG: log(net price), mean={price_col.mean():.3f}")

# v12 spec: policy + macro + income variables in X1 (NO subsidy — enters via net_price).
# Each gets its own β. Decomposition can then toggle these blocks.
df["log_income_city"] = np.log(df["Income_city"])
policy_x1_cols = ["ev_x_license", "ev_x_pilot", "ev_x_policy_str",
                  "ev_x_log_income", "ev_x_GDPpc",
                  "ev_x_log_pop_dens", "ev_x_urb_rate",
                  "oil_price", "log_pop_density", "GDP_per_capita", "urb_rate",
                  "log_income_city"]
policy_x1_arr = df[policy_x1_cols].values
# Standardize macro vars to avoid scale issues
for i, col in enumerate(policy_x1_cols):
    sd = policy_x1_arr[:, i].std()
    if sd > 1e-6:
        policy_x1_arr[:, i] = (policy_x1_arr[:, i] - policy_x1_arr[:, i].mean()) / sd
print(f"v12 X1 policy/macro additions: {len(policy_x1_cols)} cols (standardized)")

X1      = np.column_stack([price_col[:, None], x1_attr, policy_x1_arr, x1_fe])
x1_names = ([price_name, "log_power_gv", "log_ev_range", "ev_range_x_density"]
            + policy_x1_cols
            + list(fuel_d.columns) + list(body_d.columns) + list(ss_d.columns)
            + list(year_d.columns) + list(fg_d.columns) + ev_yr_cols)
print(f"X1: shape {X1.shape}, cols = {x1_names[:5]} + {X1.shape[1]-5} FE")

# X2: log_price + ev_dummy. RC ONLY on ev_dummy (captures heterogeneous taste for
# EVs across consumers). σ on continuous attrs (size/power/range) dropped — they
# are absorbed by the linear X1 β's and FuelType FE.
X2 = np.column_stack([price_col, df["ev_dummy"].values])
print(f"X2 cols: [{price_name}, ev_dummy] (2 cols)")
# X2[:,0]=price has π × inc_inv interaction; X2[:,1]=ev_dummy has σ_ev × ν

# =============================================================================
# 2. Build instruments Z
# =============================================================================
# BLP differentiation IVs: for each non-price X2 attr k, compute
#   z_jk = Σ_{l ≠ j in same market} X_lk
# Plus sum of squared differences (Gandhi-Houde).
def build_diff_ivs(attrs, m_starts, m_ends):
    """attrs: (N, K) — returns (N, 2K) of [sum_rivals_X, sum_rivals_X²]."""
    N, K = attrs.shape
    out = np.zeros((N, 2 * K))
    for s, e in zip(m_starts, m_ends):
        x = attrs[s:e]
        sum_x = x.sum(0)
        sum_x2 = (x**2).sum(0)
        out[s:e, :K]  = sum_x[None, :] - x
        out[s:e, K:]  = sum_x2[None, :] - x**2
    return out

# Differentiation IVs from non-price attributes (rivals' attrs as IVs for j's price)
print("Building BLP differentiation IVs...")
t0 = time.time()
Z_diff = build_diff_ivs(x1_attr, mkt_starts, mkt_ends)
print(f"  done in {time.time()-t0:.1f}s, Z_diff (market-level): {Z_diff.shape}")

# WITHIN-FUELTYPE differentiation IVs (Gandhi-Houde style nested IVs)
# For each (market, FuelType) group, compute sum-of-rivals' and squared-diff for
# each attribute. These vary nonlinearly with σ → help identify σ identification.
def build_nested_ivs(attrs, market_ids, fueltype, m_starts, m_ends):
    N, K = attrs.shape
    out = np.zeros((N, 2 * K + 1))
    ft_codes = pd.Categorical(fueltype).codes
    for s, e in zip(m_starts, m_ends):
        ft_m = ft_codes[s:e]
        for ft_val in np.unique(ft_m):
            idx = np.where(ft_m == ft_val)[0]
            if len(idx) < 2:
                continue
            x_ft = attrs[s:e][idx]
            sum_x = x_ft.sum(0)
            sum_x2 = (x_ft**2).sum(0)
            count_ft = len(idx)
            for kk, ii in enumerate(idx):
                out[s + ii, :K]    = sum_x - x_ft[kk]                   # sum of rivals
                out[s + ii, K:2*K] = sum_x2 - x_ft[kk]**2                # sum of rivals²
                out[s + ii, 2*K]   = count_ft                            # count
    return out
print("Building within-FuelType nested IVs...")
t0 = time.time()
Z_nest = build_nested_ivs(x1_attr, df["market_ids"].values, df["FuelType"].values,
                           mkt_starts, mkt_ends)
print(f"  done in {time.time()-t0:.1f}s, Z_nest shape {Z_nest.shape}")

# Battery cost (BNEF) — annual exogenous cost shifter
bat = pd.read_csv(f"{PROJECT_ROOT}/raw_data/battery_cost_bnef.csv")
bat_map = dict(zip(bat["year"], bat["battery_pack_usd_kwh"]))
df["bat_usd_kwh"] = df["Year"].map(bat_map).ffill().bfill()
# Multiply by ev_dummy so it's a cost shifter only for EVs (cost shock identifies α via EV price variation)
df["bat_x_ev"] = df["bat_usd_kwh"] * df["ev_dummy"]
# 2026-06-12: expanded battery-cost IV set (5 cols) to identify β_log_price
# without leaning on log_size in X1. First-stage F-test:  ΔR² = +0.014 over
# FT+BT+SS+YR FE base. Components: FT-specific battery cost (BEV/PHEV/REEV) +
# log_battery_capacity (exog cost-driven design choice) + bat × battery_capacity
# interaction (heavier-battery products are more sensitive to per-kWh cost).
df["bat_x_BEV"]  = df["bat_usd_kwh"] * (df["FuelType"] == "BEV").astype(float)
df["bat_x_PHEV"] = df["bat_usd_kwh"] * (df["FuelType"] == "PHEV").astype(float)
df["bat_x_REEV"] = df["bat_usd_kwh"] * (df["FuelType"] == "REEV").astype(float)
df["log_batcap"] = df["log_battery_capacity"].fillna(0).astype(float)
df["bat_x_batcap"] = df["bat_usd_kwh"] * df["log_batcap"]
Z_bat = df[["bat_x_BEV", "bat_x_PHEV", "bat_x_REEV",
             "log_batcap", "bat_x_batcap"]].values
print(f"Battery cost IVs (5-col v2): BNEF panel, mean={df['bat_usd_kwh'].mean():.1f} USD/kWh, "
      f"range [{df['bat_usd_kwh'].min():.0f}, {df['bat_usd_kwh'].max():.0f}]")

# Final Z = X1[non-price] + Z_diff (market) + Z_nest (FuelType nested) + Z_bat (cost)
Z = np.column_stack([X1[:, 1:], Z_diff, Z_nest, Z_bat])  # X1[:,0] = price is endogenous
print(f"Z: shape {Z.shape}  ({X1.shape[1]-1} exog X1 + {Z_diff.shape[1]} market diff "
      f"+ {Z_nest.shape[1]} nested + {Z_bat.shape[1]} battery)")

# Observed shares
s_obs = df["shares"].values
s_out = df["s_0"].values
print(f"Shares: median={np.median(s_obs):.2e}, outside-share median={np.median(s_out):.3f}")

# =============================================================================
# 3. Agent draws (ν, income_inv_normed) — match 03's RNG
# =============================================================================
income_by_market = df.groupby("market_ids")["Income_city"].first().reindex(markets).values
mean_inv = np.mean(1.0 / income_by_market)
rng = np.random.default_rng(SEED)
nu_attrs = rng.standard_normal((T, NS, 1))                       # σ_ev_dummy only
nu_inc   = rng.standard_normal((T, NS))                          # for income draws
income_draws = income_by_market[:, None] * np.exp(SIGMA_LOG_INCOME * nu_inc)
income_inv_normed = 1.0 / (income_draws * mean_inv)              # (T, NS), mean≈1
agent_w = np.full(NS, 1.0 / NS)
print(f"Agent data: NS={NS}, income_inv_normed mean={income_inv_normed.mean():.3f}")

# =============================================================================
# 4. Per-market share computation + BLP inversion
# =============================================================================
def market_shares(delta, sigma_attr, pi_p, X2_m, nu_m, inc_inv_m):
    """
    sigma_attr:   (1,) σ_ev_dummy only
    X2_m:         (J, 2) — cols [log_p, ev_dummy]
    nu_m:         (NS, 1) — ν for σ_ev
    """
    mu_price = pi_p * np.outer(X2_m[:, 0], inc_inv_m)              # (J, NS)
    mu_attr  = X2_m[:, 1:2] @ (sigma_attr[:, None] * nu_m.T)       # (J, NS) RC on ev_dummy
    u = delta[:, None] + mu_price + mu_attr                         # (J, NS)
    # Stable softmax with outside option u_0=0: shift by max(0, max u).
    u_max = np.maximum(0.0, u.max(axis=0, keepdims=True))           # (1, NS)
    e = np.exp(u - u_max)                                            # ≤ 1
    e0 = np.exp(-u_max[0])                                          # outside option ≤ 1
    denom = e0 + e.sum(axis=0)                                      # (NS,)
    s_ij = e / denom[None, :]                                       # (J, NS)
    return s_ij @ agent_w                                           # (J,)

def invert_delta(s_obs_m, sigma_attr, pi_p, X2_m, nu_m, inc_inv_m,
                 delta_init=None, tol=CONTRACTION_TOL, maxit=CONTRACTION_MAX):
    """BLP contraction with SQUAREM acceleration.
    Converges when ||log(s_obs) - log(s_pred)||_inf < tol (the actual share residual).
    """
    if delta_init is None:
        s0 = max(1.0 - s_obs_m.sum(), 1e-10)
        delta = np.log(s_obs_m) - np.log(s0)
    else:
        delta = delta_init.copy()
    log_s_obs = np.log(s_obs_m)

    for it in range(maxit):
        # Two BLP fixed-point steps
        s1 = market_shares(delta, sigma_attr, pi_p, X2_m, nu_m, inc_inv_m)
        r1 = log_s_obs - np.log(np.maximum(s1, 1e-300))
        if np.max(np.abs(r1)) < tol:
            return delta, it
        delta1 = delta + r1

        s2 = market_shares(delta1, sigma_attr, pi_p, X2_m, nu_m, inc_inv_m)
        r2 = log_s_obs - np.log(np.maximum(s2, 1e-300))
        if np.max(np.abs(r2)) < tol:
            return delta1, it
        delta2 = delta1 + r2

        # SQUAREM acceleration with safeguard
        v = r2 - r1
        norm_v = np.linalg.norm(v)
        if norm_v < 1e-30:
            delta = delta2
            continue
        alpha = -np.linalg.norm(r1) / norm_v
        delta_sq = delta - 2 * alpha * r1 + alpha**2 * v
        s_sq = market_shares(delta_sq, sigma_attr, pi_p, X2_m, nu_m, inc_inv_m)
        if not np.isfinite(s_sq).all() or (s_sq <= 0).any():
            delta = delta2
        else:
            r_sq = log_s_obs - np.log(np.maximum(s_sq, 1e-300))
            delta = delta_sq + r_sq

    return delta, maxit

# =============================================================================
# 5. GMM objective (PLUGGABLE)
# =============================================================================
def _invert_one(t, sigma_attr, pi_p, delta_init):
    s, e = mkt_starts[t], mkt_ends[t]
    d_t, _ = invert_delta(s_obs[s:e], sigma_attr, pi_p,
                          X2[s:e], nu_attrs[t], income_inv_normed[t],
                          delta_init=delta_init)
    return t, d_t

_obj_eval_count = [0]
_t_first_obj = [None]
_best = {"obj": np.inf, "theta": None}
def compute_residuals(theta, delta_cache=None):
    """
    theta = (σ_size, σ_power, π_price). σ_log_ev_range LOCKED at 0.
    Returns δ_hat (per-product).
    """
    _obj_eval_count[0] += 1
    t0 = time.time()
    if _t_first_obj[0] is None: _t_first_obj[0] = t0
    sigma_attr = np.array([float(theta[0])])  # σ_ev_dummy
    pi_p = float(theta[1])
    delta_all = np.empty(len(df))

    # delta_cache DISABLED for determinism — always start from logit init.
    results = Parallel(n_jobs=N_JOBS, batch_size=20, verbose=0)(
        delayed(_invert_one)(t, sigma_attr, pi_p, None) for t in range(T)
    )
    max_resid = 0.0
    for t, d_t in results:
        s, e = mkt_starts[t], mkt_ends[t]
        delta_all[s:e] = d_t
    return delta_all

# Drop all-zero FE columns (singletons / empty interactions)
nz = np.array([(X1[:, j] != 0).sum() > 5 for j in range(X1.shape[1])])
if not nz.all():
    dropped = [n for n, k in zip(x1_names, nz) if not k]
    print(f"  Dropping {(~nz).sum()} near-empty X1 cols: {dropped[:8]}...")
    X1 = X1[:, nz]
    x1_names = [n for n, k in zip(x1_names, nz) if k]
# Rebuild full Z (for 2SLS β recovery)
Z_X1exog = X1[:, 1:]
Z = np.column_stack([Z_X1exog, Z_diff, Z_nest, Z_bat])
# EXCLUDED IVs only (for GMM moments — these carry σ identification)
Z_excl = np.column_stack([Z_diff, Z_nest, Z_bat])
print(f"After dropping empties: X1 shape {X1.shape}, Z shape {Z.shape} "
      f"(of which {Z_excl.shape[1]} excluded IVs for GMM moments)")

# Precompute matrices for 2SLS β recovery (uses full Z, all rows)
ZTZ_inv = np.linalg.pinv(Z.T @ Z, rcond=1e-10)
ZT_X1   = Z.T @ X1
PZ_X1   = Z @ (ZTZ_inv @ ZT_X1)
A_2SLS  = np.linalg.pinv(PZ_X1.T @ X1, rcond=1e-10) @ (PZ_X1.T)
# Stacked GMM moments: EV products and GV products contribute SEPARATELY.
# obj = g_EV' W_EV g_EV + g_GV' W_GV g_GV
# EV moments identify σ_size + σ_range (since log_power_gv=0 on EV).
# GV moments identify σ_size + σ_power_gv (since log_ev_range=0 on GV).
ev_mask_arr = (df["ev_dummy"].values == 1)
gv_mask_arr = ~ev_mask_arr
N_ev = int(ev_mask_arr.sum())
N_gv = int(gv_mask_arr.sum())
Z_excl_ev = Z_excl[ev_mask_arr]
Z_excl_gv = Z_excl[gv_mask_arr]
ZeTZe_inv_ev = np.linalg.pinv(Z_excl_ev.T @ Z_excl_ev, rcond=1e-10)
ZeTZe_inv_gv = np.linalg.pinv(Z_excl_gv.T @ Z_excl_gv, rcond=1e-10)
print(f"Stacked moments: {N_ev:,} EV rows + {N_gv:,} GV rows "
      f"(of {len(df):,} total)")

def beta_2sls(delta_all):
    return A_2SLS @ delta_all

def gmm_obj_default(theta, W=None, delta_cache=None, return_extras=False):
    """Stacked GMM: obj = g_EV' W_EV g_EV + g_GV' W_GV g_GV.
    Each product type's moment block contributes separately, isolating
    EV-side σ identification from GV-side σ identification.
    """
    t0 = time.time()
    delta_all = compute_residuals(theta, delta_cache=delta_cache)
    beta = beta_2sls(delta_all)
    xi = delta_all - X1 @ beta
    xi_ev = xi[ev_mask_arr]
    xi_gv = xi[gv_mask_arr]
    g_ev = Z_excl_ev.T @ xi_ev / N_ev
    g_gv = Z_excl_gv.T @ xi_gv / N_gv
    W_ev = ZeTZe_inv_ev * N_ev
    W_gv = ZeTZe_inv_gv * N_gv
    val = float(g_ev @ W_ev @ g_ev + g_gv @ W_gv @ g_gv)
    g = np.concatenate([g_ev, g_gv])
    elapsed = time.time() - t0
    sa = np.asarray(theta[:1]); pp = float(theta[1])
    is_new_best = val < _best["obj"]
    if is_new_best:
        _best["obj"] = val
        _best["theta"] = np.asarray(theta).copy()
    flag = " *NEW BEST*" if is_new_best else ""
    print(f"  [eval {_obj_eval_count[0]:3d}] σ_ev={sa[0]:.4f} "
          f"π={pp:+.4f}  obj={val:.6e}  ({elapsed:.1f}s){flag}", flush=True)
    if return_extras:
        return val, {"delta": delta_all, "beta": beta, "xi": xi, "g": g}
    return val

# OBJ HOOK — user can override:
gmm_obj_fn = gmm_obj_default
_obj_choice = os.environ.get("DIY_OBJ", "default")
if _obj_choice == "ridge":
    LAMBDA_RIDGE = float(os.environ.get("DIY_RIDGE", "0.01"))
    def gmm_obj_fn(theta, **kw):
        val = gmm_obj_default(theta, **kw)
        sigma_attr = np.asarray(theta[:1])
        # Ridge penalty: keeps σ from boundary (BUT user can specify their own)
        return val + LAMBDA_RIDGE * (sigma_attr**2).sum()
    print(f"[OBJ] ridge: λ = {LAMBDA_RIDGE}")
else:
    print(f"[OBJ] default GMM with W = (Z'Z)^{{-1}}")

# =============================================================================
# 6. Optimize
# =============================================================================
# Determinism sanity check: call obj twice at same theta
print("\n=== Sanity check: obj must be deterministic at fixed θ ===")
_test_theta = np.array([0.5, -3.0])
_v1 = gmm_obj_default(_test_theta)
_v2 = gmm_obj_default(_test_theta)
_v3 = gmm_obj_default(_test_theta)
print(f"  obj(θ) called 3×: {_v1:.6e}, {_v2:.6e}, {_v3:.6e}")
print(f"  max diff = {max(abs(_v1-_v2), abs(_v2-_v3)):.3e}")
if abs(_v1 - _v2) / max(abs(_v1), 1) > 1e-6:
    print("  ⚠ NONDETERMINISTIC — investigate before optimizing")
else:
    print("  ✓ deterministic, proceed")

# 2026-06-12 Path D: σ_ev RC is dropped from the spec because the EV-taste
# heterogeneity is now identified by observable EV × city-characteristic
# interactions (ev_x_log_income, ev_x_GDPpc, ev_x_log_pop_dens, ev_x_urb_rate
# in X1). σ_ev is therefore HARDCODED at 0 — the only nonlinear parameter
# left for Nelder-Mead is π.
theta_init = np.array([0.0, -3.0])
bounds = [(0.0, 0.0), (-12.0, 0.0)]  # σ_ev forced to 0
delta_cache = None  # disabled for determinism
print(f"\nInitial θ: σ_ev={theta_init[0]:.2f}, π={theta_init[1]:.2f}")

# Nelder-Mead with soft bound penalty
LB = np.array([b[0] for b in bounds])
UB = np.array([b[1] for b in bounds])
def gmm_obj_penalized(th):
    if (th < LB).any() or (th > UB).any():
        pen = 1e6 * (np.maximum(0, LB - th)**2 + np.maximum(0, th - UB)**2).sum()
        return _best["obj"] + pen if np.isfinite(_best["obj"]) else 1e15 + pen
    return gmm_obj_fn(th, delta_cache=delta_cache)

# BLP_PIN_THETA="σ_ev,π" — skip Nelder-Mead, fix θ̂ at the supplied values.
# Used to reproduce the v5 cached point estimates exactly before computing SE
# (the GMM objective has corner solutions that are unstable across solver runs).
PIN_THETA = os.environ.get("BLP_PIN_THETA", "").strip()
if PIN_THETA:
    pin_vals = [float(x) for x in PIN_THETA.split(",")]
    assert len(pin_vals) == 2, f"BLP_PIN_THETA expects 2 comma-separated floats, got {PIN_THETA}"
    print(f"[PIN] θ̂ pinned at BLP_PIN_THETA = {pin_vals}; skipping Nelder-Mead")
    class _PinnedRes:  # mimic OptimizeResult interface
        x = np.array(pin_vals)
        message = f"PINNED at {pin_vals}"
    res = _PinnedRes()
    res.fun = float(gmm_obj_default(res.x))
    print(f"  obj at pinned θ̂ = {res.fun:.6e}")
else:
    print("Optimizing (Nelder-Mead, simplex)...")
    t0 = time.time()
    # Use a non-degenerate initial simplex (3 vertices in 2D). Path D: σ_ev
    # is locked at 0 via the (0,0) bound on dim 0, so simplex moves only in
    # the π direction.
    initial_simplex = np.vstack([
        theta_init,
        theta_init + np.array([0.0, +1.0]),
        theta_init + np.array([0.0, -1.0]),
    ])
    res = minimize(
        gmm_obj_penalized,
        theta_init,
        method="Nelder-Mead",
        options={"initial_simplex": initial_simplex, "maxiter": 100,
                 "xatol": 1e-3, "fatol": 1e-3, "disp": True, "adaptive": True},
    )
    print(f"  done in {time.time()-t0:.1f}s, status={res.message}")
    # Use best-seen θ (Nelder-Mead may not return it)
    if _best["theta"] is not None and _best["obj"] < res.fun:
        print(f"  using best-seen θ (obj={_best['obj']:.4e}) instead of final (obj={res.fun:.4e})")
        res.x = _best["theta"]
        res.fun = _best["obj"]

# =============================================================================
# 7. Report
# =============================================================================
theta_hat = res.x
sigma_hat = theta_hat[:1]  # σ_ev_dummy only
pi_hat = theta_hat[1]
val, extras = gmm_obj_default(theta_hat, delta_cache=delta_cache, return_extras=True)
beta_hat = extras["beta"]
xi_hat = extras["xi"]
delta_blp_hat = extras["delta"].copy()  # BLP-inverted δ at θ̂, aligned with `df`

print("\n" + "=" * 70)
print("DIY BLP RESULTS (stacked EV+GV moments)")
print("=" * 70)
print(f"Objective: {res.fun:.4f}  (final), {val:.4f}  (recomputed)")
print(f"\n--- NONLINEAR (X2 RC) ---")
print(f"σ_ev_dummy       = {sigma_hat[0]:.4f}    (RC on EV indicator)")
print(f"π_{price_name}×inc⁻¹ = {pi_hat:.4f}")

print(f"\n--- LINEAR (X1) — all {len(beta_hat)} coefficients ---")
for nm, b in zip(x1_names, beta_hat):
    print(f"  {nm:30s} = {b:+10.4f}")

print(f"\n--- IMPLIED PRICE COEFFICIENTS ---")
print(f"β_{price_name} (mean utility)   = {beta_hat[0]:+.4f}")
print(f"π_{price_name} × inc_inv         = {pi_hat:+.4f}  (× inc_inv_normed; mean=1)")
print(f"Effective α at avg income    = β + π = {beta_hat[0] + pi_hat:+.4f}")
print(f"  → mean own-price elasticity ≈ β + π = {beta_hat[0] + pi_hat:.2f}")

# =============================================================================
# 7b. Standard errors — GMM sandwich, market-clustered
# =============================================================================
# Canonical pyblp-style inference at the converged θ̂ = (σ_ev, π, β):
#   Moment vector:   g(θ) = Z' ξ / N        (full Z = [X1_exog, Z_excl])
#   Weighting:       W    = N (Z'Z)^{-1}
#   Jacobian:        G    = [∂g/∂σ_ev | ∂g/∂π | ∂g/∂β]
#                          - ∂g/∂(σ,π): central finite diff via ∂δ/∂θ_NL
#                          - ∂g/∂β     = -Z'X1 / N      (analytic)
#   Cluster S:       S    = Σ_m s_m s_m',  s_m = Z_m' ξ_m / N (cluster = market)
#   Sandwich:        V    = (G'WG)^{-1} G'W S WG (G'WG)^{-1}
# β at convergence satisfies X1_exog' ξ = 0 by 2SLS construction, so the
# subset of g corresponding to X1_exog rows is exactly zero at θ̂; the SE
# formula remains the standard pyblp form.
print("\n" + "=" * 70)
print("STANDARD ERRORS (GMM sandwich, market-clustered)")
print("=" * 70)

from scipy.stats import norm

N_full = len(df)
n_Z = Z.shape[1]
K_beta = len(beta_hat)
n_params = 2 + K_beta

ZtZ_inv_full = np.linalg.pinv(Z.T @ Z, rcond=1e-12)
W_se = N_full * ZtZ_inv_full

# Analytic Jacobian columns for β
G_beta = -(Z.T @ X1) / N_full                      # (n_Z, K_beta)

# Central finite difference for ∂g/∂(σ_ev, π) via ∂δ/∂θ_NL
print(f"Finite-differencing ∂δ/∂θ_NL (2 params × 2 sides = 4 BLP solves)...")
G_nl = np.zeros((n_Z, 2))
for j in range(2):
    h = max(1e-3 * abs(float(theta_hat[j])), 1e-4)
    th_plus = theta_hat.copy(); th_plus[j] += h
    th_minus = theta_hat.copy(); th_minus[j] -= h
    t0_fd = time.time()
    d_plus = compute_residuals(th_plus)
    d_minus = compute_residuals(th_minus)
    dd_dtheta = (d_plus - d_minus) / (2 * h)
    G_nl[:, j] = Z.T @ dd_dtheta / N_full
    print(f"  θ[{j}] (h={h:.2e}) in {time.time()-t0_fd:.1f}s")

G_se = np.hstack([G_nl, G_beta])                   # (n_Z, n_params)

# Cluster-robust S (cluster = market_ids)
print(f"Cluster-robust S accumulation (T={T} markets)...")
t0_S = time.time()
S_se = np.zeros((n_Z, n_Z))
for t_m in range(T):
    s_i, e_i = mkt_starts[t_m], mkt_ends[t_m]
    if e_i <= s_i:
        continue
    Z_m = Z[s_i:e_i]
    xi_m = xi_hat[s_i:e_i]
    s_m = (Z_m.T @ xi_m) / N_full
    S_se += np.outer(s_m, s_m)
print(f"  done in {time.time()-t0_S:.1f}s")

# HC1 (heteroskedasticity-only, no cluster): S_HC = (1/N²) Σ_i (z_i ξ_i)(z_i ξ_i)'
# Vectorized: equivalent to Z' diag(ξ²) Z / N²
print("HC1 (no-cluster) S accumulation...")
t0_HC = time.time()
xi_sq = xi_hat ** 2
S_HC = (Z.T * xi_sq) @ Z / (N_full ** 2)
print(f"  done in {time.time()-t0_HC:.1f}s")

# (1) Sandwich + cluster (default)
GtW = G_se.T @ W_se                                # (n_params, n_Z)
A_mat = GtW @ G_se
A_inv = np.linalg.pinv(A_mat, rcond=1e-12)
V_sw_cluster = A_inv @ (GtW @ S_se @ GtW.T) @ A_inv
se_sw_cluster = np.sqrt(np.maximum(np.diag(V_sw_cluster), 0.0))

# (2) Sandwich + HC1 (no cluster)
V_sw_HC = A_inv @ (GtW @ S_HC @ GtW.T) @ A_inv
se_sw_HC = np.sqrt(np.maximum(np.diag(V_sw_HC), 0.0))

# (3) 2-step optimal weighting: W* = Ŝ_cluster⁻¹; V_opt = (G' Ŝ⁻¹ G)⁻¹
S_cluster_inv = np.linalg.pinv(S_se, rcond=1e-12)
V_opt = np.linalg.pinv(G_se.T @ S_cluster_inv @ G_se, rcond=1e-12)
se_opt = np.sqrt(np.maximum(np.diag(V_opt), 0.0))

# (4) 2-step optimal weighting with HC1 meat: W* = Ŝ_HC⁻¹
S_HC_inv = np.linalg.pinv(S_HC, rcond=1e-12)
V_opt_HC = np.linalg.pinv(G_se.T @ S_HC_inv @ G_se, rcond=1e-12)
se_opt_HC = np.sqrt(np.maximum(np.diag(V_opt_HC), 0.0))

# Default reported: 2-step optimal weighting + market cluster (pyblp default,
# V = (G' Ŝ⁻¹ G)⁻¹). The sandwich + cluster variant is also computed above and
# can be substituted by changing this assignment.
se_full = se_opt
se_sigma = float(se_full[0])
se_pi    = float(se_full[1])
se_beta  = se_full[2:]

# ── Diagnostic side-by-side table ───────────────────────────────────────────
def _row(label, est, ses_dict):
    out = f"  {label:<22s}  {est:+8.4f}"
    for nm, se in ses_dict.items():
        t_v = est / max(se, 1e-12) if se > 0 else np.nan
        out += f"   {se:7.4f} (t={t_v:+5.2f})"
    return out
print("\nSE comparison across estimators:")
print(f"  {'param':<22s}  {'estimate':>8s}   "
      f"{'sw+cluster':>17s}   {'sw+HC1':>17s}   {'opt+cluster':>17s}   {'opt+HC1':>17s}")
print("  " + "-" * 110)
for j, (lab, est) in enumerate([
    ("σ_ev_dummy", float(sigma_hat[0])),
    (f"π_{price_name}", float(pi_hat)),
    (f"β_{price_name}", float(beta_hat[0])),
]):
    ses = {
        "sw+cluster":  float(se_sw_cluster[j]),
        "sw+HC1":      float(se_sw_HC[j]),
        "opt+cluster": float(se_opt[j]),
        "opt+HC1":     float(se_opt_HC[j]),
    }
    print(_row(lab, est, ses))
print(f"\n  Default reported in csv: 2-step optimal (G' Ŝ⁻¹ G)⁻¹ + market cluster.")
print(f"  Median β SE — sw+cluster: {np.median(se_sw_cluster[2:]):.4f}  "
      f"sw+HC1: {np.median(se_sw_HC[2:]):.4f}  "
      f"opt+cluster: {np.median(se_opt[2:]):.4f}  "
      f"opt+HC1: {np.median(se_opt_HC[2:]):.4f}")

# Save extended diy_blp_v12.csv with SE / t / p columns
all_params = (["sigma_ev_dummy", f"pi_{price_name}"]
              + [f"beta_{nm}" for nm in x1_names]
              + ["n_obs", "obj"])
est_core = [float(sigma_hat[0]), float(pi_hat)] + list(map(float, beta_hat))
se_core  = [se_sigma, se_pi] + list(map(float, se_beta))
t_core   = [(e / s) if s > 0 else np.nan for e, s in zip(est_core, se_core)]
p_core   = [2 * (1 - norm.cdf(abs(tv))) if np.isfinite(tv) else np.nan for tv in t_core]
estimates_full = est_core + [float(len(df)), float(res.fun)]
ses_full       = se_core  + [np.nan, np.nan]
ts_full        = t_core   + [np.nan, np.nan]
ps_full        = p_core   + [np.nan, np.nan]
out = pd.DataFrame({
    "param":    all_params,
    "estimate": estimates_full,
    "se":       ses_full,
    "t":        ts_full,
    "p":        ps_full,
})
out.to_csv(f"{PROJECT_ROOT}/output/diy_blp_v12.csv", index=False)
print(f"\nSaved → output/diy_blp_v12.csv ({len(all_params)} params, with SE/t/p)")

# =============================================================================
# 7c. OLS logit + IV logit (same X1/Z spec — for comparison tables)
# =============================================================================
print("\n" + "=" * 70)
print("OLS LOGIT + IV LOGIT (same X1/Z spec as RC BLP)")
print("=" * 70)

delta_logit = np.log(np.maximum(s_obs, 1e-300)) - np.log(np.maximum(s_out, 1e-300))

# OLS logit
_XTX_inv_ols = np.linalg.pinv(X1.T @ X1, rcond=1e-10)
beta_ols_logit = _XTX_inv_ols @ X1.T @ delta_logit
e_ols_logit    = delta_logit - X1 @ beta_ols_logit
rss_ols_logit  = float(np.sum(e_ols_logit ** 2))
tss_logit      = float(np.sum((delta_logit - delta_logit.mean()) ** 2))
r2_ols_logit   = 1.0 - rss_ols_logit / tss_logit
B_ols_l = np.zeros((X1.shape[1], X1.shape[1]))
for _s, _e in zip(mkt_starts, mkt_ends):
    _g = X1[_s:_e].T @ e_ols_logit[_s:_e]
    B_ols_l += np.outer(_g, _g)
V_ols_l = _XTX_inv_ols @ B_ols_l @ _XTX_inv_ols
se_ols_l = np.sqrt(np.maximum(np.diag(V_ols_l), 0.0))
t_ols_l  = [(b / s if s > 0 else np.nan) for b, s in zip(beta_ols_logit, se_ols_l)]
p_ols_l  = [2*(1 - norm.cdf(abs(tv))) if np.isfinite(tv) else np.nan for tv in t_ols_l]
ols_logit_rows = (list(zip(x1_names, beta_ols_logit, se_ols_l, t_ols_l, p_ols_l))
                  + [("n_obs", float(len(df)), np.nan, np.nan, np.nan),
                     ("r2", r2_ols_logit, np.nan, np.nan, np.nan)])
ols_logit_df = pd.DataFrame(ols_logit_rows, columns=["param","estimate","se","t","p"])
ols_logit_df.to_csv(f"{PROJECT_ROOT}/output/ols_logit_v12.csv", index=False)
print(f"OLS logit: β_{price_name}={beta_ols_logit[0]:.4f} (se={se_ols_l[0]:.4f}), R²={r2_ols_logit:.4f}")
print(f"Saved → output/ols_logit_v12.csv ({len(x1_names)} params)")

# IV logit (uses existing A_2SLS)
beta_iv_logit = A_2SLS @ delta_logit
e_iv_logit    = delta_logit - X1 @ beta_iv_logit
_PZX1_TX_inv = np.linalg.pinv(PZ_X1.T @ X1, rcond=1e-10)
B_iv_l = np.zeros((X1.shape[1], X1.shape[1]))
for _s, _e in zip(mkt_starts, mkt_ends):
    _g = PZ_X1[_s:_e].T @ e_iv_logit[_s:_e]
    B_iv_l += np.outer(_g, _g)
V_iv_l = _PZX1_TX_inv @ B_iv_l @ _PZX1_TX_inv
se_iv_l = np.sqrt(np.maximum(np.diag(V_iv_l), 0.0))
t_iv_l  = [(b / s if s > 0 else np.nan) for b, s in zip(beta_iv_logit, se_iv_l)]
p_iv_l  = [2*(1 - norm.cdf(abs(tv))) if np.isfinite(tv) else np.nan for tv in t_iv_l]
# First-stage F for price
_X_exog_d = X1[:, 1:]   # all X1 except price
_Z_excl_d = Z_excl      # excluded IVs
_Zfull_d  = np.column_stack([_X_exog_d, _Z_excl_d])
_k_excl   = _Z_excl_d.shape[1]
_K_full   = _Zfull_d.shape[1]
_b_full, _, _, _  = np.linalg.lstsq(_Zfull_d, price_col, rcond=None)
_rss_full  = float(np.sum((price_col - _Zfull_d @ _b_full)**2))
_b_restr, _, _, _ = np.linalg.lstsq(_X_exog_d, price_col, rcond=None)
_rss_restr = float(np.sum((price_col - _X_exog_d @ _b_restr)**2))
fs_F_demand = (_rss_restr - _rss_full) / _k_excl / (_rss_full / (len(df) - _K_full))
iv_logit_rows = (list(zip(x1_names, beta_iv_logit, se_iv_l, t_iv_l, p_iv_l))
                 + [("n_obs", float(len(df)), np.nan, np.nan, np.nan),
                    ("first_stage_F", fs_F_demand, np.nan, np.nan, np.nan)])
iv_logit_df = pd.DataFrame(iv_logit_rows, columns=["param","estimate","se","t","p"])
iv_logit_df.to_csv(f"{PROJECT_ROOT}/output/iv_logit_v12.csv", index=False)
print(f"IV logit:  β_{price_name}={beta_iv_logit[0]:.4f} (se={se_iv_l[0]:.4f}), F={fs_F_demand:.1f}")
print(f"Saved → output/iv_logit_v12.csv ({len(x1_names)} params)")

# =============================================================================
# 8. MC backout (single-product Bertrand-Nash)
# =============================================================================
print("\n" + "=" * 70)
print("MC BACKOUT (single-product Bertrand-Nash)")
print("=" * 70)
sigma_attr = sigma_hat
pi_p = pi_hat

# Per-market: compute own-price elasticity for each product
print("Computing per-market elasticities + MC...")
t0 = time.time()
manuf_codes = df["Manufacturer"].astype("category").cat.codes.values
def _mc_one(t):
    """Multi-product Bertrand-Nash MC backout.
    Derivatives (log-price BLP): ∂s_j/∂p_k = δ_jk × diag_j - A[j,k]
      where diag_j = Σ_i w_i α_i s_ij,  A[j,k] = Σ_i w_i α_i s_ij s_ik.
    Multi-product FOC: s + (own_mask ⊙ G).T (p - MC) = 0 → p - MC = -((G.T ⊙ own))⁻¹ s
    """
    s, e = mkt_starts[t], mkt_ends[t]
    J = e - s
    delta_t = extras["delta"][s:e]
    X2_m = X2[s:e]
    nu_m = nu_attrs[t]
    inc_m = income_inv_normed[t]
    p_lvl = df["price"].iloc[s:e].values
    mf_m = manuf_codes[s:e]
    # Individual shares s_ij — X2=[price, ev_dummy], sigma_attr=[σ_ev]
    mu_price = pi_p * np.outer(X2_m[:, 0], inc_m)
    mu_attr  = X2_m[:, 1:2] @ (sigma_attr[:, None] * nu_m.T)
    u = delta_t[:, None] + mu_price + mu_attr
    u_max = np.maximum(0.0, u.max(axis=0, keepdims=True))
    e_u = np.exp(u - u_max)
    denom = np.exp(-u_max[0]) + e_u.sum(axis=0)
    s_ij = e_u / denom[None, :]
    s_j  = s_ij @ agent_w
    # Heterogeneous price coefficient α_i = β_log_price + π × inc_inv_i
    alpha_i = beta_hat[0] + pi_p * inc_m
    w_alpha = agent_w * alpha_i
    # A[j,k] = Σ_i w_i α_i s_ij s_ik
    A = (s_ij * w_alpha[None, :]) @ s_ij.T
    # diag_j = Σ_i w_i α_i s_ij
    diag_j = (s_ij @ w_alpha)
    # G[j,k] = ∂s_j/∂p_k = δ_jk × diag_j - A[j,k]
    G = np.diag(diag_j) - A
    # Own-firm mask
    own_mask = (mf_m[:, None] == mf_m[None, :])
    # Multi-product FOC under log-price utility (u_ij = α_i log p_j):
    #   ∂s_j/∂p_k = (1/p_k) ∂s_j/∂log_p_k
    #   → FOC: Ω × m = -(p × s), where Ω = G.T × own
    GT_owned = G.T * own_mask
    try:
        pmc = np.linalg.solve(GT_owned, -(p_lvl * s_j))
        mc = p_lvl - pmc
    except np.linalg.LinAlgError:
        mc = p_lvl + p_lvl * s_j / np.minimum(diag_j * (1 - s_j), -1e-12)
    # Own-price elasticity: η_jj = (∂s_j/∂log_p_j) / s_j = G[j,j] / s_j.
    eta_jj = (diag_j - np.diag(A)) / np.maximum(s_j, 1e-20)
    return t, eta_jj, mc, s_j

results_mc = Parallel(n_jobs=N_JOBS, batch_size=20, verbose=0)(
    delayed(_mc_one)(t) for t in range(T)
)
eta_all = np.empty(len(df))
mc_all  = np.empty(len(df))
s_pred  = np.empty(len(df))
for t, eta, mc, sj in results_mc:
    s, e = mkt_starts[t], mkt_ends[t]
    eta_all[s:e] = eta
    mc_all[s:e]  = mc
    s_pred[s:e]  = sj
print(f"  done in {time.time()-t0:.1f}s")
print(f"Elasticity: mean={eta_all.mean():.3f}, median={np.median(eta_all):.3f}, "
      f"p10/p90={np.percentile(eta_all,10):.2f}/{np.percentile(eta_all,90):.2f}")
print(f"MC (万元):  mean={mc_all.mean():.2f}, median={np.median(mc_all):.2f}, "
      f"p10/p90={np.percentile(mc_all,10):.2f}/{np.percentile(mc_all,90):.2f}")
print(f"Markup (P/MC): median={(df['price'].values/np.maximum(mc_all,1e-6)).mean():.2f}")

# Save MC per product-market
mc_df = pd.DataFrame({
    "market_ids": df["market_ids"].values, "product_id": df.index,
    "Brand": df["Brand"].values, "firm_group": df["firm_group"].values,
    "Manufacturer": df["Manufacturer"].values, "Year": df["Year"].values,
    "price": df["price"].values, "shares": df["shares"].values,
    "s_pred": s_pred, "eta_jj": eta_all, "mc": mc_all,
    "log_size": df["log_size"].values, "log_power_gv": df["log_power_gv"].values,
    "log_ev_range": df["log_ev_range"].values, "FuelType": df["FuelType"].values,
    "BodyType": df["BodyType"].values, "ev_dummy": df["ev_dummy"].values,
})
mc_df = mc_df[mc_df["mc"] > 0].copy()  # drop nonsensical MC
mc_df["log_mc"] = np.log(mc_df["mc"])
mc_df.to_csv(f"{PROJECT_ROOT}/output/diy_mc_v12.csv", index=False)
print(f"\nSaved {len(mc_df):,} rows → output/diy_mc_v12.csv")

# =============================================================================
# 8b. NATIONAL MC backout (proper national Bertrand FOC per year)
# =============================================================================
# Solve national-level Bertrand FOC per (Year, Product) so that the resulting
# MC is consistent with what the 2_decomposition.py NATIONAL solver expects.
# Per-market mc_df (above) reflects city-by-city Bertrand FOC; aggregating
# them by Q-weighted mean does NOT recover the national-FOC MC because the
# Jacobian is nonlinear in shares.
#
# National FOC: Q_j = Σ_c M_c × s_jc;  ∂Q_j/∂p_k = Σ_c M_c × ∂s_jc/∂p_k
#   FOC for firm f: Q_k + Σ_j∈f m_j × ∂Q_j/∂p_k = 0   ∀ k ∈ f
#   matrix: (Jac_Q.T * own) × m = -Q  →  m = -((Jac_Q.T) * own)⁻¹ × Q
print("\n" + "=" * 70)
print("NATIONAL MC BACKOUT (multi-product Bertrand at national level)")
print("=" * 70)

nat_mc_records = []
years_to_solve = sorted(df["Year"].unique())
for yr in years_to_solve:
    yr_mask = (df["Year"].values == yr)
    yr_rows = np.where(yr_mask)[0]
    if len(yr_rows) == 0:
        continue
    # Build unique product list for this year (preserve order of first occurrence)
    yr_df = df.iloc[yr_rows]
    prod_keys = yr_df.drop_duplicates(["Model", "FuelType"])[
        ["Model", "FuelType", "Brand", "Manufacturer", "BodyType",
         "log_size", "log_power_gv", "log_ev_range", "ev_dummy"]
    ].reset_index(drop=True)
    # Use Manufacturer as firm id (no separate firm_id col in df)
    prod_keys["firm_id"] = pd.Categorical(prod_keys["Manufacturer"]).codes
    J_nat = len(prod_keys)
    key_to_nat = {(m, ft): i for i, (m, ft) in enumerate(
        zip(prod_keys["Model"], prod_keys["FuelType"]))}
    # Aggregate Q and Jacobian across cities for this year
    Q_nat = np.zeros(J_nat)
    Jac_nat = np.zeros((J_nat, J_nat))
    # Per-product observed price: Q-weighted mean across cities
    P_nat_num = np.zeros(J_nat); P_nat_den = np.zeros(J_nat)
    # Iterate over cities in this year
    yr_market_ids = yr_df["market_ids"].unique()
    for mkt in yr_market_ids:
        mk_mask = (df["market_ids"].values == mkt) & yr_mask
        ts = np.where(mk_mask)[0]
        if len(ts) == 0:
            continue
        # Find t (market index) for this market
        try:
            t = list(markets).index(mkt)
        except ValueError:
            continue
        s_t, e_t = mkt_starts[t], mkt_ends[t]
        if e_t - s_t == 0:
            continue
        local_keys = list(zip(df["Model"].iloc[s_t:e_t], df["FuelType"].iloc[s_t:e_t]))
        local_to_nat = np.array([key_to_nat.get(k, -1) for k in local_keys])
        if (local_to_nat < 0).all():
            continue
        # Compute shares + Jac for this market (replicate _mc_one calc)
        delta_t = extras["delta"][s_t:e_t]
        X2_m = X2[s_t:e_t]
        nu_m = nu_attrs[t]
        inc_m = income_inv_normed[t]
        p_lvl = df["price"].iloc[s_t:e_t].values
        # M_c (market size) — from Population, matching 2_decomposition
        pop_arr = df["Population"].iloc[s_t:e_t].values
        M_c = float(pop_arr[0]) * 10_000.0 / 2.62 / 5.0
        # Individual shares
        mu_price = pi_p * np.outer(X2_m[:, 0], inc_m)
        mu_attr  = X2_m[:, 1:2] @ (sigma_attr[:, None] * nu_m.T)
        u = delta_t[:, None] + mu_price + mu_attr
        u_max = np.maximum(0.0, u.max(axis=0, keepdims=True))
        e_u = np.exp(u - u_max)
        denom = np.exp(-u_max[0]) + e_u.sum(axis=0)
        s_ij = e_u / denom[None, :]
        s_j = s_ij @ agent_w
        alpha_i = beta_hat[0] + pi_p * inc_m
        w_alpha = agent_w * alpha_i
        A_m = (s_ij * w_alpha[None, :]) @ s_ij.T
        diag_m = (s_ij @ w_alpha)
        Jac_loc = np.diag(diag_m) - A_m  # ∂s_j/∂p_k for j,k local
        # Map to national: accumulate weighted by M_c
        for j_loc in range(len(local_to_nat)):
            j_nat = local_to_nat[j_loc]
            if j_nat < 0:
                continue
            Q_nat[j_nat] += M_c * s_j[j_loc]
            P_nat_num[j_nat] += M_c * s_j[j_loc] * p_lvl[j_loc]
            P_nat_den[j_nat] += M_c * s_j[j_loc]
            for k_loc in range(len(local_to_nat)):
                k_nat = local_to_nat[k_loc]
                if k_nat < 0:
                    continue
                Jac_nat[j_nat, k_nat] += M_c * Jac_loc[j_loc, k_loc]
    # Ownership matrix at national level
    firm_arr_nat = prod_keys["firm_id"].values
    own_nat = (firm_arr_nat[:, None] == firm_arr_nat[None, :]).astype(float)
    # FOC: solve (Jac_Q.T * own) × m = -Q
    Phi = Jac_nat.T * own_nat
    # Add small ridge for numerical stability
    Phi_reg = Phi + 1e-6 * np.eye(J_nat)
    try:
        P_nat_lvl = P_nat_num / np.maximum(P_nat_den, 1e-12)
        m_nat = np.linalg.solve(Phi_reg, -(P_nat_lvl * Q_nat))
    except np.linalg.LinAlgError:
        m_nat = np.zeros(J_nat)
    # National price = Q-weighted observed price across cities
    P_nat = P_nat_num / np.maximum(P_nat_den, 1e-12)
    mc_nat = P_nat - m_nat
    # Save record
    for i in range(J_nat):
        rec = prod_keys.iloc[i].to_dict()
        rec["Year"] = int(yr)
        rec["price_nat"] = float(P_nat[i])
        rec["Q_nat"] = float(Q_nat[i])
        rec["markup_nat"] = float(m_nat[i])
        rec["mc_nat"] = float(mc_nat[i])
        nat_mc_records.append(rec)

nat_mc_df = pd.DataFrame(nat_mc_records)
nat_mc_df = nat_mc_df[nat_mc_df["mc_nat"] > 0].copy()
nat_mc_df["lerner_nat"] = (nat_mc_df["price_nat"] - nat_mc_df["mc_nat"]) / nat_mc_df["price_nat"]
# Rename to match 2_decomposition.py's expected column names
nat_mc_df = nat_mc_df.rename(columns={"mc_nat": "mc_national", "price_nat": "price_national"})
nat_mc_df["mc_hat"] = nat_mc_df["mc_national"]  # fallback mc (positive)
nat_mc_df.to_parquet(f"{PROJECT_ROOT}/output/national_mc.parquet")
print(f"Saved {len(nat_mc_df):,} (product,year) rows → output/national_mc.parquet")
print(f"  National Lerner: mean={nat_mc_df['lerner_nat'].mean()*100:.2f}%, "
      f"median={nat_mc_df['lerner_nat'].median()*100:.2f}%")
for yr in [2015, 2024]:
    sub = nat_mc_df[nat_mc_df["Year"] == yr]
    print(f"  {yr}: n={len(sub)}, mean P={sub['price_national'].mean():.2f}万, "
          f"mean MC={sub['mc_national'].mean():.2f}万, "
          f"median Lerner={sub['lerner_nat'].median()*100:.2f}%")


# Year × firm_group markup decomposition (price war diagnostic)
mc_df["markup"] = mc_df["price"] / np.maximum(mc_df["mc"], 1e-6)
mc_df["lerner"] = (mc_df["price"] - mc_df["mc"]) / np.maximum(mc_df["price"], 1e-6)
mkup_by_year = mc_df.groupby("Year").agg(
    n=("markup", "size"),
    P_mean=("price", "mean"),
    MC_mean=("mc", "mean"),
    markup_median=("markup", "median"),
    lerner_median=("lerner", "median"),
).round(3)
print("\n--- Markup by Year (price war diagnostic) ---")
print(mkup_by_year.to_string())
mkup_by_fgyr = mc_df.groupby(["firm_group", "Year"]).agg(
    n=("markup", "size"),
    lerner_median=("lerner", "median"),
).unstack("Year")["lerner_median"].round(3)
print("\n--- Median Lerner by firm_group × Year ---")
print(mkup_by_fgyr.to_string())
mkup_by_fgyr.to_csv(f"{PROJECT_ROOT}/output/diy_lerner_v12.csv")

# =============================================================================
# 9. OLS on log(MC): brand quality, attributes, time
# =============================================================================
print("\n" + "=" * 70)
print("OLS: log(MC) ~ attributes + FE")
print("=" * 70)
import statsmodels.formula.api as smf
# Symmetric to BLP: firm_group FE in regressors; individual brand → residual.
# Battery cost (BNEF) × ev_dummy captures battery-cost-driven MC for EVs.
mc_df["bat_x_ev"] = mc_df.get("bat_usd_kwh", pd.Series(0, index=mc_df.index)) * mc_df["ev_dummy"]
# Battery cost wasn't merged into mc_df; re-merge from BNEF panel.
bat_panel = pd.read_csv(f"{PROJECT_ROOT}/raw_data/battery_cost_bnef.csv")
bat_map = dict(zip(bat_panel["year"], bat_panel["battery_pack_usd_kwh"]))
mc_df["bat_usd_kwh"] = mc_df["Year"].map(bat_map).ffill().bfill()
mc_df["bat_x_ev"] = mc_df["bat_usd_kwh"] * mc_df["ev_dummy"]
ols_form = ("log_mc ~ log_size + log_power_gv + log_ev_range + bat_x_ev "
            "+ C(FuelType) + C(BodyType) + C(Year) + C(firm_group)")
ols_res = smf.ols(ols_form, data=mc_df).fit(cov_type="HC1")
print(ols_res.summary().tables[1].as_text()[:3000])
print(f"\nR² = {ols_res.rsquared:.4f},  N = {int(ols_res.nobs):,}")

# Save coefficients
ols_out = pd.DataFrame({
    "param": ols_res.params.index, "estimate": ols_res.params.values,
    "se": ols_res.bse.values, "t": ols_res.tvalues.values, "p": ols_res.pvalues.values,
})
diag_rows = pd.DataFrame([
    {"param": "n_obs",     "estimate": float(ols_res.nobs), "se": np.nan, "t": np.nan, "p": np.nan},
    {"param": "r_squared", "estimate": float(ols_res.rsquared), "se": np.nan, "t": np.nan, "p": np.nan},
])
ols_out = pd.concat([ols_out, diag_rows], ignore_index=True)
ols_out.to_csv(f"{PROJECT_ROOT}/output/diy_mc_ols_v12.csv", index=False)
print(f"\nSaved → output/diy_mc_ols_v12.csv ({len(ols_out)} params, incl. n_obs + r_squared)")

# =============================================================================
# 9b. Supply IV: log_ev_range instrumented by rivals' mean range
# =============================================================================
print("\n" + "=" * 70)
print("IV SUPPLY: log(MC) ~ ... (log_ev_range instrumented)")
print("=" * 70)
import statsmodels.formula.api as smf2
# Excluded instrument: rivals' mean log_ev_range within (Year × FuelType, excl. same manufacturer)
mc_iv = mc_df.copy()
mc_iv["mfr"] = mc_iv["Manufacturer"] if "Manufacturer" in mc_iv.columns else mc_iv.get("firm_group", "unk")
def _rival_range(g):
    out = []
    for _, row in g.iterrows():
        rivals = g[g["mfr"] != row["mfr"]]
        out.append(rivals["log_ev_range"].mean() if len(rivals) > 0 else np.nan)
    return pd.Series(out, index=g.index)
mc_iv["rival_range_iv"] = (mc_iv.groupby(["Year","FuelType"], group_keys=False)
                           .apply(_rival_range))
mc_iv["rival_range_iv"] = mc_iv["rival_range_iv"].fillna(mc_iv["log_ev_range"])
from linearmodels.iv import IV2SLS as _IV2SLS
_iv_df = mc_iv.dropna(subset=["log_mc","log_size","log_power_gv","log_ev_range",
                               "bat_x_ev","FuelType","BodyType","Year","firm_group",
                               "rival_range_iv"]).copy()
_iv_df["_const"] = 1.0
_fe_cols  = (pd.get_dummies(_iv_df["FuelType"], prefix="FT", drop_first=True).astype(float)
             .join(pd.get_dummies(_iv_df["BodyType"], prefix="BT", drop_first=True).astype(float))
             .join(pd.get_dummies(_iv_df["Year"].astype(str), prefix="YR", drop_first=True).astype(float))
             .join(pd.get_dummies(_iv_df["firm_group"], prefix="FG", drop_first=True).astype(float)))
_exog_cols = ["log_size","log_power_gv","bat_x_ev"]
_exog  = pd.concat([_iv_df[["_const"] + _exog_cols], _fe_cols], axis=1)
_endog = _iv_df[["log_ev_range"]]
_instr = _iv_df[["rival_range_iv"]]
_dep   = _iv_df["log_mc"]
try:
    _iv_res = _IV2SLS(_dep, _exog, _endog, _instr).fit(cov_type="unadjusted")
    _gamma_range = float(_iv_res.params["log_ev_range"])
    _se_range    = float(_iv_res.std_errors["log_ev_range"])
    # First-stage F
    _fs_X = pd.concat([_exog, _instr], axis=1).values
    _fs_X_no_iv = _exog.values
    _b_fs, _, _, _ = np.linalg.lstsq(_fs_X, _iv_df["log_ev_range"].values, rcond=None)
    _b_r, _, _, _  = np.linalg.lstsq(_fs_X_no_iv, _iv_df["log_ev_range"].values, rcond=None)
    _rss_f  = float(np.sum((_iv_df["log_ev_range"].values - _fs_X @ _b_fs)**2))
    _rss_r  = float(np.sum((_iv_df["log_ev_range"].values - _fs_X_no_iv @ _b_r)**2))
    _fs_F_s = (_rss_r - _rss_f) / 1.0 / (_rss_f / (len(_iv_df) - _fs_X.shape[1]))
    _iv_params = _iv_res.params.reset_index()
    _iv_params.columns = ["param","estimate"]
    _iv_params["se"] = _iv_res.std_errors.values
    _iv_params["t"]  = _iv_res.tstats.values
    _iv_params["p"]  = _iv_res.pvalues.values
    _iv_diag = pd.DataFrame([
        {"param":"n_obs","estimate":float(len(_iv_df)),"se":np.nan,"t":np.nan,"p":np.nan},
        {"param":"first_stage_F","estimate":_fs_F_s,"se":np.nan,"t":np.nan,"p":np.nan},
    ])
    _iv_out = pd.concat([_iv_params, _iv_diag], ignore_index=True)
    _iv_out.to_csv(f"{PROJECT_ROOT}/output/diy_mc_iv_v12.csv", index=False)
    print(f"IV supply: γ_range={_gamma_range:+.4f} (se={_se_range:.4f}), F={_fs_F_s:.1f}")
    print(f"Saved → output/diy_mc_iv_v12.csv ({len(_iv_params)} params)")
except Exception as _exc:
    print(f"  ⚠ IV supply failed: {_exc}; copying OLS as fallback")
    _iv_out = ols_out.copy()
    _iv_out.to_csv(f"{PROJECT_ROOT}/output/diy_mc_iv_v12.csv", index=False)

# =============================================================================
# 9c. Supply split: separate OLS + IV for EV and GV subsamples
# =============================================================================
print("\n" + "=" * 70)
print("SUPPLY SPLIT: EV and GV subsamples")
print("=" * 70)

_ev_mask = mc_df["ev_dummy"] == 1
mc_ev = mc_df[_ev_mask].copy()
mc_gv = mc_df[~_ev_mask].copy()
print(f"  EV subsample: {len(mc_ev):,} rows   GV subsample: {len(mc_gv):,} rows")

def _save_ols_split(data, formula, label, out_path):
    res = smf.ols(formula, data=data).fit(cov_type="HC1")
    out = pd.DataFrame({
        "param": res.params.index, "estimate": res.params.values,
        "se": res.bse.values, "t": res.tvalues.values, "p": res.pvalues.values,
    })
    diag = pd.DataFrame([
        {"param": "n_obs",     "estimate": float(res.nobs),      "se": np.nan, "t": np.nan, "p": np.nan},
        {"param": "r_squared", "estimate": float(res.rsquared),  "se": np.nan, "t": np.nan, "p": np.nan},
    ])
    pd.concat([out, diag], ignore_index=True).to_csv(out_path, index=False)
    print(f"  {label}: R²={res.rsquared:.3f}, N={int(res.nobs):,} → {out_path.split('/')[-1]}")
    return res

_ev_ols_form = ("log_mc ~ log_ev_range + bat_x_ev "
                "+ C(FuelType) + C(BodyType) + C(Year) + C(firm_group)")
_gv_ols_form = ("log_mc ~ log_size + log_power_gv "
                "+ C(FuelType) + C(BodyType) + C(Year) + C(firm_group)")
_ev_ols = _save_ols_split(mc_ev, _ev_ols_form, "EV OLS",
                          f"{PROJECT_ROOT}/output/diy_mc_ols_ev_v12.csv")
_gv_ols = _save_ols_split(mc_gv, _gv_ols_form, "GV OLS",
                          f"{PROJECT_ROOT}/output/diy_mc_ols_gv_v12.csv")

def _iv_split(data, endog_col, exog_cols, rival_group_cols, label, out_path):
    """Run IV2SLS with rivals'-mean instrument for endog_col."""
    d = data.copy()
    d["_mfr"] = d["Manufacturer"] if "Manufacturer" in d.columns else d.get("firm_group", "unk")
    def _rival_mean(g):
        return pd.Series(
            [g.loc[g["_mfr"] != r["_mfr"], endog_col].mean() for _, r in g.iterrows()],
            index=g.index)
    d["_iv"] = d.groupby(rival_group_cols, group_keys=False).apply(_rival_mean)
    d["_iv"] = d["_iv"].fillna(d[endog_col])
    d = d.dropna(subset=["log_mc"] + exog_cols + [endog_col, "_iv"]).copy()
    d["_const"] = 1.0
    _fe = (pd.get_dummies(d["BodyType"], prefix="BT", drop_first=True).astype(float)
           .join(pd.get_dummies(d["Year"].astype(str), prefix="YR", drop_first=True).astype(float))
           .join(pd.get_dummies(d["firm_group"], prefix="FG", drop_first=True).astype(float)))
    if d["FuelType"].nunique() > 1:
        _fe = _fe.join(pd.get_dummies(d["FuelType"], prefix="FT", drop_first=True).astype(float))
    _exog  = pd.concat([d[["_const"] + exog_cols], _fe], axis=1)
    _endog = d[[endog_col]]
    _instr = d[["_iv"]]
    _dep   = d["log_mc"]
    try:
        _res = _IV2SLS(_dep, _exog, _endog, _instr).fit(cov_type="unadjusted")
        _fs_X     = pd.concat([_exog, _instr], axis=1).values
        _fs_X_no  = _exog.values
        _b_f, _, _, _ = np.linalg.lstsq(_fs_X,    d[endog_col].values, rcond=None)
        _b_r, _, _, _ = np.linalg.lstsq(_fs_X_no, d[endog_col].values, rcond=None)
        _rss_f = float(np.sum((d[endog_col].values - _fs_X @ _b_f)**2))
        _rss_r = float(np.sum((d[endog_col].values - _fs_X_no @ _b_r)**2))
        _F = (_rss_r - _rss_f) / 1.0 / (_rss_f / (len(d) - _fs_X.shape[1]))
        _p = _res.params.reset_index(); _p.columns = ["param", "estimate"]
        _p["se"] = _res.std_errors.values
        _p["t"]  = _res.tstats.values
        _p["p"]  = _res.pvalues.values
        _diag = pd.DataFrame([
            {"param": "n_obs",         "estimate": float(len(d)),  "se": np.nan, "t": np.nan, "p": np.nan},
            {"param": "first_stage_F", "estimate": _F,              "se": np.nan, "t": np.nan, "p": np.nan},
        ])
        pd.concat([_p, _diag], ignore_index=True).to_csv(out_path, index=False)
        print(f"  {label}: γ_{endog_col}={float(_res.params[endog_col]):+.4f}, F={_F:.1f} → {out_path.split('/')[-1]}")
    except Exception as _e:
        print(f"  ⚠ {label} IV failed: {_e}")

_iv_split(mc_ev, "log_ev_range", ["bat_x_ev"], ["Year", "FuelType"],
          "EV IV", f"{PROJECT_ROOT}/output/diy_mc_iv_ev_v12.csv")
_iv_split(mc_gv, "log_power_gv", ["log_size"], ["Year", "FuelType"],
          "GV IV", f"{PROJECT_ROOT}/output/diy_mc_iv_gv_v12.csv")

# =============================================================================
# 10. Save blp_essentials.npz for 2_decomposition.py
# =============================================================================
# 2_decomposition.py expects canonical pyblp labels. Remap DIY labels:
#   FT_HEV          → FuelType['HEV']
#   BT_SUV          → BodyType['SUV']
#   FG_BYD          → Brand['BYD']
#   EV_x_Y2024      → ev_x_yr2024
#   YR_*            → DROPPED (no canonical match)
#   policy/macro    → un-standardized + remap to D_MACRO_VARS / D_WEALTH_VARS / POLICY_VARS
print("\n" + "=" * 70)
print("Building blp_essentials.npz for 2_decomposition.py")
print("=" * 70)
DIY_TO_CANONICAL_POLICY = {
    "ev_x_license":     "ev_license",
    "ev_x_pilot":       "ev_x_is_pilot",
    "ev_x_policy_str":  "ev_policy_primary",
    "oil_price":        "oil_price",
    "log_pop_density":  "log_pop_density",
    "urb_rate":         "urb_rate",
    "GDP_per_capita":   "GDP_per_capita",
    # Path D 2026-06-12 EV × city interactions (replace σ_ev RC).
    # Mapped to themselves (no canonical rename) but pass through the
    # /sd rescaling so decomp can use β × raw_X.
    "ev_x_log_income":   "ev_x_log_income",
    "ev_x_GDPpc":        "ev_x_GDPpc",
    "ev_x_log_pop_dens": "ev_x_log_pop_dens",
    "ev_x_urb_rate":     "ev_x_urb_rate",
    # log_income_city DROPPED (no canonical slot, would amplify if mapped to ev_x_edu).
}
STANDARDIZED = list(DIY_TO_CANONICAL_POLICY.keys()) + ["log_income_city"]
sd_map = {col: df[col].std() if col in df.columns else 1.0 for col in STANDARDIZED}

def _remap_label(diy_label, beta_val):
    if diy_label == "log_price":            return "log_price", beta_val
    if diy_label.startswith("FT_"):         return f"FuelType['{diy_label[3:]}']", beta_val
    if diy_label.startswith("BT_"):         return f"BodyType['{diy_label[3:]}']", beta_val
    if diy_label.startswith("SS_"):         return f"SizeSegment['{diy_label[3:]}']", beta_val
    if diy_label.startswith("YR_"):         return None, None   # drop
    if diy_label.startswith("FG_"):         return f"Brand['{diy_label[3:]}']", beta_val
    if diy_label.startswith("EV_x_Y"):      return f"ev_x_yr{diy_label[6:]}", beta_val
    if diy_label == "log_income_city":      return None, None   # drop (no canonical slot)
    if diy_label in DIY_TO_CANONICAL_POLICY:
        return DIY_TO_CANONICAL_POLICY[diy_label], beta_val / max(sd_map[diy_label], 1e-9)
    return diy_label, beta_val

canonical_labels, canonical_betas = [], []
for nm, b in zip(x1_names, beta_hat):
    lab, beta_remapped = _remap_label(nm, b)
    if lab is not None:
        canonical_labels.append(lab)
        canonical_betas.append(beta_remapped)

# δ via logit inversion (simple, since v12 has different δ scale than canonical)
# Match 2_decomposition.py's singleton filter
def _singleton_filter_for_essentials(d):
    out = d.copy()
    vars_ = ["log_size", "Displacement", "electric_efficiency",
             "FuelEfficiency", "log_ev_range"]
    vars_ = [v for v in vars_ if v in out.columns]
    grp = out.groupby("market_segement", sort=False)
    n = grp[vars_[0]].transform("size")
    for v in vars_:
        s = grp[v].transform("sum")
        out[f"{v}_iv_diff"] = np.abs(out[v] - np.where(n > 1, (s - out[v]) / (n - 1), np.nan))
    iv_cols = [f"{v}_iv_diff" for v in vars_]
    return out.dropna(subset=iv_cols).reset_index(drop=True)

df_full = pd.read_parquet(f"{PROJECT_ROOT}/output/df.parquet")
df_full = _singleton_filter_for_essentials(df_full)

# δ = BLP-inverted mean utility at θ̂ (NOT simple MNL log(s/s_0)). The simple
# MNL inversion is consistent only at σ=0; with σ_ev=4.748 the BLP share
# function gives wildly inconsistent predictions if fed MNL δ — breaking the
# decomp solver's endpoint identity (root cause of pre-2026-06-12 V(∅) overshoot).
# Map BLP-inverted δ from estimation `df` (length len(df), post-line-85 dropna)
# to df_full (post-singleton-filter) via row key (Geo_Market, Year, Model, FuelType).
_key_cols = ["Geo_Market", "Year", "Model", "FuelType"]
_delta_lookup = {tuple(r): delta_blp_hat[i]
                  for i, r in enumerate(df[_key_cols].itertuples(index=False, name=None))}
delta_ess = np.array([_delta_lookup.get(tuple(r), np.nan)
                       for r in df_full[_key_cols].itertuples(index=False, name=None)])
_n_unmatched = int(np.isnan(delta_ess).sum())
if _n_unmatched:
    print(f"  ⚠ {_n_unmatched}/{len(delta_ess)} df_full rows missing δ lookup; "
          f"falling back to MNL δ for those")
    _fb = (np.log(np.maximum(df_full["shares"].values, 1e-12)) -
           np.log(np.maximum(df_full["s_0"].values, 1e-12)))
    delta_ess = np.where(np.isnan(delta_ess), _fb, delta_ess)
print(f"  ✓ δ_ess: BLP-inverted ({len(delta_ess) - _n_unmatched}/"
      f"{len(delta_ess)} rows) | range [{delta_ess.min():.2f}, {delta_ess.max():.2f}]")
pyblp_ids_ess = np.arange(len(df_full), dtype=np.int64)

ess_dir = f"{PROJECT_ROOT}/output/blp_essentials_v12"
os.makedirs(ess_dir, exist_ok=True)
np.savez(f"{ess_dir}/blp_essentials.npz",
         pi_price=pi_hat,
         sigma_diag=np.array([0.0, sigma_hat[0]]),  # [price=0, ev_dummy=σ_ev]
         beta=np.array(canonical_betas),
         beta_labels=np.array(canonical_labels, dtype=str),
         delta=delta_ess,
         pyblp_ids=pyblp_ids_ess,
         # Agent arrays — consumed by make_v5_paper_tables.py Tables 14–16
         # (substitution / income counterfactual / premium-brand) to replay
         # BLP demand at counterfactual income draws.
         nu_attrs_v12=nu_attrs,
         income_inv_normed_v12=income_inv_normed,
         markets_v12=np.array(markets, dtype=str))
print(f"Saved → {ess_dir}/blp_essentials.npz ({len(canonical_betas)} betas, "
      f"{len(delta_ess)} δ rows)")
print(f"  pi_price = {pi_hat:+.4f}")
print(f"  sigma_diag = {sigma_hat.round(3)}")
print(f"\nTo run decomposition:")
print(f"  BLP_INPUT_DIR=output/blp_essentials_v12 \\")
print(f"  DECOMP_OUTPUT_DIR=output/decomp_v12 \\")
print(f"  python heterogeneous_diffusion/code/2_decomposition.py")
