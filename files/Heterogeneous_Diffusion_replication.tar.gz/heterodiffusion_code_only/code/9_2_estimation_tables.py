"""
9_2_estimation_tables.py
========================

Generate LaTeX comparison tables from pre-computed estimation CSVs.

Inputs (all written by code/1_blp.py):
  output/ols_logit_v12.csv   — OLS logit (param, estimate, se, t, p)
  output/iv_logit_v12.csv    — IV logit  (param, estimate, se, t, p; also first_stage_F)
  output/diy_blp_v12.csv     — RC BLP    (sigma_ev_dummy, pi_*, beta_*, n_obs, obj)
  output/diy_mc_ols_v12.csv  — Supply OLS (param, estimate, se, t, p)
  output/diy_mc_iv_v12.csv   — Supply IV  (param, estimate, se, t, p; also first_stage_F)

Outputs:
  report/memos/tab_demand_estimation.tex
  report/memos/tab_supply_estimation.tex
"""
import os
import numpy as np
import pandas as pd

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT_DIR = f"{PROJECT_ROOT}/report/memos"
os.makedirs(OUT_DIR, exist_ok=True)

print("=" * 60)
print("Estimation Tables  (reads pre-computed CSVs from 1_1_blp.py)")
print("=" * 60)

# =============================================================================
# Load CSVs
# =============================================================================
ols  = pd.read_csv(f"{PROJECT_ROOT}/output/ols_logit_v12.csv").set_index("param")
iv   = pd.read_csv(f"{PROJECT_ROOT}/output/iv_logit_v12.csv").set_index("param")
rc   = pd.read_csv(f"{PROJECT_ROOT}/output/diy_blp_v12.csv").set_index("param")
s_ols = pd.read_csv(f"{PROJECT_ROOT}/output/diy_mc_ols_v12.csv").set_index("param")
s_iv  = pd.read_csv(f"{PROJECT_ROOT}/output/diy_mc_iv_v12.csv").set_index("param")
s_ols_ev = pd.read_csv(f"{PROJECT_ROOT}/output/diy_mc_ols_ev_v12.csv").set_index("param")
s_ols_gv = pd.read_csv(f"{PROJECT_ROOT}/output/diy_mc_ols_gv_v12.csv").set_index("param")

# Scalar diagnostics
n_obs_d    = int(ols.loc["n_obs", "estimate"])
r2_ols     = float(ols.loc["r2", "estimate"])
fs_F_iv    = float(iv.loc["first_stage_F", "estimate"])
n_obs_rc   = int(rc.loc["n_obs", "estimate"])
obj_rc     = float(rc.loc["obj", "estimate"])
n_obs_s    = int(s_iv.loc["n_obs", "estimate"])
fs_F_sup   = float(s_iv.loc["first_stage_F", "estimate"])
r2_s_ols = (float(s_ols.loc["r_squared", "estimate"])
            if "r_squared" in s_ols.index else np.nan)
n_obs_ev = int(s_ols_ev.loc["n_obs",     "estimate"]) if "n_obs"     in s_ols_ev.index else 0
n_obs_gv = int(s_ols_gv.loc["n_obs",     "estimate"]) if "n_obs"     in s_ols_gv.index else 0
r2_ev    = float(s_ols_ev.loc["r_squared","estimate"]) if "r_squared" in s_ols_ev.index else np.nan
r2_gv    = float(s_ols_gv.loc["r_squared","estimate"]) if "r_squared" in s_ols_gv.index else np.nan
print(f"  Demand: n={n_obs_d:,}, R²(OLS)={r2_ols:.3f}, F(IV)={fs_F_iv:.1f}")
print(f"  Supply: n={n_obs_s:,}, F(IV)={fs_F_sup:.1f}")
print(f"  Supply EV: n={n_obs_ev:,}, R²={r2_ev:.3f}")
print(f"  Supply GV: n={n_obs_gv:,}, R²={r2_gv:.3f}")

# =============================================================================
# Helpers
# =============================================================================
def stars(p):
    if np.isnan(p): return ""
    if p < 0.01: return "***"
    if p < 0.05: return "**"
    if p < 0.10: return "*"
    return ""

def fmt_coef(est, se, pval, digits=3):
    """Return (coef_str, se_str) for LaTeX. Auto-increases precision for small SEs."""
    if np.isnan(est) or np.isnan(se):
        return "", ""
    d = digits
    import math
    if se > 0 and se < 10 ** (-(d - 1)):
        d = max(d, -int(math.floor(math.log10(se))) + 1)
    fmt = f"{{:.{d}f}}"
    return fmt.format(est) + stars(pval), "(" + fmt.format(se) + ")"

def get(df, param):
    """Fetch (est, se, p) from an indexed DataFrame; returns (nan,nan,nan) if missing."""
    if param not in df.index:
        return np.nan, np.nan, np.nan
    r = df.loc[param]
    return float(r["estimate"]), float(r["se"]), float(r["p"])

def row3(label, ols_p, iv_p, rc_p, digits=3):
    """LaTeX row for demand table (3 cols). Returns '' if all missing."""
    c1, s1 = fmt_coef(*get(ols, ols_p), digits=digits)
    c2, s2 = fmt_coef(*get(iv,  iv_p),  digits=digits)
    c3, s3 = fmt_coef(*get(rc,  rc_p),  digits=digits)
    if not c1 and not c2 and not c3:
        return ""
    return (f"  {label} & {c1} & {c2} & {c3} \\\\\n"
            f"   & {s1} & {s2} & {s3} \\\\")

def row2(label, ols_p, iv_p, digits=3):
    """LaTeX row for supply table (2 cols)."""
    c1, s1 = fmt_coef(*get(s_ols, ols_p), digits=digits)
    c2, s2 = fmt_coef(*get(s_iv,  iv_p),  digits=digits)
    if not c1 and not c2:
        return ""
    return (f"  {label} & {c1} & {c2} \\\\\n"
            f"   & {s1} & {s2} \\\\")

def row4(label, ev_ols_p, ev_iv_p, gv_ols_p, gv_iv_p, digits=3):
    """LaTeX row for split supply table (EV OLS, EV IV, GV OLS, GV IV)."""
    c1, s1 = fmt_coef(*get(s_ols_ev, ev_ols_p), digits=digits)
    c2, s2 = fmt_coef(*get(s_iv_ev,  ev_iv_p),  digits=digits)
    c3, s3 = fmt_coef(*get(s_ols_gv, gv_ols_p), digits=digits)
    c4, s4 = fmt_coef(*get(s_iv_gv,  gv_iv_p),  digits=digits)
    if not c1 and not c2 and not c3 and not c4:
        return ""
    return (f"  {label} & {c1} & {c2} & {c3} & {c4} \\\\\n"
            f"   & {s1} & {s2} & {s3} & {s4} \\\\")

# =============================================================================
# DEMAND TABLE
# =============================================================================
# OLS / IV logit CSVs: param names = x1_names directly (no prefix)
# RC BLP CSV: param names = "beta_{x1_name}" for linear, "pi_{price}" for RC
# Price: 1_blp.py canonical spec uses log_price
price_param = "beta_log_price"
price_label = r"Log Price"

# (label, ols_param, iv_param, rc_param)
# ols/iv use bare x1 names; rc uses beta_ prefix
key_attr = [
    (price_label,                     "log_price",           "log_price",           "beta_log_price"),
    (r"Log Engine Power (GV)",        "log_power_gv",        "log_power_gv",        "beta_log_power_gv"),
    (r"Log EV Range (km)",            "log_ev_range",        "log_ev_range",        "beta_log_ev_range"),
    (r"EV Range $\times$ Log Density","ev_range_x_density",  "ev_range_x_density",  "beta_ev_range_x_density"),
]
policy_vars = [
    (r"EV $\times$ License Restriction","ev_x_license",      "ev_x_license",      "beta_ev_x_license"),
    (r"EV $\times$ Pilot City",         "ev_x_pilot",        "ev_x_pilot",        "beta_ev_x_pilot"),
    (r"EV $\times$ Policy Strength",    "ev_x_policy_str",   "ev_x_policy_str",   "beta_ev_x_policy_str"),
    (r"EV $\times$ Log Income",         "ev_x_log_income",   "ev_x_log_income",   "beta_ev_x_log_income"),
    (r"EV $\times$ GDP Per Capita",     "ev_x_GDPpc",        "ev_x_GDPpc",        "beta_ev_x_GDPpc"),
    (r"EV $\times$ Log Pop.\ Density",  "ev_x_log_pop_dens", "ev_x_log_pop_dens", "beta_ev_x_log_pop_dens"),
    (r"EV $\times$ Urb.\ Rate",         "ev_x_urb_rate",     "ev_x_urb_rate",     "beta_ev_x_urb_rate"),
    (r"Oil Price",                      "oil_price",         "oil_price",         "beta_oil_price"),
    (r"Log Pop.\ Density",              "log_pop_density",   "log_pop_density",   "beta_log_pop_density"),
    (r"GDP Per Capita",                 "GDP_per_capita",    "GDP_per_capita",    "beta_GDP_per_capita"),
    (r"Urbanization Rate",              "urb_rate",          "urb_rate",          "beta_urb_rate"),
    (r"Log City Income",                "log_income_city",   "log_income_city",   "beta_log_income_city"),
]

# pi param in rc
pi_param = "pi_log_price"

def row_demand(label, op, ip, rp):
    """Single row: label & OLS_coef & OLS_se & IV_coef & IV_se & RC_coef & RC_se"""
    import math
    def _parts(df, param):
        est, se, pv = get(df, param)
        if np.isnan(est): return "", ""
        d = 3
        if not np.isnan(se) and se > 0 and se < 10**(-(d-1)):
            d = max(d, -int(math.floor(math.log10(se))) + 1)
        fmt = f"{{:.{d}f}}"
        return fmt.format(est) + stars(pv), f"({fmt.format(se)})"
    c1, s1 = _parts(ols, op)
    c2, s2 = _parts(iv,  ip)
    c3, s3 = _parts(rc,  rp)
    if not c1 and not c2 and not c3:
        return ""
    return f"  {label} & {c1} & {s1} & {c2} & {s2} & {c3} & {s3} \\\\"

L = []
L.append(r"\begin{table}[htbp]")
L.append(r"\centering")
L.append(r"\footnotesize")
L.append(r"\caption{Demand Estimation Results}")
L.append(r"\label{tab:demand}")
L.append(r"\begin{tabularx}{\linewidth}{Xrrrrrr}")
L.append(r"\toprule")
L.append(r" & \multicolumn{2}{c}{OLS Logit} & \multicolumn{2}{c}{IV Logit} & \multicolumn{2}{c}{RC BLP} \\")
L.append(r"\cmidrule(lr){2-3}\cmidrule(lr){4-5}\cmidrule(lr){6-7}")
L.append(r" & Coef. & S.E. & Coef. & S.E. & Coef. & S.E. \\")
L.append(r"\midrule")
L.append(r"\multicolumn{7}{l}{\textit{Vehicle Attributes}} \\[2pt]")
for label, op, ip, rp in key_attr:
    r = row_demand(label, op, ip, rp)
    if r: L.append(r)
L.append(r"[4pt]\multicolumn{7}{l}{\textit{Policy and Market Variables}} \\[2pt]")
for label, op, ip, rp in policy_vars:
    r = row_demand(label, op, ip, rp)
    if r: L.append(r)
L.append(r"\midrule")
L.append(r"\multicolumn{7}{l}{\textit{Random Coefficients}} \\[2pt]")
_c, _s = fmt_coef(*get(rc, pi_param))
L.append(f"  $\\pi$(Income $\\times$ Price) & & & & & {_c} & {_s} \\\\")
L.append(r"\midrule")
L.append(r"  Fixed Effects & \multicolumn{2}{c}{\checkmark} & \multicolumn{2}{c}{\checkmark} & \multicolumn{2}{c}{\checkmark} \\")
L.append(f"  Observations & \\multicolumn{{2}}{{c}}{{{n_obs_d:,}}} & \\multicolumn{{2}}{{c}}{{{n_obs_d:,}}} & \\multicolumn{{2}}{{c}}{{{n_obs_rc:,}}} \\\\")
L.append(f"  $R^2$ & \\multicolumn{{2}}{{c}}{{{r2_ols:.3f}}} & \\multicolumn{{2}}{{c}}{{}} & \\multicolumn{{2}}{{c}}{{}} \\\\")
L.append(f"  First-Stage $F$ & \\multicolumn{{2}}{{c}}{{}} & \\multicolumn{{2}}{{c}}{{{fs_F_iv:.1f}}} & \\multicolumn{{2}}{{c}}{{}} \\\\")
L.append(f"  GMM Objective & \\multicolumn{{2}}{{c}}{{}} & \\multicolumn{{2}}{{c}}{{}} & \\multicolumn{{2}}{{c}}{{{obj_rc:.4f}}} \\\\")
L.append(r"\bottomrule")
L.append(r"\end{tabularx}")
L.append(r"\\[4pt]")
L.append(r"\begin{minipage}{\linewidth}")
L.append(r"  \footnotesize")
L.append(r"  \textit{Notes:} Standard errors clustered by market (OLS and IV)")
L.append(r"  or 2-step optimal GMM market-clustered (RC BLP).")
L.append(r"  $^{*}p<0.10$, $^{**}p<0.05$, $^{***}p<0.01$.")
L.append(r"  All specifications include fuel type, body type, year, firm group,")
L.append(r"  and EV~$\times$~year fixed effects.")
L.append(r"  Policy variables are standardized to unit variance.")
L.append(r"  IV and RC instruments: BLP differentiation IVs on product characteristics,")
L.append(r"  within-fuel-type nested IVs, and BNEF battery cost shifters.")
L.append(r"\end{minipage}")
L.append(r"\end{table}")

demand_tex = "\n".join(L)
with open(f"{OUT_DIR}/tab_demand_estimation.tex", "w") as f:
    f.write(demand_tex)
print(f"\nSaved → report/memos/tab_demand_estimation.tex")

# =============================================================================
# SUPPLY TABLE  (4 cols: EV OLS | EV IV | GV OLS | GV IV)
# =============================================================================
# EV subsample: BEV, PHEV, REEV — regressors: log_size, log_ev_range, bat_x_ev
# GV subsample: ICEV, HEV      — regressors: log_size, log_power_gv
# Columns: EV estimate | EV SE | GV estimate | GV SE  (all on one row)
sup_split_vars = [
    (r"Log Size",               "log_size",     "log_size"),
    (r"Log EV Range (km)",      "log_ev_range", ""),
    (r"Battery Cost (USD/kWh)", "bat_x_ev",     ""),
    (r"Log Engine Power (GV)",  "",             "log_power_gv"),
]

def row_supply(label, ev_p, gv_p):
    """One row: label & EV_est & (EV_se) & GV_est & (GV_se)"""
    ev_est, ev_se, ev_pv = get(s_ols_ev, ev_p) if ev_p else (np.nan, np.nan, np.nan)
    gv_est, gv_se, gv_pv = get(s_ols_gv, gv_p) if gv_p else (np.nan, np.nan, np.nan)
    import math
    def _fmt(est, se, pv):
        if np.isnan(est): return "", ""
        d = 3
        if not np.isnan(se) and se > 0 and se < 10**(-(d-1)):
            d = max(d, -int(math.floor(math.log10(se))) + 1)
        fmt = f"{{:.{d}f}}"
        st = stars(pv)
        return fmt.format(est) + st, f"({fmt.format(se)})"
    ce, se_str = _fmt(ev_est, ev_se, ev_pv)
    cg, sg_str = _fmt(gv_est, gv_se, gv_pv)
    return f"  {label} & {ce} & {se_str} & {cg} & {sg_str} \\\\"

S = []
S.append(r"\begin{table}[htbp]")
S.append(r"\centering")
S.append(r"\footnotesize")
S.append(r"\caption{Supply (Marginal Cost) Estimation Results}")
S.append(r"\label{tab:supply}")
S.append(r"\begin{tabularx}{\linewidth}{Xrrrr}")
S.append(r"\toprule")
S.append(r" & \multicolumn{2}{c}{EV} & \multicolumn{2}{c}{GV} \\")
S.append(r"\cmidrule(lr){2-3}\cmidrule(lr){4-5}")
S.append(r" & Coef. & S.E. & Coef. & S.E. \\")
S.append(r"\midrule")
S.append(r"\multicolumn{5}{l}{\textit{Product Characteristics}} \\[2pt]")
for label, ep, gp in sup_split_vars:
    r = row_supply(label, ep, gp)
    S.append(r)
S.append(r"\midrule")
S.append(r"\multicolumn{5}{l}{\textit{Year Fixed Effects (base: 2015)}} \\[2pt]")
for yr in range(2016, 2025):
    key = f"C(Year)[T.{yr}]"
    r = row_supply(str(yr), key, key)
    S.append(r)
S.append(r"\midrule")
S.append(r"  Fuel Type FE  & \multicolumn{2}{c}{\checkmark} & \multicolumn{2}{c}{\checkmark} \\")
S.append(r"  Body Type FE  & \multicolumn{2}{c}{\checkmark} & \multicolumn{2}{c}{\checkmark} \\")
S.append(r"  Firm Group FE & \multicolumn{2}{c}{\checkmark} & \multicolumn{2}{c}{\checkmark} \\")
S.append(f"  Observations & \\multicolumn{{2}}{{c}}{{{n_obs_ev:,}}} & \\multicolumn{{2}}{{c}}{{{n_obs_gv:,}}} \\\\")
_r2_ev_str = f"{r2_ev:.3f}" if not np.isnan(r2_ev) else ""
_r2_gv_str = f"{r2_gv:.3f}" if not np.isnan(r2_gv) else ""
S.append(f"  $R^2$ & \\multicolumn{{2}}{{c}}{{{_r2_ev_str}}} & \\multicolumn{{2}}{{c}}{{{_r2_gv_str}}} \\\\")
S.append(r"\bottomrule")
S.append(r"\end{tabularx}")
S.append(r"\\[4pt]")
S.append(r"\begin{minipage}{\linewidth}")
S.append(r"  \footnotesize")
S.append(r"  \textit{Notes:} Dependent variable is log marginal cost backed out via")
S.append(r"  multi-product Bertrand--Nash FOC at observed prices and BLP demand parameters.")
S.append(r"  EV subsample: BEV, PHEV, REEV. GV subsample: ICEV, HEV.")
S.append(r"  Standard errors (HC1, heteroskedasticity-robust) in parentheses.")
S.append(r"  $^{*}p<0.10$, $^{**}p<0.05$, $^{***}p<0.01$.")
S.append(r"  All specifications include fuel type, body type, year, and firm group fixed effects.")
S.append(r"\end{minipage}")
S.append(r"\end{table}")

supply_tex = "\n".join(S)
with open(f"{OUT_DIR}/tab_supply_estimation.tex", "w") as f:
    f.write(supply_tex)
print(f"Saved → report/memos/tab_supply_estimation.tex")
print("\nDone.")
