"""
9_3_elasticity_markup_fig.py
=============================
Produces TWO separate output files:
  - report/memos/fig_elasticity_elas.png   (own-price elasticity panel)
  - report/memos/fig_elasticity_lerner.png (Lerner index panel)

No panel titles or (A)/(B) labels are embedded — LaTeX adds subfigure captions.

Style: half-violin (KDE) + median line + jittered scatter points.
  EV  = blue   (#2166ac), violin ABOVE the center line
  GV  = red    (#d6604d), violin BELOW the center line
Y-axis: firm groups sorted by EV median elasticity ascending.
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from scipy.stats import gaussian_kde

# ── Paths ─────────────────────────────────────────────────────────────────────
ROOT     = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT      = f"{ROOT}/report/memos"
DROPBOX  = os.path.expanduser(
    "~/Dropbox/Apps/Overleaf/heterogenous_diffusion/figures"
)
os.makedirs(OUT, exist_ok=True)

# ── Load & compute ─────────────────────────────────────────────────────────────
df = pd.read_csv(f"{ROOT}/output/diy_mc_v12.csv")
df["abs_eta"] = df["eta_jj"].abs()
df["lerner"]  = (df["price"] - df["mc"]) / df["price"]

# Aggregate to national product-year means (no Model column in this file)
GROUP_COLS = [c for c in ["Brand", "Model", "FuelType", "firm_group", "Year", "ev_dummy"]
              if c in df.columns]
agg = df.groupby(GROUP_COLS)[["abs_eta", "lerner"]].mean().reset_index()

# Firm group order: ascending EV median elasticity
ev_med_order = (
    agg[agg["ev_dummy"] == 1]
    .groupby("firm_group")["abs_eta"]
    .median()
    .sort_values()
    .index.tolist()
)
# Fall back to all firms if a group only has GV
all_groups = agg["firm_group"].unique().tolist()
FIRM_ORDER = ev_med_order + [g for g in all_groups if g not in ev_med_order]

# ── Colors / style ─────────────────────────────────────────────────────────────
EV_COL  = "#2166ac"   # blue
GV_COL  = "#d6604d"   # red-orange
ALPHA_FILL   = 0.55
ALPHA_SCATTER= 0.20
VIOLIN_WIDTH = 0.38   # half-height of the violin (in y-axis units)
MEDIAN_LW    = 2.4
RNG = np.random.default_rng(42)


def make_half_violin_panel(col, xlabel, xlim, out_stem):
    """Draw one half-violin panel and save to PNG."""
    fig, ax = plt.subplots(figsize=(6.5, 4.5))

    n_firms = len(FIRM_ORDER)

    for i, fg in enumerate(FIRM_ORDER):
        # Light horizontal guide line
        ax.axhline(i, color="#cccccc", lw=0.6, zorder=1)

        for ev_flag, color, sign in [(1, EV_COL, +1), (0, GV_COL, -1)]:
            sub = agg[(agg["firm_group"] == fg) & (agg["ev_dummy"] == ev_flag)][col].dropna()
            if len(sub) == 0:
                continue

            vals = sub.values
            vmin, vmax = vals.min(), vals.max()
            med = np.median(vals)

            # ── KDE half-violin ───────────────────────────────────────────────
            if len(vals) >= 3:
                try:
                    kde = gaussian_kde(vals, bw_method="scott")
                    xs  = np.linspace(vmin, vmax, 300)
                    ys  = kde(xs)
                    # Normalize so peak touches VIOLIN_WIDTH
                    ys_norm = ys / ys.max() * VIOLIN_WIDTH
                    # Polygon: from i along sign direction, clipped at center
                    poly_x = np.concatenate([[vmin], xs,        [vmax]])
                    poly_y = np.concatenate([[i],    i + sign * ys_norm, [i]])
                    ax.fill(poly_x, poly_y, color=color, alpha=ALPHA_FILL, zorder=2)
                    ax.plot(xs, i + sign * ys_norm, color=color, lw=0.8, alpha=0.7, zorder=3)
                except Exception:
                    pass  # fallback: just scatter

            # ── Median line ───────────────────────────────────────────────────
            # Draw a thick horizontal tick at the median spanning half-violin height
            ax.plot([med, med], [i, i + sign * VIOLIN_WIDTH * 0.92],
                    color=color, lw=MEDIAN_LW, zorder=5, solid_capstyle="round")

            # ── Jittered scatter (within the half) ───────────────────────────
            jitter = RNG.uniform(0, VIOLIN_WIDTH * 0.85, size=len(vals)) * sign
            y_pts  = i + jitter
            ax.scatter(vals, y_pts, color=color, s=8, alpha=ALPHA_SCATTER,
                       linewidths=0, zorder=4)

    # ── Axes formatting ───────────────────────────────────────────────────────
    ax.set_yticks(range(n_firms))
    ax.set_yticklabels(FIRM_ORDER, fontsize=9)
    ax.set_ylim(-0.6, n_firms - 0.4)
    ax.set_xlim(*xlim)
    ax.set_xlabel(xlabel, fontsize=10)
    ax.grid(axis="x", lw=0.5, alpha=0.35, color="#aaaaaa", zorder=0)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.tick_params(axis="both", labelsize=9)

    # ── Legend ────────────────────────────────────────────────────────────────
    ev_patch = mpatches.Patch(facecolor=EV_COL, label="EV", edgecolor="none")
    gv_patch = mpatches.Patch(facecolor=GV_COL, label="GV", edgecolor="none")
    ax.legend(handles=[ev_patch, gv_patch], fontsize=9, frameon=True,
              framealpha=0.85, edgecolor="#cccccc", loc="lower right")

    plt.tight_layout()

    # ── Save ──────────────────────────────────────────────────────────────────
    png_path = f"{OUT}/{out_stem}.png"
    fig.savefig(png_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved → {png_path}")

    # Copy to Dropbox/Overleaf if accessible
    if os.path.isdir(DROPBOX):
        import shutil
        dst = f"{DROPBOX}/{out_stem}.png"
        shutil.copy2(png_path, dst)
        print(f"Copied → {dst}")
    else:
        print(f"Dropbox dir not found, skipping copy: {DROPBOX}")


# ── Elasticity panel ──────────────────────────────────────────────────────────
make_half_violin_panel(
    col      = "abs_eta",
    xlabel   = r"$|\eta_{jj}|$ (absolute own-price elasticity)",
    xlim     = (3.0, 6.5),
    out_stem = "fig_elasticity_elas",
)

# ── Lerner panel ──────────────────────────────────────────────────────────────
make_half_violin_panel(
    col      = "lerner",
    xlabel   = r"Lerner index $(p - mc)\,/\,p$",
    xlim     = (0.1, 0.4),
    out_stem = "fig_elasticity_lerner",
)
