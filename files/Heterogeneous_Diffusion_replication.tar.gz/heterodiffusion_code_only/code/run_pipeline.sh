#!/usr/bin/env bash
# =============================================================================
# Heterogeneous Diffusion — Full Replication Pipeline
# =============================================================================
#
# Numbering scheme:
#   1-1  Demand estimation            (1_1_blp.py)
#   1-2  Marginal cost estimation     (1_2_mc_estimation.py)
#   2-0  Static equilibrium check     (2_0_check_static.py)
#   2-1  Static (Shapley) decomp      (2_1_static_decomposition.py)
#   3-0  Dynamic equilibrium check    (3_0_check_dynamic.py)
#   3-1  Dynamic decomposition/sim    (3_1_dynamic_decomposition.py)
#   9-0  Summary statistics           (9_0_summary_statistics.py)
#   9-1  Heterogeneity analysis       (9_1_heterogeneity.py)
#
# Stages (PIPELINE_STAGE env var):
#   demand | mc | check_static | decomp_main | decomp_byyear |
#   check_dynamic | dynamic_sim | tables | figures | all
#
# Usage:
#   bash code/run_pipeline.sh                        # full pipeline
#   PIPELINE_STAGE=check_static bash code/run_pipeline.sh
#   PIPELINE_STAGE=figures bash code/run_pipeline.sh # generate all paper figures
# =============================================================================
set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
ROOT="$( cd "$SCRIPT_DIR/.." && pwd )"
CODE="$ROOT/code"
cd "$ROOT"

STAGE="${PIPELINE_STAGE:-all}"

divider() { echo; echo "=================================================================="; }

# ── 1-1. BLP demand estimation ───────────────────────────────────────────────
if [[ "$STAGE" == "demand" || "$STAGE" == "all" ]]; then
  divider; echo "[1-1] BLP demand estimation  (1_blp.py, v12 log-price spec)"
  divider
  # Log-price spec (default). blp_essentials_v12 stores β_log_price.
  # Do NOT set DIY_PRICE_LINEAR=1; that changes to level price and
  # produces a different essentials file incompatible with downstream steps.
  python3 "$CODE/1_blp.py"
fi

# ── 1-2. Marginal cost estimation ────────────────────────────────────────────
if [[ "$STAGE" == "mc" || "$STAGE" == "all" ]]; then
  divider; echo "[1-2] MC estimation  (1_2_mc_estimation.py)"
  divider
  python3 "$CODE/1_2_mc_estimation.py"
fi

# ── 2-0. Static equilibrium check ────────────────────────────────────────────
if [[ "$STAGE" == "check_static" || "$STAGE" == "all" ]]; then
  divider; echo "[2-0] Static equilibrium check  (2_0_check_static.py)"
  divider
  python3 "$CODE/2_0_check_static.py"
fi

# ── 2-1. Static (Shapley) decomposition — pooled 2015→2024 ───────────────────
if [[ "$STAGE" == "decomp_main" || "$STAGE" == "all" ]]; then
  divider; echo "[2-1] Pooled Shapley decomposition  (6_cross, linear Bertrand, 2015→2024)"
  divider
  # DECOMP_PRICE_FORM=linear matches the run that produced decomp_s4_final_byyear_*.
  # (The BLP β_log_price is used for demand; "linear" here refers to the
  # equilibrium-solver convention, not the BLP price variable.)
  DECOMP_BLOCKS_SPEC=6_cross \
  DECOMP_PRICE_FORM=linear \
  DECOMP_MODE=shapley \
  DECOMP_YEAR_END=2024 \
  BLP_INPUT_DIR=output/blp_essentials_v12 \
  DECOMP_OUTPUT_DIR=output/decomp_s4_final \
    python3 "$CODE/2_1_static_decomposition.py"
fi

# ── 2-1b. Static decomposition — year-by-year sweep (2016–2024) ──────────────
if [[ "$STAGE" == "decomp_byyear" || "$STAGE" == "all" ]]; then
  divider; echo "[2-1b] Year-by-year Shapley decomposition  (2016–2024)"
  divider
  for yr in 2016 2017 2018 2019 2020 2021 2022 2023 2024; do
    echo "  → $yr"
    DECOMP_BLOCKS_SPEC=6_cross \
    DECOMP_PRICE_FORM=linear \
    DECOMP_MODE=shapley \
    DECOMP_YEAR_END=$yr \
    BLP_INPUT_DIR=output/blp_essentials_v12 \
    DECOMP_OUTPUT_DIR=output/decomp_s4_final_byyear_$yr \
      python3 "$CODE/2_1_static_decomposition.py" \
      > /tmp/decomp_byyear_$yr.log 2>&1
  done
fi

# ── 3-1. Dynamic decomposition / forward simulation ──────────────────────────
if [[ "$STAGE" == "dynamic_sim" || "$STAGE" == "all" ]]; then
  divider; echo "[3-1] Dynamic decomposition / forward sim  (3_1_dynamic_decomposition.py)"
  divider
  N_DRAWS=50 python3 "$CODE/3_1_dynamic_decomposition.py"
fi

# ── 3-0. Dynamic equilibrium check  (after 3-1) ──────────────────────────────
if [[ "$STAGE" == "check_dynamic" || "$STAGE" == "all" ]]; then
  divider; echo "[3-0] Dynamic equilibrium check  (3_0_check_dynamic.py)"
  divider
  python3 "$CODE/3_0_check_dynamic.py"
fi

# ── 9-0. Summary statistics ───────────────────────────────────────────────────
if [[ "$STAGE" == "tables" || "$STAGE" == "all" ]]; then
  divider; echo "[9-0] Summary statistics  (9_0_summary_statistics.py)"
  divider
  python3 "$CODE/9_0_summary_statistics.py"
fi

# ── 9-1. Heterogeneity analysis ───────────────────────────────────────────────
if [[ "$STAGE" == "tables" || "$STAGE" == "all" ]]; then
  divider; echo "[9-1] Heterogeneity analysis  (9_1_heterogeneity.py)"
  divider
  python3 "$CODE/9_1_heterogeneity.py"
fi

# ── 9-2. Estimation tables ────────────────────────────────────────────────────
if [[ "$STAGE" == "tables" || "$STAGE" == "all" ]]; then
  divider; echo "[9-2] Estimation tables  (9_2_estimation_tables.py)"
  divider
  python3 "$CODE/9_2_estimation_tables.py"
fi

# ── 9-x. Paper figures (every figure referenced in draft.tex) ──────────────────
if [[ "$STAGE" == "figures" || "$STAGE" == "all" ]]; then
  divider; echo "[9-x] Generating paper figures"
  divider
  # Section 2 (Policy + EV growth)
  python3 "$CODE/9_2_subsidy_magnitude_fig.py"        # fig:subsidy
  python3 "$CODE/9_4_ev_progress_fig.py"              # fig:ev_progress (EV+GV panels)
  # Section 3 (Demand: BLP)
  python3 "$CODE/9_8_delta_distribution_fig.py"       # fig:delta_distribution
  python3 "$CODE/9_15_xi_distribution_fig.py"         # fig:xi_distribution
  # Section 4 (Supply: MC)
  python3 "$CODE/9_3_elasticity_markup_fig.py"        # fig:elasticity_elas / lerner
  python3 "$CODE/9_11_mc_distribution_fig.py"         # fig:mc_distribution
  python3 "$CODE/9_12_mc_unobs_distribution_fig.py"   # fig:mc_unobs_distribution
  # Section 5 (Shapley decomposition)
  python3 "$CODE/9_9_shapley_waterfall_fig.py"        # fig:waterfall (main)
  python3 "$CODE/9_16_sequential_ordering_fig.py"     # fig:ordering A,B
  python3 "$CODE/9_19_order_sensitivity_fig.py"       # fig:order_sensitivity
  python3 "$CODE/9_18_shapley_cumulative_combined_fig.py" # fig:shapley_cumulative_share, _qty
  python3 "$CODE/9_20_ev_range_trajectory_fig.py"     # fig:range_traj
  python3 "$CODE/9_32_tier_shapley.py"                # fig:shapley_by_tier + tab:shapley_by_tier
  # Section 6 (Counterfactuals)
  python3 "$CODE/9_5_subsidy_decomp_fig.py"           # fig:subsidy_equity_*
  python3 "$CODE/9_6_dynamic_quantity_fig.py"         # fig:dynamic_quantity_*
  python3 "$CODE/9_30_diffusion_lag.py"               # fig:diffusion_lag + tab:diffusion_lag
  # Appendix / diagnostics
  python3 "$CODE/9_3_firm_group_survival.py"          # tab:retention
  python3 "$CODE/9_4_welfare_direct_indirect.py"      # tab:channels (welfare CS decomp)
  python3 "$CODE/9_31_iv_diagnostics.py"              # tab:iv_diagnostics
fi

divider; echo "✓ Pipeline complete"; divider
