"""
9_16_sequential_ordering_fig.py
================================
Illustrates order-sensitivity of sequential decomposition.

Draws two waterfall charts using the *same* coalition_results.csv but
different block orderings, then compares with the Shapley average.

Seq A: Entry_qty first  → A_attrs captures almost everything
Seq B: Entry_qty last   → Entry_qty and Subsidy dominate

Output:
  report/memos/fig_seq_waterfall_A.pdf   (Entry_qty first)
  report/memos/fig_seq_waterfall_B.pdf   (Entry_qty last)
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = ["Arial Unicode MS", "DejaVu Sans"]
import matplotlib.pyplot as plt

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT  = f"{ROOT}/report/memos"
os.makedirs(OUT, exist_ok=True)

COLORS = {
    "A_attrs":   "#1f77b4",
    "Entry_qty": "#ff7f0e",
    "Battery":   "#2ca02c",
    "xi":        "#9467bd",
    "Subsidy":   "#d62728",
    "Income":    "#8c564b",
}
LABELS = {
    "A_attrs":   r"$A_\mathrm{attrs}$",
    "Entry_qty": r"Entry$_\mathrm{qty}$",
    "Battery":   "Battery",
    "xi":        r"$\xi$ demand",
    "Subsidy":   "Subsidy",
    "Income":    "Income",
}

# ── Load coalition results ────────────────────────────────────────────────────
df = pd.read_csv(f"{ROOT}/output/decomp_s4_final_byyear_2024/coalition_results.csv")
df["cset"] = df["coalition"].str.strip("{}").apply(
    lambda x: frozenset(x.split(",")) if x.strip() else frozenset())

def ev_share(blocks):
    mask = df["cset"] == frozenset(blocks)
    return float(df.loc[mask, "ev_share"].iloc[0])

ALL_BLOCKS = ["A_attrs", "Battery", "Subsidy", "Entry_qty", "xi", "Income"]
baseline = ev_share([])
final    = ev_share(ALL_BLOCKS)
total_pp = (final - baseline) * 100

# ── Sequential decomposition for a given ordering ─────────────────────────────
def seq_decomp(ordering):
    prev, result = [], {}
    for blk in ordering:
        curr = prev + [blk]
        result[blk] = ev_share(curr) - ev_share(prev)
        prev = curr
    return result

SEQ_A = ["Entry_qty", "A_attrs", "Battery", "Subsidy", "xi", "Income"]
SEQ_B = ["A_attrs",   "Battery", "Subsidy", "xi",     "Income", "Entry_qty"]

phi_A = seq_decomp(SEQ_A)
phi_B = seq_decomp(SEQ_B)

# Shapley values for comparison annotation
sh_csv = pd.read_csv(
    f"{ROOT}/output/decomp_s4_final_byyear_2024/shapley_decomposition.csv")
phi_sh = {r["block"]: r["shapley_ev_share"]
          for _, r in sh_csv.iterrows()
          if r["block"] not in ("BASELINE", "FINAL")}

# ── Plot a single sequential waterfall ───────────────────────────────────────
def plot_seq(phi, ordering, title, outpath_stem):
    x_labels = ["2015\nbaseline"] + [LABELS[b] for b in ordering] + ["2024\n(model)"]
    N  = len(x_labels)
    xs = np.arange(N)

    run = 0.0
    bottoms, heights, colors, hatches = [0.0], [0.0], ["white"], [""]

    for b in ordering:
        v = phi[b]
        if v >= 0:
            bottoms.append(run); heights.append(v)
        else:
            bottoms.append(run + v); heights.append(-v)
        colors.append(COLORS[b])
        hatches.append("" if v >= 0 else "///")
        run += v

    bottoms.append(0.0); heights.append(run)
    colors.append("#444444"); hatches.append("")

    fig, ax = plt.subplots(figsize=(11, 5.2))

    for i, (bot, h, c, hat) in enumerate(zip(bottoms, heights, colors, hatches)):
        ec = "black" if i in (0, N - 1) else "none"
        lw = 0.9   if i in (0, N - 1) else 0
        ax.bar(i, h, bottom=bot, color=c, edgecolor=ec, linewidth=lw,
               hatch=hat, alpha=0.85, width=0.68)

        if i == 0:
            ax.text(i, 0.006, f"2015 = {baseline*100:.2f}%",
                    ha="center", va="bottom", fontsize=10, color="#333")
        elif i == N - 1:
            ax.text(i, run + 0.005,
                    f"{run*100:.1f}%\n(2024 = {final*100:.2f}%)",
                    ha="center", va="bottom", fontsize=12, weight="bold")
        else:
            blk = ordering[i - 1]
            v   = phi[blk]
            v_sh = phi_sh.get(blk, 0)
            ypos = (bot + h + 0.004) if v >= 0 else (bot - 0.004)
            va_a = "bottom"           if v >= 0 else "top"
            # Primary: sequential value
            ax.text(i, ypos, f"{v*100:.1f}%",
                    ha="center", va=va_a, fontsize=12, weight="bold")
            # Secondary: Shapley in grey for comparison
            ax.text(i, ypos + (0.025 if v >= 0 else -0.025),
                    f"(Shapley: {v_sh*100:.1f}%)",
                    ha="center", va=va_a, fontsize=9, color="#777")

    # Reference line = total change
    ax.axhline(final - baseline, color="black", linestyle="--", linewidth=1.3,
               label=f"Total EV-share change 2015→2024 = {total_pp:.2f}%")

    # Connector lines
    run2 = 0.0
    for i, b in enumerate(ordering, start=1):
        ax.plot([i - 1 + 0.34, i - 0.34], [run2, run2],
                color="gray", linewidth=0.7, linestyle=":")
        run2 += phi[b]
    ax.plot([N - 2 + 0.34, N - 1 - 0.34], [run2, run2],
            color="gray", linewidth=0.7, linestyle=":")

    ax.axhline(0, color="black", linewidth=0.6)
    ax.set_xticks(xs)
    ax.set_xticklabels(x_labels, fontsize=12)
    ax.set_ylabel("EV-share change vs 2015 (%)", fontsize=12)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"{x*100:.0f}%"))
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", lw=0.5, alpha=0.3, color="gray")
    ax.tick_params(labelsize=11)
    ax.legend(loc="upper left", fontsize=11, frameon=True)

    ax.text(0.99, 0.03,
            "Solid = positive  |  Hatching = negative drag\n"
            "Grey italic = Shapley value (for comparison)",
            transform=ax.transAxes, ha="right", va="bottom", fontsize=7,
            bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#ccc", lw=0.5))

    plt.tight_layout()
    for ext in ("png", "pdf"):
        fp = f"{OUT}/{outpath_stem}.{ext}"
        fig.savefig(fp, dpi=200 if ext == "png" else 72, bbox_inches="tight")
        print(f"Saved → {fp}")
    plt.close()

# ── Generate both figures ─────────────────────────────────────────────────────
plot_seq(phi_A, SEQ_A,
         "Sequential decomposition A: Entry$_{qty}$ ordered first",
         "fig_seq_waterfall_A")

plot_seq(phi_B, SEQ_B,
         "Sequential decomposition B: Entry$_{qty}$ ordered last",
         "fig_seq_waterfall_B")

print()
print("=== Summary: order sensitivity ===")
print(f"{'Block':12s}  {'Seq A':>8s}  {'Seq B':>8s}  {'Shapley':>8s}")
print("-" * 44)
for b in ALL_BLOCKS:
    print(f"{b:12s}  {phi_A[b]*100:+8.2f}pp  {phi_B[b]*100:+8.2f}pp  "
          f"{phi_sh.get(b,0)*100:+8.2f}pp")
print(f"{'TOTAL':12s}  "
      f"{sum(phi_A.values())*100:+8.2f}pp  "
      f"{sum(phi_B.values())*100:+8.2f}pp  "
      f"{sum(phi_sh[b] for b in ALL_BLOCKS)*100:+8.2f}pp")
