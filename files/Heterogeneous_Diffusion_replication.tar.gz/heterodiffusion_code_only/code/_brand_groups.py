"""
Canonical brand-group classification used by BLP (03), Shapley (11),
and firm/segment/geographic decompositions (11b/11c/14).

Brands → Parent firms → 6 Groups:
  {BYD, Tesla, Trad. OEM, New Forces, Private National, Other}

Pulls FIRM_GROUPS + PARENT_MAP from the single source of truth so the
classification stays consistent across scripts. Apply to a DataFrame
column (Brand or Manufacturer) via `assign_firm_group()`.
"""
import pandas as pd

FIRM_GROUPS = {
    "比亚迪": "BYD",
    "特斯拉": "Tesla",
    # Traditional SOE OEMs
    "上汽集团": "Trad. OEM", "一汽集团": "Trad. OEM", "东风集团": "Trad. OEM",
    "长安集团": "Trad. OEM", "广汽集团": "Trad. OEM", "北汽集团": "Trad. OEM",
    "华晨集团": "Trad. OEM",
    # New Forces
    "蔚来": "New Forces", "理想汽车": "New Forces", "小鹏汽车": "New Forces",
    "零跑汽车": "New Forces", "哪吒汽车": "New Forces", "小米汽车": "New Forces",
    "威马汽车": "New Forces", "高合汽车": "New Forces", "爱驰汽车": "New Forces",
    # Private nationals
    "吉利集团": "Private National", "长城汽车": "Private National",
    "奇瑞集团": "Private National", "江淮汽车": "Private National",
    "赛力斯": "Private National",
}

PARENT_MAP = {
    "上汽大众": "上汽集团", "上汽大通": "上汽集团", "上汽通用": "上汽集团",
    "上汽通用五菱": "上汽集团", "上汽集团": "上汽集团",
    "智己汽车": "上汽集团", "飞凡汽车": "上汽集团",
    "一汽-大众": "一汽集团", "一汽丰田": "一汽集团", "一汽吉林": "一汽集团",
    "一汽红旗": "一汽集团", "一汽轿车": "一汽集团", "一汽马自达": "一汽集团",
    "天津一汽": "一汽集团",
    "东风汽车": "东风集团", "东风本田": "东风集团", "东风小康": "东风集团",
    "东风悦达起亚": "东风集团", "东风柳汽": "东风集团", "东风英菲尼迪": "东风集团",
    "东风裕隆": "东风集团", "东风雷诺": "东风集团",
    "岚图汽车": "东风集团", "神龙汽车": "东风集团", "郑州日产": "东风集团",
    "北京奔驰": "北汽集团", "北京汽车": "北汽集团", "北京汽车制造厂": "北汽集团",
    "北京现代": "北汽集团", "北汽瑞翔": "北汽集团", "北汽福田": "北汽集团",
    "福建戴姆勒": "北汽集团",
    "长安汽车": "长安集团", "长安标致雪铁龙": "长安集团", "长安福特": "长安集团",
    "长安铃木": "长安集团", "长安马自达": "长安集团",
    "阿维塔汽车": "长安集团", "凯翼汽车": "长安集团",
    "比亚迪汽车": "比亚迪", "腾势汽车": "比亚迪", "仰望汽车": "比亚迪",
    "吉利汽车": "吉利集团", "极氪汽车": "吉利集团", "极星汽车": "吉利集团",
    "领途汽车": "吉利集团", "沃尔沃汽车": "吉利集团", "路特斯汽车": "吉利集团",
    "智马达汽车": "吉利集团", "睿蓝汽车": "吉利集团",
    "长城汽车": "长城汽车",
    "广汽丰田": "广汽集团", "广汽本田": "广汽集团", "广汽乘用车": "广汽集团",
    "广汽埃安": "广汽集团", "广汽三菱": "广汽集团", "广汽吉奥": "广汽集团",
    "广汽菲克": "广汽集团", "合创汽车": "广汽集团",
    "奇瑞汽车": "奇瑞集团", "奇瑞捷豹路虎": "奇瑞集团", "观致汽车": "奇瑞集团",
    "华晨宝马": "华晨集团", "华晨汽车": "华晨集团",
    "江淮汽车": "江淮汽车",
    "江铃汽车": "江铃汽车", "江铃福特": "江铃汽车",
    "特斯拉": "特斯拉",
    "蔚来汽车": "蔚来", "理想汽车": "理想汽车", "小鹏汽车": "小鹏汽车",
    "零跑汽车": "零跑汽车", "小米汽车": "小米汽车", "赛力斯汽车": "赛力斯",
    "合众汽车": "哪吒汽车", "威马汽车": "威马汽车", "高合汽车": "高合汽车",
    "爱驰汽车": "爱驰汽车", "恒大汽车": "恒大汽车",
}

GROUP_ORDER = ["BYD", "Tesla", "Foreign/JV", "Trad. OEM", "New Forces", "Private National", "Other"]

# Foreign brands (defined by Brand column, NOT Manufacturer):
# Brand-level identification overrides PARENT_MAP for these 30 brand strings,
# because the JV parent (e.g., 上汽大众 → 上汽集团) wrongly classifies the
# brand-level consumer perception of "Volkswagen" as a Chinese SOE.
# This set captures consumer perception of "non-Chinese-domestic brand"
# regardless of current ownership (so MG, Volvo, Polestar, Lotus, Smart,
# Land Rover, Jaguar are all included even though they have Chinese ownership
# layers).
FOREIGN_BRANDS = {
    # German
    "大众", "奔驰", "宝马", "奥迪", "斯柯达", "MINI", "SMART", "Smart",
    # Japanese
    "丰田", "本田", "日产", "马自达", "三菱", "雷克萨斯", "讴歌", "英菲尼迪",
    # American
    "别克", "凯迪拉克", "雪佛兰", "福特", "林肯", "菲亚特",
    # Korean
    "现代", "起亚",
    # French
    "标致", "雪铁龙",
    # British (Chinese-owned but British heritage)
    "MG", "捷豹", "路虎", "路特斯",
    # Swedish (Chinese-owned but Swedish heritage)
    "沃尔沃", "极星",
}


def assign_firm_group(df: pd.DataFrame, src_col: str = "Manufacturer",
                      out_col: str = "firm_group") -> pd.DataFrame:
    """Return a copy of df with an added firm_group column.

    Logic:
        1. Map src_col (Manufacturer) via PARENT_MAP to a parent firm.
        2. Map parent firm via FIRM_GROUPS to one of 7 groups (default 'Other').
        3. OVERRIDE: rows whose Brand is in FOREIGN_BRANDS get re-classified
           to 'Foreign/JV' regardless of the manufacturer-side mapping. This
           captures consumer-perception of foreign brands sold via JV.
    """
    d = df.copy()
    d["_firm_id"] = d[src_col].map(PARENT_MAP).fillna(d[src_col])
    d[out_col] = d["_firm_id"].map(FIRM_GROUPS).fillna("Other")
    if "Brand" in d.columns:
        d.loc[d["Brand"].isin(FOREIGN_BRANDS), out_col] = "Foreign/JV"
    d.drop(columns="_firm_id", inplace=True)
    return d
