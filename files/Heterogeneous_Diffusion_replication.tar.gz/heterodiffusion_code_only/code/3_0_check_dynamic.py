"""
3_0_check_dynamic.py
====================

Stage 3-0: Dynamic equilibrium check.  Runs after 3_1_dynamic_decomposition.py
to verify that the simulated "actual" scenario (factored subsidy + factored
price) is consistent with observed year-by-year market share and price.

Checks per regime (exog_exog / exog_endo / endo_endo):

(A) EV share consistency: does sim "actual" ev_share match observed by year?
    PASS criterion: |pred − obs| ≤ 3 pp in each year.

(B) EV price consistency (from products file): does mean simulated EV sticker
    match observed mean EV sticker by year?
    PASS criterion: |pred − obs| / obs ≤ 10%.

Saves output/check_dynamic_equilibrium.csv.
"""
import os
import sys
import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

SHARE_TOL_PP = 3.0    # pp — acceptable gap between sim and observed EV share
PRICE_TOL    = 0.10   # relative — acceptable gap on mean EV sticker

print("=" * 78)
print("DYNAMIC EQUILIBRIUM CHECK  (Stage 3-0)")
print("=" * 78)

# ── Observed data ─────────────────────────────────────────────────────────────
df = pd.read_parquet("output/df.parquet")
df["ev"]  = df["FuelType"].isin(["BEV", "PHEV", "REEV"])
df["M_c"] = df["Population"] * 10000 / 2.62 / 5

obs_ev_share = (
    df.groupby("Year")
    .apply(lambda g: (g["shares"] * g["M_c"] * g["ev"]).sum()
                     / (g["shares"] * g["M_c"]).sum(), include_groups=False)
    .rename("obs_ev_share")
)

# Observed mean EV sticker (price + subsidy, 万元), quantity-weighted
if "total_subsidy_wan" in df.columns:
    df["sticker"] = df["price"] + df["total_subsidy_wan"]
else:
    df["sticker"] = df["price"]

obs_price_ev = (
    df[df["ev"]].groupby("Year")
    .apply(lambda g: (g["sticker"] * g["shares"] * g["M_c"]).sum()
                     / (g["shares"] * g["M_c"]).sum(), include_groups=False)
    .rename("obs_mean_sticker_ev")
)

print("\nObserved EV share by year:")
print(obs_ev_share.map("{:.4f}".format).to_string())

# ── Load simulation output ────────────────────────────────────────────────────
sim_agg  = pd.read_csv("output/dynamic_sim_v33_aggregated.csv")
sim_prod = pd.read_csv("output/dynamic_sim_v33_products.csv")

actual_agg  = sim_agg[sim_agg["scenario"] == "actual"].copy()
actual_prod = sim_prod[sim_prod["scenario"] == "actual"].copy()

all_rows = []

# ── (A) EV share by year × regime ────────────────────────────────────────────
print("\n" + "─" * 78)
print("(A) EV SHARE CONSISTENCY  (sim 'actual' vs observed)")
print("─" * 78)

for regime in sorted(actual_agg["regime"].unique()):
    sub = actual_agg[actual_agg["regime"] == regime]
    # If multiple draws (MC), use mean across draws
    yr_share = sub.groupby("Year")["ev_share_mean" if "ev_share_mean" in sub.columns
                                   else "ev_share"].mean()
    print(f"\n  Regime: {regime}")
    print(f"  {'Year':>6}  {'obs%':>7}  {'sim%':>7}  {'gap':>7}  status")
    all_pass = True
    for yr, obs in obs_ev_share.items():
        if yr not in yr_share.index:
            continue
        sim_val = yr_share[yr]
        gap_pp  = (sim_val - obs) * 100
        passed  = abs(gap_pp) <= SHARE_TOL_PP
        if not passed:
            all_pass = False
        print(f"  {yr:>6}  {obs*100:>6.2f}%  {sim_val*100:>6.2f}%  "
              f"{gap_pp:>+6.2f}pp  {'PASS' if passed else 'FAIL'}")
        all_rows.append(dict(check="ev_share", regime=regime, year=yr,
                             obs=obs, sim=sim_val, gap_pp=gap_pp,
                             passed=passed))
    print(f"  → Regime {regime}: {'ALL PASS' if all_pass else 'SOME FAIL'}")


# ── (B) Product-level price check ────────────────────────────────────────────
# Check that for products present in the sim, sim p_nat ≈ observed net price.
# (Aggregate comparisons are misleading because premium EVs are often dropped
#  by the sim's share-threshold exit, biasing the product mix downward.)
print("\n" + "─" * 78)
print("(B) PRODUCT-LEVEL PRICE CHECK  (sim p_nat vs observed net price per model)")
print("─" * 78)

if "p_nat" in actual_prod.columns and "Model" in actual_prod.columns:
    obs_price_mod = (
        df[df["ev"]].groupby(["Year", "Model"])
        .apply(
            lambda g: (g["price"] * g["shares"] * g["M_c"]).sum()
                      / (g["shares"] * g["M_c"]).sum(),
            include_groups=False,
        )
        .rename("obs_net")
        .reset_index()
    )

    merged = (
        actual_prod[actual_prod["ev_dummy"] == 1]
        .merge(obs_price_mod, on=["Year", "Model"], how="inner")
    )
    merged["gap_rel"] = (merged["p_nat"] - merged["obs_net"]) / merged["obs_net"]
    merged["passed"]  = merged["gap_rel"].abs() <= PRICE_TOL

    print(f"\n  {'Regime':<12}  {'Year':>6}  {'N matched':>10}  "
          f"{'med gap%':>9}  {'max |gap|%':>10}  {'PASS%':>7}")
    for (regime, yr), g in merged.groupby(["regime", "Year"]):
        med_gap  = g["gap_rel"].median() * 100
        max_gap  = g["gap_rel"].abs().max() * 100
        pct_pass = g["passed"].mean() * 100
        print(f"  {regime:<12}  {yr:>6}  {len(g):>10}  "
              f"{med_gap:>+8.1f}%  {max_gap:>9.1f}%  {pct_pass:>6.0f}%")
        all_rows.append(dict(check="ev_price_product", regime=regime, year=yr,
                             obs=g["obs_net"].mean(), sim=g["p_nat"].mean(),
                             gap_pp=med_gap, passed=(pct_pass >= 70)))
else:
    print("  (p_nat / Model columns not found in products file — skipping price check)")


# ── Summary ───────────────────────────────────────────────────────────────────
out = pd.DataFrame(all_rows)
out.to_csv("output/check_dynamic_equilibrium.csv", index=False)

share_rows = out[out["check"] == "ev_share"]
price_rows = out[out["check"] == "ev_price"]
n_share_pass = share_rows["passed"].sum() if len(share_rows) else 0
n_price_pass = price_rows["passed"].sum() if len(price_rows) else 0

print("\n" + "═" * 78)
print(f"Summary:  EV share  {n_share_pass}/{len(share_rows)} PASS "
      f"(tol ±{SHARE_TOL_PP:.0f}pp)")
if len(price_rows):
    print(f"          EV price  {n_price_pass}/{len(price_rows)} PASS "
          f"(tol ±{PRICE_TOL*100:.0f}%)")
print("Saved: output/check_dynamic_equilibrium.csv")
print("=" * 78)

# Factual convergence gate:
#   exog_exog uses observed product set → must reproduce exactly (solver check).
#   exog_endo / endo_endo use model-driven entry → warn but don't abort;
#   gaps reflect entry-model calibration, not equilibrium-solver failure.
exog_exog_rows = share_rows[share_rows["regime"] == "exog_exog"]
exog_exog_fail = len(exog_exog_rows) and exog_exog_rows["passed"].sum() < len(exog_exog_rows)
if exog_exog_fail:
    print("\nERROR: exog_exog factual EV-share check FAILED — solver not converging to factual.")
    sys.exit(1)

stoch_fail = share_rows[share_rows["regime"] != "exog_exog"]["passed"].sum() < \
             len(share_rows[share_rows["regime"] != "exog_exog"])
if stoch_fail:
    print("\nWARNING: endo_endo / exog_endo factual EV-share gaps exceed tolerance.")
    print("  This reflects entry-model calibration, not solver failure.")
    print("  Re-calibrate GAMMA_ENT or the hazard model to reduce gaps.")
