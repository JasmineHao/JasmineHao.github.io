"""
9_13_shapley_waterfall_qty_fig.py
===================================
Waterfall chart for the 2015 -> 2024 Shapley decomposition in EV QUANTITY
(millions of vehicles).

Converts the EV-share Shapley values from the canonical decomp CSV to absolute
EV volume by multiplying by the actual total auto market in 2024 (from df.parquet
shares x Population x M_PER_ROW).  This gives "how many 2024-market EVs does
each factor explain?"

Reads:  output/decomp_s4_final_byyear_2024/shapley_decomposition.csv
        output/df.parquet
Writes: report/memos/fig_shapley_waterfall_qty_2024_2026_06_15.png/.pdf
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = ["Arial Unicode MS", "DejaVu Sans"]
import matplotlib.pyplot as plt

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT  = f"{ROOT}/report/memos"
os.makedirs(OUT, exist_ok=True)

BLOCKS = ["A_attrs", "Entry_qty", "Battery", "xi", "Subsidy", "Income"]
LABELS = {
    "A_attrs":   r"$A_\mathrm{attrs}$",
    "Entry_qty": r"Entry$_\mathrm{qty}$",
    "Battery":   "Battery\n(Wright)",
    "xi":        r"$\xi$ demand",
    "Subsidy":   "Subsidy",
    "Income":    "Income",
}
COLORS = {
    "A_attrs":   "#1f77b4",
    "Entry_qty": "#ff7f0e",
    "Battery":   "#2ca02c",
    "xi":        "#9467bd",
    "Subsidy":   "#d62728",
    "Income":    "#8c564b",
}

M_PER_ROW = 21220   # cars per model unit, calibrated so total market ≈ 26M in 2024

# ── Market size in 2024 (model units x M_PER_ROW = real autos) ───────────────
df_raw = pd.read_parquet(f"{ROOT}/output/df.parquet")
df_raw["sales"] = df_raw["shares"] * df_raw["Population"]
total_2024 = float(df_raw[df_raw["Year"] == 2024]["sales"].sum()) * M_PER_ROW / 1e6  # millions

# ── Read Shapley (ev_share) and convert to quantity ────────────────────────────
csv_all  = pd.read_csv(f"{ROOT}/output/decomp_s4_final_byyear_2024/shapley_decomposition.csv")
sh       = csv_all[~csv_all["block"].isin(["BASELINE", "FINAL"])]
phi_share = {b: float(sh[sh["block"] == b]["shapley_ev_share"].values[0]) for b in BLOCKS}
phi_qty  = {b: phi_share[b] * total_2024 for b in BLOCKS}  # millions of EVs

lev_base  = float(csv_all[csv_all["block"] == "BASELINE"]["level_ev_share"].values[0])
lev_final = float(csv_all[csv_all["block"] == "FINAL"]["level_ev_share"].values[0])
obs_delta_qty = (lev_final - lev_base) * total_2024   # millions of EVs

# ── Waterfall order ───────────────────────────────────────────────────────────
blocks_pos = sorted([b for b in BLOCKS if phi_qty[b] > 0], key=lambda b: -phi_qty[b])
blocks_neg = sorted([b for b in BLOCKS if phi_qty[b] < 0], key=lambda b:  phi_qty[b])
ordered    = blocks_pos + blocks_neg

x_labels = ["2015\nbaseline"] + [LABELS[b] for b in ordered] + ["2024\n(model)"]
N  = len(x_labels)
xs = np.arange(N)

running     = 0.0
bar_bottoms = []
bar_heights = []
bar_colors  = []
bar_hatches = []

bar_bottoms.append(0.0); bar_heights.append(0.0)
bar_colors.append("white"); bar_hatches.append("")

for b in ordered:
    v = phi_qty[b]
    if v >= 0:
        bar_bottoms.append(running)
        bar_heights.append(v)
    else:
        bar_bottoms.append(running + v)
        bar_heights.append(-v)
    bar_colors.append(COLORS[b])
    bar_hatches.append("" if v >= 0 else "///")
    running += v

bar_bottoms.append(0.0)
bar_heights.append(running)
bar_colors.append("#444444")
bar_hatches.append("")

fig, ax = plt.subplots(figsize=(11, 5.8))

for i, (bot, h, c, hat) in enumerate(
        zip(bar_bottoms, bar_heights, bar_colors, bar_hatches)):
    ec = "black" if i in (0, N - 1) else "none"
    lw = 0.9 if i in (0, N - 1) else 0
    ax.bar(i, h, bottom=bot, color=c, edgecolor=ec, linewidth=lw,
           hatch=hat, alpha=0.85, width=0.68)

    if i == 0:
        ax.text(i, 0.05,
                f"2015 = {lev_base*100:.1f}% share\n({lev_base*total_2024:.2f}M EVs)",
                ha="center", va="bottom", fontsize=7, color="#333")
    elif i == N - 1:
        ax.text(i, running + 0.1,
                f"+{running:.1f}M EVs\n(2024 = {lev_final*100:.1f}% share)",
                ha="center", va="bottom", fontsize=9, weight="bold")
    else:
        v = phi_qty[ordered[i - 1]]
        ypos = bot + h + 0.06 if v >= 0 else bot - 0.06
        va   = "bottom"         if v >= 0 else "top"
        ax.text(i, ypos, f"{v:+.2f}M",
                ha="center", va=va, fontsize=9)

ax.axhline(obs_delta_qty, color="black", linestyle="--", linewidth=1.4,
           label=f"$\\Delta$ EV quantity 2015$\\to$2024 "
                 f"= $+${obs_delta_qty:.1f}M (in {total_2024:.0f}M-vehicle market)")

# Connector lines
run = 0.0
for i, b in enumerate(ordered, start=1):
    ax.plot([i - 1 + 0.34, i - 0.34], [run, run],
            color="gray", linewidth=0.7, linestyle=":")
    run += phi_qty[b]
ax.plot([N - 2 + 0.34, N - 1 - 0.34], [run, run],
        color="gray", linewidth=0.7, linestyle=":")

ax.axhline(0, color="black", linewidth=0.6)
ax.set_xticks(xs)
ax.set_xticklabels(x_labels, fontsize=9)
ax.set_ylabel("EV quantity contribution (millions of vehicles)", fontsize=10)
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"{x:+.1f}M"))
ax.spines[["top", "right"]].set_visible(False)
ax.grid(axis="y", lw=0.5, alpha=0.3, color="gray")
ax.tick_params(labelsize=8.5)
ax.legend(loc="upper left", fontsize=9.5, frameon=True)

ax.text(0.99, 0.03,
        "Solid fill = positive contribution\nHatching = negative drag",
        transform=ax.transAxes, ha="right", va="bottom", fontsize=7.5,
        bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#ccc", lw=0.5))

plt.tight_layout()
out_png = f"{OUT}/fig_shapley_waterfall_qty_2024_2026_06_15.png"
out_pdf = f"{OUT}/fig_shapley_waterfall_qty_2024_2026_06_15.pdf"
fig.savefig(out_png, dpi=200, bbox_inches="tight")
fig.savefig(out_pdf, bbox_inches="tight")
print(f"Saved -> {out_png}")
print(f"Saved -> {out_pdf}")
