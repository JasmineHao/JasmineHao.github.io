"""
9_10_shapley_cumulative_fig.py
==============================
Stacked-area cumulative Shapley decomposition, 2015 → 2024.
Positive blocks fill upward; negative blocks fill downward with hatching.
Observed Δ(EV share) overlaid as black line.

Reads:  output/decomp_s4_final_byyear_{YR}/shapley_decomposition.csv
Writes: report/memos/fig_shapley_cumulative_2026_06_15.png/.pdf
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = ["Arial Unicode MS", "DejaVu Sans"]
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT  = f"{ROOT}/report/memos"
os.makedirs(OUT, exist_ok=True)

YEARS  = list(range(2016, 2025))
BLOCKS = ["A_attrs", "Entry_qty", "Battery", "xi", "Subsidy", "Income"]
LABELS = {
    "A_attrs":   "Quality",
    "Entry_qty": "Variety",
    "Battery":   "Battery",
    "xi":        "Residual",
    "Subsidy":   "Subsidy",
    "Income":    "Market",
}
COLORS = {
    "A_attrs":   "#1f77b4",
    "Entry_qty": "#ff7f0e",
    "Battery":   "#2ca02c",
    "xi":        "#9467bd",
    "Subsidy":   "#d62728",
    "Income":    "#8c564b",
}

# ── Read Shapley per year ──────────────────────────────────────────────────────
rows = []
for yr in YEARS:
    csv = f"{ROOT}/output/decomp_s4_final_byyear_{yr}/shapley_decomposition.csv"
    if not os.path.exists(csv):
        print(f"missing: {csv}"); continue
    df_sh = pd.read_csv(csv)
    df_sh = df_sh[~df_sh["block"].isin(["BASELINE", "FINAL"])]
    rec = {"year": yr}
    for b in BLOCKS:
        v = df_sh[df_sh["block"] == b]["shapley_ev_share"]
        rec[b] = float(v.values[0]) if len(v) else np.nan
    rec["sum_signed"] = float(df_sh["shapley_ev_share"].sum())
    rows.append(rec)

df = pd.DataFrame(rows).set_index("year")
# Prepend 2015 = 0 so trajectory starts at baseline
_zero = {b: 0.0 for b in BLOCKS}
_zero["sum_signed"] = 0.0
df = pd.concat([pd.DataFrame([_zero], index=[2015]), df]).sort_index()

# ── Observed Δshare ────────────────────────────────────────────────────────────
raw = pd.read_parquet(f"{ROOT}/output/df.parquet")
raw["ev"] = raw["FuelType"].isin(["BEV", "PHEV", "REEV"]).astype(int)

def obs_share(yr):
    s = raw[raw["Year"] == yr]
    M = s["Population"] * 10000 / 2.62 / 5
    return float((s["shares"] * M * s["ev"]).sum() / (s["shares"] * M).sum())

obs_2015   = obs_share(2015)
yrs_full   = [2015] + YEARS
obs_delta  = np.array([obs_share(y) - obs_2015 for y in yrs_full])

# ── Build stacked bands ────────────────────────────────────────────────────────
yrs   = np.array(yrs_full)
N     = len(yrs)
pos_top = np.zeros(N)
neg_bot = np.zeros(N)
pos_bands = []   # (block, lo, hi)
neg_bands = []

for b in BLOCKS:
    v = df[b].values
    pos_v = np.where(v > 0, v, 0.0)
    neg_v = np.where(v < 0, v, 0.0)
    if pos_v.any():
        pos_bands.append((b, pos_top.copy(), pos_top + pos_v))
        pos_top = pos_top + pos_v
    if neg_v.any():
        neg_bands.append((b, neg_bot.copy(), neg_bot + neg_v))
        neg_bot = neg_bot + neg_v

# ── Draw ──────────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(12, 5.8))

for b, lo, hi in pos_bands:
    ax.fill_between(yrs, lo, hi, color=COLORS[b], alpha=0.82, linewidth=0,
                    label=LABELS[b])
for b, lo_base, hi_base in neg_bands:
    # hi_base is less negative (closer to 0); lo_base is more negative
    ax.fill_between(yrs, lo_base, hi_base, color=COLORS[b], alpha=0.82,
                    linewidth=0, hatch="///")

ax.plot(yrs, obs_delta, color="black", lw=2.6, marker="o", ms=5.5,
        markerfacecolor="white", markeredgewidth=1.8, zorder=6,
        label="Observed $\\Delta$ EV share")
ax.plot(yrs, df["sum_signed"].values, color="gray", lw=1.3,
        linestyle="--", marker="d", ms=4.5, zorder=5,
        label="$\\Sigma_b\\,\\phi_b$ (model closure)")

ax.axhline(0, color="black", linewidth=0.6)
ax.set_xlim(2015, 2024)
ax.set_xticks(yrs_full)
ax.set_xticklabels([str(y) for y in yrs_full], fontsize=11, rotation=30, ha="right")
ax.set_ylabel(r"Cumulative contribution to $\Delta$ EV share vs 2015 (%)", fontsize=12)
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"{x*100:.0f}%"))
ax.spines[["top", "right"]].set_visible(False)
ax.grid(axis="y", lw=0.5, alpha=0.3, color="gray")
ax.tick_params(labelsize=11)

# Legend: block patches (pos solid, neg hatched) + observed line + closure line
handles = []
for b in BLOCKS:
    v_2024 = df.loc[2024, b]
    pat = mpatches.Patch(fc=COLORS[b], alpha=0.82,
                         hatch=("///" if v_2024 < 0 else ""),
                         label=LABELS[b])
    handles.append(pat)
handles.append(Line2D([0], [0], color="black", lw=2.2, marker="o", ms=5,
                       markerfacecolor="white", markeredgewidth=1.6,
                       label="Observed $\\Delta$ share"))
handles.append(Line2D([0], [0], color="gray", lw=1.3, linestyle="--",
                       marker="d", ms=4, label="$\\Sigma_b\\,\\phi_b$"))
ax.legend(handles=handles, fontsize=11, frameon=True, loc="upper left",
          ncol=2, handlelength=1.5, labelspacing=0.4, borderpad=0.7)

plt.tight_layout()
out_png = f"{OUT}/fig_shapley_cumulative_2026_06_15.png"
out_pdf = f"{OUT}/fig_shapley_cumulative_2026_06_15.pdf"
fig.savefig(out_png, dpi=200, bbox_inches="tight")
fig.savefig(out_pdf, bbox_inches="tight")
print(f"Saved → {out_png}")
print(f"Saved → {out_pdf}")
