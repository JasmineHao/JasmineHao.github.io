"""
_rebuild_mc_decomposed.py
=========================
Rebuild output/mc_decomposed.parquet from the current S4 BLP outputs
(2026-06-12). Produces structural decomposition consistent with:
  • national_mc.parquet (S4 national-FOC mc backout)
  • diy_mc_ols_v12.csv  (γ coefficients from S4 mc OLS)

Schema (consumed by 2_decomposition.py build_coalition_mc):
  Model, FuelType, BodyType, Brand, Manufacturer, Year, is_ev,
  log_size, log_power_gv, log_ev_range,
  mc_observed, log_mc,
  mc_comp_char, mc_comp_battery_cap, mc_comp_learning, mc_comp_fe, xi_mc,
  battery_share_of_mc, wright_cost_2015, wright_cost_predicted,
  mc_decomposition_form

Identity (per row): mc_comp_char + mc_comp_battery_cap + mc_comp_learning
                  + mc_comp_fe  ≡  log(mc_observed).
This identity is what build_coalition_mc(∅) relies on so that, when all
toggles are off, the reconstructed mc equals the observed 2015 nat_mc; and
when all toggles are on, it equals observed 2024 nat_mc.

The decomposition:
  comp_char     = γ_size·log_size + γ_pow·log_power_gv + γ_range·log_ev_range
  comp_learning = γ_bat·bat_t·1[EV]                  (Wright cost-decline)
  comp_battery_cap = 0  (battery capacity not a separate OLS regressor)
  comp_fe       = residual = log(nat_mc) − above three
                ↑ absorbs Intercept + FT/BT/FG/Year FEs + xi^mc
"""
import os
import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

print("=" * 70)
print("Rebuild mc_decomposed.parquet from current S4 BLP outputs")
print("=" * 70)

nat_mc = pd.read_parquet("output/national_mc.parquet")
mc_ols = pd.read_csv("output/diy_mc_ols_v12.csv")
bat    = pd.read_csv("raw_data/battery_cost_bnef.csv")

ols = mc_ols.set_index("param")["estimate"]
gamma_logsize  = float(ols.get("log_size", 0.0))
gamma_logpower = float(ols.get("log_power_gv", 0.0))
gamma_logrange = float(ols.get("log_ev_range", 0.0))
gamma_batxev   = float(ols.get("bat_x_ev", 0.0))
intercept_ols  = float(ols.get("Intercept", 0.0))
print(f"OLS γ: log_size={gamma_logsize:+.4f}, log_power_gv={gamma_logpower:+.4f}, "
      f"log_ev_range={gamma_logrange:+.4f}, bat_x_ev={gamma_batxev:+.6f}, "
      f"intercept={intercept_ols:+.4f}")

bat_map = dict(zip(bat["year"], bat["battery_pack_usd_kwh"]))
WRIGHT_2015 = bat_map.get(2015, 373.0)

g = nat_mc.rename(columns={"mc_national": "mc_observed",
                            "price_national": "price_wtd",
                            "ev_dummy": "is_ev"}).copy()
g["is_ev"] = g["is_ev"].astype(int)
print(f"Loaded {len(g):,} national mc rows.")
# Some rows may have mc_observed <= 0 from FOC backout outliers. Clip to a
# very small positive level so log is defined; these will get a large negative
# log_mc and a correspondingly large mc_comp_fe; the identity still holds and
# downstream solver guards (mc_floor_rel) cap them.
g["mc_observed"] = g["mc_observed"].clip(lower=0.05)
g["log_mc"] = np.log(g["mc_observed"])

g["bat_kwh"] = g["Year"].map(bat_map)
if g["bat_kwh"].isna().any():
    fill = g["bat_kwh"].dropna().sort_values()
    g["bat_kwh"] = g["bat_kwh"].fillna(method="ffill").fillna(method="bfill")

g["mc_comp_char"] = (gamma_logsize  * g["log_size"]
                     + gamma_logpower * g["log_power_gv"]
                     + gamma_logrange * g["log_ev_range"])
g["mc_comp_learning"]    = gamma_batxev * g["bat_kwh"] * g["is_ev"].astype(float)
g["mc_comp_battery_cap"] = 0.0
g["mc_comp_fe"] = (g["log_mc"]
                   - g["mc_comp_char"]
                   - g["mc_comp_battery_cap"]
                   - g["mc_comp_learning"])

# Identity check
chk = (g["mc_comp_char"] + g["mc_comp_battery_cap"]
       + g["mc_comp_learning"] + g["mc_comp_fe"] - g["log_mc"]).abs().max()
print(f"Decomp identity residual max |Δ| = {chk:.2e} (must be 0)")
assert chk < 1e-10, f"Decomposition identity broken: {chk:.2e}"

# Wright diagnostic columns
g["wright_cost_2015"] = WRIGHT_2015
g["wright_cost_predicted"] = g["bat_kwh"]
g["battery_share_of_mc"] = np.where(
    g["is_ev"] == 1,
    g["mc_comp_learning"] / g["log_mc"].clip(lower=0.1),
    0.0,
)
g["mc_decomposition_form"] = "log"
g["xi_mc"] = 0.0  # ξ^mc absorbed into mc_comp_fe in this rebuild

keep_cols = [
    "Model", "FuelType", "BodyType", "Brand", "Manufacturer", "Year",
    "is_ev", "log_size", "log_power_gv", "log_ev_range",
    "mc_observed", "log_mc",
    "mc_comp_char", "mc_comp_battery_cap", "mc_comp_learning",
    "mc_comp_fe", "xi_mc",
    "battery_share_of_mc", "wright_cost_2015", "wright_cost_predicted",
    "mc_decomposition_form",
]
out = g[keep_cols].copy()
out.to_parquet("output/mc_decomposed.parquet")
print(f"\n✓ wrote output/mc_decomposed.parquet ({len(out):,} rows)")

# Per-year mean components for EVs (sanity print)
for yr in (2015, 2024):
    sub = out[(out.Year == yr) & (out.is_ev == 1)]
    print(f"  EV mean components ({yr}): "
          f"char={sub.mc_comp_char.mean():+.3f}, "
          f"learn={sub.mc_comp_learning.mean():+.3f}, "
          f"fe={sub.mc_comp_fe.mean():+.3f}, "
          f"log_mc={sub.log_mc.mean():+.3f}")
