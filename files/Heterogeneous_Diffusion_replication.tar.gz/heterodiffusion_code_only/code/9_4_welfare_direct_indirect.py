"""
9_4_welfare_direct_indirect.py
================================
Direct vs indirect welfare decomposition of the no-subsidy counterfactual
by city tier (T1 / NT1 / T2 / Rest).

Three scenarios at 2024:
  (a) actual                  : observed subsidy, observed battery cost
  (b) no_sub_obsbat (direct)  : subsidy removed, mc held at observed
  (c) no_sub_wright (total)   : subsidy removed, mc shifted by Wright's-Law
                                feedback (cf battery cost path)

Decomposition:
  ΔCS_total    = CS(actual) − CS(no_sub_wright)
  ΔCS_direct   = CS(actual) − CS(no_sub_obsbat)
  ΔCS_indirect = CS(no_sub_obsbat) − CS(no_sub_wright)

The direct channel isolates the subsidy-as-cash effect at observed mc; the
indirect channel is the additional CS loss that flows through the Wright
battery-cost feedback (counterfactual cumulative production → higher
battery cost → higher EV mc → higher equilibrium price).

Per-product national net prices for the (c) scenario come from the
deterministic exog_endo regime of dynamic_sim_v33_products.csv (matches
endo_endo on actual; pure Wright + endogenous-range channel).

Output:
  output/tab_welfare_direct_indirect_by_tier.csv
  report/memos/tab_welfare_direct_indirect.tex
"""
import os
import sys
import numpy as np
import pandas as pd

# Reuse the BLP CS routine from 9_1_heterogeneity (load essentials, build
# shares + CS the same way to ensure apples-to-apples comparison).

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT  = os.path.join(ROOT, "output")
NS   = 25
M_PER_ROW = 21220.0
YEAR_TARGET = 2024

# Wright-cf regime used for the indirect channel. exog_endo is deterministic
# (no MC draws) and captures Wright + endogenous-range FOC; endo_endo would
# add stochastic-entry noise on top.
REGIME_FOR_TOTAL = "exog_endo"

# ----------------------------------------------------------------------------
# Load BLP essentials
# ----------------------------------------------------------------------------
ess = np.load(f"{OUT}/blp_essentials_v12/blp_essentials.npz", allow_pickle=True)
PI_P     = float(ess["pi_price"])
SIGMA_EV = float(ess["sigma_diag"][1]) if len(ess["sigma_diag"]) > 1 else 0.0
beta_labels = list(ess["beta_labels"].astype(str))
# Path D canonical: log-price spec. β_log_price enters α_i = β + π·inc_inv.
BETA_PRICE = float(ess["beta"][beta_labels.index("log_price")])
delta_loaded = ess["delta"]
nu_attrs    = ess["nu_attrs_v12"]
inc_inv     = ess["income_inv_normed_v12"]
markets_blp = ess["markets_v12"].astype(str)
agent_w     = np.full(NS, 1.0 / NS)

print("=" * 70)
print("Direct vs indirect welfare decomposition")
print("=" * 70)
print(f"BLP θ: β_log_price={BETA_PRICE:+.4f}, π_price={PI_P:+.4f}, σ_ev={SIGMA_EV:+.3f}")

# ----------------------------------------------------------------------------
# Load df + mc_v33 (same as 9_1)
# ----------------------------------------------------------------------------
df = pd.read_parquet(f"{ROOT}/output/df.parquet")
df["log_power_gv"] = (1.0 - df["ev_dummy"]) * df["log_power"]

def _singleton_filter(d):
    out = d.copy()
    vs = [v for v in ["log_size", "Displacement", "electric_efficiency",
                      "FuelEfficiency", "log_ev_range"] if v in out.columns]
    grp = out.groupby("market_segement", sort=False)
    n = grp[vs[0]].transform("size")
    for v in vs:
        s = grp[v].transform("sum")
        out[f"{v}_iv_diff"] = np.abs(out[v] - np.where(n > 1, (s - out[v]) / (n - 1), np.nan))
    return out.dropna(subset=[f"{v}_iv_diff" for v in vs]).reset_index(drop=True)

df = _singleton_filter(df)
assert len(df) == len(delta_loaded), f"len mismatch: {len(df)} vs {len(delta_loaded)}"

delta_NET = delta_loaded - BETA_PRICE * df["log_price"].values

df["sticker"]     = df["price"] + df["total_subsidy_wan"].fillna(0)
df["subsidy_amt"] = df["total_subsidy_wan"].fillna(0)

mkt_to_blpidx = {m: list(markets_blp).index(m) for m in df["market_ids"].unique()
                 if m in markets_blp}

# ----------------------------------------------------------------------------
# Load Wright-cf prices from dyn sim (per Model × FuelType × Year)
# ----------------------------------------------------------------------------
sim = pd.read_csv(f"{OUT}/dynamic_sim_v33_products.csv")
sim_total = sim[(sim["Year"] == YEAR_TARGET)
                & (sim["regime"] == REGIME_FOR_TOTAL)
                & (sim["scenario"] == "no_subsidy")].copy()
# p_nat from sim is national net price under Wright-cf battery cost
sim_pnat = (sim_total.groupby(["Model", "FuelType"])
                      .agg(p_nat_cf=("p_nat", "mean"))
                      .reset_index())
print(f"\nWright-cf prices loaded for {len(sim_pnat):,} (Model, FuelType) cells "
      f"from regime '{REGIME_FOR_TOTAL}'")

# ----------------------------------------------------------------------------
# 2024 subsample
# ----------------------------------------------------------------------------
df24 = df[df["Year"] == YEAR_TARGET].reset_index(drop=False).rename(columns={"index": "orig_idx"})
df24 = df24.merge(sim_pnat, on=["Model", "FuelType"], how="left")
# Products not in sim (small ones that were filtered out): fall back to sticker
# under the total scenario (i.e., assume no Wright effect for them).
df24["p_nat_cf"] = df24["p_nat_cf"].fillna(df24["sticker"])
print(f"\n2024 sample: {len(df24):,} rows, {df24['market_ids'].nunique()} markets")
print(f"  Wright-cf mean Δ vs obs price (EVs only): "
      f"{(df24[df24.ev_dummy==1].p_nat_cf - df24[df24.ev_dummy==1].price).mean():+.3f}万元")


# ----------------------------------------------------------------------------
# BLP CS at the city level under arbitrary net-price vector
# ----------------------------------------------------------------------------
def shares_cs(df_m, net_price):
    """Compute share + per-market CS under given net-price vector.

    delta_NET is δ - β·log_price_obs; adding β·log(net) gives δ at the
    counterfactual net price.
    """
    bidx = mkt_to_blpidx.get(df_m["market_ids"].iloc[0])
    if bidx is None:
        return None, None
    inc_i  = inc_inv[bidx]
    nu_i   = nu_attrs[bidx, :, 0]
    rows   = df_m["orig_idx"].values
    delta0 = delta_NET[rows]
    ev_d   = df_m["ev_dummy"].values.astype(float)
    alpha_i = BETA_PRICE + PI_P * inc_i
    log_net = np.log(np.maximum(net_price, 1e-3))
    u = (delta0[:, None] + alpha_i[None, :] * log_net[:, None]
         + SIGMA_EV * np.outer(ev_d, nu_i))
    u_max = np.maximum(0.0, u.max(axis=0, keepdims=True))
    e  = np.exp(u - u_max)
    e0 = np.exp(-u_max[0])
    denom = e0 + e.sum(axis=0)
    s_ij = e / denom[None, :]
    s_j  = s_ij @ agent_w
    log_denom_i = np.log(np.maximum(denom, 1e-300)) + u_max.squeeze()
    cs_i = log_denom_i / np.maximum(np.abs(alpha_i), 1e-6)  # 10k yuan per agent
    cs_market = float(cs_i @ agent_w)
    return s_j, cs_market


# ----------------------------------------------------------------------------
# Compute the three scenarios per market
# ----------------------------------------------------------------------------
print("\nComputing per-market shares + CS under 3 scenarios...")
records = []
for m_id, df_m in df24.groupby("market_ids"):
    if m_id not in mkt_to_blpidx:
        continue
    # Net prices under each scenario
    p_actual = df_m["price"].values                # obs net (= sticker − subsidy)
    p_direct = df_m["sticker"].values              # subsidy removed at obs mc
    p_total  = df_m["p_nat_cf"].values             # subsidy removed at Wright mc
    s_a, cs_a = shares_cs(df_m, p_actual)
    s_d, cs_d = shares_cs(df_m, p_direct)
    s_t, cs_t = shares_cs(df_m, p_total)
    if s_a is None:
        continue
    pop = df_m["Population"].iloc[0]
    M_c = pop * M_PER_ROW
    ev_d = df_m["ev_dummy"].values
    records.append({
        "market_ids":         m_id,
        "Population":         pop,
        "M_c":                M_c,
        "ev_q_actual":        (s_a * ev_d).sum() * M_c,
        "ev_q_direct":        (s_d * ev_d).sum() * M_c,
        "ev_q_total":         (s_t * ev_d).sum() * M_c,
        "ev_share_actual":    (s_a * ev_d).sum() * 100,
        "ev_share_direct":    (s_d * ev_d).sum() * 100,
        "ev_share_total":     (s_t * ev_d).sum() * 100,
        "cs_actual_per_cap":  cs_a,
        "cs_direct_per_cap":  cs_d,
        "cs_total_per_cap":   cs_t,
    })

mkt = pd.DataFrame(records)
print(f"  Computed for {len(mkt)} markets")


# ----------------------------------------------------------------------------
# City tier assignment (matches 9_1_heterogeneity)
# ----------------------------------------------------------------------------
def _tier_from_market(m):
    cities_t1  = {"北京市", "上海市", "广州市", "深圳市"}
    cities_nt1 = {"成都市", "杭州市", "武汉市", "重庆市", "南京市", "天津市",
                  "苏州市", "西安市", "长沙市", "沈阳市", "青岛市", "郑州市",
                  "大连市", "东莞市", "宁波市"}
    city = m.split("-", 1)[1] if "-" in m else m
    if city in cities_t1:  return "T1"
    if city in cities_nt1: return "NT1"
    if "Other" in city:    return "Rest"
    return "T2"

mkt["tier"] = mkt["market_ids"].apply(_tier_from_market)

# CS in bn yuan: pop_万 × cs_per_cap (10k yuan/agent) × M_PER_ROW × 1e-5
_SCALE_TO_BN = M_PER_ROW * 1e-5
for sc in ["actual", "direct", "total"]:
    mkt[f"cs_{sc}_bn"] = mkt["Population"] * mkt[f"cs_{sc}_per_cap"] * _SCALE_TO_BN
mkt["delta_cs_total_bn"]    = mkt["cs_actual_bn"]  - mkt["cs_total_bn"]
mkt["delta_cs_direct_bn"]   = mkt["cs_actual_bn"]  - mkt["cs_direct_bn"]
mkt["delta_cs_indirect_bn"] = mkt["cs_direct_bn"]  - mkt["cs_total_bn"]


# ----------------------------------------------------------------------------
# Tier-level aggregation
# ----------------------------------------------------------------------------
def _pct_share(g):
    return g["delta_cs_indirect_bn"].sum() / g["delta_cs_total_bn"].sum() * 100

tier_summary = mkt.groupby("tier").apply(lambda g: pd.Series({
    "n_cities":            len(g),
    "pop_M":               g["Population"].sum() / 100,
    "cs_actual_bn":        g["cs_actual_bn"].sum(),
    "cs_direct_bn":        g["cs_direct_bn"].sum(),
    "cs_total_bn":         g["cs_total_bn"].sum(),
    "delta_total_bn":      g["delta_cs_total_bn"].sum(),
    "delta_direct_bn":     g["delta_cs_direct_bn"].sum(),
    "delta_indirect_bn":   g["delta_cs_indirect_bn"].sum(),
    "ev_q_actual_M":       g["ev_q_actual"].sum() / 1e6,
    "ev_q_direct_M":       g["ev_q_direct"].sum() / 1e6,
    "ev_q_total_M":        g["ev_q_total"].sum() / 1e6,
}), include_groups=False).reset_index()
tier_summary["per_cap_loss_yuan"] = -(tier_summary["delta_total_bn"] * 1e9
                                       / (tier_summary["pop_M"] * 1e6))
tier_summary["per_cap_direct_yuan"] = -(tier_summary["delta_direct_bn"] * 1e9
                                         / (tier_summary["pop_M"] * 1e6))
tier_summary["per_cap_indirect_yuan"] = -(tier_summary["delta_indirect_bn"] * 1e9
                                           / (tier_summary["pop_M"] * 1e6))
tier_summary["indirect_share_pct"]   = (tier_summary["delta_indirect_bn"]
                                         / tier_summary["delta_total_bn"]) * 100

# Order tiers
TIER_ORDER = ["T1", "NT1", "T2", "Rest"]
tier_summary["tier"] = pd.Categorical(tier_summary["tier"], TIER_ORDER, ordered=True)
tier_summary = tier_summary.sort_values("tier").reset_index(drop=True)

# Console print
print("\n" + "=" * 70)
print("CS by city tier — direct vs indirect channels (2024)")
print("=" * 70)
print(f"{'Tier':<6s} {'pop':>6s} {'CS_act':>8s} {'CS_dir':>8s} {'CS_tot':>8s} "
      f"{'ΔCS_tot':>9s} {'ΔCS_dir':>9s} {'ΔCS_ind':>9s} {'%Ind':>6s} {'/cap':>8s}")
for _, r in tier_summary.iterrows():
    print(f"{r['tier']:<6s} {r['pop_M']:>5.0f}M "
          f"{r['cs_actual_bn']:>7.1f} {r['cs_direct_bn']:>7.1f} {r['cs_total_bn']:>7.1f} "
          f"{r['delta_total_bn']:>+8.1f} {r['delta_direct_bn']:>+8.1f} {r['delta_indirect_bn']:>+8.1f} "
          f"{r['indirect_share_pct']:>5.1f}% {r['per_cap_loss_yuan']:>7.0f}")
total_row = {
    "tier": "TOTAL",
    "pop_M": tier_summary["pop_M"].sum(),
    "cs_actual_bn": tier_summary["cs_actual_bn"].sum(),
    "cs_direct_bn": tier_summary["cs_direct_bn"].sum(),
    "cs_total_bn":  tier_summary["cs_total_bn"].sum(),
    "delta_total_bn":    tier_summary["delta_total_bn"].sum(),
    "delta_direct_bn":   tier_summary["delta_direct_bn"].sum(),
    "delta_indirect_bn": tier_summary["delta_indirect_bn"].sum(),
}
total_row["indirect_share_pct"]   = total_row["delta_indirect_bn"] / total_row["delta_total_bn"] * 100
total_row["per_cap_loss_yuan"]    = -(total_row["delta_total_bn"] * 1e9
                                       / (total_row["pop_M"] * 1e6))
total_row["per_cap_direct_yuan"]  = -(total_row["delta_direct_bn"] * 1e9
                                       / (total_row["pop_M"] * 1e6))
total_row["per_cap_indirect_yuan"]= -(total_row["delta_indirect_bn"] * 1e9
                                       / (total_row["pop_M"] * 1e6))
print(f"{'NAT':<6s} {total_row['pop_M']:>5.0f}M "
      f"{total_row['cs_actual_bn']:>7.1f} {total_row['cs_direct_bn']:>7.1f} {total_row['cs_total_bn']:>7.1f} "
      f"{total_row['delta_total_bn']:>+8.1f} {total_row['delta_direct_bn']:>+8.1f} "
      f"{total_row['delta_indirect_bn']:>+8.1f} {total_row['indirect_share_pct']:>5.1f}% "
      f"{total_row['per_cap_loss_yuan']:>7.0f}")


# ----------------------------------------------------------------------------
# Outputs
# ----------------------------------------------------------------------------
csv_path = f"{OUT}/tab_welfare_direct_indirect_by_tier.csv"
tier_summary.to_csv(csv_path, index=False)
print(f"\nSaved → {csv_path}")

# LaTeX
def f_bn(x):  return f"{x:+,.1f}"
def f_bn0(x): return f"{x:,.1f}"
def f_cap(x): return f"{x:,.0f}"
def f_pct(x): return f"{x:.1f}\\%"

lines = []
lines.append(r"% Auto-generated by code/9_4_welfare_direct_indirect.py")
lines.append(r"")
lines.append(r"\begin{table}[H]")
lines.append(r"\centering")
lines.append(r"\footnotesize")
lines.append(r"\caption{Direct vs.\ indirect consumer-welfare effects of the no-subsidy counterfactual, by city tier}")
lines.append(r"\label{tab:welfare_direct_indirect}")
lines.append(r"\begin{tabular}{lrrrrrrr}")
lines.append(r"\toprule")
lines.append(r" & Pop & CS$_{\mathrm{actual}}$ & $\Delta$CS$_{\mathrm{total}}$ & $\Delta$CS$_{\mathrm{direct}}$ "
             r"& $\Delta$CS$_{\mathrm{indirect}}$ & Indirect & Per cap. \\")
lines.append(r"City tier & (M) & (bn) & (bn) & (bn) & (bn) & share & (yuan) \\")
lines.append(r"\midrule")
for _, r in tier_summary.iterrows():
    lines.append(
        f"{r['tier']} & {r['pop_M']:.0f} & {r['cs_actual_bn']:.1f} & "
        f"{r['delta_total_bn']:+.1f} & {r['delta_direct_bn']:+.1f} & "
        f"{r['delta_indirect_bn']:+.1f} & {r['indirect_share_pct']:.1f}\\% & "
        f"{r['per_cap_loss_yuan']:,.0f} \\\\"
    )
lines.append(r"\midrule")
lines.append(
    f"\\textbf{{National}} & {total_row['pop_M']:.0f} & {total_row['cs_actual_bn']:.1f} & "
    f"{total_row['delta_total_bn']:+.1f} & {total_row['delta_direct_bn']:+.1f} & "
    f"{total_row['delta_indirect_bn']:+.1f} & {total_row['indirect_share_pct']:.1f}\\% & "
    f"{total_row['per_cap_loss_yuan']:,.0f} \\\\"
)
lines.append(r"\bottomrule")
lines.append(r"\end{tabular}")
lines.append(r"")
lines.append(r"\vspace{4pt}")
lines.append(r"\begin{minipage}{\linewidth}")
lines.append(r"\footnotesize")
lines.append(
    r"\textit{Notes:} Consumer-surplus impact of removing the 2024 EV subsidy "
    r"package (cash + 10\% purchase-tax exemption), decomposed by city tier. "
    r"$\Delta$CS$_{\mathrm{direct}}$ holds counterfactual marginal cost at the "
    r"observed level, so the channel is the within-year price-elasticity "
    r"response only. $\Delta$CS$_{\mathrm{indirect}}$ is the additional CS "
    r"loss from the Wright's-Law feedback: reduced cumulative EV production "
    r"raises the counterfactual battery-cost path, which raises EV marginal "
    r"cost, which raises equilibrium price. Wright-counterfactual prices "
    f"come from the deterministic \\textit{{{REGIME_FOR_TOTAL}}} regime of "
    r"\texttt{dynamic\_sim\_v33\_products.csv} (Wright $+$ endogenous-range FOC, "
    r"no stochastic entry). Tier T1 covers Beijing, Shanghai, Guangzhou, "
    r"Shenzhen; NT1 covers 15 new first-tier cities; T2 covers the remaining "
    r"second-tier cities in the panel; ``Rest'' aggregates the small-city "
    r"residual cell."
)
lines.append(r"\end{minipage}")
lines.append(r"\end{table}")

tex_path = f"{ROOT}/report/memos/tab_welfare_direct_indirect.tex"
with open(tex_path, "w") as f:
    f.write("\n".join(lines) + "\n")
print(f"Saved → {tex_path}")
